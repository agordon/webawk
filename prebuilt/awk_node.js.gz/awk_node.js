try {
  this["Module"] = Module;
} catch (e) {
  this["Module"] = Module = {};
}
var ENVIRONMENT_IS_NODE = typeof process === "object";
var ENVIRONMENT_IS_WEB = typeof window === "object";
var ENVIRONMENT_IS_WORKER = typeof importScripts === "function";
var ENVIRONMENT_IS_SHELL = !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_NODE && !ENVIRONMENT_IS_WORKER;
if (ENVIRONMENT_IS_NODE) {
  Module["print"] = (function(x) {
    process["stdout"].write(x + "\n");
  });
  Module["printErr"] = (function(x) {
    process["stderr"].write(x + "\n");
  });
  var nodeFS = require("fs");
  var nodePath = require("path");
  Module["read"] = (function(filename) {
    filename = nodePath["normalize"](filename);
    var ret = nodeFS["readFileSync"](filename).toString();
    if (!ret && filename != nodePath["resolve"](filename)) {
      filename = path.join(__dirname, "..", "src", filename);
      ret = nodeFS["readFileSync"](filename).toString();
    }
    return ret;
  });
  Module["load"] = (function(f) {
    globalEval(read(f));
  });
  if (!Module["arguments"]) {
    Module["arguments"] = process["argv"].slice(2);
  }
}
if (ENVIRONMENT_IS_SHELL) {
  Module["print"] = print;
  if (typeof printErr != "undefined") Module["printErr"] = printErr;
  if (typeof read != "undefined") {
    Module["read"] = read;
  } else {
    Module["read"] = (function(f) {
      snarf(f);
    });
  }
  if (!Module["arguments"]) {
    if (typeof scriptArgs != "undefined") {
      Module["arguments"] = scriptArgs;
    } else if (typeof arguments != "undefined") {
      Module["arguments"] = arguments;
    }
  }
}
if (ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_WORKER) {
  if (!Module["print"]) {
    Module["print"] = (function(x) {
      console.log(x);
    });
  }
  if (!Module["printErr"]) {
    Module["printErr"] = (function(x) {
      console.log(x);
    });
  }
}
if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
  Module["read"] = (function(url) {
    var xhr = new XMLHttpRequest;
    xhr.open("GET", url, false);
    xhr.send(null);
    return xhr.responseText;
  });
  if (!Module["arguments"]) {
    if (typeof arguments != "undefined") {
      Module["arguments"] = arguments;
    }
  }
}
if (ENVIRONMENT_IS_WORKER) {
  var TRY_USE_DUMP = false;
  if (!Module["print"]) {
    Module["print"] = TRY_USE_DUMP && typeof dump !== "undefined" ? (function(x) {
      dump(x);
    }) : (function(x) {});
  }
  Module["load"] = importScripts;
}
if (!ENVIRONMENT_IS_WORKER && !ENVIRONMENT_IS_WEB && !ENVIRONMENT_IS_NODE && !ENVIRONMENT_IS_SHELL) {
  throw "Unknown runtime environment. Where are we?";
}
function globalEval(x) {
  eval.call(null, x);
}
if (!Module["load"] == "undefined" && Module["read"]) {
  Module["load"] = (function(f) {
    globalEval(Module["read"](f));
  });
}
if (!Module["print"]) {
  Module["print"] = (function() {});
}
if (!Module["printErr"]) {
  Module["printErr"] = Module["print"];
}
if (!Module["arguments"]) {
  Module["arguments"] = [];
}
Module.print = Module["print"];
Module.printErr = Module["printErr"];
if (!Module["preRun"]) Module["preRun"] = [];
if (!Module["postRun"]) Module["postRun"] = [];
var Runtime = {
  stackSave: (function() {
    return STACKTOP;
  }),
  stackRestore: (function(stackTop) {
    STACKTOP = stackTop;
  }),
  forceAlign: (function(target, quantum) {
    quantum = quantum || 4;
    if (quantum == 1) return target;
    if (isNumber(target) && isNumber(quantum)) {
      return Math.ceil(target / quantum) * quantum;
    } else if (isNumber(quantum) && isPowerOfTwo(quantum)) {
      var logg = log2(quantum);
      return "((((" + target + ")+" + (quantum - 1) + ")>>" + logg + ")<<" + logg + ")";
    }
    return "Math.ceil((" + target + ")/" + quantum + ")*" + quantum;
  }),
  isNumberType: (function(type) {
    return type in Runtime.INT_TYPES || type in Runtime.FLOAT_TYPES;
  }),
  isPointerType: function isPointerType(type) {
    return type[type.length - 1] == "*";
  },
  isStructType: function isStructType(type) {
    if (isPointerType(type)) return false;
    if (/^\[\d+\ x\ (.*)\]/.test(type)) return true;
    if (/<?{ ?[^}]* ?}>?/.test(type)) return true;
    return type[0] == "%";
  },
  INT_TYPES: {
    "i1": 0,
    "i8": 0,
    "i16": 0,
    "i32": 0,
    "i64": 0
  },
  FLOAT_TYPES: {
    "float": 0,
    "double": 0
  },
  bitshift64: (function(low, high, op, bits) {
    var ander = Math.pow(2, bits) - 1;
    if (bits < 32) {
      switch (op) {
       case "shl":
        return [ low << bits, high << bits | (low & ander << 32 - bits) >>> 32 - bits ];
       case "ashr":
        return [ (low >>> bits | (high & ander) << 32 - bits) >> 0 >>> 0, high >> bits >>> 0 ];
       case "lshr":
        return [ (low >>> bits | (high & ander) << 32 - bits) >>> 0, high >>> bits ];
      }
    } else if (bits == 32) {
      switch (op) {
       case "shl":
        return [ 0, low ];
       case "ashr":
        return [ high, (high | 0) < 0 ? ander : 0 ];
       case "lshr":
        return [ high, 0 ];
      }
    } else {
      switch (op) {
       case "shl":
        return [ 0, low << bits - 32 ];
       case "ashr":
        return [ high >> bits - 32 >>> 0, (high | 0) < 0 ? ander : 0 ];
       case "lshr":
        return [ high >>> bits - 32, 0 ];
      }
    }
    abort("unknown bitshift64 op: " + [ value, op, bits ]);
  }),
  or64: (function(x, y) {
    var l = x | 0 | (y | 0);
    var h = (Math.round(x / 4294967296) | Math.round(y / 4294967296)) * 4294967296;
    return l + h;
  }),
  and64: (function(x, y) {
    var l = (x | 0) & (y | 0);
    var h = (Math.round(x / 4294967296) & Math.round(y / 4294967296)) * 4294967296;
    return l + h;
  }),
  xor64: (function(x, y) {
    var l = (x | 0) ^ (y | 0);
    var h = (Math.round(x / 4294967296) ^ Math.round(y / 4294967296)) * 4294967296;
    return l + h;
  }),
  getNativeTypeSize: (function(type, quantumSize) {
    if (Runtime.QUANTUM_SIZE == 1) return 1;
    var size = {
      "%i1": 1,
      "%i8": 1,
      "%i16": 2,
      "%i32": 4,
      "%i64": 8,
      "%float": 4,
      "%double": 8
    }["%" + type];
    if (!size) {
      if (type.charAt(type.length - 1) == "*") {
        size = Runtime.QUANTUM_SIZE;
      } else if (type[0] == "i") {
        var bits = parseInt(type.substr(1));
        assert(bits % 8 == 0);
        size = bits / 8;
      }
    }
    return size;
  }),
  getNativeFieldSize: (function(type) {
    return Math.max(Runtime.getNativeTypeSize(type), Runtime.QUANTUM_SIZE);
  }),
  dedup: function dedup(items, ident) {
    var seen = {};
    if (ident) {
      return items.filter((function(item) {
        if (seen[item[ident]]) return false;
        seen[item[ident]] = true;
        return true;
      }));
    } else {
      return items.filter((function(item) {
        if (seen[item]) return false;
        seen[item] = true;
        return true;
      }));
    }
  },
  set: function set() {
    var args = typeof arguments[0] === "object" ? arguments[0] : arguments;
    var ret = {};
    for (var i = 0; i < args.length; i++) {
      ret[args[i]] = 0;
    }
    return ret;
  },
  calculateStructAlignment: function calculateStructAlignment(type) {
    type.flatSize = 0;
    type.alignSize = 0;
    var diffs = [];
    var prev = -1;
    type.flatIndexes = type.fields.map((function(field) {
      var size, alignSize;
      if (Runtime.isNumberType(field) || Runtime.isPointerType(field)) {
        size = Runtime.getNativeTypeSize(field);
        alignSize = size;
      } else if (Runtime.isStructType(field)) {
        size = Types.types[field].flatSize;
        alignSize = Types.types[field].alignSize;
      } else {
        throw "Unclear type in struct: " + field + ", in " + type.name_ + " :: " + dump(Types.types[type.name_]);
      }
      alignSize = type.packed ? 1 : Math.min(alignSize, Runtime.QUANTUM_SIZE);
      type.alignSize = Math.max(type.alignSize, alignSize);
      var curr = Runtime.alignMemory(type.flatSize, alignSize);
      type.flatSize = curr + size;
      if (prev >= 0) {
        diffs.push(curr - prev);
      }
      prev = curr;
      return curr;
    }));
    type.flatSize = Runtime.alignMemory(type.flatSize, type.alignSize);
    if (diffs.length == 0) {
      type.flatFactor = type.flatSize;
    } else if (Runtime.dedup(diffs).length == 1) {
      type.flatFactor = diffs[0];
    }
    type.needsFlattening = type.flatFactor != 1;
    return type.flatIndexes;
  },
  generateStructInfo: (function(struct, typeName, offset) {
    var type, alignment;
    if (typeName) {
      offset = offset || 0;
      type = (typeof Types === "undefined" ? Runtime.typeInfo : Types.types)[typeName];
      if (!type) return null;
      if (type.fields.length != struct.length) {
        printErr("Number of named fields must match the type for " + typeName + ": possibly duplicate struct names. Cannot return structInfo");
        return null;
      }
      alignment = type.flatIndexes;
    } else {
      var type = {
        fields: struct.map((function(item) {
          return item[0];
        }))
      };
      alignment = Runtime.calculateStructAlignment(type);
    }
    var ret = {
      __size__: type.flatSize
    };
    if (typeName) {
      struct.forEach((function(item, i) {
        if (typeof item === "string") {
          ret[item] = alignment[i] + offset;
        } else {
          var key;
          for (var k in item) key = k;
          ret[key] = Runtime.generateStructInfo(item[key], type.fields[i], alignment[i]);
        }
      }));
    } else {
      struct.forEach((function(item, i) {
        ret[item[1]] = alignment[i];
      }));
    }
    return ret;
  }),
  addFunction: (function(func) {
    var ret = FUNCTION_TABLE.length;
    FUNCTION_TABLE.push(func);
    FUNCTION_TABLE.push(0);
    return ret;
  }),
  warnOnce: (function(text) {
    if (!Runtime.warnOnce.shown) Runtime.warnOnce.shown = {};
    if (!Runtime.warnOnce.shown[text]) {
      Runtime.warnOnce.shown[text] = 1;
      Module.printErr(text);
    }
  }),
  funcWrappers: {},
  getFuncWrapper: (function(func) {
    if (!Runtime.funcWrappers[func]) {
      Runtime.funcWrappers[func] = (function() {
        FUNCTION_TABLE[func].apply(null, arguments);
      });
    }
    return Runtime.funcWrappers[func];
  }),
  UTF8Processor: (function() {
    var buffer = [];
    var needed = 0;
    this.processCChar = (function(code) {
      code = code & 255;
      if (needed) {
        buffer.push(code);
        needed--;
      }
      if (buffer.length == 0) {
        if (code < 128) return String.fromCharCode(code);
        buffer.push(code);
        if (code > 191 && code < 224) {
          needed = 1;
        } else {
          needed = 2;
        }
        return "";
      }
      if (needed > 0) return "";
      var c1 = buffer[0];
      var c2 = buffer[1];
      var c3 = buffer[2];
      var ret;
      if (c1 > 191 && c1 < 224) {
        ret = String.fromCharCode((c1 & 31) << 6 | c2 & 63);
      } else {
        ret = String.fromCharCode((c1 & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
      }
      buffer.length = 0;
      return ret;
    });
    this.processJSString = (function(string) {
      string = unescape(encodeURIComponent(string));
      var ret = [];
      for (var i = 0; i < string.length; i++) {
        ret.push(string.charCodeAt(i));
      }
      return ret;
    });
  }),
  stackAlloc: function stackAlloc(size) {
    var ret = STACKTOP;
    STACKTOP += size;
    STACKTOP = STACKTOP + 3 >> 2 << 2;
    return ret;
  },
  staticAlloc: function staticAlloc(size) {
    var ret = STATICTOP;
    STATICTOP += size;
    STATICTOP = STATICTOP + 3 >> 2 << 2;
    if (STATICTOP >= TOTAL_MEMORY) enlargeMemory();
    return ret;
  },
  alignMemory: function alignMemory(size, quantum) {
    var ret = size = Math.ceil(size / (quantum ? quantum : 4)) * (quantum ? quantum : 4);
    return ret;
  },
  makeBigInt: function makeBigInt(low, high, unsigned) {
    var ret = unsigned ? (low >>> 0) + (high >>> 0) * 4294967296 : (low >>> 0) + (high | 0) * 4294967296;
    return ret;
  },
  QUANTUM_SIZE: 4,
  __dummy__: 0
};
var CorrectionsMonitor = {
  MAX_ALLOWED: 0,
  corrections: 0,
  sigs: {},
  note: (function(type, succeed, sig) {
    if (!succeed) {
      this.corrections++;
      if (this.corrections >= this.MAX_ALLOWED) abort("\n\nToo many corrections!");
    }
  }),
  print: (function() {})
};
var __THREW__ = false;
var ABORT = false;
var undef = 0;
var tempValue, tempInt, tempBigInt, tempInt2, tempBigInt2, tempPair, tempBigIntI, tempBigIntR, tempBigIntS, tempBigIntP, tempBigIntD;
var tempI64, tempI64b;
function abort(text) {
  Module.print(text + ":\n" + (new Error).stack);
  ABORT = true;
  throw "Assertion: " + text;
}
function assert(condition, text) {
  if (!condition) {
    abort("Assertion failed: " + text);
  }
}
var globalScope = this;
function ccall(ident, returnType, argTypes, args) {
  var stack = 0;
  function toC(value, type) {
    if (type == "string") {
      if (value === null || value === undefined || value === 0) return 0;
      if (!stack) stack = Runtime.stackSave();
      var ret = Runtime.stackAlloc(value.length + 1);
      writeStringToMemory(value, ret);
      return ret;
    } else if (type == "array") {
      if (!stack) stack = Runtime.stackSave();
      var ret = Runtime.stackAlloc(value.length);
      writeArrayToMemory(value, ret);
      return ret;
    }
    return value;
  }
  function fromC(value, type) {
    if (type == "string") {
      return Pointer_stringify(value);
    }
    assert(type != "array");
    return value;
  }
  try {
    var func = eval("_" + ident);
  } catch (e) {
    try {
      func = globalScope["Module"]["_" + ident];
    } catch (e) {}
  }
  assert(func, "Cannot call unknown function " + ident + " (perhaps LLVM optimizations or closure removed it?)");
  var i = 0;
  var cArgs = args ? args.map((function(arg) {
    return toC(arg, argTypes[i++]);
  })) : [];
  var ret = fromC(func.apply(null, cArgs), returnType);
  if (stack) Runtime.stackRestore(stack);
  return ret;
}
Module["ccall"] = ccall;
function cwrap(ident, returnType, argTypes) {
  return (function() {
    return ccall(ident, returnType, argTypes, Array.prototype.slice.call(arguments));
  });
}
Module["cwrap"] = cwrap;
function setValue(ptr, value, type, noSafe) {
  type = type || "i8";
  if (type.charAt(type.length - 1) === "*") type = "i32";
  switch (type) {
   case "i1":
    HEAP8[ptr] = value;
    break;
   case "i8":
    HEAP8[ptr] = value;
    break;
   case "i16":
    HEAP16[ptr >> 1] = value;
    break;
   case "i32":
    HEAP32[ptr >> 2] = value;
    break;
   case "i64":
    tempI64 = [ value >>> 0, Math.min(Math.floor(value / 4294967296), 4294967295) ], HEAP32[ptr >> 2] = tempI64[0], HEAP32[ptr + 4 >> 2] = tempI64[1];
    break;
   case "float":
    HEAPF32[ptr >> 2] = value;
    break;
   case "double":
    tempDoubleF64[0] = value, HEAP32[ptr >> 2] = tempDoubleI32[0], HEAP32[ptr + 4 >> 2] = tempDoubleI32[1];
    break;
   default:
    abort("invalid type for setValue: " + type);
  }
}
Module["setValue"] = setValue;
function getValue(ptr, type, noSafe) {
  type = type || "i8";
  if (type.charAt(type.length - 1) === "*") type = "i32";
  switch (type) {
   case "i1":
    return HEAP8[ptr];
   case "i8":
    return HEAP8[ptr];
   case "i16":
    return HEAP16[ptr >> 1];
   case "i32":
    return HEAP32[ptr >> 2];
   case "i64":
    return HEAP32[ptr >> 2];
   case "float":
    return HEAPF32[ptr >> 2];
   case "double":
    return tempDoubleI32[0] = HEAP32[ptr >> 2], tempDoubleI32[1] = HEAP32[ptr + 4 >> 2], tempDoubleF64[0];
   default:
    abort("invalid type for setValue: " + type);
  }
  return null;
}
Module["getValue"] = getValue;
var ALLOC_NORMAL = 0;
var ALLOC_STACK = 1;
var ALLOC_STATIC = 2;
Module["ALLOC_NORMAL"] = ALLOC_NORMAL;
Module["ALLOC_STACK"] = ALLOC_STACK;
Module["ALLOC_STATIC"] = ALLOC_STATIC;
function allocate(slab, types, allocator) {
  var zeroinit, size;
  if (typeof slab === "number") {
    zeroinit = true;
    size = slab;
  } else {
    zeroinit = false;
    size = slab.length;
  }
  var singleType = typeof types === "string" ? types : null;
  var ret = [ _malloc, Runtime.stackAlloc, Runtime.staticAlloc ][allocator === undefined ? ALLOC_STATIC : allocator](Math.max(size, singleType ? 1 : types.length));
  if (zeroinit) {
    _memset(ret, 0, size);
    return ret;
  }
  var i = 0, type;
  while (i < size) {
    var curr = slab[i];
    if (typeof curr === "function") {
      curr = Runtime.getFunctionIndex(curr);
    }
    type = singleType || types[i];
    if (type === 0) {
      i++;
      continue;
    }
    if (type == "i64") type = "i32";
    setValue(ret + i, curr, type);
    i += Runtime.getNativeTypeSize(type);
  }
  return ret;
}
Module["allocate"] = allocate;
function Pointer_stringify(ptr, length) {
  var utf8 = new Runtime.UTF8Processor;
  var nullTerminated = typeof length == "undefined";
  var ret = "";
  var i = 0;
  var t;
  while (1) {
    t = HEAPU8[ptr + i];
    if (nullTerminated && t == 0) break;
    ret += utf8.processCChar(t);
    i += 1;
    if (!nullTerminated && i == length) break;
  }
  return ret;
}
Module["Pointer_stringify"] = Pointer_stringify;
function Array_stringify(array) {
  var ret = "";
  for (var i = 0; i < array.length; i++) {
    ret += String.fromCharCode(array[i]);
  }
  return ret;
}
Module["Array_stringify"] = Array_stringify;
var FUNCTION_TABLE;
var PAGE_SIZE = 4096;
function alignMemoryPage(x) {
  return x + 4095 >> 12 << 12;
}
var HEAP;
var HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
var STACK_ROOT, STACKTOP, STACK_MAX;
var STATICTOP;
function enlargeMemory() {
  abort("Cannot enlarge memory arrays. Adjust TOTAL_MEMORY (currently " + TOTAL_MEMORY + ") or compile with ALLOW_MEMORY_GROWTH");
}
var TOTAL_STACK = Module["TOTAL_STACK"] || 5242880;
var TOTAL_MEMORY = Module["TOTAL_MEMORY"] || 10485760;
var FAST_MEMORY = Module["FAST_MEMORY"] || 2097152;
assert(!!Int32Array && !!Float64Array && !!(new Int32Array(1))["subarray"] && !!(new Int32Array(1))["set"], "Cannot fallback to non-typed array case: Code is too specialized");
var buffer = new ArrayBuffer(TOTAL_MEMORY);
HEAP8 = new Int8Array(buffer);
HEAP16 = new Int16Array(buffer);
HEAP32 = new Int32Array(buffer);
HEAPU8 = new Uint8Array(buffer);
HEAPU16 = new Uint16Array(buffer);
HEAPU32 = new Uint32Array(buffer);
HEAPF32 = new Float32Array(buffer);
HEAPF64 = new Float64Array(buffer);
HEAP32[0] = 255;
assert(HEAPU8[0] === 255 && HEAPU8[3] === 0, "Typed arrays 2 must be run on a little-endian system");
Module["HEAP"] = HEAP;
Module["HEAP8"] = HEAP8;
Module["HEAP16"] = HEAP16;
Module["HEAP32"] = HEAP32;
Module["HEAPU8"] = HEAPU8;
Module["HEAPU16"] = HEAPU16;
Module["HEAPU32"] = HEAPU32;
Module["HEAPF32"] = HEAPF32;
Module["HEAPF64"] = HEAPF64;
STACK_ROOT = STACKTOP = Runtime.alignMemory(1);
STACK_MAX = STACK_ROOT + TOTAL_STACK;
var tempDoublePtr = Runtime.alignMemory(STACK_MAX, 8);
var tempDoubleI8 = HEAP8.subarray(tempDoublePtr);
var tempDoubleI32 = HEAP32.subarray(tempDoublePtr >> 2);
var tempDoubleF32 = HEAPF32.subarray(tempDoublePtr >> 2);
var tempDoubleF64 = HEAPF64.subarray(tempDoublePtr >> 3);
function copyTempFloat(ptr) {
  tempDoubleI8[0] = HEAP8[ptr];
  tempDoubleI8[1] = HEAP8[ptr + 1];
  tempDoubleI8[2] = HEAP8[ptr + 2];
  tempDoubleI8[3] = HEAP8[ptr + 3];
}
function copyTempDouble(ptr) {
  tempDoubleI8[0] = HEAP8[ptr];
  tempDoubleI8[1] = HEAP8[ptr + 1];
  tempDoubleI8[2] = HEAP8[ptr + 2];
  tempDoubleI8[3] = HEAP8[ptr + 3];
  tempDoubleI8[4] = HEAP8[ptr + 4];
  tempDoubleI8[5] = HEAP8[ptr + 5];
  tempDoubleI8[6] = HEAP8[ptr + 6];
  tempDoubleI8[7] = HEAP8[ptr + 7];
}
STACK_MAX = tempDoublePtr + 8;
STATICTOP = alignMemoryPage(STACK_MAX);
assert(STATICTOP < TOTAL_MEMORY);
var nullString = allocate(intArrayFromString("(null)"), "i8", ALLOC_STATIC);
function callRuntimeCallbacks(callbacks) {
  while (callbacks.length > 0) {
    var callback = callbacks.shift();
    var func = callback.func;
    if (typeof func === "number") {
      func = FUNCTION_TABLE[func];
    }
    func(callback.arg === undefined ? null : callback.arg);
  }
}
var __ATINIT__ = [];
var __ATMAIN__ = [];
var __ATEXIT__ = [];
function initRuntime() {
  callRuntimeCallbacks(__ATINIT__);
}
function preMain() {
  callRuntimeCallbacks(__ATMAIN__);
}
function exitRuntime() {
  callRuntimeCallbacks(__ATEXIT__);
  CorrectionsMonitor.print();
}
function String_len(ptr) {
  var i = ptr;
  while (HEAP8[i++]) {}
  return i - ptr - 1;
}
Module["String_len"] = String_len;
function intArrayFromString(stringy, dontAddNull, length) {
  var ret = (new Runtime.UTF8Processor).processJSString(stringy);
  if (length) {
    ret.length = length;
  }
  if (!dontAddNull) {
    ret.push(0);
  }
  return ret;
}
Module["intArrayFromString"] = intArrayFromString;
function intArrayToString(array) {
  var ret = [];
  for (var i = 0; i < array.length; i++) {
    var chr = array[i];
    if (chr > 255) {
      chr &= 255;
    }
    ret.push(String.fromCharCode(chr));
  }
  return ret.join("");
}
Module["intArrayToString"] = intArrayToString;
function writeStringToMemory(string, buffer, dontAddNull) {
  var array = intArrayFromString(string, dontAddNull);
  var i = 0;
  while (i < array.length) {
    var chr = array[i];
    HEAP8[buffer + i] = chr;
    i = i + 1;
  }
}
Module["writeStringToMemory"] = writeStringToMemory;
function writeArrayToMemory(array, buffer) {
  for (var i = 0; i < array.length; i++) {
    HEAP8[buffer + i] = array[i];
  }
}
Module["writeArrayToMemory"] = writeArrayToMemory;
var STRING_TABLE = [];
function unSign(value, bits, ignore, sig) {
  if (value >= 0) {
    return value;
  }
  return bits <= 32 ? 2 * Math.abs(1 << bits - 1) + value : Math.pow(2, bits) + value;
}
function reSign(value, bits, ignore, sig) {
  if (value <= 0) {
    return value;
  }
  var half = bits <= 32 ? Math.abs(1 << bits - 1) : Math.pow(2, bits - 1);
  if (value >= half && (bits <= 32 || value > half)) {
    value = -2 * half + value;
  }
  return value;
}
var runDependencies = 0;
var runDependencyTracking = {};
var calledRun = false;
var runDependencyWatcher = null;
function addRunDependency(id) {
  runDependencies++;
  if (Module["monitorRunDependencies"]) {
    Module["monitorRunDependencies"](runDependencies);
  }
  if (id) {
    assert(!runDependencyTracking[id]);
    runDependencyTracking[id] = 1;
    if (runDependencyWatcher === null && typeof setInterval !== "undefined") {
      runDependencyWatcher = setInterval((function() {
        var shown = false;
        for (var dep in runDependencyTracking) {
          if (!shown) {
            shown = true;
            Module.printErr("still waiting on run dependencies:");
          }
          Module.printErr("dependency: " + dep);
        }
        if (shown) {
          Module.printErr("(end of list)");
        }
      }), 6e3);
    }
  } else {
    Module.printErr("warning: run dependency added without ID");
  }
}
Module["addRunDependency"] = addRunDependency;
function removeRunDependency(id) {
  runDependencies--;
  if (Module["monitorRunDependencies"]) {
    Module["monitorRunDependencies"](runDependencies);
  }
  if (id) {
    assert(runDependencyTracking[id]);
    delete runDependencyTracking[id];
  } else {
    Module.printErr("warning: run dependency removed without ID");
  }
  if (runDependencies == 0) {
    if (runDependencyWatcher !== null) {
      clearInterval(runDependencyWatcher);
      runDependencyWatcher = null;
    }
    if (!calledRun) run();
  }
}
Module["removeRunDependency"] = removeRunDependency;
Module["preloadedImages"] = {};
Module["preloadedAudios"] = {};
function _fldinit() {
  _morefields();
  var $3 = HEAP32[HEAP32[_fldtab >> 2] >> 2];
  HEAP32[$3 >> 2] = HEAP32[_field0 >> 2];
  HEAP32[$3 + 4 >> 2] = HEAP32[_field0 + 4 >> 2];
  HEAP32[$3 + 8 >> 2] = HEAP32[_field0 + 8 >> 2];
  HEAP32[$3 + 12 >> 2] = HEAP32[_field0 + 12 >> 2];
  HEAP32[$3 + 16 >> 2] = HEAP32[_field0 + 16 >> 2];
  HEAP32[$3 + 20 >> 2] = HEAP32[_field0 + 20 >> 2];
  return;
}
function _setclvar($s) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $p_0 = $s;
    __label__ = 3;
    break;
   case 3:
    var $p_0;
    var $2 = HEAP8[$p_0];
    var $3 = $2 << 24 >> 24 == 61;
    var $4 = $p_0 + 1 | 0;
    if ($3) {
      __label__ = 4;
      break;
    } else {
      var $p_0 = $4;
      __label__ = 3;
      break;
    }
   case 4:
    HEAP8[$p_0] = 0;
    var $6 = _tostring($4);
    var $7 = _setsymtab($s, $6, 0, 1, _symtab | 0);
    _setsval($7, $4);
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $9 = _printf(STRING_TABLE.__str7 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $s, HEAP32[tempInt + 4 >> 2] = $4, tempInt));
    __label__ = 6;
    break;
   case 6:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _fldbld() {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_record >> 2];
    var $2 = HEAP32[_fields >> 2];
    var $3 = HEAP32[_FS >> 2];
    var $4 = HEAP32[$3 >> 2];
    var $5 = HEAP8[$4];
    var $phitmp5 = $5 << 24 >> 24 == 32;
    if ($phitmp5) {
      var $r_0_ph = $1;
      var $fr_0_ph = $2;
      var $i_0_ph = 0;
      __label__ = 3;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 3:
    var $i_0_ph;
    var $fr_0_ph;
    var $r_0_ph;
    var $r_0 = $r_0_ph;
    __label__ = 4;
    break;
   case 4:
    var $r_0;
    var $7 = HEAP8[$r_0];
    if ($7 << 24 >> 24 == 32 || $7 << 24 >> 24 == 9 || $7 << 24 >> 24 == 10) {
      __label__ = 5;
      break;
    } else if ($7 << 24 >> 24 == 0) {
      var $fr_5 = $fr_0_ph;
      var $i_2 = $i_0_ph;
      __label__ = 32;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $8 = $r_0 + 1 | 0;
    var $r_0 = $8;
    __label__ = 4;
    break;
   case 6:
    var $10 = $i_0_ph + 1 | 0;
    var $11 = HEAP32[_MAXFLD >> 2];
    var $12 = ($10 | 0) < ($11 | 0);
    if ($12) {
      __label__ = 8;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    _morefields();
    __label__ = 8;
    break;
   case 8:
    var $14 = HEAP32[_fldtab >> 2];
    var $15 = $14 + ($10 << 2) | 0;
    var $16 = HEAP32[$15 >> 2];
    var $17 = $16 + 16 | 0;
    var $18 = HEAP32[$17 >> 2];
    var $19 = $18 & 4;
    var $20 = ($19 | 0) == 0;
    if ($20) {
      __label__ = 9;
      break;
    } else {
      var $34 = $14;
      var $33 = $16;
      __label__ = 12;
      break;
    }
   case 9:
    var $22 = $16 + 4 | 0;
    var $23 = HEAP32[$22 >> 2];
    var $24 = ($23 | 0) == 0;
    var $25 = ($23 | 0) == (_EMPTY | 0);
    var $or_cond14 = $24 | $25;
    if ($or_cond14) {
      var $29 = $14;
      var $28 = $16;
      __label__ = 11;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    _free($23);
    var $_pre14 = HEAP32[_fldtab >> 2];
    var $_phi_trans_insert15 = $_pre14 + ($10 << 2) | 0;
    var $_pre16 = HEAP32[$_phi_trans_insert15 >> 2];
    var $29 = $_pre14;
    var $28 = $_pre16;
    __label__ = 11;
    break;
   case 11:
    var $28;
    var $29;
    var $30 = $29 + ($10 << 2) | 0;
    var $31 = $28 + 4 | 0;
    HEAP32[$31 >> 2] = _EMPTY | 0;
    var $_pre17 = HEAP32[$30 >> 2];
    var $34 = $29;
    var $33 = $_pre17;
    __label__ = 12;
    break;
   case 12:
    var $33;
    var $34;
    var $35 = $34 + ($10 << 2) | 0;
    var $36 = $33 + 4 | 0;
    HEAP32[$36 >> 2] = $fr_0_ph;
    var $37 = HEAP32[$35 >> 2];
    var $38 = $37 + 16 | 0;
    HEAP32[$38 >> 2] = 5;
    var $r_1 = $r_0;
    var $fr_1 = $fr_0_ph;
    var $n_0 = 1;
    __label__ = 13;
    break;
   case 13:
    var $n_0;
    var $fr_1;
    var $r_1;
    var $39 = $r_1 + 1 | 0;
    var $40 = HEAP8[$r_1];
    var $41 = $fr_1 + 1 | 0;
    HEAP8[$fr_1] = $40;
    var $42 = $n_0 - 1 | 0;
    var $43 = ($42 | 0) == 0;
    if ($43) {
      __label__ = 14;
      break;
    } else {
      var $r_1 = $39;
      var $fr_1 = $41;
      var $n_0 = $42;
      __label__ = 13;
      break;
    }
   case 14:
    var $45 = HEAP8[$39];
    var $46 = $45 & 255;
    if (($46 | 0) == 32 || ($46 | 0) == 10 || ($46 | 0) == 9 || ($46 | 0) == 0) {
      __label__ = 15;
      break;
    } else {
      var $r_1 = $39;
      var $fr_1 = $41;
      var $n_0 = 1;
      __label__ = 13;
      break;
    }
   case 15:
    var $47 = $fr_1 + 2 | 0;
    HEAP8[$41] = 0;
    var $r_0_ph = $39;
    var $fr_0_ph = $47;
    var $i_0_ph = $10;
    __label__ = 3;
    break;
   case 16:
    var $49 = HEAP8[$1];
    var $50 = $49 << 24 >> 24 == 0;
    if ($50) {
      var $fr_5 = $2;
      var $i_2 = 0;
      __label__ = 32;
      break;
    } else {
      var $r_2 = $1;
      var $fr_2 = $2;
      var $i_1 = 1;
      __label__ = 17;
      break;
    }
   case 17:
    var $i_1;
    var $fr_2;
    var $r_2;
    var $51 = HEAP32[_MAXFLD >> 2];
    var $52 = ($i_1 | 0) < ($51 | 0);
    if ($52) {
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    _morefields();
    __label__ = 19;
    break;
   case 19:
    var $54 = HEAP32[_fldtab >> 2];
    var $55 = $54 + ($i_1 << 2) | 0;
    var $56 = HEAP32[$55 >> 2];
    var $57 = $56 + 16 | 0;
    var $58 = HEAP32[$57 >> 2];
    var $59 = $58 & 4;
    var $60 = ($59 | 0) == 0;
    if ($60) {
      __label__ = 20;
      break;
    } else {
      var $74 = $54;
      var $73 = $56;
      __label__ = 23;
      break;
    }
   case 20:
    var $62 = $56 + 4 | 0;
    var $63 = HEAP32[$62 >> 2];
    var $64 = ($63 | 0) == 0;
    var $65 = ($63 | 0) == (_EMPTY | 0);
    var $or_cond = $64 | $65;
    if ($or_cond) {
      var $69 = $54;
      var $68 = $56;
      __label__ = 22;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    _free($63);
    var $_pre10 = HEAP32[_fldtab >> 2];
    var $_phi_trans_insert11 = $_pre10 + ($i_1 << 2) | 0;
    var $_pre12 = HEAP32[$_phi_trans_insert11 >> 2];
    var $69 = $_pre10;
    var $68 = $_pre12;
    __label__ = 22;
    break;
   case 22:
    var $68;
    var $69;
    var $70 = $69 + ($i_1 << 2) | 0;
    var $71 = $68 + 4 | 0;
    HEAP32[$71 >> 2] = _EMPTY | 0;
    var $_pre13 = HEAP32[$70 >> 2];
    var $74 = $69;
    var $73 = $_pre13;
    __label__ = 23;
    break;
   case 23:
    var $73;
    var $74;
    var $75 = $74 + ($i_1 << 2) | 0;
    var $76 = $73 + 4 | 0;
    HEAP32[$76 >> 2] = $fr_2;
    var $77 = HEAP32[$75 >> 2];
    var $78 = $77 + 16 | 0;
    HEAP32[$78 >> 2] = 5;
    var $r_3 = $r_2;
    var $fr_3 = $fr_2;
    __label__ = 25;
    break;
   case 24:
    var $scevgep46 = $r_3 + 1 | 0;
    var $r_3 = $scevgep46;
    var $fr_3 = $scevgep;
    __label__ = 25;
    break;
   case 25:
    var $fr_3;
    var $r_3;
    var $80 = HEAP8[$r_3];
    var $81 = $80 << 24 >> 24 == $5 << 24 >> 24;
    if ($81) {
      __label__ = 30;
      break;
    } else {
      __label__ = 26;
      break;
    }
   case 26:
    var $82 = $80 & 255;
    if (($82 | 0) == 10 || ($82 | 0) == 0) {
      __label__ = 30;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $scevgep = $fr_3 + 1 | 0;
    var $r_4 = $r_3;
    var $fr_4 = $fr_3;
    var $n_3 = 0;
    var $84 = $80;
    __label__ = 28;
    break;
   case 28:
    var $84;
    var $n_3;
    var $fr_4;
    var $r_4;
    var $85 = $r_4 + 1 | 0;
    HEAP8[$fr_4] = $84;
    var $86 = ($n_3 | 0) == 0;
    if ($86) {
      __label__ = 24;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    var $87 = $fr_4 + 1 | 0;
    var $_pre21 = HEAP8[$85];
    var $phitmp22 = $n_3 - 1 | 0;
    var $r_4 = $85;
    var $fr_4 = $87;
    var $n_3 = $phitmp22;
    var $84 = $_pre21;
    __label__ = 28;
    break;
   case 30:
    var $88 = $fr_3 + 1 | 0;
    HEAP8[$fr_3] = 0;
    var $89 = $80 << 24 >> 24 == 0;
    if ($89) {
      var $fr_5 = $88;
      var $i_2 = $i_1;
      __label__ = 32;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 31:
    var $91 = $r_3 + 1 | 0;
    var $phitmp = $i_1 + 1 | 0;
    var $r_2 = $91;
    var $fr_2 = $88;
    var $i_1 = $phitmp;
    __label__ = 17;
    break;
   case 32:
    var $i_2;
    var $fr_5;
    HEAP8[$fr_5] = 0;
    var $92 = HEAP32[_MAXFLD >> 2];
    var $j_037 = $92 - 1 | 0;
    var $93 = ($j_037 | 0) > ($i_2 | 0);
    if ($93) {
      __label__ = 33;
      break;
    } else {
      __label__ = 39;
      break;
    }
   case 33:
    var $_pre = HEAP32[_fldtab >> 2];
    var $j_038 = $j_037;
    var $94 = $_pre;
    __label__ = 34;
    break;
   case 34:
    var $94;
    var $j_038;
    var $95 = $94 + ($j_038 << 2) | 0;
    var $96 = HEAP32[$95 >> 2];
    var $97 = $96 + 16 | 0;
    var $98 = HEAP32[$97 >> 2];
    var $99 = $98 & 4;
    var $100 = ($99 | 0) == 0;
    if ($100) {
      __label__ = 35;
      break;
    } else {
      var $114 = $94;
      var $113 = $96;
      __label__ = 38;
      break;
    }
   case 35:
    var $102 = $96 + 4 | 0;
    var $103 = HEAP32[$102 >> 2];
    var $104 = ($103 | 0) == 0;
    var $105 = ($103 | 0) == (_EMPTY | 0);
    var $or_cond15 = $104 | $105;
    if ($or_cond15) {
      var $109 = $94;
      var $108 = $96;
      __label__ = 37;
      break;
    } else {
      __label__ = 36;
      break;
    }
   case 36:
    _free($103);
    var $_pre7 = HEAP32[_fldtab >> 2];
    var $_phi_trans_insert = $_pre7 + ($j_038 << 2) | 0;
    var $_pre8 = HEAP32[$_phi_trans_insert >> 2];
    var $109 = $_pre7;
    var $108 = $_pre8;
    __label__ = 37;
    break;
   case 37:
    var $108;
    var $109;
    var $110 = $109 + ($j_038 << 2) | 0;
    var $111 = $108 + 4 | 0;
    HEAP32[$111 >> 2] = _EMPTY | 0;
    var $_pre9 = HEAP32[$110 >> 2];
    var $114 = $109;
    var $113 = $_pre9;
    __label__ = 38;
    break;
   case 38:
    var $113;
    var $114;
    var $115 = $114 + ($j_038 << 2) | 0;
    var $116 = $113 + 16 | 0;
    HEAP32[$116 >> 2] = 5;
    var $117 = HEAP32[$115 >> 2];
    var $118 = $117 + 4 | 0;
    HEAP32[$118 >> 2] = _EMPTY | 0;
    var $j_0 = $j_038 - 1 | 0;
    var $119 = ($j_0 | 0) > ($i_2 | 0);
    if ($119) {
      var $j_038 = $j_0;
      var $94 = $114;
      __label__ = 34;
      break;
    } else {
      __label__ = 39;
      break;
    }
   case 39:
    HEAP32[_maxfld >> 2] = $i_2;
    HEAP8[_donefld_b] = 1;
    var $120 = ($i_2 | 0) < 1;
    if ($120) {
      __label__ = 44;
      break;
    } else {
      __label__ = 40;
      break;
    }
   case 40:
    var $_pre20 = HEAP32[_fldtab >> 2];
    var $i_335 = 1;
    __label__ = 41;
    break;
   case 41:
    var $i_335;
    var $121 = $_pre20 + ($i_335 << 2) | 0;
    var $122 = HEAP32[$121 >> 2];
    var $123 = $122 + 4 | 0;
    var $124 = HEAP32[$123 >> 2];
    var $125 = _isanumber($124);
    var $126 = ($125 | 0) == 0;
    if ($126) {
      __label__ = 43;
      break;
    } else {
      __label__ = 42;
      break;
    }
   case 42:
    var $128 = _atof($124);
    var $129 = $122 + 8 | 0;
    tempDoubleF64[0] = $128, HEAP32[$129 >> 2] = tempDoubleI32[0], HEAP32[$129 + 4 >> 2] = tempDoubleI32[1];
    var $130 = HEAP32[$121 >> 2];
    var $131 = $130 + 16 | 0;
    var $132 = HEAP32[$131 >> 2];
    var $133 = $132 | 2;
    HEAP32[$131 >> 2] = $133;
    __label__ = 43;
    break;
   case 43:
    var $135 = $i_335 + 1 | 0;
    var $136 = ($135 | 0) > ($i_2 | 0);
    if ($136) {
      __label__ = 44;
      break;
    } else {
      var $i_335 = $135;
      __label__ = 41;
      break;
    }
   case 44:
    var $137 = _lookup(STRING_TABLE.__str14344 | 0, _symtab | 0);
    var $138 = $i_2 | 0;
    _setfval($137, $138);
    var $_b = HEAP8[_dbg_b];
    var $139 = $_b ^ 1;
    var $140 = HEAP32[_maxfld >> 2];
    var $141 = ($140 | 0) < 0;
    var $or_cond50 = $141 | $139;
    if ($or_cond50) {
      __label__ = 46;
      break;
    } else {
      var $i_433 = 0;
      __label__ = 45;
      break;
    }
   case 45:
    var $i_433;
    var $142 = HEAP32[_fldtab >> 2];
    var $143 = $142 + ($i_433 << 2) | 0;
    var $144 = HEAP32[$143 >> 2];
    var $145 = $144 + 4 | 0;
    var $146 = HEAP32[$145 >> 2];
    var $147 = _printf(STRING_TABLE.__str9 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $i_433, HEAP32[tempInt + 4 >> 2] = $146, tempInt));
    var $148 = $i_433 + 1 | 0;
    var $149 = HEAP32[_maxfld >> 2];
    var $150 = ($148 | 0) > ($149 | 0);
    if ($150) {
      __label__ = 46;
      break;
    } else {
      var $i_433 = $148;
      __label__ = 45;
      break;
    }
   case 46:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_fldbld["X"] = 1;
function _growrec() {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_record >> 2];
    var $2 = HEAP32[_RECSIZE >> 2];
    var $3 = $2 + 129 | 0;
    var $4 = _realloc($1, $3);
    HEAP32[_record >> 2] = $4;
    var $5 = HEAP32[_fields >> 2];
    var $6 = HEAP32[_RECSIZE >> 2];
    var $7 = $6 + 129 | 0;
    var $8 = _realloc($5, $7);
    HEAP32[_fields >> 2] = $8;
    var $9 = HEAP32[_record >> 2];
    var $10 = ($9 | 0) == 0;
    var $11 = ($8 | 0) == 0;
    var $or_cond = $10 | $11;
    if ($or_cond) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $9, tempInt));
   case 4:
    var $14 = HEAP32[_fldtab >> 2];
    var $15 = HEAP32[$14 >> 2];
    var $16 = $15 + 4 | 0;
    HEAP32[$16 >> 2] = $9;
    var $17 = HEAP32[_recloc >> 2];
    var $18 = $17 + 4 | 0;
    HEAP32[$18 >> 2] = $9;
    var $19 = HEAP32[_RECSIZE >> 2];
    var $20 = $19 + 128 | 0;
    HEAP32[_RECSIZE >> 2] = $20;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _error($fmt) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 4;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $ap = __stackBase__;
    var $1 = $ap;
    HEAP32[$1 >> 2] = arguments[_error.length];
    var $2 = HEAP32[_stderr >> 2];
    var $3 = HEAP32[_progname >> 2];
    var $4 = _fprintf($2, STRING_TABLE.__str14 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $3, tempInt));
    var $5 = HEAP32[_stderr >> 2];
    var $6 = HEAP32[$ap >> 2];
    var $7 = _vfprintf($5, $fmt, $6);
    var $8 = HEAP32[_stderr >> 2];
    var $fputc = _fputc(10, $8);
    var $9 = HEAP32[_NR >> 2];
    var $10 = ($9 | 0) == 0;
    if ($10) {
      __label__ = 5;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $12 = (tempDoubleI32[0] = HEAP32[$9 >> 2], tempDoubleI32[1] = HEAP32[$9 + 4 >> 2], tempDoubleF64[0]);
    var $13 = $12 > 0;
    if ($13) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    var $15 = HEAP32[_stderr >> 2];
    var $16 = _fprintf($15, STRING_TABLE.__str16 | 0, (tempInt = STACKTOP, STACKTOP += 8, tempDoubleF64[0] = $12, HEAP32[tempInt >> 2] = tempDoubleI32[0], HEAP32[tempInt + 4 >> 2] = tempDoubleI32[1], tempInt));
    __label__ = 5;
    break;
   case 5:
    _exit(2);
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _morefields() {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_fldtab >> 2];
    var $2 = $1;
    var $3 = HEAP32[_MAXFLD >> 2];
    var $4 = $3 << 2;
    var $5 = $4 + 132 | 0;
    var $6 = _realloc($2, $5);
    var $7 = $6;
    HEAP32[_fldtab >> 2] = $7;
    var $8 = ($6 | 0) == 0;
    if ($8) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $10 = HEAP32[_record >> 2];
    _error(STRING_TABLE.__str19 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $10, tempInt));
   case 4:
    var $11 = HEAP32[_MAXFLD >> 2];
    var $i_01 = $11;
    __label__ = 5;
    break;
   case 5:
    var $i_01;
    var $13 = _malloc(24);
    var $14 = $13;
    var $15 = HEAP32[_fldtab >> 2];
    var $16 = $15 + ($i_01 << 2) | 0;
    HEAP32[$16 >> 2] = $14;
    var $17 = ($13 | 0) == 0;
    if ($17) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    var $19 = HEAP32[_record >> 2];
    _error(STRING_TABLE.__str19 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $19, tempInt));
   case 7:
    HEAP32[$13 >> 2] = HEAP32[_FINIT >> 2];
    HEAP32[$13 + 4 >> 2] = HEAP32[_FINIT + 4 >> 2];
    HEAP32[$13 + 8 >> 2] = HEAP32[_FINIT + 8 >> 2];
    HEAP32[$13 + 12 >> 2] = HEAP32[_FINIT + 12 >> 2];
    HEAP32[$13 + 16 >> 2] = HEAP32[_FINIT + 16 >> 2];
    HEAP32[$13 + 20 >> 2] = HEAP32[_FINIT + 20 >> 2];
    var $21 = $i_01 + 1 | 0;
    var $22 = HEAP32[_MAXFLD >> 2];
    var $23 = $22 + 32 | 0;
    var $24 = ($21 | 0) < ($23 | 0);
    if ($24) {
      var $i_01 = $21;
      __label__ = 5;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    HEAP32[_MAXFLD >> 2] = $23;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _getrec() {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_b3 = HEAP8[_dbg_b];
    if ($_b3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $2 = HEAP32[_RS >> 2];
    var $3 = HEAP32[$2 >> 2];
    var $4 = HEAP8[$3];
    var $5 = $4 << 24 >> 24;
    var $6 = HEAP32[_FS >> 2];
    var $7 = HEAP32[$6 >> 2];
    var $8 = HEAP8[$7];
    var $9 = $8 << 24 >> 24;
    var $10 = _printf(STRING_TABLE.__str1 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $5, HEAP32[tempInt + 4 >> 2] = $9, tempInt));
    __label__ = 4;
    break;
   case 4:
    HEAP8[_donefld_b] = 0;
    HEAP8[_donerec_b] = 1;
    var $12 = HEAP32[_record >> 2];
    HEAP8[$12] = 0;
    var $_pr = HEAP32[_svargc >> 2];
    var $13 = $_pr;
    __label__ = 5;
    break;
   case 5:
    var $13;
    var $14 = ($13 | 0) > 0;
    if ($14) {
      __label__ = 6;
      break;
    } else {
      var $_0 = 0;
      __label__ = 47;
      break;
    }
   case 6:
    var $_b2 = HEAP8[_dbg_b];
    if ($_b2) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $17 = HEAP32[_svargv >> 2];
    var $18 = HEAP32[$17 >> 2];
    var $19 = _printf(STRING_TABLE.__str2 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $13, HEAP32[tempInt + 4 >> 2] = $18, tempInt));
    __label__ = 8;
    break;
   case 8:
    var $20 = HEAP32[_infile >> 2];
    var $21 = ($20 | 0) == 0;
    if ($21) {
      __label__ = 9;
      break;
    } else {
      var $53 = $20;
      __label__ = 19;
      break;
    }
   case 9:
    var $23 = HEAP32[_svargv >> 2];
    var $24 = HEAP32[$23 >> 2];
    var $25 = _member($24);
    var $26 = ($25 | 0) == 0;
    if ($26) {
      __label__ = 11;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    _setclvar($24);
    var $28 = HEAP32[_svargv >> 2];
    var $29 = $28 + 4 | 0;
    HEAP32[_svargv >> 2] = $29;
    var $30 = HEAP32[_svargc >> 2];
    var $31 = $30 - 1 | 0;
    HEAP32[_svargc >> 2] = $31;
    var $13 = $31;
    __label__ = 5;
    break;
   case 11:
    HEAP32[_file >> 2] = $24;
    var $33 = HEAP32[_FILENAME >> 2];
    HEAP32[$33 >> 2] = $24;
    var $_b1 = HEAP8[_dbg_b];
    if ($_b1) {
      __label__ = 12;
      break;
    } else {
      var $37 = $24;
      __label__ = 13;
      break;
    }
   case 12:
    var $35 = _printf(STRING_TABLE.__str3 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $24, tempInt));
    var $_pre = HEAP32[_file >> 2];
    var $37 = $_pre;
    __label__ = 13;
    break;
   case 13:
    var $37;
    var $38 = HEAP8[$37];
    var $39 = $38 << 24 >> 24 == 45;
    if ($39) {
      __label__ = 14;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 14:
    var $41 = HEAP32[_yyin >> 2];
    var $42 = HEAP32[_stdin >> 2];
    var $43 = ($41 | 0) != ($42 | 0);
    var $44 = HEAP32[_lexprog >> 2];
    var $45 = ($44 | 0) != 0;
    var $or_cond = $43 | $45;
    if ($or_cond) {
      __label__ = 16;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    _error(STRING_TABLE.__str4 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 16:
    HEAP32[_infile >> 2] = $42;
    var $53 = $42;
    __label__ = 19;
    break;
   case 17:
    var $49 = _fopen($37, STRING_TABLE.__str5137 | 0);
    HEAP32[_infile >> 2] = $49;
    var $50 = ($49 | 0) == 0;
    if ($50) {
      __label__ = 18;
      break;
    } else {
      var $53 = $49;
      __label__ = 19;
      break;
    }
   case 18:
    var $52 = HEAP32[_file >> 2];
    _error(STRING_TABLE.__str6138 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $52, tempInt));
   case 19:
    var $53;
    var $54 = HEAP32[_RS >> 2];
    var $55 = HEAP32[$54 >> 2];
    var $56 = HEAP8[$55];
    var $57 = $56 << 24 >> 24;
    var $58 = $56 << 24 >> 24 == 0;
    var $sep_0 = $58 ? 10 : $57;
    var $59 = HEAP32[_record >> 2];
    var $rr_0 = $59;
    var $60 = $53;
    __label__ = 20;
    break;
   case 20:
    var $60;
    var $rr_0;
    var $61 = _getc($60);
    var $62 = ($61 | 0) == ($sep_0 | 0);
    var $63 = ($61 | 0) == -1;
    var $or_cond5 = $62 | $63;
    if ($or_cond5) {
      __label__ = 25;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $65 = HEAP32[_record >> 2];
    var $66 = HEAP32[_RECSIZE >> 2];
    var $_sum4 = $66 - 4 | 0;
    var $67 = $65 + $_sum4 | 0;
    var $68 = $rr_0 >>> 0 < $67 >>> 0;
    if ($68) {
      var $rr_1 = $rr_0;
      __label__ = 23;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    var $70 = $rr_0;
    var $71 = $65;
    var $72 = $70 - $71 | 0;
    _growrec();
    var $73 = HEAP32[_record >> 2];
    var $74 = $73 + $72 | 0;
    var $rr_1 = $74;
    __label__ = 23;
    break;
   case 23:
    var $rr_1;
    var $76 = $61 & 255;
    var $77 = $rr_1 + 1 | 0;
    HEAP8[$rr_1] = $76;
    var $rr_0_be = $77;
    __label__ = 24;
    break;
   case 24:
    var $rr_0_be;
    var $_pre5 = HEAP32[_infile >> 2];
    var $rr_0 = $rr_0_be;
    var $60 = $_pre5;
    __label__ = 20;
    break;
   case 25:
    if ($63) {
      var $rr_3 = $rr_0;
      var $c_1 = -1;
      __label__ = 35;
      break;
    } else {
      var $c_0 = $61;
      var $m_0 = 1;
      __label__ = 26;
      break;
    }
   case 26:
    var $m_0;
    var $c_0;
    var $78 = ($m_0 | 0) < 1;
    if ($78) {
      __label__ = 27;
      break;
    } else {
      var $rr_3 = $rr_0;
      var $c_1 = $c_0;
      __label__ = 35;
      break;
    }
   case 27:
    var $80 = HEAP32[_infile >> 2];
    var $81 = _getc($80);
    var $82 = ($81 | 0) == -1;
    if ($82) {
      __label__ = 29;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 28:
    var $84 = HEAP32[_RS >> 2];
    var $85 = HEAP32[$84 >> 2];
    var $86 = $85 + $m_0 | 0;
    var $87 = HEAP8[$86];
    var $88 = $87 << 24 >> 24;
    var $89 = ($81 | 0) == ($88 | 0);
    if ($89) {
      __label__ = 34;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    var $90 = ($m_0 | 0) > 0;
    if ($90) {
      __label__ = 30;
      break;
    } else {
      var $rr_2_lcssa = $rr_0;
      __label__ = 32;
      break;
    }
   case 30:
    var $lftr_limit = $rr_0 + $m_0 | 0;
    var $_pre6 = HEAP32[_RS >> 2];
    var $k_013 = 0;
    var $rr_214 = $rr_0;
    __label__ = 31;
    break;
   case 31:
    var $rr_214;
    var $k_013;
    var $92 = HEAP32[$_pre6 >> 2];
    var $93 = $92 + $k_013 | 0;
    var $94 = HEAP8[$93];
    var $95 = $rr_214 + 1 | 0;
    HEAP8[$rr_214] = $94;
    var $96 = $k_013 + 1 | 0;
    var $exitcond = ($95 | 0) == ($lftr_limit | 0);
    if ($exitcond) {
      var $rr_2_lcssa = $lftr_limit;
      __label__ = 32;
      break;
    } else {
      var $k_013 = $96;
      var $rr_214 = $95;
      __label__ = 31;
      break;
    }
   case 32:
    var $rr_2_lcssa;
    if ($82) {
      var $rr_3 = $rr_2_lcssa;
      var $c_1 = -1;
      __label__ = 35;
      break;
    } else {
      __label__ = 33;
      break;
    }
   case 33:
    var $98 = $81 & 255;
    var $99 = $rr_2_lcssa + 1 | 0;
    HEAP8[$rr_2_lcssa] = $98;
    var $rr_0_be = $99;
    __label__ = 24;
    break;
   case 34:
    var $101 = $m_0 + 1 | 0;
    var $c_0 = $81;
    var $m_0 = $101;
    __label__ = 26;
    break;
   case 35:
    var $c_1;
    var $rr_3;
    var $102 = HEAP32[_RS >> 2];
    var $103 = HEAP32[$102 >> 2];
    var $104 = HEAP8[$103];
    var $105 = $104 << 24 >> 24;
    var $106 = ($105 | 0) == ($sep_0 | 0);
    var $107 = ($c_1 | 0) == -1;
    var $or_cond6 = $106 | $107;
    if ($or_cond6) {
      var $c_2 = $c_1;
      __label__ = 40;
      break;
    } else {
      __label__ = 36;
      break;
    }
   case 36:
    var $109 = HEAP32[_infile >> 2];
    var $110 = _getc($109);
    if (($110 | 0) == 10 || ($110 | 0) == -1) {
      var $c_2 = $110;
      __label__ = 40;
      break;
    } else {
      __label__ = 37;
      break;
    }
   case 37:
    var $112 = HEAP32[_record >> 2];
    var $113 = HEAP32[_RECSIZE >> 2];
    var $_sum2 = $113 - 4 | 0;
    var $114 = $112 + $_sum2 | 0;
    var $115 = $rr_3 >>> 0 < $114 >>> 0;
    if ($115) {
      var $rr_4 = $rr_3;
      __label__ = 39;
      break;
    } else {
      __label__ = 38;
      break;
    }
   case 38:
    var $117 = $rr_3;
    var $118 = $112;
    var $119 = $117 - $118 | 0;
    _growrec();
    var $120 = HEAP32[_record >> 2];
    var $121 = $120 + $119 | 0;
    var $rr_4 = $121;
    __label__ = 39;
    break;
   case 39:
    var $rr_4;
    var $123 = $rr_4 + 1 | 0;
    HEAP8[$rr_4] = 10;
    var $124 = $110 & 255;
    var $125 = $rr_4 + 2 | 0;
    HEAP8[$123] = $124;
    var $rr_0_be = $125;
    __label__ = 24;
    break;
   case 40:
    var $c_2;
    HEAP8[$rr_3] = 0;
    var $_b = HEAP8[_mustfld_b];
    if ($_b) {
      __label__ = 41;
      break;
    } else {
      __label__ = 42;
      break;
    }
   case 41:
    _fldbld();
    __label__ = 42;
    break;
   case 42:
    var $129 = ($c_2 | 0) != -1;
    var $130 = HEAP32[_record >> 2];
    var $131 = $rr_3 >>> 0 > $130 >>> 0;
    var $or_cond8 = $129 | $131;
    if ($or_cond8) {
      __label__ = 43;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 43:
    var $133 = HEAP32[_recloc >> 2];
    var $134 = $133 + 16 | 0;
    var $135 = HEAP32[$134 >> 2];
    var $136 = $135 & -4;
    var $137 = $136 | 1;
    HEAP32[$134 >> 2] = $137;
    var $138 = HEAP32[_nrloc >> 2];
    var $139 = $138 + 8 | 0;
    var $140 = (tempDoubleI32[0] = HEAP32[$139 >> 2], tempDoubleI32[1] = HEAP32[$139 + 4 >> 2], tempDoubleF64[0]);
    var $141 = $140 + 1;
    tempDoubleF64[0] = $141, HEAP32[$139 >> 2] = tempDoubleI32[0], HEAP32[$139 + 4 >> 2] = tempDoubleI32[1];
    var $142 = $138 + 16 | 0;
    var $143 = HEAP32[$142 >> 2];
    var $144 = $143 & -4;
    var $145 = $144 | 2;
    HEAP32[$142 >> 2] = $145;
    var $_0 = 1;
    __label__ = 47;
    break;
   case 44:
    var $147 = HEAP32[_infile >> 2];
    var $148 = HEAP32[_stdin >> 2];
    var $149 = ($147 | 0) == ($148 | 0);
    if ($149) {
      __label__ = 46;
      break;
    } else {
      __label__ = 45;
      break;
    }
   case 45:
    var $151 = _fclose($147);
    __label__ = 46;
    break;
   case 46:
    HEAP32[_infile >> 2] = 0;
    var $153 = HEAP32[_svargc >> 2];
    var $154 = $153 - 1 | 0;
    HEAP32[_svargc >> 2] = $154;
    var $155 = HEAP32[_svargv >> 2];
    var $156 = $155 + 4 | 0;
    HEAP32[_svargv >> 2] = $156;
    var $13 = $154;
    __label__ = 5;
    break;
   case 47:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_getrec["X"] = 1;
function _exptostat($a) {
  HEAP8[$a | 0] = 2;
  return $a;
}
function _linkum($a, $b) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($a | 0) == 0;
    if ($1) {
      var $_0 = $b;
      __label__ = 6;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = ($b | 0) == 0;
    if ($3) {
      var $_0 = $a;
      __label__ = 6;
      break;
    } else {
      var $c_0 = $a;
      __label__ = 4;
      break;
    }
   case 4:
    var $c_0;
    var $4 = $c_0 + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = ($5 | 0) == 0;
    if ($6) {
      __label__ = 5;
      break;
    } else {
      var $c_0 = $5;
      __label__ = 4;
      break;
    }
   case 5:
    HEAP32[$4 >> 2] = $b;
    var $_0 = $a;
    __label__ = 6;
    break;
   case 6:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _isanumber($s) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($s | 0) == 0;
    if ($1) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      var $_01 = $s;
      __label__ = 3;
      break;
    }
   case 3:
    var $_01;
    var $2 = HEAP8[$_01];
    if ($2 << 24 >> 24 == 32 || $2 << 24 >> 24 == 9 || $2 << 24 >> 24 == 10) {
      __label__ = 4;
      break;
    } else if ($2 << 24 >> 24 == 43 || $2 << 24 >> 24 == 45) {
      __label__ = 5;
      break;
    } else if ($2 << 24 >> 24 == 0) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      var $_1 = $_01;
      var $6 = $2;
      __label__ = 6;
      break;
    }
   case 4:
    var $3 = $_01 + 1 | 0;
    var $_01 = $3;
    __label__ = 3;
    break;
   case 5:
    var $5 = $_01 + 1 | 0;
    var $_pre = HEAP8[$5];
    var $_1 = $5;
    var $6 = $_pre;
    __label__ = 6;
    break;
   case 6:
    var $6;
    var $_1;
    var $7 = $6 & 255;
    var $isdigittmp = $7 - 48 | 0;
    var $isdigit = $isdigittmp >>> 0 < 10;
    if ($isdigit) {
      var $_2 = $_1;
      var $d1_0 = 0;
      __label__ = 11;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $9 = HEAP32[_radixchar >> 2];
    var $10 = HEAP8[$9];
    var $11 = $6 << 24 >> 24 == $10 << 24 >> 24;
    if ($11) {
      var $d1_118 = 0;
      var $_319 = $_1;
      var $25 = $6;
      __label__ = 13;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $13 = HEAP32[_radixcharlen >> 2];
    var $14 = ($13 | 0) == 1;
    if ($14) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $16 = _strncmp($_1, $9, $13);
    var $17 = ($16 | 0) == 0;
    if ($17) {
      __label__ = 10;
      break;
    } else {
      var $_0 = 0;
      __label__ = 32;
      break;
    }
   case 10:
    if ($isdigit) {
      var $_2 = $_1;
      var $d1_0 = 0;
      __label__ = 11;
      break;
    } else {
      var $d1_118 = 0;
      var $_319 = $_1;
      var $25 = $6;
      __label__ = 13;
      break;
    }
   case 11:
    var $d1_0;
    var $_2;
    var $19 = $d1_0 + 1 | 0;
    var $20 = $_2 + 1 | 0;
    var $21 = HEAP8[$20];
    var $22 = $21 & 255;
    var $isdigittmp8 = $22 - 48 | 0;
    var $isdigit9 = $isdigittmp8 >>> 0 < 10;
    if ($isdigit9) {
      var $_2 = $20;
      var $d1_0 = $19;
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $24 = ($19 | 0) > 37;
    if ($24) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      var $d1_118 = $19;
      var $_319 = $20;
      var $25 = $21;
      __label__ = 13;
      break;
    }
   case 13:
    var $25;
    var $_319;
    var $d1_118;
    var $26 = HEAP32[_radixchar >> 2];
    var $27 = HEAP8[$26];
    var $28 = $25 << 24 >> 24 == $27 << 24 >> 24;
    if ($28) {
      __label__ = 14;
      break;
    } else {
      var $_4 = $_319;
      var $point_0 = 0;
      var $38 = $25;
      __label__ = 17;
      break;
    }
   case 14:
    var $30 = HEAP32[_radixcharlen >> 2];
    var $31 = ($30 | 0) == 1;
    if ($31) {
      __label__ = 16;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $33 = _strncmp($_319, $26, $30);
    var $34 = ($33 | 0) == 0;
    if ($34) {
      __label__ = 16;
      break;
    } else {
      var $_4 = $_319;
      var $point_0 = 0;
      var $38 = $25;
      __label__ = 17;
      break;
    }
   case 16:
    var $36 = $_319 + $30 | 0;
    var $_pre2 = HEAP8[$36];
    var $_4 = $36;
    var $point_0 = 1;
    var $38 = $_pre2;
    __label__ = 17;
    break;
   case 17:
    var $38;
    var $point_0;
    var $_4;
    var $39 = $38 << 24 >> 24;
    var $isdigittmp10 = $39 - 48 | 0;
    var $isdigit11 = $isdigittmp10 >>> 0 < 10;
    if ($isdigit11) {
      var $_5 = $_4;
      __label__ = 18;
      break;
    } else {
      var $_6 = $_4;
      var $d2_0 = 0;
      var $43 = $38;
      __label__ = 19;
      break;
    }
   case 18:
    var $_5;
    var $40 = $_5 + 1 | 0;
    var $41 = HEAP8[$40];
    var $42 = $41 & 255;
    var $isdigittmp12 = $42 - 48 | 0;
    var $isdigit13 = $isdigittmp12 >>> 0 < 10;
    if ($isdigit13) {
      var $_5 = $40;
      __label__ = 18;
      break;
    } else {
      var $_6 = $40;
      var $d2_0 = 1;
      var $43 = $41;
      __label__ = 19;
      break;
    }
   case 19:
    var $43;
    var $d2_0;
    var $_6;
    var $44 = ($d1_118 | 0) == 0;
    if ($44) {
      __label__ = 20;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 20:
    var $46 = ($point_0 | 0) == 0;
    var $47 = ($d2_0 | 0) == 0;
    var $or_cond = $46 | $47;
    if ($or_cond) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    if ($43 << 24 >> 24 == 101 || $43 << 24 >> 24 == 69) {
      __label__ = 22;
      break;
    } else {
      var $_9 = $_6;
      var $76 = $43;
      __label__ = 29;
      break;
    }
   case 22:
    var $50 = $_6 + 1 | 0;
    var $51 = HEAP8[$50];
    if ($51 << 24 >> 24 == 43 || $51 << 24 >> 24 == 45) {
      __label__ = 23;
      break;
    } else {
      var $_7 = $50;
      var $55 = $51;
      __label__ = 24;
      break;
    }
   case 23:
    var $53 = $_6 + 2 | 0;
    var $_pre3 = HEAP8[$53];
    var $_7 = $53;
    var $55 = $_pre3;
    __label__ = 24;
    break;
   case 24:
    var $55;
    var $_7;
    var $56 = $55 & 255;
    var $isdigittmp14 = $56 - 48 | 0;
    var $isdigit15 = $isdigittmp14 >>> 0 < 10;
    if ($isdigit15) {
      var $_8 = $_7;
      __label__ = 25;
      break;
    } else {
      var $_0 = 0;
      __label__ = 32;
      break;
    }
   case 25:
    var $_8;
    var $57 = $_8 + 1 | 0;
    var $58 = HEAP8[$57];
    var $59 = $58 & 255;
    var $isdigittmp16 = $59 - 48 | 0;
    var $isdigit17 = $isdigittmp16 >>> 0 < 10;
    if ($isdigit17) {
      var $_8 = $57;
      __label__ = 25;
      break;
    } else {
      __label__ = 26;
      break;
    }
   case 26:
    var $61 = $57;
    var $62 = $_7;
    var $63 = $61 - $62 | 0;
    var $64 = ($63 | 0) > 2;
    if ($64) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $66 = ($63 | 0) == 2;
    if ($66) {
      __label__ = 28;
      break;
    } else {
      var $_9 = $57;
      var $76 = $58;
      __label__ = 29;
      break;
    }
   case 28:
    var $68 = $55 << 24 >> 24;
    var $69 = $68 * 10 | 0;
    var $70 = $_7 + 1 | 0;
    var $71 = HEAP8[$70];
    var $72 = $71 << 24 >> 24;
    var $73 = $72 - 528 | 0;
    var $74 = $73 + $69 | 0;
    var $75 = ($74 | 0) > 37;
    if ($75) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      var $_9 = $57;
      var $76 = $58;
      __label__ = 29;
      break;
    }
   case 29:
    var $76;
    var $_9;
    if ($76 << 24 >> 24 == 32 || $76 << 24 >> 24 == 9 || $76 << 24 >> 24 == 10) {
      __label__ = 30;
      break;
    } else if ($76 << 24 >> 24 == 0) {
      var $_0 = 1;
      __label__ = 32;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 30:
    var $77 = $_9 + 1 | 0;
    var $_pre4 = HEAP8[$77];
    var $_9 = $77;
    var $76 = $_pre4;
    __label__ = 29;
    break;
   case 31:
    var $_0 = 0;
    __label__ = 32;
    break;
   case 32:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_isanumber["X"] = 1;
function _recbld() {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_b = HEAP8[_donefld_b];
    var $1 = $_b ^ 1;
    var $_b1 = HEAP8[_donerec_b];
    var $or_cond = $_b1 | $1;
    if ($or_cond) {
      __label__ = 15;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = HEAP32[_record >> 2];
    var $4 = HEAP32[_NF >> 2];
    var $5 = (tempDoubleI32[0] = HEAP32[$4 >> 2], tempDoubleI32[1] = HEAP32[$4 + 4 >> 2], tempDoubleF64[0]);
    var $6 = $5 < 1;
    if ($6) {
      var $r_0_lcssa = $3;
      __label__ = 10;
      break;
    } else {
      var $r_03 = $3;
      var $i_04 = 1;
      __label__ = 4;
      break;
    }
   case 4:
    var $i_04;
    var $r_03;
    var $7 = HEAP32[_fldtab >> 2];
    var $8 = $7 + ($i_04 << 2) | 0;
    var $9 = HEAP32[$8 >> 2];
    var $10 = _getsval($9);
    var $11 = HEAP8[$10];
    var $12 = $r_03 + 1 | 0;
    HEAP8[$r_03] = $11;
    var $13 = $11 << 24 >> 24 == 0;
    if ($13) {
      var $r_1_lcssa = $r_03;
      var $_lcssa = $12;
      __label__ = 9;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $_pre = HEAP32[_record >> 2];
    var $_pn = $10;
    var $15 = $12;
    var $14 = $_pre;
    __label__ = 6;
    break;
   case 6:
    var $14;
    var $15;
    var $_pn;
    var $16 = $_pn + 1 | 0;
    var $17 = HEAP32[_RECSIZE >> 2];
    var $18 = $14 + $17 | 0;
    var $19 = $15 >>> 0 < $18 >>> 0;
    if ($19) {
      var $r_1_be = $15;
      var $26 = $14;
      __label__ = 8;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $21 = $15;
    var $22 = $14;
    var $23 = $21 - $22 | 0;
    _growrec();
    var $24 = HEAP32[_record >> 2];
    var $25 = $24 + $23 | 0;
    var $r_1_be = $25;
    var $26 = $24;
    __label__ = 8;
    break;
   case 8:
    var $26;
    var $r_1_be;
    var $27 = HEAP8[$16];
    var $28 = $r_1_be + 1 | 0;
    HEAP8[$r_1_be] = $27;
    var $29 = $27 << 24 >> 24 == 0;
    if ($29) {
      var $r_1_lcssa = $r_1_be;
      var $_lcssa = $28;
      __label__ = 9;
      break;
    } else {
      var $_pn = $16;
      var $15 = $28;
      var $14 = $26;
      __label__ = 6;
      break;
    }
   case 9:
    var $_lcssa;
    var $r_1_lcssa;
    var $30 = HEAP32[_OFS >> 2];
    var $31 = HEAP32[$30 >> 2];
    var $32 = HEAP8[$31];
    HEAP8[$r_1_lcssa] = $32;
    var $33 = $i_04 + 1 | 0;
    var $34 = $33 | 0;
    var $35 = HEAP32[_NF >> 2];
    var $36 = (tempDoubleI32[0] = HEAP32[$35 >> 2], tempDoubleI32[1] = HEAP32[$35 + 4 >> 2], tempDoubleF64[0]);
    var $37 = $34 > $36;
    if ($37) {
      var $r_0_lcssa = $_lcssa;
      __label__ = 10;
      break;
    } else {
      var $r_03 = $_lcssa;
      var $i_04 = $33;
      __label__ = 4;
      break;
    }
   case 10:
    var $r_0_lcssa;
    var $38 = $r_0_lcssa - 1 | 0;
    HEAP8[$38] = 0;
    var $_b3 = HEAP8[_dbg_b];
    if ($_b3) {
      __label__ = 12;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $39 = HEAP32[_recloc >> 2];
    var $40 = $39 + 16 | 0;
    HEAP32[$40 >> 2] = 5;
    __label__ = 15;
    break;
   case 12:
    var $42 = HEAP32[_FS >> 2];
    var $43 = HEAP32[$42 >> 2];
    var $44 = HEAP8[$43];
    var $45 = $44 << 24 >> 24;
    var $46 = HEAP32[_recloc >> 2];
    var $47 = $46;
    var $48 = _printf(STRING_TABLE.__str10 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $45, HEAP32[tempInt + 4 >> 2] = $47, tempInt));
    var $_b2_pre = HEAP8[_dbg_b];
    var $49 = HEAP32[_recloc >> 2];
    var $50 = $49 + 16 | 0;
    HEAP32[$50 >> 2] = 5;
    if ($_b2_pre) {
      __label__ = 13;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 13:
    var $52 = HEAP32[_FS >> 2];
    var $53 = HEAP32[$52 >> 2];
    var $54 = HEAP8[$53];
    var $55 = $54 << 24 >> 24;
    var $56 = $49;
    var $57 = _printf(STRING_TABLE.__str10 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $55, HEAP32[tempInt + 4 >> 2] = $56, tempInt));
    var $_pr_b = HEAP8[_dbg_b];
    if ($_pr_b) {
      __label__ = 14;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 14:
    var $59 = HEAP32[_record >> 2];
    var $60 = _printf(STRING_TABLE.__str11 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $59, tempInt));
    __label__ = 15;
    break;
   case 15:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_recbld["X"] = 1;
function _yyerror($s) {
  var __stackBase__ = STACKTOP;
  var $2 = HEAP32[_progname >> 2];
  var $3$0 = HEAP32[_lineno >> 2];
  var $3$1 = HEAP32[_lineno + 4 >> 2];
  _fprintf(HEAP32[_stderr >> 2], STRING_TABLE.__str13 | 0, (tempInt = STACKTOP, STACKTOP += 16, HEAP32[tempInt >> 2] = $2, HEAP32[tempInt + 4 >> 2] = $s, HEAP32[tempInt + 8 >> 2] = $3$0, HEAP32[tempInt + 12 >> 2] = $3$1, tempInt));
  HEAP32[_errorflag >> 2] = 2;
  STACKTOP = __stackBase__;
  return;
}
function _PUTS($s) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $puts = _puts($s);
    __label__ = 4;
    break;
   case 4:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _node0($a) {
  var $1 = _ALLOC(0);
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$1 + 8 >> 2] = $a;
  return $1;
}
function _node1($a, $b) {
  var $1 = _ALLOC(1);
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$1 + 8 >> 2] = $a;
  HEAP32[$1 + 12 >> 2] = $b;
  return $1;
}
function _node2($a, $b, $c) {
  var $1 = _ALLOC(2);
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$1 + 8 >> 2] = $a;
  HEAP32[$1 + 12 >> 2] = $b;
  HEAP32[$1 + 16 >> 2] = $c;
  return $1;
}
function _node3($a, $b, $c, $d) {
  var $1 = _ALLOC(3);
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$1 + 8 >> 2] = $a;
  HEAP32[$1 + 12 >> 2] = $b;
  HEAP32[$1 + 16 >> 2] = $c;
  HEAP32[$1 + 20 >> 2] = $d;
  return $1;
}
function _node4($b, $c, $d, $e) {
  var $1 = _ALLOC(4);
  HEAP32[$1 + 4 >> 2] = 0;
  HEAP32[$1 + 8 >> 2] = 293;
  HEAP32[$1 + 12 >> 2] = $b;
  HEAP32[$1 + 16 >> 2] = $c;
  HEAP32[$1 + 20 >> 2] = $d;
  HEAP32[$1 + 24 >> 2] = $e;
  return $1;
}
function _stat3($a, $b, $c, $d) {
  var $1 = _node3($a, $b, $c, $d);
  HEAP8[$1 | 0] = 2;
  return $1;
}
function _op2($a, $b, $c) {
  var $1 = _node2($a, $b, $c);
  HEAP8[$1 | 0] = 3;
  return $1;
}
function _op1($a, $b) {
  var $1 = _node1($a, $b);
  HEAP8[$1 | 0] = 3;
  return $1;
}
function _stat1($a, $b) {
  var $1 = _node1($a, $b);
  HEAP8[$1 | 0] = 2;
  return $1;
}
function _op3($a, $b, $c, $d) {
  var $1 = _node3($a, $b, $c, $d);
  HEAP8[$1 | 0] = 3;
  return $1;
}
function _stat2($a, $b, $c) {
  var $1 = _node2($a, $b, $c);
  HEAP8[$1 | 0] = 2;
  return $1;
}
function _stat4($b, $c, $d, $e) {
  var $1 = _node4($b, $c, $d, $e);
  HEAP8[$1 | 0] = 2;
  return $1;
}
function _valtonode($a, $b) {
  var $2 = _node0($a);
  HEAP8[$2 | 0] = 1;
  HEAP8[$2 + 1 | 0] = $b & 255;
  return $2;
}
function _pa2stat($a, $b, $c) {
  var $1 = HEAP32[_paircnt >> 2];
  HEAP32[_paircnt >> 2] = $1 + 1 | 0;
  var $3 = _node3($1, $a, $b, $c);
  HEAP8[$3 | 0] = 4;
  return $3;
}
function _genprint() {
  var $3 = _stat2(286, _valtonode(_lookup(STRING_TABLE.__str3321 | 0, _symtab | 0), 1), 0);
  return $3;
}
function _fieldadr($n) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($n | 0) < 0;
    if ($1) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str12 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n, tempInt));
   case 4:
    var $3 = HEAP32[_MAXFLD >> 2];
    var $4 = ($3 | 0) > ($n | 0);
    if ($4) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    _morefields();
    var $5 = HEAP32[_MAXFLD >> 2];
    var $6 = ($5 | 0) > ($n | 0);
    if ($6) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 6:
    var $7 = HEAP32[_fldtab >> 2];
    var $8 = $7 + ($n << 2) | 0;
    var $9 = HEAP32[$8 >> 2];
    STACKTOP = __stackBase__;
    return $9;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _ALLOC($n) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $n << 2;
    var $2 = $1 + 12 | 0;
    var $3 = _malloc($2);
    var $4 = ($3 | 0) == 0;
    if ($4) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str20 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 4:
    var $7 = $3;
    STACKTOP = __stackBase__;
    return $7;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yyparse() {
  var __stackBase__ = STACKTOP;
  STACKTOP += 1200;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $yyssa = __stackBase__;
    var $yyvsa = __stackBase__ + 400;
    var $1 = $yyssa | 0;
    var $2 = $yyvsa | 0;
    HEAP32[_yynerrs >> 2] = 0;
    HEAP32[_yychar >> 2] = -2;
    var $yystate_1 = 0;
    var $yyerrstatus_1 = 0;
    var $yyss_0 = $1;
    var $yyssp_1 = $1;
    var $yyvs_0 = $2;
    var $yyvsp_1 = $2;
    var $yystacksize_0 = 200;
    __label__ = 4;
    break;
   case 3:
    var $yyvsp_0;
    var $yyssp_0;
    var $yyerrstatus_0;
    var $yystate_0;
    var $4 = $yyssp_0 + 2 | 0;
    var $yystate_1 = $yystate_0;
    var $yyerrstatus_1 = $yyerrstatus_0;
    var $yyss_0 = $yyss_1;
    var $yyssp_1 = $4;
    var $yyvs_0 = $yyvs_1;
    var $yyvsp_1 = $yyvsp_0;
    var $yystacksize_0 = $yystacksize_2;
    __label__ = 4;
    break;
   case 4:
    var $yystacksize_0;
    var $yyvsp_1;
    var $yyvs_0;
    var $yyssp_1;
    var $yyss_0;
    var $yyerrstatus_1;
    var $yystate_1;
    var $6 = $yystate_1 & 65535;
    HEAP16[$yyssp_1 >> 1] = $6;
    var $_sum = $yystacksize_0 - 1 | 0;
    var $7 = $yyss_0 + ($_sum << 1) | 0;
    var $8 = $7 >>> 0 > $yyssp_1 >>> 0;
    if ($8) {
      var $yyss_1 = $yyss_0;
      var $yyssp_2 = $yyssp_1;
      var $yyvs_1 = $yyvs_0;
      var $yyvsp_2 = $yyvsp_1;
      var $yystacksize_2 = $yystacksize_0;
      __label__ = 10;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $10 = $yyssp_1;
    var $11 = $yyss_0;
    var $12 = $10 - $11 | 0;
    var $13 = $12 >> 1;
    var $14 = $13 + 1 | 0;
    var $15 = $yystacksize_0 >>> 0 > 9999;
    if ($15) {
      __label__ = 141;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $17 = $yystacksize_0 << 1;
    var $18 = $17 >>> 0 > 1e4;
    var $yystacksize_1 = $18 ? 1e4 : $17;
    var $19 = $yystacksize_1 * 6 | 0;
    var $20 = $19 | 3;
    var $21 = _malloc($20);
    var $22 = ($21 | 0) == 0;
    if ($22) {
      __label__ = 141;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $24 = $21;
    var $25 = $21;
    var $26 = $yyss_0;
    var $27 = $14 << 1;
    _memcpy($21, $26, $27, 1);
    var $28 = $yystacksize_1 >>> 1;
    var $29 = $28 & 1073741823;
    var $30 = $24 + ($29 << 2) | 0;
    var $31 = $30;
    var $32 = $yyvs_0;
    var $33 = $14 << 2;
    _memcpy($31, $32, $33, 1);
    var $34 = ($yyss_0 | 0) == ($1 | 0);
    if ($34) {
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    _free($26);
    __label__ = 9;
    break;
   case 9:
    var $37 = $25 + ($13 << 1) | 0;
    var $38 = $30 + ($13 << 2) | 0;
    var $_sum9 = $yystacksize_1 - 1 | 0;
    var $39 = ($_sum9 | 0) > ($13 | 0);
    if ($39) {
      var $yyss_1 = $25;
      var $yyssp_2 = $37;
      var $yyvs_1 = $30;
      var $yyvsp_2 = $38;
      var $yystacksize_2 = $yystacksize_1;
      __label__ = 10;
      break;
    } else {
      var $yyss_3 = $25;
      __label__ = 142;
      break;
    }
   case 10:
    var $yystacksize_2;
    var $yyvsp_2;
    var $yyvs_1;
    var $yyssp_2;
    var $yyss_1;
    var $41 = ($yystate_1 | 0) == 6;
    if ($41) {
      var $yyss_3 = $yyss_1;
      __label__ = 142;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $43 = _yypact + ($yystate_1 << 1) | 0;
    var $44 = HEAP16[$43 >> 1];
    var $45 = $44 << 16 >> 16;
    var $46 = $44 << 16 >> 16 == -106;
    if ($46) {
      __label__ = 23;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $48 = HEAP32[_yychar >> 2];
    var $49 = ($48 | 0) == -2;
    if ($49) {
      __label__ = 13;
      break;
    } else {
      var $53 = $48;
      __label__ = 14;
      break;
    }
   case 13:
    var $51 = _yylex();
    HEAP32[_yychar >> 2] = $51;
    var $53 = $51;
    __label__ = 14;
    break;
   case 14:
    var $53;
    var $54 = ($53 | 0) < 1;
    if ($54) {
      __label__ = 15;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 15:
    HEAP32[_yychar >> 2] = 0;
    var $yytoken_0 = 0;
    __label__ = 18;
    break;
   case 16:
    var $57 = $53 >>> 0 < 336;
    if ($57) {
      __label__ = 17;
      break;
    } else {
      var $yytoken_0 = 2;
      __label__ = 18;
      break;
    }
   case 17:
    var $59 = STRING_TABLE._yytranslate + $53 | 0;
    var $60 = HEAP8[$59];
    var $61 = $60 & 255;
    var $yytoken_0 = $61;
    __label__ = 18;
    break;
   case 18:
    var $yytoken_0;
    var $63 = $yytoken_0 + $45 | 0;
    var $64 = $63 >>> 0 > 1725;
    if ($64) {
      __label__ = 23;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 19:
    var $66 = _yycheck + ($63 << 1) | 0;
    var $67 = HEAP16[$66 >> 1];
    var $68 = $67 << 16 >> 16;
    var $69 = ($68 | 0) == ($yytoken_0 | 0);
    if ($69) {
      __label__ = 20;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 20:
    var $71 = _yytable + ($63 << 1) | 0;
    var $72 = HEAP16[$71 >> 1];
    var $73 = $72 << 16 >> 16;
    var $74 = $72 << 16 >> 16 < 1;
    if ($74) {
      __label__ = 21;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 21:
    var $76 = -$73 | 0;
    var $yyn_0 = $76;
    __label__ = 24;
    break;
   case 22:
    var $78 = $yyerrstatus_1 - 1 | 0;
    var $79 = ($yyerrstatus_1 | 0) == 0;
    var $yyerrstatus_1_ = $79 ? 0 : $78;
    HEAP32[_yychar >> 2] = -2;
    var $80 = HEAP32[_yylval >> 2];
    var $81 = $yyvsp_2 + 4 | 0;
    HEAP32[$81 >> 2] = $80;
    var $yystate_0 = $73;
    var $yyerrstatus_0 = $yyerrstatus_1_;
    var $yyssp_0 = $yyssp_2;
    var $yyvsp_0 = $81;
    __label__ = 3;
    break;
   case 23:
    var $83 = STRING_TABLE._yydefact + $yystate_1 | 0;
    var $84 = HEAP8[$83];
    var $85 = $84 & 255;
    var $86 = $84 << 24 >> 24 == 0;
    if ($86) {
      __label__ = 129;
      break;
    } else {
      var $yyn_0 = $85;
      __label__ = 24;
      break;
    }
   case 24:
    var $yyn_0;
    var $88 = STRING_TABLE._yyr2 + $yyn_0 | 0;
    var $89 = HEAP8[$88];
    var $90 = $89 & 255;
    var $91 = 1 - $90 | 0;
    var $92 = $yyvsp_2 + ($91 << 2) | 0;
    var $93 = HEAP32[$92 >> 2];
    if (($yyn_0 | 0) == 2) {
      __label__ = 25;
      break;
    } else if (($yyn_0 | 0) == 3) {
      __label__ = 27;
      break;
    } else if (($yyn_0 | 0) == 4) {
      __label__ = 28;
      break;
    } else if (($yyn_0 | 0) == 6) {
      __label__ = 29;
      break;
    } else if (($yyn_0 | 0) == 7) {
      __label__ = 30;
      break;
    } else if (($yyn_0 | 0) == 9) {
      __label__ = 31;
      break;
    } else if (($yyn_0 | 0) == 10) {
      __label__ = 32;
      break;
    } else if (($yyn_0 | 0) == 11) {
      __label__ = 33;
      break;
    } else if (($yyn_0 | 0) == 12) {
      __label__ = 34;
      break;
    } else if (($yyn_0 | 0) == 13) {
      __label__ = 35;
      break;
    } else if (($yyn_0 | 0) == 14) {
      __label__ = 36;
      break;
    } else if (($yyn_0 | 0) == 15) {
      __label__ = 37;
      break;
    } else if (($yyn_0 | 0) == 16) {
      __label__ = 38;
      break;
    } else if (($yyn_0 | 0) == 17) {
      __label__ = 39;
      break;
    } else if (($yyn_0 | 0) == 18) {
      __label__ = 40;
      break;
    } else if (($yyn_0 | 0) == 19) {
      __label__ = 41;
      break;
    } else if (($yyn_0 | 0) == 20) {
      __label__ = 42;
      break;
    } else if (($yyn_0 | 0) == 21) {
      __label__ = 43;
      break;
    } else if (($yyn_0 | 0) == 22) {
      __label__ = 44;
      break;
    } else if (($yyn_0 | 0) == 23) {
      __label__ = 45;
      break;
    } else if (($yyn_0 | 0) == 24) {
      __label__ = 46;
      break;
    } else if (($yyn_0 | 0) == 25) {
      __label__ = 47;
      break;
    } else if (($yyn_0 | 0) == 26) {
      __label__ = 48;
      break;
    } else if (($yyn_0 | 0) == 27) {
      __label__ = 49;
      break;
    } else if (($yyn_0 | 0) == 28) {
      __label__ = 50;
      break;
    } else if (($yyn_0 | 0) == 29) {
      __label__ = 51;
      break;
    } else if (($yyn_0 | 0) == 30) {
      __label__ = 52;
      break;
    } else if (($yyn_0 | 0) == 31) {
      __label__ = 53;
      break;
    } else if (($yyn_0 | 0) == 34) {
      __label__ = 54;
      break;
    } else if (($yyn_0 | 0) == 35) {
      __label__ = 55;
      break;
    } else if (($yyn_0 | 0) == 36) {
      __label__ = 56;
      break;
    } else if (($yyn_0 | 0) == 37) {
      __label__ = 57;
      break;
    } else if (($yyn_0 | 0) == 38) {
      __label__ = 58;
      break;
    } else if (($yyn_0 | 0) == 39) {
      __label__ = 59;
      break;
    } else if (($yyn_0 | 0) == 40) {
      __label__ = 60;
      break;
    } else if (($yyn_0 | 0) == 41) {
      __label__ = 61;
      break;
    } else if (($yyn_0 | 0) == 42) {
      __label__ = 62;
      break;
    } else if (($yyn_0 | 0) == 43) {
      __label__ = 63;
      break;
    } else if (($yyn_0 | 0) == 44) {
      __label__ = 64;
      break;
    } else if (($yyn_0 | 0) == 45) {
      __label__ = 65;
      break;
    } else if (($yyn_0 | 0) == 46) {
      __label__ = 66;
      break;
    } else if (($yyn_0 | 0) == 47) {
      __label__ = 67;
      break;
    } else if (($yyn_0 | 0) == 48) {
      __label__ = 68;
      break;
    } else if (($yyn_0 | 0) == 49) {
      __label__ = 69;
      break;
    } else if (($yyn_0 | 0) == 50) {
      __label__ = 70;
      break;
    } else if (($yyn_0 | 0) == 51) {
      __label__ = 71;
      break;
    } else if (($yyn_0 | 0) == 52) {
      __label__ = 72;
      break;
    } else if (($yyn_0 | 0) == 53) {
      __label__ = 73;
      break;
    } else if (($yyn_0 | 0) == 54) {
      __label__ = 74;
      break;
    } else if (($yyn_0 | 0) == 55) {
      __label__ = 75;
      break;
    } else if (($yyn_0 | 0) == 56) {
      __label__ = 76;
      break;
    } else if (($yyn_0 | 0) == 57) {
      __label__ = 77;
      break;
    } else if (($yyn_0 | 0) == 58) {
      __label__ = 78;
      break;
    } else if (($yyn_0 | 0) == 61) {
      __label__ = 79;
      break;
    } else if (($yyn_0 | 0) == 62) {
      __label__ = 80;
      break;
    } else if (($yyn_0 | 0) == 63) {
      __label__ = 81;
      break;
    } else if (($yyn_0 | 0) == 64) {
      __label__ = 82;
      break;
    } else if (($yyn_0 | 0) == 65) {
      __label__ = 83;
      break;
    } else if (($yyn_0 | 0) == 66) {
      __label__ = 84;
      break;
    } else if (($yyn_0 | 0) == 67) {
      __label__ = 85;
      break;
    } else if (($yyn_0 | 0) == 68) {
      __label__ = 86;
      break;
    } else if (($yyn_0 | 0) == 69) {
      __label__ = 87;
      break;
    } else if (($yyn_0 | 0) == 70) {
      __label__ = 88;
      break;
    } else if (($yyn_0 | 0) == 71) {
      __label__ = 89;
      break;
    } else if (($yyn_0 | 0) == 72) {
      __label__ = 90;
      break;
    } else if (($yyn_0 | 0) == 73) {
      __label__ = 91;
      break;
    } else if (($yyn_0 | 0) == 74) {
      __label__ = 92;
      break;
    } else if (($yyn_0 | 0) == 75) {
      __label__ = 93;
      break;
    } else if (($yyn_0 | 0) == 76) {
      __label__ = 94;
      break;
    } else if (($yyn_0 | 0) == 77) {
      __label__ = 95;
      break;
    } else if (($yyn_0 | 0) == 78) {
      __label__ = 96;
      break;
    } else if (($yyn_0 | 0) == 81) {
      __label__ = 97;
      break;
    } else if (($yyn_0 | 0) == 82) {
      __label__ = 98;
      break;
    } else if (($yyn_0 | 0) == 83) {
      __label__ = 99;
      break;
    } else if (($yyn_0 | 0) == 84) {
      __label__ = 100;
      break;
    } else if (($yyn_0 | 0) == 87) {
      __label__ = 101;
      break;
    } else if (($yyn_0 | 0) == 88) {
      __label__ = 102;
      break;
    } else if (($yyn_0 | 0) == 89) {
      __label__ = 103;
      break;
    } else if (($yyn_0 | 0) == 90) {
      __label__ = 104;
      break;
    } else if (($yyn_0 | 0) == 91) {
      __label__ = 105;
      break;
    } else if (($yyn_0 | 0) == 92) {
      __label__ = 106;
      break;
    } else if (($yyn_0 | 0) == 93) {
      __label__ = 107;
      break;
    } else if (($yyn_0 | 0) == 94) {
      __label__ = 108;
      break;
    } else if (($yyn_0 | 0) == 95) {
      __label__ = 109;
      break;
    } else if (($yyn_0 | 0) == 96) {
      __label__ = 110;
      break;
    } else if (($yyn_0 | 0) == 97) {
      __label__ = 111;
      break;
    } else if (($yyn_0 | 0) == 98) {
      __label__ = 112;
      break;
    } else if (($yyn_0 | 0) == 99) {
      __label__ = 113;
      break;
    } else if (($yyn_0 | 0) == 100) {
      __label__ = 114;
      break;
    } else if (($yyn_0 | 0) == 101) {
      __label__ = 115;
      break;
    } else if (($yyn_0 | 0) == 102) {
      __label__ = 116;
      break;
    } else if (($yyn_0 | 0) == 103) {
      __label__ = 117;
      break;
    } else if (($yyn_0 | 0) == 104) {
      __label__ = 118;
      break;
    } else if (($yyn_0 | 0) == 105) {
      __label__ = 119;
      break;
    } else if (($yyn_0 | 0) == 106) {
      __label__ = 120;
      break;
    } else if (($yyn_0 | 0) == 107) {
      __label__ = 121;
      break;
    } else if (($yyn_0 | 0) == 108) {
      __label__ = 122;
      break;
    } else if (($yyn_0 | 0) == 109) {
      __label__ = 123;
      break;
    } else if (($yyn_0 | 0) == 110) {
      __label__ = 124;
      break;
    } else {
      var $yyval_0 = $93;
      __label__ = 125;
      break;
    }
   case 25:
    var $95 = HEAP32[_errorflag >> 2];
    var $96 = ($95 | 0) == 0;
    if ($96) {
      __label__ = 26;
      break;
    } else {
      var $yyval_0 = $93;
      __label__ = 125;
      break;
    }
   case 26:
    var $98 = $yyvsp_2 - 8 | 0;
    var $99 = HEAP32[$98 >> 2];
    var $100 = $99;
    var $101 = $yyvsp_2 - 4 | 0;
    var $102 = HEAP32[$101 >> 2];
    var $103 = $102;
    var $104 = HEAP32[$yyvsp_2 >> 2];
    var $105 = $104;
    var $106 = _stat3(299, $100, $103, $105);
    HEAP32[_winner >> 2] = $106;
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 27:
    HEAP32[_yychar >> 2] = -2;
    _yyerror(STRING_TABLE.__str3276 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 28:
    _PUTS(STRING_TABLE.__str123 | 0);
    var $109 = $yyvsp_2 - 4 | 0;
    var $110 = HEAP32[$109 >> 2];
    var $yyval_0 = $110;
    __label__ = 125;
    break;
   case 29:
    _PUTS(STRING_TABLE.__str224 | 0);
    var $yyval_0 = 0;
    __label__ = 125;
    break;
   case 30:
    _PUTS(STRING_TABLE.__str325 | 0);
    var $113 = $yyvsp_2 - 4 | 0;
    var $114 = HEAP32[$113 >> 2];
    var $yyval_0 = $114;
    __label__ = 125;
    break;
   case 31:
    _PUTS(STRING_TABLE.__str426 | 0);
    var $yyval_0 = 0;
    __label__ = 125;
    break;
   case 32:
    _PUTS(STRING_TABLE.__str527 | 0);
    var $117 = $yyvsp_2 - 8 | 0;
    var $118 = HEAP32[$117 >> 2];
    var $119 = $118;
    var $120 = HEAP32[$yyvsp_2 >> 2];
    var $121 = $120;
    var $122 = _op2(304, $119, $121);
    var $123 = $122 | 0;
    var $yyval_0 = $123;
    __label__ = 125;
    break;
   case 33:
    _PUTS(STRING_TABLE.__str628 | 0);
    var $125 = $yyvsp_2 - 8 | 0;
    var $126 = HEAP32[$125 >> 2];
    var $127 = $126;
    var $128 = HEAP32[$yyvsp_2 >> 2];
    var $129 = $128;
    var $130 = _op2(305, $127, $129);
    var $131 = $130 | 0;
    var $yyval_0 = $131;
    __label__ = 125;
    break;
   case 34:
    _PUTS(STRING_TABLE.__str729 | 0);
    var $133 = HEAP32[$yyvsp_2 >> 2];
    var $134 = $133;
    var $135 = _op1(306, $134);
    var $136 = $135 | 0;
    var $yyval_0 = $136;
    __label__ = 125;
    break;
   case 35:
    var $138 = $yyvsp_2 - 4 | 0;
    var $139 = HEAP32[$138 >> 2];
    var $yyval_0 = $139;
    __label__ = 125;
    break;
   case 36:
    _PUTS(STRING_TABLE.__str830 | 0);
    var $141 = $yyvsp_2 - 8 | 0;
    var $142 = HEAP32[$141 >> 2];
    var $143 = $142;
    var $144 = HEAP32[$yyvsp_2 >> 2];
    var $145 = $144;
    var $146 = _op2(304, $143, $145);
    var $147 = $146 | 0;
    var $yyval_0 = $147;
    __label__ = 125;
    break;
   case 37:
    _PUTS(STRING_TABLE.__str931 | 0);
    var $149 = $yyvsp_2 - 8 | 0;
    var $150 = HEAP32[$149 >> 2];
    var $151 = $150;
    var $152 = HEAP32[$yyvsp_2 >> 2];
    var $153 = $152;
    var $154 = _op2(305, $151, $153);
    var $155 = $154 | 0;
    var $yyval_0 = $155;
    __label__ = 125;
    break;
   case 38:
    _PUTS(STRING_TABLE.__str1032 | 0);
    var $157 = HEAP32[$yyvsp_2 >> 2];
    var $158 = $157;
    var $159 = _op1(306, $158);
    var $160 = $159 | 0;
    var $yyval_0 = $160;
    __label__ = 125;
    break;
   case 39:
    var $162 = $yyvsp_2 - 4 | 0;
    var $163 = HEAP32[$162 >> 2];
    var $yyval_0 = $163;
    __label__ = 125;
    break;
   case 40:
    _PUTS(STRING_TABLE.__str1133 | 0);
    var $165 = HEAP32[$yyvsp_2 >> 2];
    var $166 = $165;
    var $167 = _lookup(STRING_TABLE.__str1319 | 0, _symtab | 0);
    var $168 = _valtonode($167, 0);
    var $169 = _op2(266, $166, $168);
    var $170 = $169 | 0;
    var $yyval_0 = $170;
    __label__ = 125;
    break;
   case 41:
    _PUTS(STRING_TABLE.__str1335 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 42:
    _PUTS(STRING_TABLE.__str1436 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 43:
    _PUTS(STRING_TABLE.__str1537 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 44:
    _PUTS(STRING_TABLE.__str1638 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 45:
    _PUTS(STRING_TABLE.__str1739 | 0);
    var $176 = HEAP32[$yyvsp_2 >> 2];
    var $177 = $176;
    var $178 = _valtonode($177, 1);
    var $179 = $178 | 0;
    var $yyval_0 = $179;
    __label__ = 125;
    break;
   case 46:
    _PUTS(STRING_TABLE.__str1840 | 0);
    var $181 = HEAP32[$yyvsp_2 >> 2];
    var $182 = $181;
    var $183 = _op1(333, $182);
    var $184 = $183 | 0;
    var $yyval_0 = $184;
    __label__ = 125;
    break;
   case 47:
    _PUTS(STRING_TABLE.__str1941 | 0);
    var $186 = $yyvsp_2 - 8 | 0;
    var $187 = HEAP32[$186 >> 2];
    var $yyval_0 = $187;
    __label__ = 125;
    break;
   case 48:
    _PUTS(STRING_TABLE.__str2042 | 0);
    var $189 = $yyvsp_2 - 4 | 0;
    var $190 = HEAP32[$189 >> 2];
    var $191 = $190;
    var $192 = $yyvsp_2 - 8 | 0;
    var $193 = HEAP32[$192 >> 2];
    var $194 = $193;
    var $195 = HEAP32[$yyvsp_2 >> 2];
    var $196 = _makedfa($195);
    var $197 = $196;
    var $198 = _op2($191, $194, $197);
    var $199 = $198 | 0;
    var $yyval_0 = $199;
    __label__ = 125;
    break;
   case 49:
    _PUTS(STRING_TABLE.__str21 | 0);
    var $201 = $yyvsp_2 - 4 | 0;
    var $202 = HEAP32[$201 >> 2];
    var $yyval_0 = $202;
    __label__ = 125;
    break;
   case 50:
    _PUTS(STRING_TABLE.__str2243 | 0);
    var $204 = HEAP32[$yyvsp_2 >> 2];
    var $205 = $204;
    var $206 = _valtonode($205, 0);
    var $207 = $206 | 0;
    var $yyval_0 = $207;
    __label__ = 125;
    break;
   case 51:
    _PUTS(STRING_TABLE.__str23 | 0);
    var $209 = HEAP32[$yyvsp_2 >> 2];
    var $210 = $209;
    var $211 = _valtonode($210, 0);
    var $212 = $211 | 0;
    var $yyval_0 = $212;
    __label__ = 125;
    break;
   case 52:
    _PUTS(STRING_TABLE.__str24 | 0);
    var $214 = HEAP32[$yyvsp_2 >> 2];
    var $215 = $214;
    var $216 = _valtonode($215, 2);
    var $217 = $216 | 0;
    var $yyval_0 = $217;
    __label__ = 125;
    break;
   case 53:
    _PUTS(STRING_TABLE.__str25 | 0);
    var $219 = $yyvsp_2 - 12 | 0;
    var $220 = HEAP32[$219 >> 2];
    var $221 = $220;
    var $222 = $yyvsp_2 - 4 | 0;
    var $223 = HEAP32[$222 >> 2];
    var $224 = $223;
    var $225 = _op2(311, $221, $224);
    var $226 = $225 | 0;
    var $yyval_0 = $226;
    __label__ = 125;
    break;
   case 54:
    _PUTS(STRING_TABLE.__str26 | 0);
    var $228 = _op1(314, 0);
    var $229 = $228 | 0;
    var $yyval_0 = $229;
    __label__ = 125;
    break;
   case 55:
    _PUTS(STRING_TABLE.__str27 | 0);
    var $231 = HEAP32[$yyvsp_2 >> 2];
    var $232 = $231;
    var $233 = _lookup(STRING_TABLE.__str3321 | 0, _symtab | 0);
    var $234 = _valtonode($233, 1);
    var $235 = _op2(310, $232, $234);
    var $236 = $235 | 0;
    var $yyval_0 = $236;
    __label__ = 125;
    break;
   case 56:
    _PUTS(STRING_TABLE.__str29 | 0);
    var $238 = $yyvsp_2 - 8 | 0;
    var $239 = HEAP32[$238 >> 2];
    var $240 = $239;
    var $241 = _lookup(STRING_TABLE.__str3321 | 0, _symtab | 0);
    var $242 = _valtonode($241, 1);
    var $243 = _op2(310, $240, $242);
    var $244 = $243 | 0;
    var $yyval_0 = $244;
    __label__ = 125;
    break;
   case 57:
    _PUTS(STRING_TABLE.__str30 | 0);
    var $246 = $yyvsp_2 - 12 | 0;
    var $247 = HEAP32[$246 >> 2];
    var $248 = $247;
    var $249 = $yyvsp_2 - 4 | 0;
    var $250 = HEAP32[$249 >> 2];
    var $251 = $250;
    var $252 = _op2(310, $248, $251);
    var $253 = $252 | 0;
    var $yyval_0 = $253;
    __label__ = 125;
    break;
   case 58:
    _PUTS(STRING_TABLE.__str31 | 0);
    var $255 = $yyvsp_2 - 4 | 0;
    var $256 = HEAP32[$255 >> 2];
    var $257 = $256;
    var $258 = HEAP32[$yyvsp_2 >> 2];
    var $259 = $258;
    var $260 = _op1($257, $259);
    var $261 = $260 | 0;
    var $yyval_0 = $261;
    __label__ = 125;
    break;
   case 59:
    _PUTS(STRING_TABLE.__str32 | 0);
    var $263 = $yyvsp_2 - 20 | 0;
    var $264 = HEAP32[$263 >> 2];
    var $265 = $264;
    var $266 = $yyvsp_2 - 12 | 0;
    var $267 = HEAP32[$266 >> 2];
    var $268 = $267;
    var $269 = $yyvsp_2 - 4 | 0;
    var $270 = HEAP32[$269 >> 2];
    var $271 = $270;
    var $272 = _op3(309, $265, $268, $271);
    var $273 = $272 | 0;
    var $yyval_0 = $273;
    __label__ = 125;
    break;
   case 60:
    _PUTS(STRING_TABLE.__str32 | 0);
    var $275 = $yyvsp_2 - 12 | 0;
    var $276 = HEAP32[$275 >> 2];
    var $277 = $276;
    var $278 = $yyvsp_2 - 4 | 0;
    var $279 = HEAP32[$278 >> 2];
    var $280 = $279;
    var $281 = _op3(309, $277, $280, 0);
    var $282 = $281 | 0;
    var $yyval_0 = $282;
    __label__ = 125;
    break;
   case 61:
    _PUTS(STRING_TABLE.__str33 | 0);
    var $284 = $yyvsp_2 - 20 | 0;
    var $285 = HEAP32[$284 >> 2];
    var $286 = $285;
    var $287 = $yyvsp_2 - 12 | 0;
    var $288 = HEAP32[$287 >> 2];
    var $289 = $288;
    var $290 = $yyvsp_2 - 4 | 0;
    var $291 = HEAP32[$290 >> 2];
    var $292 = $291;
    var $293 = _op3(289, $286, $289, $292);
    var $294 = $293 | 0;
    var $yyval_0 = $294;
    __label__ = 125;
    break;
   case 62:
    _PUTS(STRING_TABLE.__str33 | 0);
    var $296 = $yyvsp_2 - 12 | 0;
    var $297 = HEAP32[$296 >> 2];
    var $298 = $297;
    var $299 = $yyvsp_2 - 4 | 0;
    var $300 = HEAP32[$299 >> 2];
    var $301 = $300;
    var $302 = _op3(289, $298, $301, 0);
    var $303 = $302 | 0;
    var $yyval_0 = $303;
    __label__ = 125;
    break;
   case 63:
    _PUTS(STRING_TABLE.__str34 | 0);
    var $305 = $yyvsp_2 - 12 | 0;
    var $306 = HEAP32[$305 >> 2];
    var $307 = $306;
    var $308 = $yyvsp_2 - 4 | 0;
    var $309 = HEAP32[$308 >> 2];
    var $310 = $309;
    var $311 = _op2(307, $307, $310);
    var $312 = $311 | 0;
    var $yyval_0 = $312;
    __label__ = 125;
    break;
   case 64:
    _PUTS(STRING_TABLE.__str35 | 0);
    var $314 = $yyvsp_2 - 4 | 0;
    var $315 = HEAP32[$314 >> 2];
    var $yyval_0 = $315;
    __label__ = 125;
    break;
   case 65:
    _PUTS(STRING_TABLE.__str36 | 0);
    var $317 = $yyvsp_2 - 8 | 0;
    var $318 = HEAP32[$317 >> 2];
    var $319 = $318;
    var $320 = HEAP32[$yyvsp_2 >> 2];
    var $321 = $320;
    var $322 = _op2(270, $319, $321);
    var $323 = $322 | 0;
    var $yyval_0 = $323;
    __label__ = 125;
    break;
   case 66:
    _PUTS(STRING_TABLE.__str37 | 0);
    var $325 = $yyvsp_2 - 8 | 0;
    var $326 = HEAP32[$325 >> 2];
    var $327 = $326;
    var $328 = HEAP32[$yyvsp_2 >> 2];
    var $329 = $328;
    var $330 = _op2(271, $327, $329);
    var $331 = $330 | 0;
    var $yyval_0 = $331;
    __label__ = 125;
    break;
   case 67:
    _PUTS(STRING_TABLE.__str38 | 0);
    var $333 = $yyvsp_2 - 8 | 0;
    var $334 = HEAP32[$333 >> 2];
    var $335 = $334;
    var $336 = HEAP32[$yyvsp_2 >> 2];
    var $337 = $336;
    var $338 = _op2(272, $335, $337);
    var $339 = $338 | 0;
    var $yyval_0 = $339;
    __label__ = 125;
    break;
   case 68:
    _PUTS(STRING_TABLE.__str39 | 0);
    var $341 = $yyvsp_2 - 8 | 0;
    var $342 = HEAP32[$341 >> 2];
    var $343 = $342;
    var $344 = HEAP32[$yyvsp_2 >> 2];
    var $345 = $344;
    var $346 = _op2(273, $343, $345);
    var $347 = $346 | 0;
    var $yyval_0 = $347;
    __label__ = 125;
    break;
   case 69:
    _PUTS(STRING_TABLE.__str40 | 0);
    var $349 = $yyvsp_2 - 8 | 0;
    var $350 = HEAP32[$349 >> 2];
    var $351 = $350;
    var $352 = HEAP32[$yyvsp_2 >> 2];
    var $353 = $352;
    var $354 = _op2(274, $351, $353);
    var $355 = $354 | 0;
    var $yyval_0 = $355;
    __label__ = 125;
    break;
   case 70:
    _PUTS(STRING_TABLE.__str41 | 0);
    var $357 = HEAP32[$yyvsp_2 >> 2];
    var $358 = $357;
    var $359 = _op1(275, $358);
    var $360 = $359 | 0;
    var $yyval_0 = $360;
    __label__ = 125;
    break;
   case 71:
    _PUTS(STRING_TABLE.__str42 | 0);
    var $362 = HEAP32[$yyvsp_2 >> 2];
    var $yyval_0 = $362;
    __label__ = 125;
    break;
   case 72:
    _PUTS(STRING_TABLE.__str43 | 0);
    var $364 = HEAP32[$yyvsp_2 >> 2];
    var $365 = $364;
    var $366 = _op1(331, $365);
    var $367 = $366 | 0;
    var $yyval_0 = $367;
    __label__ = 125;
    break;
   case 73:
    _PUTS(STRING_TABLE.__str44 | 0);
    var $369 = HEAP32[$yyvsp_2 >> 2];
    var $370 = $369;
    var $371 = _op1(329, $370);
    var $372 = $371 | 0;
    var $yyval_0 = $372;
    __label__ = 125;
    break;
   case 74:
    _PUTS(STRING_TABLE.__str45 | 0);
    var $374 = $yyvsp_2 - 4 | 0;
    var $375 = HEAP32[$374 >> 2];
    var $376 = $375;
    var $377 = _op1(332, $376);
    var $378 = $377 | 0;
    var $yyval_0 = $378;
    __label__ = 125;
    break;
   case 75:
    _PUTS(STRING_TABLE.__str46 | 0);
    var $380 = $yyvsp_2 - 4 | 0;
    var $381 = HEAP32[$380 >> 2];
    var $382 = $381;
    var $383 = _op1(330, $382);
    var $384 = $383 | 0;
    var $yyval_0 = $384;
    __label__ = 125;
    break;
   case 76:
    _PUTS(STRING_TABLE.__str47 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 77:
    _PUTS(STRING_TABLE.__str48 | 0);
    var $387 = $yyvsp_2 - 4 | 0;
    var $388 = HEAP32[$387 >> 2];
    var $389 = $388;
    var $390 = HEAP32[$yyvsp_2 >> 2];
    var $391 = $390;
    var $392 = _op2(323, $389, $391);
    var $393 = $392 | 0;
    var $yyval_0 = $393;
    __label__ = 125;
    break;
   case 78:
    _PUTS(STRING_TABLE.__str49 | 0);
    var $395 = $yyvsp_2 - 4 | 0;
    var $396 = HEAP32[$395 >> 2];
    var $397 = $396;
    var $398 = $yyvsp_2 - 8 | 0;
    var $399 = HEAP32[$398 >> 2];
    var $400 = $399;
    var $401 = HEAP32[$yyvsp_2 >> 2];
    var $402 = $401;
    var $403 = _stat2($397, $400, $402);
    var $404 = $403 | 0;
    var $yyval_0 = $404;
    __label__ = 125;
    break;
   case 79:
    _PUTS(STRING_TABLE.__str50 | 0);
    var $406 = HEAP32[$yyvsp_2 >> 2];
    var $407 = $406;
    var $408 = _genprint();
    var $409 = _stat2(300, $407, $408);
    var $410 = $409 | 0;
    var $yyval_0 = $410;
    __label__ = 125;
    break;
   case 80:
    _PUTS(STRING_TABLE.__str51 | 0);
    var $412 = $yyvsp_2 - 12 | 0;
    var $413 = HEAP32[$412 >> 2];
    var $414 = $413;
    var $415 = $yyvsp_2 - 4 | 0;
    var $416 = HEAP32[$415 >> 2];
    var $417 = $416;
    var $418 = _stat2(300, $414, $417);
    var $419 = $418 | 0;
    var $yyval_0 = $419;
    __label__ = 125;
    break;
   case 81:
    _PUTS(STRING_TABLE.__str52 | 0);
    var $421 = $yyvsp_2 - 8 | 0;
    var $422 = HEAP32[$421 >> 2];
    var $423 = $422;
    var $424 = HEAP32[$yyvsp_2 >> 2];
    var $425 = $424;
    var $426 = _genprint();
    var $427 = _pa2stat($423, $425, $426);
    var $428 = $427 | 0;
    var $yyval_0 = $428;
    __label__ = 125;
    break;
   case 82:
    _PUTS(STRING_TABLE.__str53 | 0);
    var $430 = $yyvsp_2 - 20 | 0;
    var $431 = HEAP32[$430 >> 2];
    var $432 = $431;
    var $433 = $yyvsp_2 - 12 | 0;
    var $434 = HEAP32[$433 >> 2];
    var $435 = $434;
    var $436 = $yyvsp_2 - 4 | 0;
    var $437 = HEAP32[$436 >> 2];
    var $438 = $437;
    var $439 = _pa2stat($432, $435, $438);
    var $440 = $439 | 0;
    var $yyval_0 = $440;
    __label__ = 125;
    break;
   case 83:
    _PUTS(STRING_TABLE.__str54 | 0);
    var $442 = $yyvsp_2 - 4 | 0;
    var $443 = HEAP32[$442 >> 2];
    var $444 = $443;
    var $445 = _stat2(300, 0, $444);
    var $446 = $445 | 0;
    var $yyval_0 = $446;
    __label__ = 125;
    break;
   case 84:
    _PUTS(STRING_TABLE.__str55 | 0);
    var $448 = $yyvsp_2 - 8 | 0;
    var $449 = HEAP32[$448 >> 2];
    var $450 = $449;
    var $451 = $yyvsp_2 - 4 | 0;
    var $452 = HEAP32[$451 >> 2];
    var $453 = $452;
    var $454 = _linkum($450, $453);
    var $455 = $454 | 0;
    var $yyval_0 = $455;
    __label__ = 125;
    break;
   case 85:
    _PUTS(STRING_TABLE.__str56 | 0);
    var $yyval_0 = 0;
    __label__ = 125;
    break;
   case 86:
    _PUTS(STRING_TABLE.__str55 | 0);
    var $458 = $yyvsp_2 - 4 | 0;
    var $459 = HEAP32[$458 >> 2];
    var $460 = $459;
    var $461 = HEAP32[$yyvsp_2 >> 2];
    var $462 = $461;
    var $463 = _linkum($460, $462);
    var $464 = $463 | 0;
    var $yyval_0 = $464;
    __label__ = 125;
    break;
   case 87:
    _PUTS(STRING_TABLE.__str57 | 0);
    var $466 = _lookup(STRING_TABLE.__str3321 | 0, _symtab | 0);
    var $467 = _valtonode($466, 1);
    var $468 = HEAP32[$yyvsp_2 >> 2];
    var $469 = _makedfa($468);
    var $470 = $469;
    var $471 = _op2(267, $467, $470);
    var $472 = $471 | 0;
    var $yyval_0 = $472;
    __label__ = 125;
    break;
   case 88:
    _PUTS(STRING_TABLE.__str1335 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 89:
    _PUTS(STRING_TABLE.__str1436 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 90:
    _PUTS(STRING_TABLE.__str58 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 91:
    _PUTS(STRING_TABLE.__str1133 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 92:
    _PUTS(STRING_TABLE.__str59 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 93:
    _PUTS(STRING_TABLE.__str60 | 0);
    var $479 = _lookup(STRING_TABLE.__str3321 | 0, _symtab | 0);
    var $480 = _valtonode($479, 1);
    var $481 = $480 | 0;
    var $yyval_0 = $481;
    __label__ = 125;
    break;
   case 94:
    var $483 = $yyvsp_2 - 8 | 0;
    var $484 = HEAP32[$483 >> 2];
    var $485 = $484;
    var $486 = HEAP32[$yyvsp_2 >> 2];
    var $487 = $486;
    var $488 = _linkum($485, $487);
    var $489 = $488 | 0;
    var $yyval_0 = $489;
    __label__ = 125;
    break;
   case 95:
    var $491 = $yyvsp_2 - 8 | 0;
    var $492 = HEAP32[$491 >> 2];
    var $493 = $492;
    var $494 = HEAP32[$yyvsp_2 >> 2];
    var $495 = $494;
    var $496 = _linkum($493, $495);
    var $497 = $496 | 0;
    var $yyval_0 = $497;
    __label__ = 125;
    break;
   case 96:
    var $499 = $yyvsp_2 - 4 | 0;
    var $500 = HEAP32[$499 >> 2];
    var $yyval_0 = $500;
    __label__ = 125;
    break;
   case 97:
    _startreg();
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 98:
    _PUTS(STRING_TABLE.__str61 | 0);
    var $503 = $yyvsp_2 - 4 | 0;
    var $504 = HEAP32[$503 >> 2];
    var $yyval_0 = $504;
    __label__ = 125;
    break;
   case 99:
    _PUTS(STRING_TABLE.__str62 | 0);
    var $506 = $yyvsp_2 - 4 | 0;
    var $507 = HEAP32[$506 >> 2];
    var $508 = $507;
    var $509 = $yyvsp_2 - 8 | 0;
    var $510 = HEAP32[$509 >> 2];
    var $511 = $510;
    var $512 = HEAP32[$yyvsp_2 >> 2];
    var $513 = $512;
    var $514 = _op2($508, $511, $513);
    var $515 = $514 | 0;
    var $yyval_0 = $515;
    __label__ = 125;
    break;
   case 100:
    _PUTS(STRING_TABLE.__str63 | 0);
    var $517 = $yyvsp_2 - 4 | 0;
    var $518 = HEAP32[$517 >> 2];
    var $yyval_0 = $518;
    __label__ = 125;
    break;
   case 101:
    _PUTS(STRING_TABLE.__str64 | 0);
    var $520 = $yyvsp_2 - 12 | 0;
    var $521 = HEAP32[$520 >> 2];
    var $522 = $521;
    var $523 = $yyvsp_2 - 8 | 0;
    var $524 = HEAP32[$523 >> 2];
    var $525 = $524;
    var $526 = $yyvsp_2 - 4 | 0;
    var $527 = HEAP32[$526 >> 2];
    var $528 = $527;
    var $529 = HEAP32[$yyvsp_2 >> 2];
    var $530 = $529;
    var $531 = _stat3($522, $525, $528, $530);
    var $532 = $531 | 0;
    var $yyval_0 = $532;
    __label__ = 125;
    break;
   case 102:
    _PUTS(STRING_TABLE.__str65 | 0);
    var $534 = $yyvsp_2 - 4 | 0;
    var $535 = HEAP32[$534 >> 2];
    var $536 = $535;
    var $537 = HEAP32[$yyvsp_2 >> 2];
    var $538 = $537;
    var $539 = _stat3($536, $538, 0, 0);
    var $540 = $539 | 0;
    var $yyval_0 = $540;
    __label__ = 125;
    break;
   case 103:
    _PUTS(STRING_TABLE.__str66 | 0);
    var $542 = $yyvsp_2 - 12 | 0;
    var $543 = HEAP32[$542 >> 2];
    var $544 = $543;
    var $545 = $yyvsp_2 - 8 | 0;
    var $546 = HEAP32[$545 >> 2];
    var $547 = $546;
    var $548 = $yyvsp_2 - 4 | 0;
    var $549 = HEAP32[$548 >> 2];
    var $550 = $549;
    var $551 = HEAP32[$yyvsp_2 >> 2];
    var $552 = $551;
    var $553 = _stat3($544, $547, $550, $552);
    var $554 = $553 | 0;
    var $yyval_0 = $554;
    __label__ = 125;
    break;
   case 104:
    _PUTS(STRING_TABLE.__str67 | 0);
    var $556 = $yyvsp_2 - 4 | 0;
    var $557 = HEAP32[$556 >> 2];
    var $558 = $557;
    var $559 = HEAP32[$yyvsp_2 >> 2];
    var $560 = $559;
    var $561 = _stat3($558, $560, 0, 0);
    var $562 = $561 | 0;
    var $yyval_0 = $562;
    __label__ = 125;
    break;
   case 105:
    _PUTS(STRING_TABLE.__str1133 | 0);
    var $564 = HEAP32[$yyvsp_2 >> 2];
    var $565 = $564;
    var $566 = _exptostat($565);
    var $567 = $566 | 0;
    var $yyval_0 = $567;
    __label__ = 125;
    break;
   case 106:
    _PUTS(STRING_TABLE.__str68 | 0);
    var $yyval_0 = 0;
    __label__ = 125;
    break;
   case 107:
    HEAP32[_yychar >> 2] = -2;
    _yyerror(STRING_TABLE.__str69 | 0);
    var $yyval_0 = 0;
    __label__ = 125;
    break;
   case 108:
    _PUTS(STRING_TABLE.__str70 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 109:
    _PUTS(STRING_TABLE.__str71 | 0);
    var $572 = $yyvsp_2 - 4 | 0;
    var $573 = HEAP32[$572 >> 2];
    var $574 = $573;
    var $575 = HEAP32[$yyvsp_2 >> 2];
    var $576 = $575;
    var $577 = _stat3(290, $574, $576, 0);
    var $578 = $577 | 0;
    var $yyval_0 = $578;
    __label__ = 125;
    break;
   case 110:
    _PUTS(STRING_TABLE.__str72 | 0);
    var $580 = $yyvsp_2 - 12 | 0;
    var $581 = HEAP32[$580 >> 2];
    var $582 = $581;
    var $583 = $yyvsp_2 - 8 | 0;
    var $584 = HEAP32[$583 >> 2];
    var $585 = $584;
    var $586 = HEAP32[$yyvsp_2 >> 2];
    var $587 = $586;
    var $588 = _stat3(290, $582, $585, $587);
    var $589 = $588 | 0;
    var $yyval_0 = $589;
    __label__ = 125;
    break;
   case 111:
    _PUTS(STRING_TABLE.__str73 | 0);
    var $591 = $yyvsp_2 - 4 | 0;
    var $592 = HEAP32[$591 >> 2];
    var $593 = $592;
    var $594 = HEAP32[$yyvsp_2 >> 2];
    var $595 = $594;
    var $596 = _stat2(292, $593, $595);
    var $597 = $596 | 0;
    var $yyval_0 = $597;
    __label__ = 125;
    break;
   case 112:
    _PUTS(STRING_TABLE.__str74 | 0);
    var $yyval_0 = $93;
    __label__ = 125;
    break;
   case 113:
    _PUTS(STRING_TABLE.__str75 | 0);
    var $600 = _stat1(295, 0);
    var $601 = $600 | 0;
    var $yyval_0 = $601;
    __label__ = 125;
    break;
   case 114:
    _PUTS(STRING_TABLE.__str76 | 0);
    var $603 = _stat1(296, 0);
    var $604 = $603 | 0;
    var $yyval_0 = $604;
    __label__ = 125;
    break;
   case 115:
    _PUTS(STRING_TABLE.__str76 | 0);
    var $606 = $yyvsp_2 - 4 | 0;
    var $607 = HEAP32[$606 >> 2];
    var $608 = $607;
    var $609 = _stat1(296, $608);
    var $610 = $609 | 0;
    var $yyval_0 = $610;
    __label__ = 125;
    break;
   case 116:
    _PUTS(STRING_TABLE.__str77 | 0);
    var $612 = _stat1(297, 0);
    var $613 = $612 | 0;
    var $yyval_0 = $613;
    __label__ = 125;
    break;
   case 117:
    _PUTS(STRING_TABLE.__str78 | 0);
    var $615 = _stat1(298, 0);
    var $616 = $615 | 0;
    var $yyval_0 = $616;
    __label__ = 125;
    break;
   case 118:
    _PUTS(STRING_TABLE.__str79 | 0);
    var $618 = $yyvsp_2 - 4 | 0;
    var $619 = HEAP32[$618 >> 2];
    var $yyval_0 = $619;
    __label__ = 125;
    break;
   case 119:
    _PUTS(STRING_TABLE.__str80 | 0);
    var $621 = $yyvsp_2 - 4 | 0;
    var $622 = HEAP32[$621 >> 2];
    var $623 = $622;
    var $624 = HEAP32[$yyvsp_2 >> 2];
    var $625 = $624;
    var $626 = _linkum($623, $625);
    var $627 = $626 | 0;
    var $yyval_0 = $627;
    __label__ = 125;
    break;
   case 120:
    _PUTS(STRING_TABLE.__str81 | 0);
    var $yyval_0 = 0;
    __label__ = 125;
    break;
   case 121:
    _PUTS(STRING_TABLE.__str82 | 0);
    var $630 = $yyvsp_2 - 8 | 0;
    var $631 = HEAP32[$630 >> 2];
    var $yyval_0 = $631;
    __label__ = 125;
    break;
   case 122:
    _PUTS(STRING_TABLE.__str83 | 0);
    var $633 = $yyvsp_2 - 28 | 0;
    var $634 = HEAP32[$633 >> 2];
    var $635 = $634;
    var $636 = $yyvsp_2 - 20 | 0;
    var $637 = HEAP32[$636 >> 2];
    var $638 = $637;
    var $639 = $yyvsp_2 - 12 | 0;
    var $640 = HEAP32[$639 >> 2];
    var $641 = $640;
    var $642 = HEAP32[$yyvsp_2 >> 2];
    var $643 = $642;
    var $644 = _stat4($635, $638, $641, $643);
    var $645 = $644 | 0;
    var $yyval_0 = $645;
    __label__ = 125;
    break;
   case 123:
    _PUTS(STRING_TABLE.__str83 | 0);
    var $647 = $yyvsp_2 - 24 | 0;
    var $648 = HEAP32[$647 >> 2];
    var $649 = $648;
    var $650 = $yyvsp_2 - 12 | 0;
    var $651 = HEAP32[$650 >> 2];
    var $652 = $651;
    var $653 = HEAP32[$yyvsp_2 >> 2];
    var $654 = $653;
    var $655 = _stat4($649, 0, $652, $654);
    var $656 = $655 | 0;
    var $yyval_0 = $656;
    __label__ = 125;
    break;
   case 124:
    _PUTS(STRING_TABLE.__str84 | 0);
    var $658 = $yyvsp_2 - 20 | 0;
    var $659 = HEAP32[$658 >> 2];
    var $660 = $659;
    var $661 = $yyvsp_2 - 12 | 0;
    var $662 = HEAP32[$661 >> 2];
    var $663 = $662;
    var $664 = HEAP32[$yyvsp_2 >> 2];
    var $665 = $664;
    var $666 = _stat3(294, $660, $663, $665);
    var $667 = $666 | 0;
    var $yyval_0 = $667;
    __label__ = 125;
    break;
   case 125:
    var $yyval_0;
    var $669 = -$90 | 0;
    var $670 = $yyssp_2 + ($669 << 1) | 0;
    HEAP32[$92 >> 2] = $yyval_0;
    var $671 = STRING_TABLE._yyr1 + $yyn_0 | 0;
    var $672 = HEAP8[$671];
    var $673 = $672 & 255;
    var $674 = $673 - 97 | 0;
    var $675 = _yypgoto + ($674 << 1) | 0;
    var $676 = HEAP16[$675 >> 1];
    var $677 = $676 << 16 >> 16;
    var $678 = HEAP16[$670 >> 1];
    var $679 = $678 << 16 >> 16;
    var $680 = $679 + $677 | 0;
    var $681 = $680 >>> 0 < 1726;
    if ($681) {
      __label__ = 126;
      break;
    } else {
      __label__ = 128;
      break;
    }
   case 126:
    var $683 = _yycheck + ($680 << 1) | 0;
    var $684 = HEAP16[$683 >> 1];
    var $685 = $684 << 16 >> 16 == $678 << 16 >> 16;
    if ($685) {
      __label__ = 127;
      break;
    } else {
      __label__ = 128;
      break;
    }
   case 127:
    var $687 = _yytable + ($680 << 1) | 0;
    var $688 = HEAP16[$687 >> 1];
    var $689 = $688 << 16 >> 16;
    var $yystate_0 = $689;
    var $yyerrstatus_0 = $yyerrstatus_1;
    var $yyssp_0 = $670;
    var $yyvsp_0 = $92;
    __label__ = 3;
    break;
   case 128:
    var $691 = _yydefgoto + ($674 << 1) | 0;
    var $692 = HEAP16[$691 >> 1];
    var $693 = $692 << 16 >> 16;
    var $yystate_0 = $693;
    var $yyerrstatus_0 = $yyerrstatus_1;
    var $yyssp_0 = $670;
    var $yyvsp_0 = $92;
    __label__ = 3;
    break;
   case 129:
    var $695 = HEAP32[_yychar >> 2];
    if (($yyerrstatus_1 | 0) == 0) {
      __label__ = 130;
      break;
    } else if (($yyerrstatus_1 | 0) == 3) {
      __label__ = 131;
      break;
    } else {
      var $yyssp_3 = $yyssp_2;
      var $yyvsp_3 = $yyvsp_2;
      var $704 = $44;
      __label__ = 134;
      break;
    }
   case 130:
    var $697 = HEAP32[_yynerrs >> 2];
    var $698 = $697 + 1 | 0;
    HEAP32[_yynerrs >> 2] = $698;
    _yyerror(STRING_TABLE.__str2275 | 0);
    var $yyssp_3 = $yyssp_2;
    var $yyvsp_3 = $yyvsp_2;
    var $704 = $44;
    __label__ = 134;
    break;
   case 131:
    var $700 = ($695 | 0) < 1;
    if ($700) {
      __label__ = 132;
      break;
    } else {
      __label__ = 133;
      break;
    }
   case 132:
    var $702 = ($695 | 0) == 0;
    if ($702) {
      var $yyss_3 = $yyss_1;
      __label__ = 142;
      break;
    } else {
      var $yyssp_3 = $yyssp_2;
      var $yyvsp_3 = $yyvsp_2;
      var $704 = $44;
      __label__ = 134;
      break;
    }
   case 133:
    HEAP32[_yychar >> 2] = -2;
    var $yyssp_3 = $yyssp_2;
    var $yyvsp_3 = $yyvsp_2;
    var $704 = $44;
    __label__ = 134;
    break;
   case 134:
    var $704;
    var $yyvsp_3;
    var $yyssp_3;
    var $705 = $704 << 16 >> 16 == -106;
    if ($705) {
      __label__ = 138;
      break;
    } else {
      __label__ = 135;
      break;
    }
   case 135:
    var $707 = $704 << 16 >> 16;
    var $708 = $707 + 1 | 0;
    var $709 = $708 >>> 0 < 1726;
    if ($709) {
      __label__ = 136;
      break;
    } else {
      __label__ = 138;
      break;
    }
   case 136:
    var $711 = _yycheck + ($708 << 1) | 0;
    var $712 = HEAP16[$711 >> 1];
    var $713 = $712 << 16 >> 16 == 1;
    if ($713) {
      __label__ = 137;
      break;
    } else {
      __label__ = 138;
      break;
    }
   case 137:
    var $715 = _yytable + ($708 << 1) | 0;
    var $716 = HEAP16[$715 >> 1];
    var $717 = $716 << 16 >> 16 > 0;
    if ($717) {
      __label__ = 140;
      break;
    } else {
      __label__ = 138;
      break;
    }
   case 138:
    var $719 = ($yyssp_3 | 0) == ($yyss_1 | 0);
    if ($719) {
      var $yyss_3 = $yyss_1;
      __label__ = 142;
      break;
    } else {
      __label__ = 139;
      break;
    }
   case 139:
    var $721 = $yyvsp_3 - 4 | 0;
    var $722 = $yyssp_3 - 2 | 0;
    var $723 = HEAP16[$722 >> 1];
    var $724 = $723 << 16 >> 16;
    var $_phi_trans_insert = _yypact + ($724 << 1) | 0;
    var $_pre = HEAP16[$_phi_trans_insert >> 1];
    var $yyssp_3 = $722;
    var $yyvsp_3 = $721;
    var $704 = $_pre;
    __label__ = 134;
    break;
   case 140:
    var $726 = $716 << 16 >> 16;
    var $727 = HEAP32[_yylval >> 2];
    var $728 = $yyvsp_3 + 4 | 0;
    HEAP32[$728 >> 2] = $727;
    var $yystate_0 = $726;
    var $yyerrstatus_0 = 3;
    var $yyssp_0 = $yyssp_3;
    var $yyvsp_0 = $728;
    __label__ = 3;
    break;
   case 141:
    _yyerror(STRING_TABLE.__str88 | 0);
    var $yyss_3 = $yyss_0;
    __label__ = 142;
    break;
   case 142:
    var $yyss_3;
    var $730 = ($yyss_3 | 0) == ($1 | 0);
    if ($730) {
      __label__ = 144;
      break;
    } else {
      __label__ = 143;
      break;
    }
   case 143:
    var $732 = $yyss_3;
    _free($732);
    __label__ = 144;
    break;
   case 144:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_yyparse["X"] = 1;
function _nullproc($agg_result, $a, $n) {
  var $1 = $agg_result;
  var $$emscripten$temp$0 = _true;
  var $2$1 = HEAP32[$$emscripten$temp$0 + 4 >> 2];
  HEAP32[$1 >> 2] = HEAP32[$$emscripten$temp$0 >> 2];
  HEAP32[$1 + 4 >> 2] = $2$1;
  return;
}
function _run() {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = __stackBase__;
    var $2 = HEAP32[_winner >> 2];
    _execute($1, $2);
    var $3 = HEAP32[_filenum >> 2];
    var $4 = ($3 | 0) > 0;
    if ($4) {
      var $i_01 = 0;
      var $5 = $3;
      __label__ = 3;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 3:
    var $5;
    var $i_01;
    var $6 = HEAP32[_files >> 2];
    var $7 = $6 + $i_01 * 12 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = ($8 | 0) == 0;
    if ($9) {
      var $17 = $5;
      __label__ = 6;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $11 = $6 + $i_01 * 12 + 4 | 0;
    var $12 = HEAP32[$11 >> 2];
    var $13 = ($12 | 0) == 124;
    if ($13) {
      __label__ = 5;
      break;
    } else {
      var $17 = $5;
      __label__ = 6;
      break;
    }
   case 5:
    var $15 = _pclose($8);
    var $_pre = HEAP32[_filenum >> 2];
    var $17 = $_pre;
    __label__ = 6;
    break;
   case 6:
    var $17;
    var $18 = $i_01 + 1 | 0;
    var $19 = ($18 | 0) < ($17 | 0);
    if ($19) {
      var $i_01 = $18;
      var $5 = $17;
      __label__ = 3;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _nodetoobj($agg_result, $a_0_1_val, $a_0_3_val) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $a_0_3_val;
    var $_b = HEAP8[_donefld_b];
    var $2 = $_b ^ 1;
    var $3 = $a_0_1_val << 24 >> 24 == 1;
    var $or_cond = $3 & $2;
    if ($or_cond) {
      __label__ = 3;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 3:
    var $5 = $1 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = ($6 | 0) == (_EMPTY | 0);
    if ($7) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    _fldbld();
    __label__ = 5;
    break;
   case 5:
    var $agg_result_0 = $agg_result | 0;
    HEAP8[$agg_result_0] = 0;
    var $agg_result_1 = $agg_result + 1 | 0;
    HEAP8[$agg_result_1] = $a_0_1_val;
    var $agg_result_2 = $agg_result + 4 | 0;
    HEAP32[$agg_result_2 >> 2] = $1;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _dopa2($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = __stackBase__ + 8;
    var $2 = _pairstack + ($n << 2) | 0;
    var $3 = HEAP32[$2 >> 2];
    var $4 = ($3 | 0) == 0;
    if ($4) {
      __label__ = 3;
      break;
    } else {
      var $16 = $3;
      __label__ = 6;
      break;
    }
   case 3:
    var $6 = HEAP32[$a >> 2];
    _execute($x, $6);
    var $7 = $x;
    var $8 = HEAP16[$7 >> 1];
    var $9 = $8 & 255;
    var $10 = $9 << 24 >> 24 == 2;
    var $11 = ($8 & 65535) >>> 8;
    var $12 = $11 & 255;
    var $13 = $12 << 24 >> 24 == 1;
    var $or_cond = $10 & $13;
    if ($or_cond) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    HEAP32[$2 >> 2] = 1;
    __label__ = 5;
    break;
   case 5:
    var $x_23 = $x + 4 | 0;
    var $x_23_val = HEAP32[$x_23 >> 2];
    _tempfree($9, $12, $x_23_val);
    var $_pr = HEAP32[$2 >> 2];
    var $16 = $_pr;
    __label__ = 6;
    break;
   case 6:
    var $16;
    var $17 = ($16 | 0) == 1;
    if ($17) {
      __label__ = 7;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 7:
    var $19 = $a + 4 | 0;
    var $20 = HEAP32[$19 >> 2];
    _execute($x, $20);
    var $21 = $x;
    var $22 = $x;
    var $23 = HEAP16[$22 >> 1];
    var $24 = $23 & 255;
    var $25 = $24 << 24 >> 24 == 2;
    var $26 = ($23 & 65535) >>> 8;
    var $27 = $26 & 255;
    var $28 = $27 << 24 >> 24 == 1;
    var $or_cond5 = $25 & $28;
    if ($or_cond5) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    HEAP32[$2 >> 2] = 0;
    __label__ = 9;
    break;
   case 9:
    var $x_2 = $x + 4 | 0;
    var $x_2_val = HEAP32[$x_2 >> 2];
    _tempfree($24, $27, $x_2_val);
    var $30 = $a + 8 | 0;
    var $31 = HEAP32[$30 >> 2];
    _execute($1, $31);
    var $32 = $1;
    var $st$7$0 = $32 | 0;
    var $33$0 = HEAP32[$st$7$0 >> 2];
    var $st$7$1 = $32 + 4 | 0;
    var $33$1 = HEAP32[$st$7$1 >> 2];
    var $st$11$0 = $21 | 0;
    HEAP32[$st$11$0 >> 2] = $33$0;
    var $st$11$1 = $21 + 4 | 0;
    HEAP32[$st$11$1 >> 2] = $33$1;
    var $34 = $agg_result;
    var $st$16$0 = $34 | 0;
    HEAP32[$st$16$0 >> 2] = $33$0;
    var $st$16$1 = $34 + 4 | 0;
    HEAP32[$st$16$1 >> 2] = $33$1;
    __label__ = 11;
    break;
   case 10:
    var $36 = $agg_result;
    var $$emscripten$temp$0 = _false;
    var $st$2$0 = $$emscripten$temp$0 | 0;
    var $37$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$0 + 4 | 0;
    var $37$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $36 | 0;
    HEAP32[$st$6$0 >> 2] = $37$0;
    var $st$6$1 = $36 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $37$1;
    __label__ = 11;
    break;
   case 11:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_dopa2["X"] = 1;
function _tempfree($a_0, $a_1, $a_2) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $a_0 << 24 >> 24 == 0;
    var $2 = $a_1 << 24 >> 24 == 4;
    var $or_cond4 = $1 & $2;
    if ($or_cond4) {
      __label__ = 3;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 3:
    var $4 = $a_2 + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = ($5 | 0) == 0;
    var $7 = ($5 | 0) == (_EMPTY | 0);
    var $or_cond = $6 | $7;
    if ($or_cond) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    _free($5);
    __label__ = 5;
    break;
   case 5:
    HEAP32[$4 >> 2] = _EMPTY | 0;
    var $10 = $a_2 + 16 | 0;
    HEAP32[$10 >> 2] = 0;
    __label__ = 6;
    break;
   case 6:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _xxgetline($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var $1 = __stackBase__;
  _gettemp($1);
  var $2 = $1;
  var $srcval1$0 = HEAP32[$2 >> 2];
  var $srcval1$1 = HEAP32[$2 + 4 >> 2];
  _setfval($srcval1$1, _getrec() | 0);
  var $8 = $agg_result;
  HEAP32[$8 >> 2] = $srcval1$0;
  HEAP32[$8 + 4 >> 2] = $srcval1$1;
  STACKTOP = __stackBase__;
  return;
}
function _array($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var $x = __stackBase__;
  _execute($x, HEAP32[$a + 4 >> 2]);
  var $5 = HEAP16[$x >> 1];
  var $6 = $5 & 255;
  var $8 = ($5 & 65535) >>> 8 & 255;
  var $x_23_val = HEAP32[$x + 4 >> 2];
  _arrayel($agg_result, HEAP32[$a >> 2], $6, $8, $x_23_val);
  _tempfree($6, $8, $x_23_val);
  STACKTOP = __stackBase__;
  return;
}
function _arrayel($agg_result, $a, $b_0, $b_1, $b_2) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _getsval($b_2);
    var $2 = $a + 16 | 0;
    var $3 = $2;
    var $4 = HEAP32[$3 >> 2];
    var $5 = $4 & 16;
    var $6 = ($5 | 0) == 0;
    var $7 = $a + 4 | 0;
    if ($6) {
      __label__ = 3;
      break;
    } else {
      var $_pre_phi = $7;
      __label__ = 6;
      break;
    }
   case 3:
    var $9 = HEAP32[$7 >> 2];
    var $10 = $9 | 0;
    var $11 = ($9 | 0) == 0;
    var $12 = ($10 | 0) == (_EMPTY | 0);
    var $or_cond = $11 | $12;
    if ($or_cond) {
      var $15 = $4;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    _free($10);
    var $_pre = HEAP32[$3 >> 2];
    var $15 = $_pre;
    __label__ = 5;
    break;
   case 5:
    var $15;
    HEAP32[$7 >> 2] = _EMPTY;
    var $16 = $15 & -18;
    var $17 = $16 | 16;
    HEAP32[$3 >> 2] = $17;
    var $18 = _makesymtab();
    var $_c = $18;
    HEAP32[$7 >> 2] = $_c;
    var $_pre_phi = $7;
    __label__ = 6;
    break;
   case 6:
    var $_pre_phi;
    var $19 = _tostring(__str2320 | 0);
    var $20 = HEAP32[$_pre_phi >> 2];
    var $21 = $20;
    var $22 = _setsymtab($1, $19, 0, 3, $21);
    var $agg_result_0 = $agg_result | 0;
    HEAP8[$agg_result_0] = 0;
    var $agg_result_1 = $agg_result + 1 | 0;
    HEAP8[$agg_result_1] = 2;
    var $agg_result_2 = $agg_result + 4 | 0;
    HEAP32[$agg_result_2 >> 2] = $22;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _matchop($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    _execute($x, $1);
    var $2 = $x + 4 | 0;
    var $3 = HEAP32[$2 >> 2];
    var $4 = $3 + 16 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = $5 & 1;
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $9 = $3 + 4 | 0;
    var $10 = HEAP32[$9 >> 2];
    var $s_0 = $10;
    __label__ = 5;
    break;
   case 4:
    var $12 = _getsval($3);
    var $s_0 = $12;
    __label__ = 5;
    break;
   case 5:
    var $s_0;
    var $14 = $x;
    var $x_0_val = HEAP16[$14 >> 1];
    var $15 = $x_0_val & 255;
    var $16 = ($x_0_val & 65535) >>> 8;
    var $17 = $16 & 255;
    _tempfree($15, $17, $3);
    var $18 = $a + 4 | 0;
    var $19 = HEAP32[$18 >> 2];
    var $20 = $19 | 0;
    var $21 = _match($20, $s_0);
    var $22 = ($n | 0) == 267;
    var $23 = ($21 | 0) == 1;
    var $or_cond = $22 & $23;
    if ($or_cond) {
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $25 = ($n | 0) == 268;
    var $26 = ($21 | 0) == 0;
    var $or_cond1 = $25 & $26;
    if ($or_cond1) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $28 = $agg_result;
    var $$emscripten$temp$0 = _true;
    var $st$2$0 = $$emscripten$temp$0 | 0;
    var $29$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$0 + 4 | 0;
    var $29$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $28 | 0;
    HEAP32[$st$6$0 >> 2] = $29$0;
    var $st$6$1 = $28 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $29$1;
    __label__ = 9;
    break;
   case 8:
    var $31 = $agg_result;
    var $$emscripten$temp$1 = _false;
    var $st$2$0 = $$emscripten$temp$1 | 0;
    var $32$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$1 + 4 | 0;
    var $32$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $31 | 0;
    HEAP32[$st$6$0 >> 2] = $32$0;
    var $st$6$1 = $31 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $32$1;
    __label__ = 9;
    break;
   case 9:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_matchop["X"] = 1;
function _indirect($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var $x = __stackBase__;
  _execute($x, HEAP32[$a >> 2]);
  var $2 = $x;
  var $3 = $x + 4 | 0;
  var $4 = HEAP32[$3 >> 2];
  var $6 = _getfval($4) & -1;
  var $x_0_val = HEAP16[$x >> 1];
  _tempfree($x_0_val & 255, ($x_0_val & 65535) >>> 8 & 255, $4);
  HEAP32[$3 >> 2] = _fieldadr($6);
  HEAP8[$x | 0] = 0;
  HEAP8[$x + 1 | 0] = 1;
  var $12 = $agg_result;
  var $13$1 = HEAP32[$2 + 4 >> 2];
  HEAP32[$12 >> 2] = HEAP32[$2 >> 2];
  HEAP32[$12 + 4 >> 2] = $13$1;
  STACKTOP = __stackBase__;
  return;
}
function _execute($agg_result, $u) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = ($u | 0) == 0;
    if ($1) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $2 = $x;
    var $3 = $x + 1 | 0;
    var $4 = $x | 0;
    var $5 = $x + 4 | 0;
    var $a_0 = $u;
    __label__ = 5;
    break;
   case 4:
    var $7 = $agg_result;
    var $$emscripten$temp$0 = _true;
    var $st$2$0 = $$emscripten$temp$0 | 0;
    var $8$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$0 + 4 | 0;
    var $8$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $7 | 0;
    HEAP32[$st$6$0 >> 2] = $8$0;
    var $st$6$1 = $7 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $8$1;
    __label__ = 23;
    break;
   case 5:
    var $a_0;
    var $10 = $a_0 | 0;
    var $11 = HEAP8[$10];
    if ($11 << 24 >> 24 == 4) {
      __label__ = 6;
      break;
    } else if ($11 << 24 >> 24 == 1) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 6:
    var $_phi_trans_insert = $a_0 + 8 | 0;
    var $_pre = HEAP32[$_phi_trans_insert >> 2];
    var $proc_0 = 2;
    var $24 = $_pre;
    __label__ = 11;
    break;
   case 7:
    var $a_0_idx = $a_0 + 1 | 0;
    var $a_0_idx_val = HEAP8[$a_0_idx];
    var $a_0_idx1 = $a_0 + 8 | 0;
    var $a_0_idx1_val = HEAP32[$a_0_idx1 >> 2];
    _nodetoobj($agg_result, $a_0_idx_val, $a_0_idx1_val);
    __label__ = 23;
    break;
   case 8:
    var $14 = $a_0 + 8 | 0;
    var $15 = HEAP32[$14 >> 2];
    var $_off = $15 - 259 | 0;
    var $16 = $_off >>> 0 > 75;
    if ($16) {
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $18 = $15 - 258 | 0;
    var $19 = _proctab + ($18 << 2) | 0;
    var $20 = HEAP32[$19 >> 2];
    var $21 = ($20 | 0) == (4 | 0);
    if ($21) {
      __label__ = 10;
      break;
    } else {
      var $proc_0 = $20;
      var $24 = $15;
      __label__ = 11;
      break;
    }
   case 10:
    _error(STRING_TABLE.__str92 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $a_0, tempInt));
   case 11:
    var $24;
    var $proc_0;
    var $25 = $a_0 + 12 | 0;
    FUNCTION_TABLE[$proc_0]($x, $25, $24);
    var $_b = HEAP8[_donefld_b];
    if ($_b) {
      __label__ = 16;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $27 = HEAP8[$3];
    var $28 = $27 << 24 >> 24 == 1;
    if ($28) {
      __label__ = 13;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 13:
    var $30 = HEAP8[$4];
    var $31 = $30 << 24 >> 24 == 0;
    if ($31) {
      __label__ = 14;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 14:
    var $33 = HEAP32[$5 >> 2];
    var $34 = $33 | 0;
    var $35 = HEAP32[$34 >> 2];
    var $36 = ($35 | 0) == (_EMPTY | 0);
    if ($36) {
      __label__ = 15;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 15:
    _fldbld();
    __label__ = 16;
    break;
   case 16:
    var $39 = HEAP8[$10];
    var $40 = $39 << 24 >> 24 == 3;
    if ($40) {
      __label__ = 17;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 17:
    var $42 = $agg_result;
    var $st$1$0 = $2 | 0;
    var $43$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $2 + 4 | 0;
    var $43$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $42 | 0;
    HEAP32[$st$5$0 >> 2] = $43$0;
    var $st$5$1 = $42 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $43$1;
    __label__ = 23;
    break;
   case 18:
    var $45 = $x;
    var $46 = HEAP16[$45 >> 1];
    var $47 = $46 & 255;
    var $48 = $47 << 24 >> 24 == 3;
    var $49 = ($46 & 65535) >>> 8;
    var $50 = $49 & 255;
    if ($48) {
      __label__ = 19;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 19:
    var $52 = $agg_result;
    var $st$1$0 = $2 | 0;
    var $53$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $2 + 4 | 0;
    var $53$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $52 | 0;
    HEAP32[$st$5$0 >> 2] = $53$0;
    var $st$5$1 = $52 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $53$1;
    __label__ = 23;
    break;
   case 20:
    var $55 = $a_0 + 4 | 0;
    var $56 = HEAP32[$55 >> 2];
    var $57 = ($56 | 0) == 0;
    if ($57) {
      __label__ = 21;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 21:
    var $59 = $agg_result;
    var $st$1$0 = $2 | 0;
    var $60$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $2 + 4 | 0;
    var $60$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $59 | 0;
    HEAP32[$st$5$0 >> 2] = $60$0;
    var $st$5$1 = $59 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $60$1;
    __label__ = 23;
    break;
   case 22:
    var $x_2_val = HEAP32[$5 >> 2];
    _tempfree($47, $50, $x_2_val);
    var $62 = HEAP32[$55 >> 2];
    var $a_0 = $62;
    __label__ = 5;
    break;
   case 23:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_execute["X"] = 1;
function _program($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $_pre7 = $x | 0;
    var $x_23_pre = $x + 4 | 0;
    var $_pre_phi8 = $_pre7;
    var $x_23_pre_phi = $x_23_pre;
    __label__ = 9;
    break;
   case 4:
    _execute($x, $1);
    var $4 = $x | 0;
    var $5 = $x;
    var $6 = HEAP16[$5 >> 1];
    var $7 = $6 & 255;
    var $8 = $7 << 24 >> 24 == 3;
    var $9 = ($6 & 65535) >>> 8;
    var $10 = $9 & 255;
    if ($8) {
      __label__ = 5;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 5:
    var $12 = $10 << 24 >> 24 == 1;
    if ($12) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    var $14 = $agg_result;
    var $$emscripten$temp$0 = _true;
    var $st$2$0 = $$emscripten$temp$0 | 0;
    var $15$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$0 + 4 | 0;
    var $15$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $14 | 0;
    HEAP32[$st$6$0 >> 2] = $15$0;
    var $st$6$1 = $14 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $15$1;
    __label__ = 19;
    break;
   case 7:
    _error(STRING_TABLE.__str193 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 8:
    var $x_26 = $x + 4 | 0;
    var $x_26_val = HEAP32[$x_26 >> 2];
    _tempfree($7, $10, $x_26_val);
    var $_pre_phi8 = $4;
    var $x_23_pre_phi = $x_26;
    __label__ = 9;
    break;
   case 9:
    var $x_23_pre_phi;
    var $_pre_phi8;
    var $17 = $a + 4 | 0;
    __label__ = 10;
    break;
   case 10:
    var $19 = _getrec();
    var $20 = ($19 | 0) == 0;
    if ($20) {
      __label__ = 13;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $22 = HEAP32[$17 >> 2];
    _execute($x, $22);
    var $23 = $_pre_phi8;
    var $24 = HEAP16[$23 >> 1];
    var $25 = $24 & 255;
    var $26 = $25 << 24 >> 24 == 3;
    var $27 = ($24 & 65535) >>> 8;
    var $28 = $27 & 255;
    var $29 = $28 << 24 >> 24 == 1;
    var $or_cond = $26 & $29;
    if ($or_cond) {
      __label__ = 13;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $x_23_val = HEAP32[$x_23_pre_phi >> 2];
    _tempfree($25, $28, $x_23_val);
    __label__ = 10;
    break;
   case 13:
    var $32 = $a + 8 | 0;
    var $33 = HEAP32[$32 >> 2];
    var $34 = ($33 | 0) == 0;
    if ($34) {
      __label__ = 18;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    _execute($x, $33);
    var $36 = $_pre_phi8;
    var $37 = HEAP16[$36 >> 1];
    var $38 = $37 & 255;
    var $39 = $38 << 24 >> 24 == 3;
    var $40 = ($37 & 65535) >>> 8;
    var $41 = $40 & 255;
    if ($39) {
      __label__ = 15;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 15:
    var $_off = $41 - 2 & 255;
    var $switch = ($_off & 255) < 3;
    if ($switch) {
      __label__ = 16;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 16:
    _error(STRING_TABLE.__str193 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 17:
    var $x_2_val = HEAP32[$x_23_pre_phi >> 2];
    _tempfree($38, $41, $x_2_val);
    __label__ = 18;
    break;
   case 18:
    var $45 = $agg_result;
    var $$emscripten$temp$1 = _true;
    var $st$2$0 = $$emscripten$temp$1 | 0;
    var $46$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$1 + 4 | 0;
    var $46$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $45 | 0;
    HEAP32[$st$6$0 >> 2] = $46$0;
    var $st$6$1 = $45 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $46$1;
    __label__ = 19;
    break;
   case 19:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_program["X"] = 1;
function _gettemp($agg_result) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $i_0 = 0;
    __label__ = 3;
    break;
   case 3:
    var $i_0;
    var $2 = ($i_0 | 0) < 20;
    if ($2) {
      __label__ = 4;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 4:
    var $4 = _tmps + $i_0 * 24 + 16 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = ($5 | 0) == 0;
    if ($6) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $8 = $i_0 + 1 | 0;
    var $i_0 = $8;
    __label__ = 3;
    break;
   case 6:
    var $10 = ($i_0 | 0) == 20;
    if ($10) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    _error(STRING_TABLE.__str597 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 8:
    var $13 = _tmps + $i_0 * 24 | 0;
    var $14 = $13;
    HEAP32[$14 >> 2] = HEAP32[_nullval >> 2];
    HEAP32[$14 + 4 >> 2] = HEAP32[_nullval + 4 >> 2];
    HEAP32[$14 + 8 >> 2] = HEAP32[_nullval + 8 >> 2];
    HEAP32[$14 + 12 >> 2] = HEAP32[_nullval + 12 >> 2];
    HEAP32[$14 + 16 >> 2] = HEAP32[_nullval + 16 >> 2];
    HEAP32[$14 + 20 >> 2] = HEAP32[_nullval + 20 >> 2];
    var $agg_result_0 = $agg_result | 0;
    HEAP8[$agg_result_0] = 0;
    var $agg_result_1 = $agg_result + 1 | 0;
    HEAP8[$agg_result_1] = 4;
    var $agg_result_2 = $agg_result + 4 | 0;
    HEAP32[$agg_result_2 >> 2] = $13;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _boolop($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $y = __stackBase__ + 8;
    var $0 = HEAP32[$a >> 2];
    _execute($x, $0);
    var $1 = $x;
    var $2 = HEAP16[$1 >> 1];
    var $3 = $2 & 255;
    var $4 = $3 << 24 >> 24 == 2;
    var $5 = ($2 & 65535) >>> 8;
    var $6 = $5 & 255;
    var $7 = $6 << 24 >> 24 == 1;
    var $8 = $4 ? $7 : 0;
    var $x_2 = $x + 4 | 0;
    var $x_2_val = HEAP32[$x_2 >> 2];
    _tempfree($3, $6, $x_2_val);
    if (($n | 0) == 304) {
      __label__ = 4;
      break;
    } else if (($n | 0) == 305) {
      __label__ = 11;
      break;
    } else if (($n | 0) == 306) {
      __label__ = 18;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str395 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n, tempInt));
   case 4:
    if ($8) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $12 = $agg_result;
    var $$emscripten$temp$0 = _true;
    var $st$2$0 = $$emscripten$temp$0 | 0;
    var $13$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$0 + 4 | 0;
    var $13$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $12 | 0;
    HEAP32[$st$6$0 >> 2] = $13$0;
    var $st$6$1 = $12 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $13$1;
    __label__ = 21;
    break;
   case 6:
    var $15 = $a + 4 | 0;
    var $16 = HEAP32[$15 >> 2];
    _execute($y, $16);
    var $17 = $y;
    var $18 = HEAP16[$17 >> 1];
    var $19 = $18 & 255;
    var $20 = $19 << 24 >> 24 == 2;
    var $21 = ($18 & 65535) >>> 8;
    var $22 = $21 & 255;
    if ($20) {
      __label__ = 8;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $y_29 = $y + 4 | 0;
    var $y_29_val = HEAP32[$y_29 >> 2];
    _tempfree($19, $22, $y_29_val);
    var $23 = $agg_result;
    var $30 = $23;
    __label__ = 10;
    break;
   case 8:
    var $25 = $22 << 24 >> 24 == 1;
    var $y_26 = $y + 4 | 0;
    var $y_26_val = HEAP32[$y_26 >> 2];
    _tempfree(2, $22, $y_26_val);
    var $26 = $agg_result;
    if ($25) {
      __label__ = 9;
      break;
    } else {
      var $30 = $26;
      __label__ = 10;
      break;
    }
   case 9:
    var $$emscripten$temp$1 = _true;
    var $st$1$0 = $$emscripten$temp$1 | 0;
    var $28$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$1 + 4 | 0;
    var $28$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $26 | 0;
    HEAP32[$st$5$0 >> 2] = $28$0;
    var $st$5$1 = $26 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $28$1;
    __label__ = 21;
    break;
   case 10:
    var $30;
    var $$emscripten$temp$2 = _false;
    var $st$2$0 = $$emscripten$temp$2 | 0;
    var $31$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$2 + 4 | 0;
    var $31$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $30 | 0;
    HEAP32[$st$6$0 >> 2] = $31$0;
    var $st$6$1 = $30 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $31$1;
    __label__ = 21;
    break;
   case 11:
    if ($8) {
      __label__ = 13;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $34 = $agg_result;
    var $$emscripten$temp$3 = _false;
    var $st$2$0 = $$emscripten$temp$3 | 0;
    var $35$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$3 + 4 | 0;
    var $35$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $34 | 0;
    HEAP32[$st$6$0 >> 2] = $35$0;
    var $st$6$1 = $34 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $35$1;
    __label__ = 21;
    break;
   case 13:
    var $37 = $a + 4 | 0;
    var $38 = HEAP32[$37 >> 2];
    _execute($y, $38);
    var $39 = $y;
    var $40 = HEAP16[$39 >> 1];
    var $41 = $40 & 255;
    var $42 = $41 << 24 >> 24 == 2;
    var $43 = ($40 & 65535) >>> 8;
    var $44 = $43 & 255;
    if ($42) {
      __label__ = 15;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $y_23 = $y + 4 | 0;
    var $y_23_val = HEAP32[$y_23 >> 2];
    _tempfree($41, $44, $y_23_val);
    var $45 = $agg_result;
    var $52 = $45;
    __label__ = 17;
    break;
   case 15:
    var $47 = $44 << 24 >> 24 == 1;
    var $y_2 = $y + 4 | 0;
    var $y_2_val = HEAP32[$y_2 >> 2];
    _tempfree(2, $44, $y_2_val);
    var $48 = $agg_result;
    if ($47) {
      __label__ = 16;
      break;
    } else {
      var $52 = $48;
      __label__ = 17;
      break;
    }
   case 16:
    var $$emscripten$temp$4 = _true;
    var $st$1$0 = $$emscripten$temp$4 | 0;
    var $50$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$4 + 4 | 0;
    var $50$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $48 | 0;
    HEAP32[$st$5$0 >> 2] = $50$0;
    var $st$5$1 = $48 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $50$1;
    __label__ = 21;
    break;
   case 17:
    var $52;
    var $$emscripten$temp$5 = _false;
    var $st$2$0 = $$emscripten$temp$5 | 0;
    var $53$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$5 + 4 | 0;
    var $53$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $52 | 0;
    HEAP32[$st$6$0 >> 2] = $53$0;
    var $st$6$1 = $52 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $53$1;
    __label__ = 21;
    break;
   case 18:
    var $55 = $agg_result;
    if ($8) {
      __label__ = 19;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 19:
    var $$emscripten$temp$6 = _false;
    var $st$1$0 = $$emscripten$temp$6 | 0;
    var $57$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$6 + 4 | 0;
    var $57$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $55 | 0;
    HEAP32[$st$5$0 >> 2] = $57$0;
    var $st$5$1 = $55 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $57$1;
    __label__ = 21;
    break;
   case 20:
    var $$emscripten$temp$7 = _true;
    var $st$1$0 = $$emscripten$temp$7 | 0;
    var $59$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$7 + 4 | 0;
    var $59$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $55 | 0;
    HEAP32[$st$5$0 >> 2] = $59$0;
    var $st$5$1 = $55 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $59$1;
    __label__ = 21;
    break;
   case 21:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_boolop["X"] = 1;
function _relop($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $y = __stackBase__ + 8;
    var $1 = HEAP32[$a >> 2];
    _execute($x, $1);
    var $2 = $a + 4 | 0;
    var $3 = HEAP32[$2 >> 2];
    _execute($y, $3);
    var $4 = $x + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = $5 + 16 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = $7 & 2;
    var $9 = ($8 | 0) == 0;
    var $_phi_trans_insert = $y + 4 | 0;
    var $_pre = HEAP32[$_phi_trans_insert >> 2];
    if ($9) {
      var $25 = $_pre;
      __label__ = 6;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $11 = $_pre + 16 | 0;
    var $12 = HEAP32[$11 >> 2];
    var $13 = $12 & 2;
    var $14 = ($13 | 0) == 0;
    if ($14) {
      var $25 = $_pre;
      __label__ = 6;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $16 = $5 + 8 | 0;
    var $17 = (tempDoubleI32[0] = HEAP32[$16 >> 2], tempDoubleI32[1] = HEAP32[$16 + 4 >> 2], tempDoubleF64[0]);
    var $18 = $_pre + 8 | 0;
    var $19 = (tempDoubleI32[0] = HEAP32[$18 >> 2], tempDoubleI32[1] = HEAP32[$18 + 4 >> 2], tempDoubleF64[0]);
    var $20 = $17 - $19;
    var $21 = $20 < 0;
    if ($21) {
      var $i_0 = -1;
      var $y_2_val = $_pre;
      __label__ = 7;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $23 = $20 > 0;
    var $24 = $23 & 1;
    var $i_0 = $24;
    var $y_2_val = $_pre;
    __label__ = 7;
    break;
   case 6:
    var $25;
    var $26 = _getsval($5);
    var $27 = _getsval($25);
    var $28 = _strcoll($26, $27);
    var $i_0 = $28;
    var $y_2_val = $25;
    __label__ = 7;
    break;
   case 7:
    var $y_2_val;
    var $i_0;
    var $30 = $x;
    var $x_0_val = HEAP16[$30 >> 1];
    var $31 = $x_0_val & 255;
    var $32 = ($x_0_val & 65535) >>> 8;
    var $33 = $32 & 255;
    _tempfree($31, $33, $5);
    var $34 = $y;
    var $y_0_val = HEAP16[$34 >> 1];
    var $35 = $y_0_val & 255;
    var $36 = ($y_0_val & 65535) >>> 8;
    var $37 = $36 & 255;
    _tempfree($35, $37, $y_2_val);
    if (($n | 0) == 261) {
      __label__ = 9;
      break;
    } else if (($n | 0) == 262) {
      __label__ = 12;
      break;
    } else if (($n | 0) == 266) {
      __label__ = 15;
      break;
    } else if (($n | 0) == 265) {
      __label__ = 18;
      break;
    } else if (($n | 0) == 264) {
      __label__ = 21;
      break;
    } else if (($n | 0) == 263) {
      __label__ = 24;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    _error(STRING_TABLE.__str496 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n, tempInt));
   case 9:
    var $40 = ($i_0 | 0) < 0;
    var $41 = $agg_result;
    if ($40) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    var $$emscripten$temp$0 = _true;
    var $st$1$0 = $$emscripten$temp$0 | 0;
    var $43$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$0 + 4 | 0;
    var $43$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $41 | 0;
    HEAP32[$st$5$0 >> 2] = $43$0;
    var $st$5$1 = $41 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $43$1;
    __label__ = 27;
    break;
   case 11:
    var $$emscripten$temp$1 = _false;
    var $st$1$0 = $$emscripten$temp$1 | 0;
    var $45$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$1 + 4 | 0;
    var $45$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $41 | 0;
    HEAP32[$st$5$0 >> 2] = $45$0;
    var $st$5$1 = $41 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $45$1;
    __label__ = 27;
    break;
   case 12:
    var $47 = ($i_0 | 0) < 1;
    var $48 = $agg_result;
    if ($47) {
      __label__ = 13;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 13:
    var $$emscripten$temp$2 = _true;
    var $st$1$0 = $$emscripten$temp$2 | 0;
    var $50$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$2 + 4 | 0;
    var $50$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $48 | 0;
    HEAP32[$st$5$0 >> 2] = $50$0;
    var $st$5$1 = $48 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $50$1;
    __label__ = 27;
    break;
   case 14:
    var $$emscripten$temp$3 = _false;
    var $st$1$0 = $$emscripten$temp$3 | 0;
    var $52$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$3 + 4 | 0;
    var $52$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $48 | 0;
    HEAP32[$st$5$0 >> 2] = $52$0;
    var $st$5$1 = $48 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $52$1;
    __label__ = 27;
    break;
   case 15:
    var $54 = ($i_0 | 0) == 0;
    var $55 = $agg_result;
    if ($54) {
      __label__ = 17;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $$emscripten$temp$4 = _true;
    var $st$1$0 = $$emscripten$temp$4 | 0;
    var $57$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$4 + 4 | 0;
    var $57$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $55 | 0;
    HEAP32[$st$5$0 >> 2] = $57$0;
    var $st$5$1 = $55 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $57$1;
    __label__ = 27;
    break;
   case 17:
    var $$emscripten$temp$5 = _false;
    var $st$1$0 = $$emscripten$temp$5 | 0;
    var $59$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$5 + 4 | 0;
    var $59$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $55 | 0;
    HEAP32[$st$5$0 >> 2] = $59$0;
    var $st$5$1 = $55 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $59$1;
    __label__ = 27;
    break;
   case 18:
    var $61 = ($i_0 | 0) == 0;
    var $62 = $agg_result;
    if ($61) {
      __label__ = 19;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 19:
    var $$emscripten$temp$6 = _true;
    var $st$1$0 = $$emscripten$temp$6 | 0;
    var $64$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$6 + 4 | 0;
    var $64$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $62 | 0;
    HEAP32[$st$5$0 >> 2] = $64$0;
    var $st$5$1 = $62 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $64$1;
    __label__ = 27;
    break;
   case 20:
    var $$emscripten$temp$7 = _false;
    var $st$1$0 = $$emscripten$temp$7 | 0;
    var $66$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$7 + 4 | 0;
    var $66$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $62 | 0;
    HEAP32[$st$5$0 >> 2] = $66$0;
    var $st$5$1 = $62 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $66$1;
    __label__ = 27;
    break;
   case 21:
    var $68 = ($i_0 | 0) > -1;
    var $69 = $agg_result;
    if ($68) {
      __label__ = 22;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 22:
    var $$emscripten$temp$8 = _true;
    var $st$1$0 = $$emscripten$temp$8 | 0;
    var $71$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$8 + 4 | 0;
    var $71$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $69 | 0;
    HEAP32[$st$5$0 >> 2] = $71$0;
    var $st$5$1 = $69 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $71$1;
    __label__ = 27;
    break;
   case 23:
    var $$emscripten$temp$9 = _false;
    var $st$1$0 = $$emscripten$temp$9 | 0;
    var $73$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$9 + 4 | 0;
    var $73$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $69 | 0;
    HEAP32[$st$5$0 >> 2] = $73$0;
    var $st$5$1 = $69 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $73$1;
    __label__ = 27;
    break;
   case 24:
    var $75 = ($i_0 | 0) > 0;
    var $76 = $agg_result;
    if ($75) {
      __label__ = 25;
      break;
    } else {
      __label__ = 26;
      break;
    }
   case 25:
    var $$emscripten$temp$10 = _true;
    var $st$1$0 = $$emscripten$temp$10 | 0;
    var $78$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$10 + 4 | 0;
    var $78$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $76 | 0;
    HEAP32[$st$5$0 >> 2] = $78$0;
    var $st$5$1 = $76 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $78$1;
    __label__ = 27;
    break;
   case 26:
    var $$emscripten$temp$11 = _false;
    var $st$1$0 = $$emscripten$temp$11 | 0;
    var $80$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$11 + 4 | 0;
    var $80$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $76 | 0;
    HEAP32[$st$5$0 >> 2] = $80$0;
    var $st$5$1 = $76 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $80$1;
    __label__ = 27;
    break;
   case 27:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_relop["X"] = 1;
function _chrdist($s, $end) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_0 = $s;
    var $m_0 = 1;
    __label__ = 3;
    break;
   case 3:
    var $m_0;
    var $_0;
    var $2 = $_0 >>> 0 < $end >>> 0;
    if ($2) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    var $4 = $_0 + 1 | 0;
    var $5 = $m_0 + 1 | 0;
    var $_0 = $4;
    var $m_0 = $5;
    __label__ = 3;
    break;
   case 5:
    return $m_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _substr($agg_result, $a, $nnn) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    _execute($x, $1);
    var $2 = $x;
    var $3 = $x + 4 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = _getsval($4);
    var $6 = _strlen($5);
    var $7 = $6 + 1 | 0;
    var $8 = $x;
    var $x_08_val = HEAP16[$8 >> 1];
    var $9 = $x_08_val & 255;
    var $10 = ($x_08_val & 65535) >>> 8;
    var $11 = $10 & 255;
    _tempfree($9, $11, $4);
    var $12 = $a + 4 | 0;
    var $13 = HEAP32[$12 >> 2];
    _execute($x, $13);
    var $14 = HEAP32[$3 >> 2];
    var $15 = _getfval($14);
    var $16 = $15 & -1;
    var $17 = ($16 | 0) < 1;
    if ($17) {
      var $m_0 = 1;
      __label__ = 5;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $19 = ($16 | 0) > ($7 | 0);
    if ($19) {
      __label__ = 4;
      break;
    } else {
      var $m_0 = $16;
      __label__ = 5;
      break;
    }
   case 4:
    var $m_0 = $7;
    __label__ = 5;
    break;
   case 5:
    var $m_0;
    var $x_05_val = HEAP16[$8 >> 1];
    var $22 = $x_05_val & 255;
    var $23 = ($x_05_val & 65535) >>> 8;
    var $24 = $23 & 255;
    _tempfree($22, $24, $14);
    var $25 = $a + 8 | 0;
    var $26 = HEAP32[$25 >> 2];
    var $27 = ($26 | 0) == 0;
    if ($27) {
      var $n_0 = $6;
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    _execute($x, $26);
    var $29 = HEAP32[$3 >> 2];
    var $30 = _getfval($29);
    var $31 = $30 & -1;
    var $x_0_val = HEAP16[$8 >> 1];
    var $32 = $x_0_val & 255;
    var $33 = ($x_0_val & 65535) >>> 8;
    var $34 = $33 & 255;
    _tempfree($32, $34, $29);
    var $n_0 = $31;
    __label__ = 7;
    break;
   case 7:
    var $n_0;
    var $36 = ($n_0 | 0) < 0;
    if ($36) {
      var $n_1 = 0;
      __label__ = 10;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $38 = $7 - $m_0 | 0;
    var $39 = ($n_0 | 0) > ($38 | 0);
    if ($39) {
      __label__ = 9;
      break;
    } else {
      var $n_1 = $n_0;
      __label__ = 10;
      break;
    }
   case 9:
    var $n_1 = $38;
    __label__ = 10;
    break;
   case 10:
    var $n_1;
    var $_b1 = HEAP8[_dbg_b];
    if ($_b1) {
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 11:
    var $43 = _printf(STRING_TABLE.__str698 | 0, (tempInt = STACKTOP, STACKTOP += 12, HEAP32[tempInt >> 2] = $m_0, HEAP32[tempInt + 4 >> 2] = $n_1, HEAP32[tempInt + 8 >> 2] = $5, tempInt));
    __label__ = 12;
    break;
   case 12:
    _gettemp($x);
    var $45 = $m_0 - 1 | 0;
    var $46 = $45 + $n_1 | 0;
    var $47 = $5 + $46 | 0;
    var $48 = HEAP8[$47];
    HEAP8[$47] = 0;
    var $49 = HEAP32[$3 >> 2];
    var $50 = $5 + $45 | 0;
    _setsval($49, $50);
    HEAP8[$47] = $48;
    var $51 = $agg_result;
    var $st$11$0 = $2 | 0;
    var $52$0 = HEAP32[$st$11$0 >> 2];
    var $st$11$1 = $2 + 4 | 0;
    var $52$1 = HEAP32[$st$11$1 >> 2];
    var $st$15$0 = $51 | 0;
    HEAP32[$st$15$0 >> 2] = $52$0;
    var $st$15$1 = $51 + 4 | 0;
    HEAP32[$st$15$1 >> 2] = $52$1;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_substr["X"] = 1;
function _sindex($agg_result, $a, $nnn) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    _execute($x, $1);
    var $2 = $x;
    var $3 = $x + 4 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = _getsval($4);
    var $6 = $x;
    var $x_03_val = HEAP16[$6 >> 1];
    var $7 = $x_03_val & 255;
    var $8 = ($x_03_val & 65535) >>> 8;
    var $9 = $8 & 255;
    _tempfree($7, $9, $4);
    var $10 = $a + 4 | 0;
    var $11 = HEAP32[$10 >> 2];
    _execute($x, $11);
    var $12 = HEAP32[$3 >> 2];
    var $13 = _getsval($12);
    var $x_0_val = HEAP16[$6 >> 1];
    var $14 = $x_0_val & 255;
    var $15 = ($x_0_val & 65535) >>> 8;
    var $16 = $15 & 255;
    _tempfree($14, $16, $12);
    _gettemp($x);
    var $p1_0 = $5;
    __label__ = 3;
    break;
   case 3:
    var $p1_0;
    var $18 = HEAP8[$p1_0];
    var $phitmp = $18 << 24 >> 24 == 0;
    if ($phitmp) {
      __label__ = 9;
      break;
    } else {
      var $q_0 = $p1_0;
      var $p2_0 = $13;
      var $19 = $18;
      __label__ = 4;
      break;
    }
   case 4:
    var $19;
    var $p2_0;
    var $q_0;
    var $20 = HEAP8[$p2_0];
    var $21 = $20 << 24 >> 24 == 0;
    if ($21) {
      __label__ = 7;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $23 = $19 << 24 >> 24 == $20 << 24 >> 24;
    if ($23) {
      __label__ = 6;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 6:
    var $25 = $q_0 + 1 | 0;
    var $26 = $p2_0 + 1 | 0;
    var $_pre = HEAP8[$25];
    var $q_0 = $25;
    var $p2_0 = $26;
    var $19 = $_pre;
    __label__ = 4;
    break;
   case 7:
    var $27 = HEAP32[$3 >> 2];
    var $28 = _chrdist($5, $p1_0);
    var $29 = $28 | 0;
    _setfval($27, $29);
    var $30 = $agg_result;
    var $st$5$0 = $2 | 0;
    var $31$0 = HEAP32[$st$5$0 >> 2];
    var $st$5$1 = $2 + 4 | 0;
    var $31$1 = HEAP32[$st$5$1 >> 2];
    var $st$9$0 = $30 | 0;
    HEAP32[$st$9$0 >> 2] = $31$0;
    var $st$9$1 = $30 + 4 | 0;
    HEAP32[$st$9$1 >> 2] = $31$1;
    __label__ = 10;
    break;
   case 8:
    var $32 = $p1_0 + 1 | 0;
    var $p1_0 = $32;
    __label__ = 3;
    break;
   case 9:
    var $34 = HEAP32[$3 >> 2];
    _setfval($34, 0);
    var $35 = $agg_result;
    var $st$3$0 = $2 | 0;
    var $36$0 = HEAP32[$st$3$0 >> 2];
    var $st$3$1 = $2 + 4 | 0;
    var $36$1 = HEAP32[$st$3$1 >> 2];
    var $st$7$0 = $35 | 0;
    HEAP32[$st$7$0 >> 2] = $36$0;
    var $st$7$1 = $35 + 4 | 0;
    HEAP32[$st$7$1 >> 2] = $36$1;
    __label__ = 10;
    break;
   case 10:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_sindex["X"] = 1;
function _awsprintf($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var $x = __stackBase__;
  var $1 = HEAP32[$a >> 2];
  var $3 = HEAP32[$1 + 4 >> 2];
  _execute($x, $1);
  var $4 = $x;
  var $5 = $x + 4 | 0;
  var $6 = HEAP32[$5 >> 2];
  var $8 = _format(_getsval($6), $3);
  var $x_0_val = HEAP16[$x >> 1];
  _tempfree($x_0_val & 255, ($x_0_val & 65535) >>> 8 & 255, $6);
  _gettemp($x);
  var $13 = HEAP32[$5 >> 2];
  HEAP32[$13 + 4 >> 2] = $8;
  HEAP32[$13 + 16 >> 2] = 1;
  var $16 = $agg_result;
  var $17$1 = HEAP32[$4 + 4 >> 2];
  HEAP32[$16 >> 2] = HEAP32[$4 >> 2];
  HEAP32[$16 + 4 >> 2] = $17$1;
  STACKTOP = __stackBase__;
  return;
}
function _incrdecr($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = __stackBase__ + 8;
    var $2 = HEAP32[$a >> 2];
    _execute($x, $2);
    var $3 = $x;
    var $4 = $x + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = _getfval($5);
    var $7 = ($n | 0) == 331;
    if ($7) {
      var $10 = 1;
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $9 = ($n | 0) == 332;
    var $phitmp3 = $9 ? 1 : -1;
    var $cond = ($n | 0) == 329;
    if ($cond) {
      var $10 = $phitmp3;
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    var $10;
    var $11 = $6 + $10;
    _setfval($5, $11);
    var $12 = $agg_result;
    var $st$4$0 = $3 | 0;
    var $13$0 = HEAP32[$st$4$0 >> 2];
    var $st$4$1 = $3 + 4 | 0;
    var $13$1 = HEAP32[$st$4$1 >> 2];
    var $st$8$0 = $12 | 0;
    HEAP32[$st$8$0 >> 2] = $13$0;
    var $st$8$1 = $12 + 4 | 0;
    HEAP32[$st$8$1 >> 2] = $13$1;
    __label__ = 6;
    break;
   case 5:
    _gettemp($1);
    var $15 = $1;
    var $st$2$0 = $15 | 0;
    var $srcval2$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $15 + 4 | 0;
    var $srcval2$1 = HEAP32[$st$2$1 >> 2];
    var $16$0 = $srcval2$1;
    var $17$0 = $16$0;
    var $17 = $17$0;
    var $18 = $17;
    _setfval($18, $6);
    var $19 = $6 + $phitmp3;
    _setfval($5, $19);
    var $20 = $x;
    var $x_0_val = HEAP16[$20 >> 1];
    var $21 = $x_0_val & 255;
    var $22 = ($x_0_val & 65535) >>> 8;
    var $23 = $22 & 255;
    _tempfree($21, $23, $5);
    var $24 = $agg_result;
    var $st$21$0 = $24 | 0;
    HEAP32[$st$21$0 >> 2] = $srcval2$0;
    var $st$21$1 = $24 + 4 | 0;
    HEAP32[$st$21$1 >> 2] = $srcval2$1;
    __label__ = 6;
    break;
   case 6:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_incrdecr["X"] = 1;
function _cat($agg_result, $a, $q) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 24;
  var $x = __stackBase__;
  var $y = __stackBase__ + 8;
  var $1 = __stackBase__ + 16;
  _execute($x, HEAP32[$a >> 2]);
  _execute($y, HEAP32[$a + 4 >> 2]);
  var $5 = $x + 4 | 0;
  var $6 = HEAP32[$5 >> 2];
  _getsval($6);
  var $9 = HEAP32[$y + 4 >> 2];
  _getsval($9);
  var $11 = $6 + 4 | 0;
  var $13 = _strlen(HEAP32[$11 >> 2]);
  var $14 = $9 + 4 | 0;
  var $19 = _malloc($13 + 1 + _strlen(HEAP32[$14 >> 2]) | 0);
  _strcpy($19, HEAP32[$11 >> 2]);
  _strcpy($19 + $13 | 0, HEAP32[$14 >> 2]);
  var $y_0_val = HEAP16[$y >> 1];
  _tempfree($y_0_val & 255, ($y_0_val & 65535) >>> 8 & 255, $9);
  _gettemp($1);
  var $29 = $1;
  var $srcval1$0 = HEAP32[$29 >> 2];
  var $srcval1$1 = HEAP32[$29 + 4 >> 2];
  var $32 = $srcval1$1;
  HEAP32[$32 + 4 >> 2] = $19;
  HEAP32[$32 + 16 >> 2] = 1;
  var $x_0_val = HEAP16[$x >> 1];
  _tempfree($x_0_val & 255, ($x_0_val & 65535) >>> 8 & 255, HEAP32[$5 >> 2]);
  var $39 = $agg_result;
  HEAP32[$39 >> 2] = $srcval1$0;
  HEAP32[$39 + 4 >> 2] = $srcval1$1;
  STACKTOP = __stackBase__;
  return;
}
_cat["X"] = 1;
function _format($s, $a) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 32;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $p = __stackBase__;
    var $fmt = __stackBase__ + 4;
    var $t = __stackBase__ + 8;
    var $fmtsz = __stackBase__ + 12;
    var $x = __stackBase__ + 16;
    var $buf = __stackBase__ + 24;
    var $bufsz = __stackBase__ + 28;
    var $1 = HEAP32[_RECSIZE >> 2];
    var $2 = $1 + 1 | 0;
    HEAP32[$fmtsz >> 2] = $2;
    var $3 = _malloc($2);
    HEAP32[$fmt >> 2] = $3;
    var $4 = HEAP32[_RECSIZE >> 2];
    var $5 = $4 + 1 | 0;
    HEAP32[$bufsz >> 2] = $5;
    var $6 = _malloc($5);
    HEAP32[$buf >> 2] = $6;
    var $7 = ($3 | 0) == 0;
    var $8 = ($6 | 0) == 0;
    var $or_cond = $7 | $8;
    if ($or_cond) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str8100 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 4:
    HEAP32[$p >> 2] = $6;
    var $11 = $x + 4 | 0;
    var $_0_ph = $s;
    var $_01_ph = $a;
    var $xs_0_ph = 0;
    var $xf_0_ph = 0;
    __label__ = 5;
    break;
   case 5:
    var $xf_0_ph;
    var $xs_0_ph;
    var $_01_ph;
    var $_0_ph;
    var $_0 = $_0_ph;
    __label__ = 6;
    break;
   case 6:
    var $_0;
    var $12 = HEAP8[$_0];
    var $13 = $12 << 24 >> 24 == 0;
    var $14 = HEAP32[$p >> 2];
    if ($13) {
      __label__ = 39;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $16 = HEAP32[$bufsz >> 2];
    var $17 = HEAP32[$buf >> 2];
    var $18 = $17 + $16 | 0;
    var $19 = $14 >>> 0 < $18 >>> 0;
    if ($19) {
      var $23 = $12;
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $21 = HEAP32[_RECSIZE >> 2];
    _growbuf($buf, $bufsz, $21, $p);
    var $_pre = HEAP8[$_0];
    var $23 = $_pre;
    __label__ = 9;
    break;
   case 9:
    var $23;
    var $24 = $23 << 24 >> 24 == 37;
    var $25 = $_0 + 1 | 0;
    if ($24) {
      __label__ = 11;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $27 = HEAP32[$p >> 2];
    var $28 = $27 + 1 | 0;
    HEAP32[$p >> 2] = $28;
    HEAP8[$27] = $23;
    var $_0 = $25;
    __label__ = 6;
    break;
   case 11:
    var $30 = HEAP8[$25];
    var $31 = $30 << 24 >> 24 == 37;
    if ($31) {
      __label__ = 12;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 12:
    var $33 = HEAP32[$p >> 2];
    var $34 = $33 + 1 | 0;
    HEAP32[$p >> 2] = $34;
    HEAP8[$33] = 37;
    var $35 = $_0 + 2 | 0;
    var $_0 = $35;
    __label__ = 6;
    break;
   case 13:
    var $37 = HEAP32[$fmt >> 2];
    HEAP32[$t >> 2] = $37;
    var $_1 = $_0;
    var $39 = $37;
    __label__ = 14;
    break;
   case 14:
    var $39;
    var $_1;
    var $40 = HEAP8[$_1];
    var $41 = $39 + 1 | 0;
    HEAP32[$t >> 2] = $41;
    HEAP8[$39] = $40;
    var $42 = $40 << 24 >> 24 == 0;
    if ($42) {
      __label__ = 19;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $44 = HEAP32[$t >> 2];
    var $45 = HEAP32[$fmtsz >> 2];
    var $46 = HEAP32[$fmt >> 2];
    var $47 = $46 + $45 | 0;
    var $48 = $44 >>> 0 < $47 >>> 0;
    if ($48) {
      __label__ = 17;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $50 = HEAP32[_RECSIZE >> 2];
    _growbuf($fmt, $fmtsz, $50, $t);
    __label__ = 17;
    break;
   case 17:
    var $52 = HEAP8[$_1];
    var $_off = $52 - 97 & 255;
    var $or_cond2_not = ($_off & 255) > 25;
    var $53 = $52 << 24 >> 24 == 108;
    var $or_cond3 = $or_cond2_not | $53;
    if ($or_cond3) {
      __label__ = 18;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 18:
    var $55 = $_1 + 1 | 0;
    var $_pre2 = HEAP32[$t >> 2];
    var $_1 = $55;
    var $39 = $_pre2;
    __label__ = 14;
    break;
   case 19:
    var $56 = HEAP32[$t >> 2];
    HEAP8[$56] = 0;
    var $57 = HEAP8[$_1];
    var $58 = $57 << 24 >> 24;
    if (($58 | 0) == 100) {
      __label__ = 20;
      break;
    } else if (($58 | 0) == 111 || ($58 | 0) == 120) {
      __label__ = 22;
      break;
    } else if (($58 | 0) == 102 || ($58 | 0) == 101 || ($58 | 0) == 103) {
      __label__ = 24;
      break;
    } else if (($58 | 0) == 115) {
      __label__ = 25;
      break;
    } else if (($58 | 0) == 99) {
      var $flag_0_ph = 3;
      __label__ = 26;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 20:
    var $60 = $_1 - 1 | 0;
    var $61 = HEAP8[$60];
    var $62 = $61 << 24 >> 24 == 108;
    if ($62) {
      var $flag_0_ph = 2;
      __label__ = 26;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $64 = HEAP32[$t >> 2];
    var $65 = $64 - 1 | 0;
    HEAP8[$65] = 108;
    var $66 = HEAP32[$t >> 2];
    HEAP8[$66] = 100;
    var $67 = HEAP32[$t >> 2];
    var $68 = $67 + 1 | 0;
    HEAP32[$t >> 2] = $68;
    HEAP8[$68] = 0;
    var $flag_0_ph = 2;
    __label__ = 26;
    break;
   case 22:
    var $70 = $_1 - 1 | 0;
    var $71 = HEAP8[$70];
    var $72 = $71 << 24 >> 24 == 108;
    var $73 = $72 ? 2 : 3;
    var $flag_0_ph = $73;
    __label__ = 26;
    break;
   case 23:
    var $75 = HEAP32[$fmt >> 2];
    _growsprintf($buf, $p, $bufsz, STRING_TABLE.__str10102 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $75, tempInt));
    var $_0 = $_1;
    __label__ = 6;
    break;
   case 24:
    var $flag_0_ph = 1;
    __label__ = 26;
    break;
   case 25:
    var $flag_0_ph = 4;
    __label__ = 26;
    break;
   case 26:
    var $flag_0_ph;
    var $77 = ($_01_ph | 0) == 0;
    if ($77) {
      __label__ = 27;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 27:
    _error(STRING_TABLE.__str11103 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $s, tempInt));
   case 28:
    _execute($x, $_01_ph);
    var $80 = $_01_ph + 4 | 0;
    var $81 = HEAP32[$80 >> 2];
    var $82 = ($flag_0_ph | 0) == 4;
    var $83 = HEAP32[$11 >> 2];
    if ($82) {
      __label__ = 30;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    var $85 = _getfval($83);
    var $xs_1 = $xs_0_ph;
    var $xf_1 = $85;
    __label__ = 32;
    break;
   case 30:
    var $87 = $83 + 4 | 0;
    var $88 = HEAP32[$87 >> 2];
    var $89 = ($88 | 0) == 0;
    if ($89) {
      var $xf_15 = $xf_0_ph;
      var $xs_17 = __str2320 | 0;
      __label__ = 36;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 31:
    var $91 = _getsval($83);
    var $xs_1 = $91;
    var $xf_1 = $xf_0_ph;
    __label__ = 32;
    break;
   case 32:
    var $xf_1;
    var $xs_1;
    if (($flag_0_ph | 0) == 1) {
      __label__ = 33;
      break;
    } else if (($flag_0_ph | 0) == 2) {
      __label__ = 34;
      break;
    } else if (($flag_0_ph | 0) == 3) {
      __label__ = 35;
      break;
    } else if (($flag_0_ph | 0) == 4) {
      var $xf_15 = $xf_1;
      var $xs_17 = $xs_1;
      __label__ = 36;
      break;
    } else if (($flag_0_ph | 0) == 6) {
      __label__ = 37;
      break;
    } else {
      var $xf_16 = $xf_1;
      var $xs_18 = $xs_1;
      __label__ = 38;
      break;
    }
   case 33:
    var $94 = HEAP32[$fmt >> 2];
    _growsprintf($buf, $p, $bufsz, $94, (tempInt = STACKTOP, STACKTOP += 8, tempDoubleF64[0] = $xf_1, HEAP32[tempInt >> 2] = tempDoubleI32[0], HEAP32[tempInt + 4 >> 2] = tempDoubleI32[1], tempInt));
    var $xf_16 = $xf_1;
    var $xs_18 = $xs_1;
    __label__ = 38;
    break;
   case 34:
    var $96 = HEAP32[$fmt >> 2];
    var $97 = $xf_1 & -1;
    _growsprintf($buf, $p, $bufsz, $96, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $97, tempInt));
    var $xf_16 = $xf_1;
    var $xs_18 = $xs_1;
    __label__ = 38;
    break;
   case 35:
    var $99 = HEAP32[$fmt >> 2];
    var $100 = $xf_1 & -1;
    _growsprintf($buf, $p, $bufsz, $99, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $100, tempInt));
    var $xf_16 = $xf_1;
    var $xs_18 = $xs_1;
    __label__ = 38;
    break;
   case 36:
    var $xs_17;
    var $xf_15;
    var $101 = HEAP32[$fmt >> 2];
    _growsprintf($buf, $p, $bufsz, $101, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $xs_17, tempInt));
    var $xf_16 = $xf_15;
    var $xs_18 = $xs_17;
    __label__ = 38;
    break;
   case 37:
    var $103 = HEAP32[$fmt >> 2];
    var $104 = $xf_1 >= 0 ? Math.floor($xf_1) : Math.ceil($xf_1);
    _growsprintf($buf, $p, $bufsz, $103, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $104, tempInt));
    var $xf_16 = $xf_1;
    var $xs_18 = $xs_1;
    __label__ = 38;
    break;
   case 38:
    var $xs_18;
    var $xf_16;
    var $106 = $x;
    var $x_0_val = HEAP16[$106 >> 1];
    var $107 = $x_0_val & 255;
    var $108 = ($x_0_val & 65535) >>> 8;
    var $109 = $108 & 255;
    _tempfree($107, $109, $83);
    var $110 = $_1 + 1 | 0;
    var $_0_ph = $110;
    var $_01_ph = $81;
    var $xs_0_ph = $xs_18;
    var $xf_0_ph = $xf_16;
    __label__ = 5;
    break;
   case 39:
    HEAP8[$14] = 0;
    var $112 = HEAP32[$fmt >> 2];
    var $113 = ($112 | 0) == 0;
    if ($113) {
      __label__ = 41;
      break;
    } else {
      __label__ = 40;
      break;
    }
   case 40:
    _free($112);
    HEAP32[$fmt >> 2] = 0;
    __label__ = 41;
    break;
   case 41:
    var $115 = HEAP32[$buf >> 2];
    STACKTOP = __stackBase__;
    return $115;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_format["X"] = 1;
function _growbuf($buf, $bufsize, $incr, $ptr) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[$buf >> 2];
    var $2 = HEAP32[$bufsize >> 2];
    var $3 = $2 + $incr | 0;
    HEAP32[$bufsize >> 2] = $3;
    var $4 = _realloc($1, $3);
    HEAP32[$buf >> 2] = $4;
    var $5 = ($4 | 0) == 0;
    if ($5) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str26120 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = STRING_TABLE.__str9101 | 0, tempInt));
   case 4:
    var $8 = ($ptr | 0) == 0;
    if ($8) {
      __label__ = 7;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $10 = HEAP32[$ptr >> 2];
    var $11 = ($10 | 0) == 0;
    if ($11) {
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $13 = $10;
    var $14 = $1;
    var $15 = $13 - $14 | 0;
    var $16 = $4 + $15 | 0;
    HEAP32[$ptr >> 2] = $16;
    __label__ = 7;
    break;
   case 7:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _growsprintf($whole, $target, $size, $fmt) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $ap = __stackBase__;
    var $dummy = __stackBase__ + 4;
    var $1 = HEAP32[$size >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $_pre = HEAP32[$target >> 2];
    var $10 = $_pre;
    __label__ = 6;
    break;
   case 4:
    var $4 = HEAP32[_RECSIZE >> 2];
    var $5 = $4 + 1 | 0;
    HEAP32[$size >> 2] = $5;
    var $6 = _malloc($5);
    HEAP32[$whole >> 2] = $6;
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 12;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    HEAP32[$target >> 2] = $6;
    var $10 = $6;
    __label__ = 6;
    break;
   case 6:
    var $10;
    var $11 = HEAP32[$whole >> 2];
    var $12 = $10;
    var $13 = $11;
    var $14 = $12 - $13 | 0;
    var $15 = $ap;
    var $16 = $dummy | 0;
    var $17 = $14 + 9 | 0;
    __label__ = 7;
    break;
   case 7:
    HEAP32[$15 >> 2] = arguments[_growsprintf.length];
    var $19 = HEAP32[$size >> 2];
    var $20 = $19 - $14 | 0;
    var $21 = $20 - 8 | 0;
    var $22 = HEAP32[$target >> 2];
    var $23 = HEAP32[$ap >> 2];
    var $24 = _vsnprintf($22, $21, $fmt, $23);
    var $25 = ($24 | 0) < 0;
    var $_not = $25 ^ 1;
    var $26 = $24 >>> 0 < $21 >>> 0;
    var $or_cond = $26 & $_not;
    if ($or_cond) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    var $27 = HEAP32[$target >> 2];
    var $28 = HEAP8[$27];
    var $29 = $28 << 24 >> 24 == 0;
    if ($29) {
      __label__ = 15;
      break;
    } else {
      var $42 = $27;
      __label__ = 14;
      break;
    }
   case 9:
    if ($25) {
      __label__ = 10;
      break;
    } else {
      var $ret_0 = $24;
      __label__ = 11;
      break;
    }
   case 10:
    HEAP32[$15 >> 2] = arguments[_growsprintf.length];
    var $32 = HEAP32[$ap >> 2];
    var $33 = _vsnprintf($16, 2, $fmt, $32);
    var $34 = ($33 | 0) < 0;
    if ($34) {
      __label__ = 12;
      break;
    } else {
      var $ret_0 = $33;
      __label__ = 11;
      break;
    }
   case 11:
    var $ret_0;
    var $36 = HEAP32[$whole >> 2];
    var $37 = $17 + $ret_0 | 0;
    HEAP32[$size >> 2] = $37;
    var $38 = _realloc($36, $37);
    HEAP32[$whole >> 2] = $38;
    var $39 = ($38 | 0) == 0;
    if ($39) {
      __label__ = 12;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 12:
    _error(STRING_TABLE.__str27121 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $fmt, tempInt));
   case 13:
    var $41 = $38 + $14 | 0;
    HEAP32[$target >> 2] = $41;
    __label__ = 7;
    break;
   case 14:
    var $42;
    var $43 = $42 + 1 | 0;
    HEAP32[$target >> 2] = $43;
    var $44 = HEAP8[$43];
    var $45 = $44 << 24 >> 24 == 0;
    if ($45) {
      __label__ = 15;
      break;
    } else {
      var $42 = $43;
      __label__ = 14;
      break;
    }
   case 15:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_growsprintf["X"] = 1;
function _arith($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 24;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $y = __stackBase__ + 8;
    var $1 = __stackBase__ + 16;
    var $2 = HEAP32[$a >> 2];
    _execute($x, $2);
    var $3 = $x + 4 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = _getfval($4);
    var $6 = $x;
    var $x_0_val = HEAP16[$6 >> 1];
    var $7 = $x_0_val & 255;
    var $8 = ($x_0_val & 65535) >>> 8;
    var $9 = $8 & 255;
    _tempfree($7, $9, $4);
    var $10 = ($n | 0) == 275;
    if ($10) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _gettemp($1);
    var $11 = $1;
    var $st$2$0 = $11 | 0;
    var $srcval12$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $11 + 4 | 0;
    var $srcval12$1 = HEAP32[$st$2$1 >> 2];
    var $12 = -$5;
    var $i_0 = $12;
    var $srcval13$1 = $srcval12$1;
    var $srcval13$0 = $srcval12$0;
    __label__ = 15;
    break;
   case 4:
    var $14 = $a + 4 | 0;
    var $15 = HEAP32[$14 >> 2];
    _execute($y, $15);
    var $16 = $y + 4 | 0;
    var $17 = HEAP32[$16 >> 2];
    var $18 = _getfval($17);
    var $19 = $y;
    var $y_0_val = HEAP16[$19 >> 1];
    var $20 = $y_0_val & 255;
    var $21 = ($y_0_val & 65535) >>> 8;
    var $22 = $21 & 255;
    _tempfree($20, $22, $17);
    _gettemp($1);
    var $23 = $1;
    var $st$14$0 = $23 | 0;
    var $srcval1$0 = HEAP32[$st$14$0 >> 2];
    var $st$14$1 = $23 + 4 | 0;
    var $srcval1$1 = HEAP32[$st$14$1 >> 2];
    if (($n | 0) == 270) {
      __label__ = 6;
      break;
    } else if (($n | 0) == 271) {
      __label__ = 7;
      break;
    } else if (($n | 0) == 272) {
      __label__ = 8;
      break;
    } else if (($n | 0) == 273) {
      __label__ = 9;
      break;
    } else if (($n | 0) == 274) {
      __label__ = 12;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    _error(STRING_TABLE.__str12104 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n, tempInt));
   case 6:
    var $26 = $5 + $18;
    var $i_0 = $26;
    var $srcval13$1 = $srcval1$1;
    var $srcval13$0 = $srcval1$0;
    __label__ = 15;
    break;
   case 7:
    var $28 = $5 - $18;
    var $i_0 = $28;
    var $srcval13$1 = $srcval1$1;
    var $srcval13$0 = $srcval1$0;
    __label__ = 15;
    break;
   case 8:
    var $30 = $5 * $18;
    var $i_0 = $30;
    var $srcval13$1 = $srcval1$1;
    var $srcval13$0 = $srcval1$0;
    __label__ = 15;
    break;
   case 9:
    var $32 = $18 == 0;
    if ($32) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    _error(STRING_TABLE.__str13105 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 11:
    var $35 = $5 / $18;
    var $i_0 = $35;
    var $srcval13$1 = $srcval1$1;
    var $srcval13$0 = $srcval1$0;
    __label__ = 15;
    break;
   case 12:
    var $37 = $18 == 0;
    if ($37) {
      __label__ = 13;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 13:
    _error(STRING_TABLE.__str13105 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 14:
    var $40 = $5 / $18;
    var $41 = $40 & -1;
    var $42 = $41 | 0;
    var $43 = $18 * $42;
    var $44 = $5 - $43;
    var $i_0 = $44;
    var $srcval13$1 = $srcval1$1;
    var $srcval13$0 = $srcval1$0;
    __label__ = 15;
    break;
   case 15:
    var $srcval13$0;
    var $srcval13$1;
    var $i_0;
    var $46$0 = $srcval13$1;
    var $47$0 = $46$0;
    var $47 = $47$0;
    var $48 = $47;
    _setfval($48, $i_0);
    var $49 = $agg_result;
    var $st$10$0 = $49 | 0;
    HEAP32[$st$10$0 >> 2] = $srcval13$0;
    var $st$10$1 = $49 + 4 | 0;
    HEAP32[$st$10$1 >> 2] = $srcval13$1;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_arith["X"] = 1;
function _assign($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $y = __stackBase__;
    var $1 = __stackBase__ + 8;
    var $2 = HEAP32[$a >> 2];
    _execute($1, $2);
    var $3 = $1;
    var $st$5$0 = $3 | 0;
    var $srcval2$0 = HEAP32[$st$5$0 >> 2];
    var $st$5$1 = $3 + 4 | 0;
    var $srcval2$1 = HEAP32[$st$5$1 >> 2];
    var $4 = $a + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    _execute($y, $5);
    var $6 = ($n | 0) == 276;
    if ($6) {
      __label__ = 3;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 3:
    var $8 = $y + 4 | 0;
    var $9 = HEAP32[$8 >> 2];
    var $10 = $9 + 16 | 0;
    var $11 = HEAP32[$10 >> 2];
    var $12 = $11 & 3;
    var $13 = ($12 | 0) == 3;
    if ($13) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    var $15$0 = $srcval2$1;
    var $16$0 = $15$0;
    var $16 = $16$0;
    var $17 = $16;
    var $18 = $9 + 4 | 0;
    var $19 = HEAP32[$18 >> 2];
    _setsval($17, $19);
    var $20 = $9 + 8 | 0;
    var $21 = (tempDoubleI32[0] = HEAP32[$20 >> 2], tempDoubleI32[1] = HEAP32[$20 + 4 >> 2], tempDoubleF64[0]);
    var $22 = $17 + 8 | 0;
    tempDoubleF64[0] = $21, HEAP32[$22 >> 2] = tempDoubleI32[0], HEAP32[$22 + 4 >> 2] = tempDoubleI32[1];
    var $23 = $17 + 16 | 0;
    var $24 = HEAP32[$23 >> 2];
    var $25 = $24 | 2;
    HEAP32[$23 >> 2] = $25;
    var $y_23_val_pre = HEAP32[$8 >> 2];
    var $y_23_val = $y_23_val_pre;
    __label__ = 9;
    break;
   case 5:
    var $27 = $11 & 1;
    var $28 = ($27 | 0) == 0;
    if ($28) {
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $30$0 = $srcval2$1;
    var $31$0 = $30$0;
    var $31 = $31$0;
    var $32 = $31;
    var $33 = $9 + 4 | 0;
    var $34 = HEAP32[$33 >> 2];
    _setsval($32, $34);
    var $y_23_val = $9;
    __label__ = 9;
    break;
   case 7:
    var $36 = $11 & 2;
    var $37 = ($36 | 0) == 0;
    if ($37) {
      var $y_23_val = $9;
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $39$0 = $srcval2$1;
    var $40$0 = $39$0;
    var $40 = $40$0;
    var $41 = $40;
    var $42 = $9 + 8 | 0;
    var $43 = (tempDoubleI32[0] = HEAP32[$42 >> 2], tempDoubleI32[1] = HEAP32[$42 + 4 >> 2], tempDoubleF64[0]);
    _setfval($41, $43);
    var $y_23_val = $9;
    __label__ = 9;
    break;
   case 9:
    var $y_23_val;
    var $45 = $y;
    var $y_01_val = HEAP16[$45 >> 1];
    var $46 = $y_01_val & 255;
    var $47 = ($y_01_val & 65535) >>> 8;
    var $48 = $47 & 255;
    _tempfree($46, $48, $y_23_val);
    var $49 = $agg_result;
    var $st$8$0 = $49 | 0;
    HEAP32[$st$8$0 >> 2] = $srcval2$0;
    var $st$8$1 = $49 + 4 | 0;
    HEAP32[$st$8$1 >> 2] = $srcval2$1;
    __label__ = 22;
    break;
   case 10:
    var $51$0 = $srcval2$1;
    var $52$0 = $51$0;
    var $52 = $52$0;
    var $53 = $52;
    var $54 = _getfval($53);
    var $55 = $y + 4 | 0;
    var $56 = HEAP32[$55 >> 2];
    var $57 = _getfval($56);
    if (($n | 0) == 277) {
      __label__ = 11;
      break;
    } else if (($n | 0) == 278) {
      __label__ = 12;
      break;
    } else if (($n | 0) == 279) {
      __label__ = 13;
      break;
    } else if (($n | 0) == 280) {
      __label__ = 14;
      break;
    } else if (($n | 0) == 281) {
      __label__ = 17;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 11:
    var $59 = $54 + $57;
    var $xf_0 = $59;
    __label__ = 21;
    break;
   case 12:
    var $61 = $54 - $57;
    var $xf_0 = $61;
    __label__ = 21;
    break;
   case 13:
    var $63 = $54 * $57;
    var $xf_0 = $63;
    __label__ = 21;
    break;
   case 14:
    var $65 = $57 == 0;
    if ($65) {
      __label__ = 15;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 15:
    _error(STRING_TABLE.__str13105 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 16:
    var $68 = $54 / $57;
    var $xf_0 = $68;
    __label__ = 21;
    break;
   case 17:
    var $70 = $57 == 0;
    if ($70) {
      __label__ = 18;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 18:
    _error(STRING_TABLE.__str13105 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 19:
    var $73 = $54 / $57;
    var $74 = $73 & -1;
    var $75 = $74 | 0;
    var $76 = $57 * $75;
    var $77 = $54 - $76;
    var $xf_0 = $77;
    __label__ = 21;
    break;
   case 20:
    _error(STRING_TABLE.__str14106 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n, tempInt));
   case 21:
    var $xf_0;
    var $80 = $y;
    var $y_0_val = HEAP16[$80 >> 1];
    var $81 = $y_0_val & 255;
    var $82 = ($y_0_val & 65535) >>> 8;
    var $83 = $82 & 255;
    _tempfree($81, $83, $56);
    _setfval($53, $xf_0);
    var $84 = $agg_result;
    var $st$9$0 = $84 | 0;
    HEAP32[$st$9$0 >> 2] = $srcval2$0;
    var $st$9$1 = $84 + 4 | 0;
    HEAP32[$st$9$1 >> 2] = $srcval2$1;
    __label__ = 22;
    break;
   case 22:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_assign["X"] = 1;
function _chrlen($s) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_0 = $s;
    var $m_0 = 0;
    __label__ = 3;
    break;
   case 3:
    var $m_0;
    var $_0;
    var $2 = HEAP8[$_0];
    var $phitmp = $2 << 24 >> 24 == 0;
    if ($phitmp) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $4 = $_0 + 1 | 0;
    var $5 = $m_0 + 1 | 0;
    var $_0 = $4;
    var $m_0 = $5;
    __label__ = 3;
    break;
   case 5:
    return $m_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _pastat($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $4 = $x;
    var $$emscripten$temp$0 = _true;
    var $st$2$0 = $$emscripten$temp$0 | 0;
    var $5$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$0 + 4 | 0;
    var $5$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $4 | 0;
    HEAP32[$st$6$0 >> 2] = $5$0;
    var $st$6$1 = $4 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $5$1;
    var $6$0 = $5$0;
    var $6 = $6$0 & 255;
    var $7$0 = $5$0 >>> 8 | $5$1 << 24;
    var $8$0 = $7$0;
    var $8 = $8$0 & 255;
    var $x_0_val = $6;
    var $x_1_val = $8;
    __label__ = 5;
    break;
   case 4:
    _execute($x, $1);
    var $10 = $x;
    var $11 = HEAP16[$10 >> 1];
    var $12 = $11 & 255;
    var $13 = ($11 & 65535) >>> 8;
    var $14 = $13 & 255;
    var $x_0_val = $12;
    var $x_1_val = $14;
    __label__ = 5;
    break;
   case 5:
    var $x_1_val;
    var $x_0_val;
    var $16 = $x_0_val << 24 >> 24 == 2;
    var $17 = $x_1_val << 24 >> 24 == 1;
    var $or_cond = $16 & $17;
    if ($or_cond) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    var $x_2 = $x + 4 | 0;
    var $x_2_val = HEAP32[$x_2 >> 2];
    _tempfree($x_0_val, $x_1_val, $x_2_val);
    var $19 = $a + 4 | 0;
    var $20 = HEAP32[$19 >> 2];
    _execute($x, $20);
    __label__ = 7;
    break;
   case 7:
    var $21 = $x;
    var $22 = $agg_result;
    var $st$2$0 = $21 | 0;
    var $23$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $21 + 4 | 0;
    var $23$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $22 | 0;
    HEAP32[$st$6$0 >> 2] = $23$0;
    var $st$6$1 = $22 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $23$1;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_pastat["X"] = 1;
function _aprintf($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    _awsprintf($x, $a, undef);
    var $1 = $a + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    var $4 = $x + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = $5 + 4 | 0;
    var $7 = HEAP32[$6 >> 2];
    if ($3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $9 = _printf(STRING_TABLE.__str10102 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $7, tempInt));
    var $10 = $x;
    var $x_0_val = HEAP16[$10 >> 1];
    var $11 = $x_0_val & 255;
    var $12 = ($x_0_val & 65535) >>> 8;
    var $13 = $12 & 255;
    _tempfree($11, $13, $5);
    var $14 = $agg_result;
    var $$emscripten$temp$0 = _true;
    var $st$9$0 = $$emscripten$temp$0 | 0;
    var $15$0 = HEAP32[$st$9$0 >> 2];
    var $st$9$1 = $$emscripten$temp$0 + 4 | 0;
    var $15$1 = HEAP32[$st$9$1 >> 2];
    var $st$13$0 = $14 | 0;
    HEAP32[$st$13$0 >> 2] = $15$0;
    var $st$13$1 = $14 + 4 | 0;
    HEAP32[$st$13$1 >> 2] = $15$1;
    __label__ = 5;
    break;
   case 4:
    var $17 = $x;
    var $18 = $2;
    var $19 = $a + 8 | 0;
    var $20 = HEAP32[$19 >> 2];
    _redirprint($7, $18, $20);
    var $21 = $agg_result;
    var $st$6$0 = $17 | 0;
    var $22$0 = HEAP32[$st$6$0 >> 2];
    var $st$6$1 = $17 + 4 | 0;
    var $22$1 = HEAP32[$st$6$1 >> 2];
    var $st$10$0 = $21 | 0;
    HEAP32[$st$10$0 >> 2] = $22$0;
    var $st$10$1 = $21 + 4 | 0;
    HEAP32[$st$10$1 >> 2] = $22$1;
    __label__ = 5;
    break;
   case 5:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _split($agg_result, $a, $nnn) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 36;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $num = __stackBase__ + 8;
    var $1 = HEAP32[$a >> 2];
    _execute($x, $1);
    var $2 = $x;
    var $3 = $x + 4 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = _getsval($4);
    var $6 = $x;
    var $x_05_val = HEAP16[$6 >> 1];
    var $7 = $x_05_val & 255;
    var $8 = ($x_05_val & 65535) >>> 8;
    var $9 = $8 & 255;
    _tempfree($7, $9, $4);
    var $10 = $a + 8 | 0;
    var $11 = HEAP32[$10 >> 2];
    var $12 = ($11 | 0) == 0;
    if ($12) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $14 = HEAP32[_FS >> 2];
    var $15 = HEAP32[$14 >> 2];
    var $fs_0 = $15;
    __label__ = 5;
    break;
   case 4:
    _execute($x, $11);
    var $17 = HEAP32[$3 >> 2];
    var $18 = _getsval($17);
    var $x_0_val = HEAP16[$6 >> 1];
    var $19 = $x_0_val & 255;
    var $20 = ($x_0_val & 65535) >>> 8;
    var $21 = $20 & 255;
    _tempfree($19, $21, $17);
    var $fs_0 = $18;
    __label__ = 5;
    break;
   case 5:
    var $fs_0;
    var $23 = HEAP8[$fs_0];
    var $24 = $a + 4 | 0;
    var $25 = HEAP32[$24 >> 2];
    var $26 = $25;
    _freesymtab($26);
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    var $28 = $23 & 255;
    var $29 = $25;
    var $30 = HEAP32[$29 >> 2];
    var $31 = _printf(STRING_TABLE.__str15107 | 0, (tempInt = STACKTOP, STACKTOP += 12, HEAP32[tempInt >> 2] = $5, HEAP32[tempInt + 4 >> 2] = $30, HEAP32[tempInt + 8 >> 2] = $28, tempInt));
    __label__ = 7;
    break;
   case 7:
    var $33 = $25 + 16 | 0;
    var $34 = $33;
    var $35 = HEAP32[$34 >> 2];
    var $36 = $35 & -18;
    var $37 = $36 | 16;
    HEAP32[$34 >> 2] = $37;
    var $38 = _makesymtab();
    var $39 = $25 + 4 | 0;
    var $_c = $38;
    HEAP32[$39 >> 2] = $_c;
    var $40 = $23 << 24 >> 24 == 32;
    if ($40) {
      __label__ = 8;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 8:
    var $41 = $num | 0;
    var $n_0_ph = 0;
    var $s_0_ph = $5;
    __label__ = 9;
    break;
   case 9:
    var $s_0_ph;
    var $n_0_ph;
    var $s_0 = $s_0_ph;
    __label__ = 10;
    break;
   case 10:
    var $s_0;
    var $43 = HEAP8[$s_0];
    if ($43 << 24 >> 24 == 32 || $43 << 24 >> 24 == 9 || $43 << 24 >> 24 == 10) {
      __label__ = 11;
      break;
    } else if ($43 << 24 >> 24 == 0) {
      var $n_2 = $n_0_ph;
      __label__ = 30;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 11:
    var $44 = $s_0 + 1 | 0;
    var $s_0 = $44;
    __label__ = 10;
    break;
   case 12:
    var $46 = $n_0_ph + 1 | 0;
    var $s_1 = $s_0;
    __label__ = 13;
    break;
   case 13:
    var $s_1;
    var $48 = $s_1 + 1 | 0;
    var $49 = HEAP8[$48];
    var $50 = $49 & 255;
    if (($50 | 0) == 32 || ($50 | 0) == 10 || ($50 | 0) == 9 || ($50 | 0) == 0) {
      __label__ = 14;
      break;
    } else {
      var $s_1 = $48;
      __label__ = 13;
      break;
    }
   case 14:
    HEAP8[$48] = 0;
    var $51 = _snprintf($41, 25, STRING_TABLE.__str16108 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $46, tempInt));
    var $52 = _isanumber($s_0);
    var $53 = ($52 | 0) == 0;
    var $54 = _tostring($s_0);
    if ($53) {
      __label__ = 16;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $56 = _atof($s_0);
    var $57 = HEAP32[$39 >> 2];
    var $58 = $57;
    var $59 = _setsymtab($41, $54, $56, 3, $58);
    __label__ = 17;
    break;
   case 16:
    var $61 = HEAP32[$39 >> 2];
    var $62 = $61;
    var $63 = _setsymtab($41, $54, 0, 1, $62);
    __label__ = 17;
    break;
   case 17:
    HEAP8[$48] = $49;
    var $65 = $49 << 24 >> 24 == 0;
    if ($65) {
      var $n_0_ph = $46;
      var $s_0_ph = $48;
      __label__ = 9;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $67 = $s_1 + 2 | 0;
    var $n_0_ph = $46;
    var $s_0_ph = $67;
    __label__ = 9;
    break;
   case 19:
    var $69 = HEAP8[$5];
    var $70 = $69 << 24 >> 24 == 0;
    if ($70) {
      var $n_2 = 0;
      __label__ = 30;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 20:
    var $71 = $num | 0;
    var $n_1 = 1;
    var $s_2 = $5;
    __label__ = 21;
    break;
   case 21:
    var $s_2;
    var $n_1;
    var $s_3 = $s_2;
    __label__ = 22;
    break;
   case 22:
    var $s_3;
    var $74 = HEAP8[$s_3];
    var $75 = $74 << 24 >> 24 == $23 << 24 >> 24;
    if ($75) {
      __label__ = 25;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $76 = $74 & 255;
    if (($76 | 0) == 10 || ($76 | 0) == 0) {
      __label__ = 25;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 24:
    var $78 = $s_3 + 1 | 0;
    var $s_3 = $78;
    __label__ = 22;
    break;
   case 25:
    HEAP8[$s_3] = 0;
    var $79 = _snprintf($71, 25, STRING_TABLE.__str16108 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n_1, tempInt));
    var $80 = _isanumber($s_2);
    var $81 = ($80 | 0) == 0;
    var $82 = _tostring($s_2);
    if ($81) {
      __label__ = 27;
      break;
    } else {
      __label__ = 26;
      break;
    }
   case 26:
    var $84 = _atof($s_2);
    var $85 = HEAP32[$39 >> 2];
    var $86 = $85;
    var $87 = _setsymtab($71, $82, $84, 3, $86);
    __label__ = 28;
    break;
   case 27:
    var $89 = HEAP32[$39 >> 2];
    var $90 = $89;
    var $91 = _setsymtab($71, $82, 0, 1, $90);
    __label__ = 28;
    break;
   case 28:
    HEAP8[$s_3] = $74;
    var $93 = $74 << 24 >> 24 == 0;
    if ($93) {
      var $n_2 = $n_1;
      __label__ = 30;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    var $95 = $s_3 + 1 | 0;
    var $phitmp = $n_1 + 1 | 0;
    var $n_1 = $phitmp;
    var $s_2 = $95;
    __label__ = 21;
    break;
   case 30:
    var $n_2;
    _gettemp($x);
    var $96 = HEAP32[$3 >> 2];
    var $97 = $96 + 16 | 0;
    HEAP32[$97 >> 2] = 2;
    var $98 = $n_2 | 0;
    var $99 = $96 + 8 | 0;
    tempDoubleF64[0] = $98, HEAP32[$99 >> 2] = tempDoubleI32[0], HEAP32[$99 + 4 >> 2] = tempDoubleI32[1];
    var $100 = $agg_result;
    var $st$9$0 = $2 | 0;
    var $101$0 = HEAP32[$st$9$0 >> 2];
    var $st$9$1 = $2 + 4 | 0;
    var $101$1 = HEAP32[$st$9$1 >> 2];
    var $st$13$0 = $100 | 0;
    HEAP32[$st$13$0 >> 2] = $101$0;
    var $st$13$1 = $100 + 4 | 0;
    HEAP32[$st$13$1 >> 2] = $101$1;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_split["X"] = 1;
function _ifstat($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    _execute($x, $1);
    var $2 = $x;
    var $3 = $x;
    var $4 = HEAP16[$3 >> 1];
    var $5 = $4 & 255;
    var $6 = $5 << 24 >> 24 == 2;
    var $7 = ($4 & 65535) >>> 8;
    var $8 = $7 & 255;
    var $9 = $8 << 24 >> 24 == 1;
    var $or_cond = $6 & $9;
    if ($or_cond) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $x_23 = $x + 4 | 0;
    var $x_23_val = HEAP32[$x_23 >> 2];
    _tempfree(2, 1, $x_23_val);
    var $11 = $a + 4 | 0;
    var $12 = HEAP32[$11 >> 2];
    _execute($x, $12);
    __label__ = 6;
    break;
   case 4:
    var $14 = $a + 8 | 0;
    var $15 = HEAP32[$14 >> 2];
    var $16 = ($15 | 0) == 0;
    if ($16) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $x_2 = $x + 4 | 0;
    var $x_2_val = HEAP32[$x_2 >> 2];
    _tempfree($5, $8, $x_2_val);
    var $18 = HEAP32[$14 >> 2];
    _execute($x, $18);
    __label__ = 6;
    break;
   case 6:
    var $20 = $agg_result;
    var $st$1$0 = $2 | 0;
    var $21$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $2 + 4 | 0;
    var $21$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $20 | 0;
    HEAP32[$st$5$0 >> 2] = $21$0;
    var $st$5$1 = $20 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $21$1;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _whilestat($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = $x;
    var $2 = $a + 4 | 0;
    var $x_23 = $x + 4 | 0;
    __label__ = 3;
    break;
   case 3:
    var $4 = HEAP32[$a >> 2];
    _execute($x, $4);
    var $5 = $x;
    var $6 = HEAP16[$5 >> 1];
    var $7 = $6 & 255;
    var $8 = $7 << 24 >> 24 == 2;
    var $_mask = $6 & -256;
    var $9 = $_mask << 16 >> 16 == 256;
    var $or_cond = $8 & $9;
    if ($or_cond) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $11 = $agg_result;
    var $st$1$0 = $1 | 0;
    var $12$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $1 + 4 | 0;
    var $12$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $11 | 0;
    HEAP32[$st$5$0 >> 2] = $12$0;
    var $st$5$1 = $11 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $12$1;
    __label__ = 10;
    break;
   case 5:
    var $x_23_val = HEAP32[$x_23 >> 2];
    _tempfree(2, 1, $x_23_val);
    var $14 = HEAP32[$2 >> 2];
    _execute($x, $14);
    var $15 = HEAP16[$5 >> 1];
    var $16 = $15 & 255;
    var $17 = $16 << 24 >> 24 == 3;
    var $18 = ($15 & 65535) >>> 8;
    var $19 = $18 & 255;
    if ($17) {
      __label__ = 6;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 6:
    if ($19 << 24 >> 24 == 3) {
      __label__ = 7;
      break;
    } else if ($19 << 24 >> 24 == 2 || $19 << 24 >> 24 == 1) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 7:
    var $$emscripten$temp$0 = _true;
    var $st$1$0 = $$emscripten$temp$0 | 0;
    var $22$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$0 + 4 | 0;
    var $22$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $1 | 0;
    HEAP32[$st$5$0 >> 2] = $22$0;
    var $st$5$1 = $1 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $22$1;
    var $23 = $agg_result;
    var $st$10$0 = $23 | 0;
    HEAP32[$st$10$0 >> 2] = $22$0;
    var $st$10$1 = $23 + 4 | 0;
    HEAP32[$st$10$1 >> 2] = $22$1;
    __label__ = 10;
    break;
   case 8:
    var $25 = $agg_result;
    var $st$1$0 = $1 | 0;
    var $26$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $1 + 4 | 0;
    var $26$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $25 | 0;
    HEAP32[$st$5$0 >> 2] = $26$0;
    var $st$5$1 = $25 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $26$1;
    __label__ = 10;
    break;
   case 9:
    var $x_2_val = HEAP32[$x_23 >> 2];
    _tempfree($16, $19, $x_2_val);
    __label__ = 3;
    break;
   case 10:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_whilestat["X"] = 1;
function _forstat($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 24;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = __stackBase__ + 8;
    var $2 = __stackBase__ + 16;
    var $3 = HEAP32[$a >> 2];
    _execute($1, $3);
    var $4 = $1;
    var $_04_val = HEAP16[$4 >> 1];
    var $5 = $_04_val & 255;
    var $6 = ($_04_val & 65535) >>> 8;
    var $7 = $6 & 255;
    var $_26 = $1 + 4 | 0;
    var $_26_val = HEAP32[$_26 >> 2];
    _tempfree($5, $7, $_26_val);
    var $8 = $a + 4 | 0;
    var $9 = $a + 12 | 0;
    var $10 = $x;
    var $11 = $a + 8 | 0;
    var $x_2 = $x + 4 | 0;
    var $_2 = $2 + 4 | 0;
    __label__ = 3;
    break;
   case 3:
    var $13 = HEAP32[$8 >> 2];
    var $14 = ($13 | 0) == 0;
    if ($14) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    var $_pre = $x;
    var $_pre_phi = $_pre;
    __label__ = 8;
    break;
   case 5:
    _execute($x, $13);
    var $16 = $x;
    var $17 = HEAP16[$16 >> 1];
    var $18 = $17 & 255;
    var $19 = $18 << 24 >> 24 == 2;
    var $_mask = $17 & -256;
    var $20 = $_mask << 16 >> 16 == 256;
    var $or_cond = $19 & $20;
    if ($or_cond) {
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $22 = $agg_result;
    var $st$1$0 = $10 | 0;
    var $23$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $10 + 4 | 0;
    var $23$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $22 | 0;
    HEAP32[$st$5$0 >> 2] = $23$0;
    var $st$5$1 = $22 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $23$1;
    __label__ = 13;
    break;
   case 7:
    var $x_23_val = HEAP32[$x_2 >> 2];
    _tempfree(2, 1, $x_23_val);
    var $_pre_phi = $16;
    __label__ = 8;
    break;
   case 8:
    var $_pre_phi;
    var $26 = HEAP32[$9 >> 2];
    _execute($x, $26);
    var $27 = HEAP16[$_pre_phi >> 1];
    var $28 = $27 & 255;
    var $29 = $28 << 24 >> 24 == 3;
    var $30 = ($27 & 65535) >>> 8;
    var $31 = $30 & 255;
    if ($29) {
      __label__ = 9;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 9:
    if ($31 << 24 >> 24 == 3) {
      __label__ = 10;
      break;
    } else if ($31 << 24 >> 24 == 2 || $31 << 24 >> 24 == 1) {
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 10:
    var $$emscripten$temp$0 = _true;
    var $st$1$0 = $$emscripten$temp$0 | 0;
    var $34$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$0 + 4 | 0;
    var $34$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $10 | 0;
    HEAP32[$st$5$0 >> 2] = $34$0;
    var $st$5$1 = $10 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $34$1;
    var $35 = $agg_result;
    var $st$10$0 = $35 | 0;
    HEAP32[$st$10$0 >> 2] = $34$0;
    var $st$10$1 = $35 + 4 | 0;
    HEAP32[$st$10$1 >> 2] = $34$1;
    __label__ = 13;
    break;
   case 11:
    var $37 = $agg_result;
    var $st$1$0 = $10 | 0;
    var $38$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $10 + 4 | 0;
    var $38$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $37 | 0;
    HEAP32[$st$5$0 >> 2] = $38$0;
    var $st$5$1 = $37 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $38$1;
    __label__ = 13;
    break;
   case 12:
    var $x_2_val = HEAP32[$x_2 >> 2];
    _tempfree($28, $31, $x_2_val);
    var $39 = HEAP32[$11 >> 2];
    _execute($2, $39);
    var $40 = $2;
    var $_0_val = HEAP16[$40 >> 1];
    var $41 = $_0_val & 255;
    var $42 = ($_0_val & 65535) >>> 8;
    var $43 = $42 & 255;
    var $_2_val = HEAP32[$_2 >> 2];
    _tempfree($41, $43, $_2_val);
    __label__ = 3;
    break;
   case 13:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_forstat["X"] = 1;
function _redirprint($s, $a, $b) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    _execute($x, $b);
    var $1 = $x + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = _getsval($2);
    var $4 = HEAP32[_filenum >> 2];
    var $5 = HEAP32[_files >> 2];
    var $6 = $2 + 4 | 0;
    var $i_0 = 0;
    __label__ = 3;
    break;
   case 3:
    var $i_0;
    var $8 = ($i_0 | 0) < ($4 | 0);
    if ($8) {
      __label__ = 4;
      break;
    } else {
      var $i_1 = 0;
      __label__ = 7;
      break;
    }
   case 4:
    var $10 = $5 + $i_0 * 12 | 0;
    var $11 = HEAP32[$10 >> 2];
    var $12 = ($11 | 0) == 0;
    if ($12) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $14 = HEAP32[$6 >> 2];
    var $15 = $5 + $i_0 * 12 + 8 | 0;
    var $16 = HEAP32[$15 >> 2];
    var $17 = _strcmp($14, $16);
    var $18 = ($17 | 0) == 0;
    if ($18) {
      var $i_2 = $i_0;
      var $75 = $11;
      __label__ = 23;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $20 = $i_0 + 1 | 0;
    var $i_0 = $20;
    __label__ = 3;
    break;
   case 7:
    var $i_1;
    var $21 = ($i_1 | 0) < ($4 | 0);
    if ($21) {
      __label__ = 8;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 8:
    var $23 = $5 + $i_1 * 12 | 0;
    var $24 = HEAP32[$23 >> 2];
    var $25 = ($24 | 0) == 0;
    if ($25) {
      __label__ = 13;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $27 = $i_1 + 1 | 0;
    var $i_1 = $27;
    __label__ = 7;
    break;
   case 10:
    var $29 = $5;
    var $30 = $i_1 + 15 | 0;
    HEAP32[_filenum >> 2] = $30;
    var $31 = $30 * 12 | 0;
    var $32 = _realloc($29, $31);
    var $33 = $32;
    HEAP32[_files >> 2] = $33;
    var $34 = ($32 | 0) == 0;
    if ($34) {
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 11:
    _error(STRING_TABLE.__str21113 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $i_1, tempInt));
   case 12:
    var $37 = $33 + $i_1 * 12 | 0;
    var $38 = $37;
    var $39 = HEAP32[_filenum >> 2];
    var $40 = $39 - $i_1 | 0;
    var $41 = $40 * 12 | 0;
    _memset($38, 0, $41, 1);
    __label__ = 13;
    break;
   case 13:
    var $42 = ($a | 0) == 124;
    if ($42) {
      __label__ = 14;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 14:
    var $44 = HEAP32[$6 >> 2];
    var $45 = _popen($44, STRING_TABLE.__str22114 | 0);
    var $46 = HEAP32[_files >> 2];
    var $47 = $46 + $i_1 * 12 | 0;
    HEAP32[$47 >> 2] = $45;
    var $60 = $45;
    __label__ = 18;
    break;
   case 15:
    var $49 = ($a | 0) == 269;
    var $50 = HEAP32[$6 >> 2];
    if ($49) {
      __label__ = 16;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 16:
    var $52 = _fopen($50, STRING_TABLE.__str23115 | 0);
    var $53 = HEAP32[_files >> 2];
    var $54 = $53 + $i_1 * 12 | 0;
    HEAP32[$54 >> 2] = $52;
    var $60 = $52;
    __label__ = 18;
    break;
   case 17:
    var $56 = _fopen($50, STRING_TABLE.__str22114 | 0);
    var $57 = HEAP32[_files >> 2];
    var $58 = $57 + $i_1 * 12 | 0;
    HEAP32[$58 >> 2] = $56;
    var $60 = $56;
    __label__ = 18;
    break;
   case 18:
    var $60;
    var $61 = ($60 | 0) == 0;
    if ($61) {
      __label__ = 19;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 19:
    var $63 = HEAP32[$6 >> 2];
    _error(STRING_TABLE.__str24116 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $63, tempInt));
   case 20:
    var $65 = _fileno($60);
    var $66 = _fcntl($65, 2, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = 1, tempInt));
    var $67 = ($66 | 0) < 0;
    if ($67) {
      __label__ = 21;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 21:
    _error(STRING_TABLE.__str25117 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 22:
    var $70 = HEAP32[$6 >> 2];
    var $71 = _tostring($70);
    var $72 = HEAP32[_files >> 2];
    var $73 = $72 + $i_1 * 12 + 8 | 0;
    HEAP32[$73 >> 2] = $71;
    var $74 = $72 + $i_1 * 12 + 4 | 0;
    HEAP32[$74 >> 2] = $a;
    var $_phi_trans_insert = $72 + $i_1 * 12 | 0;
    var $_pre = HEAP32[$_phi_trans_insert >> 2];
    var $i_2 = $i_1;
    var $75 = $_pre;
    __label__ = 23;
    break;
   case 23:
    var $75;
    var $i_2;
    var $fputs = _fputs($s, $75);
    var $76 = HEAP32[_files >> 2];
    var $77 = $76 + $i_2 * 12 | 0;
    var $78 = HEAP32[$77 >> 2];
    var $79 = _fflush($78);
    var $80 = $x;
    var $x_0_val = HEAP16[$80 >> 1];
    var $81 = $x_0_val & 255;
    var $82 = ($x_0_val & 65535) >>> 8;
    var $83 = $82 & 255;
    _tempfree($81, $83, $2);
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_redirprint["X"] = 1;
function _instat($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    var $2 = $1;
    var $3 = $a + 4 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = $4 + 16 | 0;
    var $6 = $5;
    var $7 = HEAP32[$6 >> 2];
    var $8 = $7 & 16;
    var $9 = ($8 | 0) == 0;
    if ($9) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $11 = $4;
    var $12 = HEAP32[$11 >> 2];
    _error(STRING_TABLE.__str17109 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $12, tempInt));
   case 4:
    var $14 = $4 + 4 | 0;
    var $15 = HEAP32[$14 >> 2];
    var $16 = $15;
    var $17 = $a + 8 | 0;
    var $18 = $x;
    var $x_2 = $x + 4 | 0;
    var $i_0 = 0;
    __label__ = 5;
    break;
   case 5:
    var $i_0;
    var $20 = ($i_0 | 0) < 50;
    if ($20) {
      __label__ = 6;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 6:
    var $22 = $16 + ($i_0 << 2) | 0;
    var $cp_0_in = $22;
    __label__ = 7;
    break;
   case 7:
    var $cp_0_in;
    var $cp_0 = HEAP32[$cp_0_in >> 2];
    var $24 = ($cp_0 | 0) == 0;
    if ($24) {
      __label__ = 13;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $26 = $cp_0 | 0;
    var $27 = HEAP32[$26 >> 2];
    _setsval($2, $27);
    var $28 = HEAP32[$17 >> 2];
    _execute($x, $28);
    var $29 = $x;
    var $30 = HEAP16[$29 >> 1];
    var $31 = $30 & 255;
    var $32 = $31 << 24 >> 24 == 3;
    var $33 = ($30 & 65535) >>> 8;
    var $34 = $33 & 255;
    if ($32) {
      __label__ = 9;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 9:
    if ($34 << 24 >> 24 == 3) {
      __label__ = 10;
      break;
    } else if ($34 << 24 >> 24 == 2 || $34 << 24 >> 24 == 1) {
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 10:
    var $$emscripten$temp$0 = _true;
    var $st$1$0 = $$emscripten$temp$0 | 0;
    var $37$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $$emscripten$temp$0 + 4 | 0;
    var $37$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $18 | 0;
    HEAP32[$st$5$0 >> 2] = $37$0;
    var $st$5$1 = $18 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $37$1;
    var $38 = $agg_result;
    var $st$10$0 = $38 | 0;
    HEAP32[$st$10$0 >> 2] = $37$0;
    var $st$10$1 = $38 + 4 | 0;
    HEAP32[$st$10$1 >> 2] = $37$1;
    __label__ = 15;
    break;
   case 11:
    var $40 = $agg_result;
    var $st$1$0 = $18 | 0;
    var $41$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = $18 + 4 | 0;
    var $41$1 = HEAP32[$st$1$1 >> 2];
    var $st$5$0 = $40 | 0;
    HEAP32[$st$5$0 >> 2] = $41$0;
    var $st$5$1 = $40 + 4 | 0;
    HEAP32[$st$5$1 >> 2] = $41$1;
    __label__ = 15;
    break;
   case 12:
    var $x_2_val = HEAP32[$x_2 >> 2];
    _tempfree($31, $34, $x_2_val);
    var $42 = $cp_0 + 20 | 0;
    var $cp_0_in = $42;
    __label__ = 7;
    break;
   case 13:
    var $44 = $i_0 + 1 | 0;
    var $i_0 = $44;
    __label__ = 5;
    break;
   case 14:
    var $46 = $agg_result;
    var $$emscripten$temp$1 = _true;
    var $st$2$0 = $$emscripten$temp$1 | 0;
    var $47$0 = HEAP32[$st$2$0 >> 2];
    var $st$2$1 = $$emscripten$temp$1 + 4 | 0;
    var $47$1 = HEAP32[$st$2$1 >> 2];
    var $st$6$0 = $46 | 0;
    HEAP32[$st$6$0 >> 2] = $47$0;
    var $st$6$1 = $46 + 4 | 0;
    HEAP32[$st$6$1 >> 2] = $47$1;
    __label__ = 15;
    break;
   case 15:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_instat["X"] = 1;
function _jump($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = __stackBase__;
    if (($n | 0) == 296) {
      __label__ = 4;
      break;
    } else if (($n | 0) == 297) {
      __label__ = 6;
      break;
    } else if (($n | 0) == 298) {
      __label__ = 7;
      break;
    } else if (($n | 0) == 295) {
      var $x_0$1 = 0;
      var $x_0$0 = 515;
      __label__ = 8;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str18110 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n, tempInt));
   case 4:
    var $4 = HEAP32[$a >> 2];
    var $5 = ($4 | 0) == 0;
    if ($5) {
      var $x_0$1 = 0;
      var $x_0$0 = 259;
      __label__ = 8;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    _execute($1, $4);
    var $_2 = $1 + 4 | 0;
    var $tmp2 = HEAP32[$_2 >> 2];
    var $7 = _getfval($tmp2);
    var $8 = $7 & -1;
    HEAP32[_errorflag >> 2] = $8;
    var $x_0$1 = 0;
    var $x_0$0 = 259;
    __label__ = 8;
    break;
   case 6:
    var $x_0$1 = 0;
    var $x_0$0 = 771;
    __label__ = 8;
    break;
   case 7:
    var $x_0$1 = 0;
    var $x_0$0 = 1027;
    __label__ = 8;
    break;
   case 8:
    var $x_0$0;
    var $x_0$1;
    var $12 = $agg_result;
    var $st$3$0 = $12 | 0;
    HEAP32[$st$3$0 >> 2] = $x_0$0;
    var $st$3$1 = $12 + 4 | 0;
    HEAP32[$st$3$1 >> 2] = $x_0$1;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _fncn($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $x = __stackBase__;
    var $1 = HEAP32[$a >> 2];
    var $2 = $1;
    var $3 = $a + 4 | 0;
    var $4 = HEAP32[$3 >> 2];
    _execute($x, $4);
    var $5 = $x;
    if (($2 | 0) == 1) {
      __label__ = 3;
      break;
    } else if (($2 | 0) == 4) {
      __label__ = 4;
      break;
    } else if (($2 | 0) == 5) {
      __label__ = 5;
      break;
    } else if (($2 | 0) == 3) {
      __label__ = 6;
      break;
    } else if (($2 | 0) == 2) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 3:
    var $7 = $x + 4 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = _getsval($8);
    var $10 = _chrlen($9);
    var $11 = $10 | 0;
    var $u_0 = $11;
    var $x_2_val = $8;
    __label__ = 9;
    break;
   case 4:
    var $13 = $x + 4 | 0;
    var $14 = HEAP32[$13 >> 2];
    var $15 = _getfval($14);
    var $16 = _log($15);
    var $u_0 = $16;
    var $x_2_val = $14;
    __label__ = 9;
    break;
   case 5:
    var $18 = $x + 4 | 0;
    var $19 = HEAP32[$18 >> 2];
    var $20 = _getfval($19);
    var $21 = $20 & -1;
    var $22 = $21 | 0;
    var $u_0 = $22;
    var $x_2_val = $19;
    __label__ = 9;
    break;
   case 6:
    var $24 = $x + 4 | 0;
    var $25 = HEAP32[$24 >> 2];
    var $26 = _getfval($25);
    var $27 = _exp($26);
    var $u_0 = $27;
    var $x_2_val = $25;
    __label__ = 9;
    break;
   case 7:
    var $29 = $x + 4 | 0;
    var $30 = HEAP32[$29 >> 2];
    var $31 = _getfval($30);
    var $32 = _sqrt($31);
    var $u_0 = $32;
    var $x_2_val = $30;
    __label__ = 9;
    break;
   case 8:
    _error(STRING_TABLE.__str19111 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $2, tempInt));
   case 9:
    var $x_2_val;
    var $u_0;
    var $35 = $x;
    var $x_0_val = HEAP16[$35 >> 1];
    var $36 = $x_0_val & 255;
    var $37 = ($x_0_val & 65535) >>> 8;
    var $38 = $37 & 255;
    var $x_2 = $x + 4 | 0;
    _tempfree($36, $38, $x_2_val);
    _gettemp($x);
    var $39 = HEAP32[$x_2 >> 2];
    _setfval($39, $u_0);
    var $40 = $agg_result;
    var $st$13$0 = $5 | 0;
    var $41$0 = HEAP32[$st$13$0 >> 2];
    var $st$13$1 = $5 + 4 | 0;
    var $41$1 = HEAP32[$st$13$1 >> 2];
    var $st$17$0 = $40 | 0;
    HEAP32[$st$17$0 >> 2] = $41$0;
    var $st$17$1 = $40 + 4 | 0;
    HEAP32[$st$17$1 >> 2] = $41$1;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_fncn["X"] = 1;
function _member($s) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_01 = $s;
    __label__ = 3;
    break;
   case 3:
    var $_01;
    var $2 = HEAP8[$_01];
    var $3 = $2 << 24 >> 24 == 0;
    if ($3) {
      var $_0 = 0;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $5 = $_01 + 1 | 0;
    var $6 = $2 << 24 >> 24 == 61;
    if ($6) {
      var $_0 = 1;
      __label__ = 5;
      break;
    } else {
      var $_01 = $5;
      __label__ = 3;
      break;
    }
   case 5:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _match($v, $p) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $v + 4 | 0;
    var $2 = $1;
    var $3 = _regexec($2, $p);
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $5 = $v;
    var $6 = HEAP32[$5 >> 2];
    var $7 = _printf(STRING_TABLE.__str4277 | 0, (tempInt = STACKTOP, STACKTOP += 12, HEAP32[tempInt >> 2] = $6, HEAP32[tempInt + 4 >> 2] = $p, HEAP32[tempInt + 8 >> 2] = $3, tempInt));
    __label__ = 4;
    break;
   case 4:
    var $9 = ($3 | 0) == 0;
    var $10 = $9 & 1;
    STACKTOP = __stackBase__;
    return $10;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _print($agg_result, $a, $n) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $y = __stackBase__;
    var $1 = HEAP32[_print_s >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      var $10 = $1;
      __label__ = 5;
      break;
    }
   case 3:
    var $4 = HEAP32[_RECSIZE >> 2];
    var $5 = $4 + 1 | 0;
    HEAP32[_print_ssz >> 2] = $5;
    var $6 = _malloc($5);
    HEAP32[_print_s >> 2] = $6;
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 4;
      break;
    } else {
      var $10 = $6;
      __label__ = 5;
      break;
    }
   case 4:
    _error(STRING_TABLE.__str20112 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = 0, tempInt));
   case 5:
    var $10;
    HEAP8[$10] = 0;
    var $x_09 = HEAP32[$a >> 2];
    var $11 = ($x_09 | 0) == 0;
    if ($11) {
      var $54 = $10;
      __label__ = 17;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $12 = $y + 4 | 0;
    var $sp_010 = $10;
    var $x_011 = $x_09;
    __label__ = 8;
    break;
   case 7:
    var $sp_2_lcssa;
    var $x_0 = HEAP32[$17 >> 2];
    var $13 = ($x_0 | 0) == 0;
    if ($13) {
      __label__ = 16;
      break;
    } else {
      var $sp_010 = $sp_2_lcssa;
      var $x_011 = $x_0;
      __label__ = 8;
      break;
    }
   case 8:
    var $x_011;
    var $sp_010;
    _execute($y, $x_011);
    var $15 = HEAP32[$12 >> 2];
    var $16 = _getsval($15);
    var $17 = $x_011 + 4 | 0;
    var $18 = HEAP32[$17 >> 2];
    var $19 = ($18 | 0) == 0;
    var $ORS_val = HEAP32[_ORS >> 2];
    var $OFS_val = HEAP32[_OFS >> 2];
    var $_in = $19 ? $ORS_val : $OFS_val;
    var $20 = HEAP32[$_in >> 2];
    var $21 = _strlen($16);
    var $22 = _strlen($20);
    var $_sum = $21 + 1 | 0;
    var $_sum1 = $_sum + $22 | 0;
    var $23 = $sp_010 + $_sum1 | 0;
    var $24 = HEAP32[_print_s >> 2];
    var $25 = $23;
    var $26 = $24;
    var $27 = $25 - $26 | 0;
    var $28 = HEAP32[_print_ssz >> 2];
    var $29 = $27 >>> 0 > $28 >>> 0;
    if ($29) {
      __label__ = 9;
      break;
    } else {
      var $sp_1_ph = $sp_010;
      __label__ = 12;
      break;
    }
   case 9:
    HEAP32[_print_ssz >> 2] = $27;
    var $31 = _realloc($24, $27);
    HEAP32[_print_s >> 2] = $31;
    var $32 = ($31 | 0) == 0;
    if ($32) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    _error(STRING_TABLE.__str20112 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = 0, tempInt));
   case 11:
    var $35 = $sp_010;
    var $36 = $35 - $26 | 0;
    var $37 = $31 + $36 | 0;
    var $sp_1_ph = $37;
    __label__ = 12;
    break;
   case 12:
    var $sp_1_ph;
    var $38 = HEAP8[$16];
    HEAP8[$sp_1_ph] = $38;
    var $39 = $38 << 24 >> 24 == 0;
    if ($39) {
      var $sp_1_lcssa = $sp_1_ph;
      __label__ = 14;
      break;
    } else {
      var $p_02 = $16;
      var $sp_13 = $sp_1_ph;
      __label__ = 13;
      break;
    }
   case 13:
    var $sp_13;
    var $p_02;
    var $40 = $p_02 + 1 | 0;
    var $41 = $sp_13 + 1 | 0;
    var $42 = HEAP8[$40];
    HEAP8[$41] = $42;
    var $43 = $42 << 24 >> 24 == 0;
    if ($43) {
      var $sp_1_lcssa = $41;
      __label__ = 14;
      break;
    } else {
      var $p_02 = $40;
      var $sp_13 = $41;
      __label__ = 13;
      break;
    }
   case 14:
    var $sp_1_lcssa;
    var $44 = $y;
    var $y_0_val = HEAP16[$44 >> 1];
    var $45 = $y_0_val & 255;
    var $46 = ($y_0_val & 65535) >>> 8;
    var $47 = $46 & 255;
    var $y_2_val = HEAP32[$12 >> 2];
    _tempfree($45, $47, $y_2_val);
    var $48 = HEAP8[$20];
    HEAP8[$sp_1_lcssa] = $48;
    var $49 = $48 << 24 >> 24 == 0;
    if ($49) {
      var $sp_2_lcssa = $sp_1_lcssa;
      __label__ = 7;
      break;
    } else {
      var $q_04 = $20;
      var $sp_25 = $sp_1_lcssa;
      __label__ = 15;
      break;
    }
   case 15:
    var $sp_25;
    var $q_04;
    var $50 = $q_04 + 1 | 0;
    var $51 = $sp_25 + 1 | 0;
    var $52 = HEAP8[$50];
    HEAP8[$51] = $52;
    var $53 = $52 << 24 >> 24 == 0;
    if ($53) {
      var $sp_2_lcssa = $51;
      __label__ = 7;
      break;
    } else {
      var $q_04 = $50;
      var $sp_25 = $51;
      __label__ = 15;
      break;
    }
   case 16:
    var $_pre = HEAP32[_print_s >> 2];
    var $54 = $_pre;
    __label__ = 17;
    break;
   case 17:
    var $54;
    var $55 = $a + 4 | 0;
    var $56 = HEAP32[$55 >> 2];
    var $57 = ($56 | 0) == 0;
    if ($57) {
      __label__ = 18;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 18:
    var $59 = _printf(STRING_TABLE.__str10102 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $54, tempInt));
    var $60 = $agg_result;
    var $$emscripten$temp$0 = _true;
    var $st$3$0 = $$emscripten$temp$0 | 0;
    var $61$0 = HEAP32[$st$3$0 >> 2];
    var $st$3$1 = $$emscripten$temp$0 + 4 | 0;
    var $61$1 = HEAP32[$st$3$1 >> 2];
    var $st$7$0 = $60 | 0;
    HEAP32[$st$7$0 >> 2] = $61$0;
    var $st$7$1 = $60 + 4 | 0;
    HEAP32[$st$7$1 >> 2] = $61$1;
    __label__ = 20;
    break;
   case 19:
    var $63 = $56;
    var $64 = $a + 8 | 0;
    var $65 = HEAP32[$64 >> 2];
    _redirprint($54, $63, $65);
    var $66 = $agg_result;
    var $$emscripten$temp$1 = _false;
    var $st$6$0 = $$emscripten$temp$1 | 0;
    var $67$0 = HEAP32[$st$6$0 >> 2];
    var $st$6$1 = $$emscripten$temp$1 + 4 | 0;
    var $67$1 = HEAP32[$st$6$1 >> 2];
    var $st$10$0 = $66 | 0;
    HEAP32[$st$10$0 >> 2] = $67$0;
    var $st$10$1 = $66 + 4 | 0;
    HEAP32[$st$10$1 >> 2] = $67$1;
    __label__ = 20;
    break;
   case 20:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_print["X"] = 1;
function _main($argc, $argv) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    HEAP8[_mb_cur_max_b] = 1;
    var $1 = HEAP32[$argv >> 2];
    var $2 = _basename($1);
    var $3 = _tostring($2);
    HEAP32[_progname >> 2] = $3;
    var $4 = ($argc | 0) == 1;
    if ($4) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str3135 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $3, tempInt));
   case 4:
    _fldinit();
    _syminit();
    _growrec();
    var $_0 = $argv;
    var $_01 = $argc;
    __label__ = 5;
    break;
   case 5:
    var $_01;
    var $_0;
    var $7 = ($_01 | 0) > 1;
    if ($7) {
      __label__ = 6;
      break;
    } else {
      var $_124 = $_01;
      var $_15 = $_0;
      __label__ = 29;
      break;
    }
   case 6:
    var $9 = $_01 - 1 | 0;
    var $10 = $_0 + 4 | 0;
    var $11 = HEAP32[$10 >> 2];
    var $12 = HEAP8[$11];
    var $13 = $12 << 24 >> 24 == 45;
    if ($13) {
      __label__ = 7;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 7:
    var $15 = $11 + 1 | 0;
    var $16 = HEAP8[$15];
    var $17 = $16 << 24 >> 24 == 102;
    if ($17) {
      __label__ = 8;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 8:
    var $19 = $11 + 2 | 0;
    var $20 = HEAP8[$19];
    var $21 = $20 << 24 >> 24 == 0;
    if ($21) {
      __label__ = 9;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 9:
    var $23 = $_0 + 8 | 0;
    var $24 = HEAP32[$23 >> 2];
    var $25 = ($24 | 0) == 0;
    if ($25) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    _error(STRING_TABLE.__str4136 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 11:
    var $28 = HEAP8[$24];
    var $29 = $28 << 24 >> 24 == 45;
    if ($29) {
      __label__ = 12;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 12:
    var $31 = $24 + 1 | 0;
    var $32 = HEAP8[$31];
    var $33 = $32 << 24 >> 24 == 0;
    if ($33) {
      __label__ = 13;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 13:
    var $35 = HEAP32[_stdin >> 2];
    HEAP32[_yyin >> 2] = $35;
    __label__ = 16;
    break;
   case 14:
    var $37 = _fopen($24, STRING_TABLE.__str5137 | 0);
    HEAP32[_yyin >> 2] = $37;
    var $38 = ($37 | 0) == 0;
    if ($38) {
      __label__ = 15;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 15:
    var $40 = HEAP32[$23 >> 2];
    _error(STRING_TABLE.__str6138 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $40, tempInt));
   case 16:
    var $42 = $_01 - 2 | 0;
    var $_1 = $23;
    var $_12 = $42;
    __label__ = 28;
    break;
   case 17:
    if ($13) {
      __label__ = 18;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 18:
    var $44 = $11 + 1 | 0;
    var $45 = HEAP8[$44];
    var $46 = $45 << 24 >> 24 == 70;
    if ($46) {
      __label__ = 19;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 19:
    var $48 = $11 + 2 | 0;
    var $49 = HEAP8[$48];
    var $50 = $49 << 24 >> 24 == 116;
    if ($50) {
      __label__ = 20;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 20:
    var $52 = HEAP32[_FS >> 2];
    var $53 = HEAP32[$52 >> 2];
    HEAP8[$53] = 9;
    var $_0 = $10;
    var $_01 = $9;
    __label__ = 5;
    break;
   case 21:
    var $55 = _tostring($48);
    var $56 = HEAP32[_FS >> 2];
    HEAP32[$56 >> 2] = $55;
    var $_0 = $10;
    var $_01 = $9;
    __label__ = 5;
    break;
   case 22:
    if ($13) {
      __label__ = 26;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $_b2 = HEAP8[_dbg_b];
    if ($_b2) {
      __label__ = 24;
      break;
    } else {
      var $61 = $11;
      __label__ = 25;
      break;
    }
   case 24:
    var $59 = _printf(STRING_TABLE.__str7139 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $11, tempInt));
    var $_pre = HEAP32[$10 >> 2];
    var $61 = $_pre;
    __label__ = 25;
    break;
   case 25:
    var $61;
    HEAP32[_yyin >> 2] = 0;
    HEAP32[_lexprog >> 2] = $61;
    var $62 = HEAP32[$_0 >> 2];
    HEAP32[$10 >> 2] = $62;
    var $_1 = $10;
    var $_12 = $9;
    __label__ = 28;
    break;
   case 26:
    var $64 = _strcmp(STRING_TABLE.__str8142 | 0, $11);
    var $65 = ($64 | 0) == 0;
    if ($65) {
      __label__ = 27;
      break;
    } else {
      var $_0 = $10;
      var $_01 = $9;
      __label__ = 5;
      break;
    }
   case 27:
    HEAP8[_dbg_b] = 1;
    var $_0 = $10;
    var $_01 = $9;
    __label__ = 5;
    break;
   case 28:
    var $_12;
    var $_1;
    var $68 = ($_12 | 0) < 2;
    if ($68) {
      var $_124 = $_12;
      var $_15 = $_1;
      __label__ = 29;
      break;
    } else {
      var $_2 = $_1;
      var $_23 = $_12;
      __label__ = 30;
      break;
    }
   case 29:
    var $_15;
    var $_124;
    var $69 = HEAP32[$_15 >> 2];
    HEAP8[$69] = 45;
    var $70 = HEAP32[$_15 >> 2];
    var $71 = $70 + 1 | 0;
    HEAP8[$71] = 0;
    var $72 = $_124 + 1 | 0;
    var $73 = $_15 - 4 | 0;
    var $_2 = $73;
    var $_23 = $72;
    __label__ = 30;
    break;
   case 30:
    var $_23;
    var $_2;
    var $74 = $_23 - 1 | 0;
    HEAP32[_svargc >> 2] = $74;
    var $75 = $_2 + 4 | 0;
    HEAP32[_svargv >> 2] = $75;
    var $_b1 = HEAP8[_dbg_b];
    if ($_b1) {
      __label__ = 31;
      break;
    } else {
      var $80 = $75;
      __label__ = 32;
      break;
    }
   case 31:
    var $77 = HEAP32[$75 >> 2];
    var $78 = _printf(STRING_TABLE.__str9147 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $74, HEAP32[tempInt + 4 >> 2] = $77, tempInt));
    var $_pre3 = HEAP32[_svargv >> 2];
    var $80 = $_pre3;
    __label__ = 32;
    break;
   case 32:
    var $80;
    var $81 = HEAP32[$80 >> 2];
    var $82 = HEAP32[_FILENAME >> 2];
    HEAP32[$82 >> 2] = $81;
    _yyparse();
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 33;
      break;
    } else {
      __label__ = 34;
      break;
    }
   case 33:
    var $84 = HEAP32[_errorflag >> 2];
    var $85 = _printf(STRING_TABLE.__str10148 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $84, tempInt));
    __label__ = 34;
    break;
   case 34:
    var $87 = HEAP32[_errorflag >> 2];
    var $88 = ($87 | 0) == 0;
    if ($88) {
      __label__ = 36;
      break;
    } else {
      __label__ = 35;
      break;
    }
   case 35:
    _exit($87);
   case 36:
    var $91 = _nl_langinfo(50);
    HEAP32[_radixchar >> 2] = $91;
    var $92 = HEAP8[$91];
    var $93 = $92 << 24 >> 24 == 0;
    if ($93) {
      var $storemerge = STRING_TABLE.__str124 | 0;
      __label__ = 38;
      break;
    } else {
      __label__ = 37;
      break;
    }
   case 37:
    var $95 = _tostring($91);
    var $storemerge = $95;
    __label__ = 38;
    break;
   case 38:
    var $storemerge;
    HEAP32[_radixchar >> 2] = $storemerge;
    var $97 = _strlen($storemerge);
    HEAP32[_radixcharlen >> 2] = $97;
    _run();
    var $98 = HEAP32[_errorflag >> 2];
    _exit($98);
   default:
    assert(0, "bad label: " + __label__);
  }
}
Module["_main"] = _main;
_main["X"] = 1;
function _overflo() {
  _error(STRING_TABLE.__str273 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
}
function _makedfa($p) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $2 = _printf(STRING_TABLE.__str1274 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $p, tempInt));
    __label__ = 4;
    break;
   case 4:
    var $4 = _malloc(32);
    var $5 = $4;
    var $6 = ($4 | 0) == 0;
    if ($6) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    _overflo();
   case 6:
    var $9 = $4 + 4 | 0;
    var $10 = $9;
    var $11 = _regcomp($10, $p);
    if (($11 | 0) == 17) {
      __label__ = 7;
      break;
    } else if (($11 | 0) == 0) {
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    _overflo();
   case 8:
    _yyerror(STRING_TABLE.__str2275 | 0);
    _yyerror(STRING_TABLE.__str3276 | 0);
    _exit(2);
   case 9:
    var $15 = _tostring($p);
    var $16 = $4;
    HEAP32[$16 >> 2] = $15;
    STACKTOP = __stackBase__;
    return $5;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yylex() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_b = HEAP8[_yylex_sc_flag_b];
    if ($_b) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    HEAP32[_yy_start >> 2] = 1;
    HEAP8[_yylex_sc_flag_b] = 0;
    var $_0 = 125;
    __label__ = 282;
    break;
   case 4:
    var $_b1 = HEAP8[_yy_init_b];
    if ($_b1) {
      __label__ = 15;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    HEAP8[_yy_init_b] = 1;
    var $4 = HEAP32[_yy_start >> 2];
    var $5 = ($4 | 0) == 0;
    if ($5) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 7;
    break;
   case 7:
    var $8 = HEAP32[_yyin >> 2];
    var $9 = ($8 | 0) == 0;
    if ($9) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    var $11 = HEAP32[_stdin >> 2];
    HEAP32[_yyin >> 2] = $11;
    __label__ = 9;
    break;
   case 9:
    var $13 = HEAP32[_yyout >> 2];
    var $14 = ($13 | 0) == 0;
    if ($14) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    var $16 = HEAP32[_stdout >> 2];
    HEAP32[_yyout >> 2] = $16;
    __label__ = 11;
    break;
   case 11:
    var $18 = HEAP32[_yy_buffer_stack >> 2];
    var $19 = ($18 | 0) == 0;
    if ($19) {
      __label__ = 13;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $21 = HEAP32[$18 >> 2];
    var $22 = ($21 | 0) == 0;
    if ($22) {
      __label__ = 13;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 13:
    _yyensure_buffer_stack();
    var $24 = HEAP32[_yyin >> 2];
    var $25 = _yy_create_buffer($24);
    var $26 = HEAP32[_yy_buffer_stack >> 2];
    HEAP32[$26 >> 2] = $25;
    __label__ = 14;
    break;
   case 14:
    _yy_load_buffer_state();
    __label__ = 15;
    break;
   case 15:
    var $28 = HEAP32[_yy_c_buf_p >> 2];
    var $29 = HEAP8[_yy_hold_char];
    HEAP8[$28] = $29;
    var $30 = HEAP32[_yy_start >> 2];
    var $31 = HEAP32[_yy_buffer_stack >> 2];
    var $32 = HEAP32[$31 >> 2];
    var $33 = $32 + 28 | 0;
    var $34 = HEAP32[$33 >> 2];
    var $35 = $34 + $30 | 0;
    var $yy_current_state_0_ph = $35;
    var $yy_cp_0_ph = $28;
    var $yy_bp_0_ph = $28;
    __label__ = 16;
    break;
   case 16:
    var $yy_bp_0_ph;
    var $yy_cp_0_ph;
    var $yy_current_state_0_ph;
    var $yy_current_state_0 = $yy_current_state_0_ph;
    var $yy_cp_0 = $yy_cp_0_ph;
    __label__ = 17;
    break;
   case 17:
    var $yy_cp_0;
    var $yy_current_state_0;
    var $36 = HEAP8[$yy_cp_0];
    var $37 = $36 & 255;
    var $38 = _yy_ec + ($37 << 2) | 0;
    var $39 = HEAP32[$38 >> 2];
    var $40 = _yy_accept + ($yy_current_state_0 << 1) | 0;
    var $41 = HEAP16[$40 >> 1];
    var $42 = $41 << 16 >> 16 == 0;
    if ($42) {
      var $yy_current_state_1_ph = $yy_current_state_0;
      var $yy_c_0_ph_in = $39;
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    HEAP32[_yy_last_accepting_state >> 2] = $yy_current_state_0;
    HEAP32[_yy_last_accepting_cpos >> 2] = $yy_cp_0;
    var $yy_current_state_1_ph = $yy_current_state_0;
    var $yy_c_0_ph_in = $39;
    __label__ = 19;
    break;
   case 19:
    var $yy_c_0_ph_in;
    var $yy_current_state_1_ph;
    var $44 = $yy_c_0_ph_in & 255;
    var $yy_current_state_1 = $yy_current_state_1_ph;
    __label__ = 20;
    break;
   case 20:
    var $yy_current_state_1;
    var $46 = _yy_base + ($yy_current_state_1 << 1) | 0;
    var $47 = HEAP16[$46 >> 1];
    var $48 = $47 << 16 >> 16;
    var $49 = $48 + $44 | 0;
    var $50 = _yy_chk + ($49 << 1) | 0;
    var $51 = HEAP16[$50 >> 1];
    var $52 = $51 << 16 >> 16;
    var $53 = ($52 | 0) == ($yy_current_state_1 | 0);
    if ($53) {
      __label__ = 23;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $55 = _yy_def + ($yy_current_state_1 << 1) | 0;
    var $56 = HEAP16[$55 >> 1];
    var $57 = $56 << 16 >> 16;
    var $58 = $56 << 16 >> 16 > 196;
    if ($58) {
      __label__ = 22;
      break;
    } else {
      var $yy_current_state_1 = $57;
      __label__ = 20;
      break;
    }
   case 22:
    var $60 = _yy_meta + ($44 << 2) | 0;
    var $61 = HEAP32[$60 >> 2];
    var $yy_current_state_1_ph = $57;
    var $yy_c_0_ph_in = $61;
    __label__ = 19;
    break;
   case 23:
    var $63 = _yy_nxt + ($49 << 1) | 0;
    var $64 = HEAP16[$63 >> 1];
    var $65 = $64 << 16 >> 16;
    var $66 = $yy_cp_0 + 1 | 0;
    var $67 = _yy_base + ($65 << 1) | 0;
    var $68 = HEAP16[$67 >> 1];
    var $69 = $68 << 16 >> 16 == 246;
    if ($69) {
      var $yy_current_state_2_ph = $65;
      var $yy_cp_1_ph = $66;
      var $yy_bp_1_ph = $yy_bp_0_ph;
      __label__ = 24;
      break;
    } else {
      var $yy_current_state_0 = $65;
      var $yy_cp_0 = $66;
      __label__ = 17;
      break;
    }
   case 24:
    var $yy_bp_1_ph;
    var $yy_cp_1_ph;
    var $yy_current_state_2_ph;
    var $70 = $yy_bp_1_ph;
    var $yy_current_state_2 = $yy_current_state_2_ph;
    var $yy_cp_1 = $yy_cp_1_ph;
    __label__ = 25;
    break;
   case 25:
    var $yy_cp_1;
    var $yy_current_state_2;
    var $72 = _yy_accept + ($yy_current_state_2 << 1) | 0;
    var $73 = HEAP16[$72 >> 1];
    var $74 = $73 << 16 >> 16 == 0;
    if ($74) {
      __label__ = 26;
      break;
    } else {
      var $yy_cp_2 = $yy_cp_1;
      var $yy_act_0_in = $73;
      __label__ = 27;
      break;
    }
   case 26:
    var $76 = HEAP32[_yy_last_accepting_cpos >> 2];
    var $77 = HEAP32[_yy_last_accepting_state >> 2];
    var $78 = _yy_accept + ($77 << 1) | 0;
    var $79 = HEAP16[$78 >> 1];
    var $yy_cp_2 = $76;
    var $yy_act_0_in = $79;
    __label__ = 27;
    break;
   case 27:
    var $yy_act_0_in;
    var $yy_cp_2;
    var $yy_act_0 = $yy_act_0_in << 16 >> 16;
    HEAP32[_yytext >> 2] = $yy_bp_1_ph;
    var $81 = $yy_cp_2;
    var $82 = $81 - $70 | 0;
    HEAP32[_yyleng >> 2] = $82;
    var $83 = HEAP8[$yy_cp_2];
    HEAP8[_yy_hold_char] = $83;
    HEAP8[$yy_cp_2] = 0;
    HEAP32[_yy_c_buf_p >> 2] = $yy_cp_2;
    var $yy_act_1 = $yy_act_0;
    var $86 = $yy_bp_1_ph;
    var $85 = $yy_cp_2;
    __label__ = 28;
    break;
   case 28:
    var $85;
    var $86;
    var $yy_act_1;
    if (($yy_act_1 | 0) == 0) {
      __label__ = 29;
      break;
    } else if (($yy_act_1 | 0) == 1) {
      __label__ = 30;
      break;
    } else if (($yy_act_1 | 0) == 2) {
      __label__ = 33;
      break;
    } else if (($yy_act_1 | 0) == 3) {
      __label__ = 36;
      break;
    } else if (($yy_act_1 | 0) == 4) {
      __label__ = 38;
      break;
    } else if (($yy_act_1 | 0) == 5) {
      __label__ = 41;
      break;
    } else if (($yy_act_1 | 0) == 6) {
      __label__ = 43;
      break;
    } else if (($yy_act_1 | 0) == 7) {
      __label__ = 45;
      break;
    } else if (($yy_act_1 | 0) == 8) {
      __label__ = 47;
      break;
    } else if (($yy_act_1 | 0) == 9) {
      __label__ = 49;
      break;
    } else if (($yy_act_1 | 0) == 10) {
      __label__ = 51;
      break;
    } else if (($yy_act_1 | 0) == 11) {
      __label__ = 53;
      break;
    } else if (($yy_act_1 | 0) == 12) {
      __label__ = 56;
      break;
    } else if (($yy_act_1 | 0) == 13) {
      __label__ = 59;
      break;
    } else if (($yy_act_1 | 0) == 14) {
      __label__ = 62;
      break;
    } else if (($yy_act_1 | 0) == 15) {
      __label__ = 65;
      break;
    } else if (($yy_act_1 | 0) == 16) {
      __label__ = 68;
      break;
    } else if (($yy_act_1 | 0) == 17) {
      __label__ = 71;
      break;
    } else if (($yy_act_1 | 0) == 18) {
      __label__ = 74;
      break;
    } else if (($yy_act_1 | 0) == 19) {
      __label__ = 77;
      break;
    } else if (($yy_act_1 | 0) == 20) {
      __label__ = 80;
      break;
    } else if (($yy_act_1 | 0) == 21) {
      __label__ = 83;
      break;
    } else if (($yy_act_1 | 0) == 22) {
      __label__ = 86;
      break;
    } else if (($yy_act_1 | 0) == 23) {
      __label__ = 89;
      break;
    } else if (($yy_act_1 | 0) == 24) {
      __label__ = 92;
      break;
    } else if (($yy_act_1 | 0) == 25) {
      __label__ = 95;
      break;
    } else if (($yy_act_1 | 0) == 26) {
      __label__ = 98;
      break;
    } else if (($yy_act_1 | 0) == 27) {
      __label__ = 101;
      break;
    } else if (($yy_act_1 | 0) == 28) {
      __label__ = 104;
      break;
    } else if (($yy_act_1 | 0) == 29) {
      __label__ = 109;
      break;
    } else if (($yy_act_1 | 0) == 30) {
      __label__ = 111;
      break;
    } else if (($yy_act_1 | 0) == 31) {
      __label__ = 114;
      break;
    } else if (($yy_act_1 | 0) == 32) {
      __label__ = 117;
      break;
    } else if (($yy_act_1 | 0) == 33) {
      __label__ = 120;
      break;
    } else if (($yy_act_1 | 0) == 34) {
      __label__ = 123;
      break;
    } else if (($yy_act_1 | 0) == 35) {
      __label__ = 126;
      break;
    } else if (($yy_act_1 | 0) == 36) {
      __label__ = 129;
      break;
    } else if (($yy_act_1 | 0) == 37) {
      __label__ = 131;
      break;
    } else if (($yy_act_1 | 0) == 38) {
      __label__ = 133;
      break;
    } else if (($yy_act_1 | 0) == 39) {
      __label__ = 135;
      break;
    } else if (($yy_act_1 | 0) == 40) {
      __label__ = 137;
      break;
    } else if (($yy_act_1 | 0) == 41) {
      __label__ = 139;
      break;
    } else if (($yy_act_1 | 0) == 42) {
      __label__ = 141;
      break;
    } else if (($yy_act_1 | 0) == 43) {
      __label__ = 143;
      break;
    } else if (($yy_act_1 | 0) == 44) {
      __label__ = 145;
      break;
    } else if (($yy_act_1 | 0) == 45) {
      __label__ = 148;
      break;
    } else if (($yy_act_1 | 0) == 46) {
      __label__ = 151;
      break;
    } else if (($yy_act_1 | 0) == 47) {
      __label__ = 154;
      break;
    } else if (($yy_act_1 | 0) == 48) {
      __label__ = 157;
      break;
    } else if (($yy_act_1 | 0) == 49) {
      __label__ = 159;
      break;
    } else if (($yy_act_1 | 0) == 50) {
      __label__ = 161;
      break;
    } else if (($yy_act_1 | 0) == 51) {
      __label__ = 163;
      break;
    } else if (($yy_act_1 | 0) == 52) {
      __label__ = 165;
      break;
    } else if (($yy_act_1 | 0) == 53) {
      __label__ = 168;
      break;
    } else if (($yy_act_1 | 0) == 54) {
      __label__ = 171;
      break;
    } else if (($yy_act_1 | 0) == 55) {
      __label__ = 174;
      break;
    } else if (($yy_act_1 | 0) == 56) {
      __label__ = 177;
      break;
    } else if (($yy_act_1 | 0) == 57) {
      __label__ = 180;
      break;
    } else if (($yy_act_1 | 0) == 58) {
      __label__ = 183;
      break;
    } else if (($yy_act_1 | 0) == 59) {
      __label__ = 186;
      break;
    } else if (($yy_act_1 | 0) == 60) {
      __label__ = 189;
      break;
    } else if (($yy_act_1 | 0) == 61) {
      __label__ = 192;
      break;
    } else if (($yy_act_1 | 0) == 62) {
      __label__ = 194;
      break;
    } else if (($yy_act_1 | 0) == 63) {
      __label__ = 197;
      break;
    } else if (($yy_act_1 | 0) == 64) {
      __label__ = 201;
      break;
    } else if (($yy_act_1 | 0) == 65) {
      __label__ = 205;
      break;
    } else if (($yy_act_1 | 0) == 66) {
      __label__ = 209;
      break;
    } else if (($yy_act_1 | 0) == 67) {
      __label__ = 212;
      break;
    } else if (($yy_act_1 | 0) == 68) {
      __label__ = 215;
      break;
    } else if (($yy_act_1 | 0) == 69) {
      __label__ = 219;
      break;
    } else if (($yy_act_1 | 0) == 70) {
      __label__ = 222;
      break;
    } else if (($yy_act_1 | 0) == 71) {
      __label__ = 225;
      break;
    } else if (($yy_act_1 | 0) == 72) {
      __label__ = 228;
      break;
    } else if (($yy_act_1 | 0) == 73) {
      __label__ = 231;
      break;
    } else if (($yy_act_1 | 0) == 74) {
      __label__ = 234;
      break;
    } else if (($yy_act_1 | 0) == 75) {
      __label__ = 237;
      break;
    } else if (($yy_act_1 | 0) == 76) {
      __label__ = 240;
      break;
    } else if (($yy_act_1 | 0) == 77) {
      __label__ = 243;
      break;
    } else if (($yy_act_1 | 0) == 78) {
      __label__ = 246;
      break;
    } else if (($yy_act_1 | 0) == 79) {
      __label__ = 250;
      break;
    } else if (($yy_act_1 | 0) == 80) {
      __label__ = 253;
      break;
    } else if (($yy_act_1 | 0) == 81) {
      __label__ = 257;
      break;
    } else if (($yy_act_1 | 0) == 82) {
      __label__ = 260;
      break;
    } else if (($yy_act_1 | 0) == 83) {
      __label__ = 264;
      break;
    } else if (($yy_act_1 | 0) == 84) {
      __label__ = 268;
      break;
    } else if (($yy_act_1 | 0) == 85) {
      __label__ = 271;
      break;
    } else if (($yy_act_1 | 0) == 86 || ($yy_act_1 | 0) == 87 || ($yy_act_1 | 0) == 88 || ($yy_act_1 | 0) == 89 || ($yy_act_1 | 0) == 90 || ($yy_act_1 | 0) == 91) {
      var $_0 = 0;
      __label__ = 282;
      break;
    } else {
      __label__ = 281;
      break;
    }
   case 29:
    var $88 = HEAP8[_yy_hold_char];
    HEAP8[$yy_cp_2] = $88;
    var $89 = HEAP32[_yy_last_accepting_cpos >> 2];
    var $90 = HEAP32[_yy_last_accepting_state >> 2];
    var $yy_current_state_2 = $90;
    var $yy_cp_1 = $89;
    __label__ = 25;
    break;
   case 30:
    var $92 = HEAP32[_yyleng >> 2];
    var $93 = ($92 | 0) > 0;
    if ($93) {
      __label__ = 31;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 31:
    var $95 = $92 - 1 | 0;
    var $96 = $86 + $95 | 0;
    var $97 = HEAP8[$96];
    var $98 = $97 << 24 >> 24 == 10;
    var $99 = $98 & 1;
    var $100 = HEAP32[_yy_buffer_stack >> 2];
    var $101 = HEAP32[$100 >> 2];
    var $102 = $101 + 28 | 0;
    HEAP32[$102 >> 2] = $99;
    __label__ = 32;
    break;
   case 32:
    var $st$0$0 = _lineno | 0;
    var $103$0 = HEAP32[$st$0$0 >> 2];
    var $st$0$1 = _lineno + 4 | 0;
    var $103$1 = HEAP32[$st$0$1 >> 2];
    var $$emscripten$temp$0$0 = 1;
    var $$emscripten$temp$0$1 = 0;
    var $104$0 = (i64Math.add($103$0, $103$1, $$emscripten$temp$0$0, $$emscripten$temp$0$1), i64Math.result[0]);
    var $104$1 = i64Math.result[1];
    var $st$7$0 = _lineno | 0;
    HEAP32[$st$7$0 >> 2] = $104$0;
    var $st$7$1 = _lineno + 4 | 0;
    HEAP32[$st$7$1 >> 2] = $104$1;
    __label__ = 15;
    break;
   case 33:
    var $106 = HEAP32[_yyleng >> 2];
    var $107 = ($106 | 0) > 0;
    if ($107) {
      __label__ = 34;
      break;
    } else {
      __label__ = 35;
      break;
    }
   case 34:
    var $109 = $106 - 1 | 0;
    var $110 = $86 + $109 | 0;
    var $111 = HEAP8[$110];
    var $112 = $111 << 24 >> 24 == 10;
    var $113 = $112 & 1;
    var $114 = HEAP32[_yy_buffer_stack >> 2];
    var $115 = HEAP32[$114 >> 2];
    var $116 = $115 + 28 | 0;
    HEAP32[$116 >> 2] = $113;
    __label__ = 35;
    break;
   case 35:
    var $st$0$0 = _lineno | 0;
    var $117$0 = HEAP32[$st$0$0 >> 2];
    var $st$0$1 = _lineno + 4 | 0;
    var $117$1 = HEAP32[$st$0$1 >> 2];
    var $$emscripten$temp$1$0 = 1;
    var $$emscripten$temp$1$1 = 0;
    var $118$0 = (i64Math.add($117$0, $117$1, $$emscripten$temp$1$0, $$emscripten$temp$1$1), i64Math.result[0]);
    var $118$1 = i64Math.result[1];
    var $st$7$0 = _lineno | 0;
    HEAP32[$st$7$0 >> 2] = $118$0;
    var $st$7$1 = _lineno + 4 | 0;
    HEAP32[$st$7$1 >> 2] = $118$1;
    __label__ = 15;
    break;
   case 36:
    var $120 = HEAP32[_yyleng >> 2];
    var $121 = ($120 | 0) > 0;
    if ($121) {
      __label__ = 37;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 37:
    var $123 = $120 - 1 | 0;
    var $124 = $86 + $123 | 0;
    var $125 = HEAP8[$124];
    var $126 = $125 << 24 >> 24 == 10;
    var $127 = $126 & 1;
    var $128 = HEAP32[_yy_buffer_stack >> 2];
    var $129 = HEAP32[$128 >> 2];
    var $130 = $129 + 28 | 0;
    HEAP32[$130 >> 2] = $127;
    __label__ = 15;
    break;
   case 38:
    var $132 = HEAP32[_yyleng >> 2];
    var $133 = ($132 | 0) > 0;
    if ($133) {
      __label__ = 39;
      break;
    } else {
      __label__ = 40;
      break;
    }
   case 39:
    var $135 = $132 - 1 | 0;
    var $136 = $86 + $135 | 0;
    var $137 = HEAP8[$136];
    var $138 = $137 << 24 >> 24 == 10;
    var $139 = $138 & 1;
    var $140 = HEAP32[_yy_buffer_stack >> 2];
    var $141 = HEAP32[$140 >> 2];
    var $142 = $141 + 28 | 0;
    HEAP32[$142 >> 2] = $139;
    __label__ = 40;
    break;
   case 40:
    var $st$0$0 = _lineno | 0;
    var $143$0 = HEAP32[$st$0$0 >> 2];
    var $st$0$1 = _lineno + 4 | 0;
    var $143$1 = HEAP32[$st$0$1 >> 2];
    var $$emscripten$temp$2$0 = 1;
    var $$emscripten$temp$2$1 = 0;
    var $144$0 = (i64Math.add($143$0, $143$1, $$emscripten$temp$2$0, $$emscripten$temp$2$1), i64Math.result[0]);
    var $144$1 = i64Math.result[1];
    var $st$7$0 = _lineno | 0;
    HEAP32[$st$7$0 >> 2] = $144$0;
    var $st$7$1 = _lineno + 4 | 0;
    HEAP32[$st$7$1 >> 2] = $144$1;
    __label__ = 15;
    break;
   case 41:
    var $146 = HEAP32[_yyleng >> 2];
    var $147 = ($146 | 0) > 0;
    if ($147) {
      __label__ = 42;
      break;
    } else {
      var $_0 = 304;
      __label__ = 282;
      break;
    }
   case 42:
    var $149 = $146 - 1 | 0;
    var $150 = $86 + $149 | 0;
    var $151 = HEAP8[$150];
    var $152 = $151 << 24 >> 24 == 10;
    var $153 = $152 & 1;
    var $154 = HEAP32[_yy_buffer_stack >> 2];
    var $155 = HEAP32[$154 >> 2];
    var $156 = $155 + 28 | 0;
    HEAP32[$156 >> 2] = $153;
    var $_0 = 304;
    __label__ = 282;
    break;
   case 43:
    var $158 = HEAP32[_yyleng >> 2];
    var $159 = ($158 | 0) > 0;
    if ($159) {
      __label__ = 44;
      break;
    } else {
      var $_0 = 283;
      __label__ = 282;
      break;
    }
   case 44:
    var $161 = $158 - 1 | 0;
    var $162 = $86 + $161 | 0;
    var $163 = HEAP8[$162];
    var $164 = $163 << 24 >> 24 == 10;
    var $165 = $164 & 1;
    var $166 = HEAP32[_yy_buffer_stack >> 2];
    var $167 = HEAP32[$166 >> 2];
    var $168 = $167 + 28 | 0;
    HEAP32[$168 >> 2] = $165;
    var $_0 = 283;
    __label__ = 282;
    break;
   case 45:
    var $170 = HEAP32[_yyleng >> 2];
    var $171 = ($170 | 0) > 0;
    if ($171) {
      __label__ = 46;
      break;
    } else {
      var $_0 = 284;
      __label__ = 282;
      break;
    }
   case 46:
    var $173 = $170 - 1 | 0;
    var $174 = $86 + $173 | 0;
    var $175 = HEAP8[$174];
    var $176 = $175 << 24 >> 24 == 10;
    var $177 = $176 & 1;
    var $178 = HEAP32[_yy_buffer_stack >> 2];
    var $179 = HEAP32[$178 >> 2];
    var $180 = $179 + 28 | 0;
    HEAP32[$180 >> 2] = $177;
    var $_0 = 284;
    __label__ = 282;
    break;
   case 47:
    var $182 = HEAP32[_yyleng >> 2];
    var $183 = ($182 | 0) > 0;
    if ($183) {
      __label__ = 48;
      break;
    } else {
      var $_0 = -1;
      __label__ = 282;
      break;
    }
   case 48:
    var $185 = $182 - 1 | 0;
    var $186 = $86 + $185 | 0;
    var $187 = HEAP8[$186];
    var $188 = $187 << 24 >> 24 == 10;
    var $189 = $188 & 1;
    var $190 = HEAP32[_yy_buffer_stack >> 2];
    var $191 = HEAP32[$190 >> 2];
    var $192 = $191 + 28 | 0;
    HEAP32[$192 >> 2] = $189;
    var $_0 = -1;
    __label__ = 282;
    break;
   case 49:
    var $194 = HEAP32[_yyleng >> 2];
    var $195 = ($194 | 0) > 0;
    if ($195) {
      __label__ = 50;
      break;
    } else {
      var $_0 = 305;
      __label__ = 282;
      break;
    }
   case 50:
    var $197 = $194 - 1 | 0;
    var $198 = $86 + $197 | 0;
    var $199 = HEAP8[$198];
    var $200 = $199 << 24 >> 24 == 10;
    var $201 = $200 & 1;
    var $202 = HEAP32[_yy_buffer_stack >> 2];
    var $203 = HEAP32[$202 >> 2];
    var $204 = $203 + 28 | 0;
    HEAP32[$204 >> 2] = $201;
    var $_0 = 305;
    __label__ = 282;
    break;
   case 51:
    var $206 = HEAP32[_yyleng >> 2];
    var $207 = ($206 | 0) > 0;
    if ($207) {
      __label__ = 52;
      break;
    } else {
      var $_0 = 306;
      __label__ = 282;
      break;
    }
   case 52:
    var $209 = $206 - 1 | 0;
    var $210 = $86 + $209 | 0;
    var $211 = HEAP8[$210];
    var $212 = $211 << 24 >> 24 == 10;
    var $213 = $212 & 1;
    var $214 = HEAP32[_yy_buffer_stack >> 2];
    var $215 = HEAP32[$214 >> 2];
    var $216 = $215 + 28 | 0;
    HEAP32[$216 >> 2] = $213;
    var $_0 = 306;
    __label__ = 282;
    break;
   case 53:
    var $218 = HEAP32[_yyleng >> 2];
    var $219 = ($218 | 0) > 0;
    if ($219) {
      __label__ = 54;
      break;
    } else {
      __label__ = 55;
      break;
    }
   case 54:
    var $221 = $218 - 1 | 0;
    var $222 = $86 + $221 | 0;
    var $223 = HEAP8[$222];
    var $224 = $223 << 24 >> 24 == 10;
    var $225 = $224 & 1;
    var $226 = HEAP32[_yy_buffer_stack >> 2];
    var $227 = HEAP32[$226 >> 2];
    var $228 = $227 + 28 | 0;
    HEAP32[$228 >> 2] = $225;
    __label__ = 55;
    break;
   case 55:
    HEAP32[_yylval >> 2] = 266;
    var $_0 = 316;
    __label__ = 282;
    break;
   case 56:
    var $231 = HEAP32[_yyleng >> 2];
    var $232 = ($231 | 0) > 0;
    if ($232) {
      __label__ = 57;
      break;
    } else {
      __label__ = 58;
      break;
    }
   case 57:
    var $234 = $231 - 1 | 0;
    var $235 = $86 + $234 | 0;
    var $236 = HEAP8[$235];
    var $237 = $236 << 24 >> 24 == 10;
    var $238 = $237 & 1;
    var $239 = HEAP32[_yy_buffer_stack >> 2];
    var $240 = HEAP32[$239 >> 2];
    var $241 = $240 + 28 | 0;
    HEAP32[$241 >> 2] = $238;
    __label__ = 58;
    break;
   case 58:
    HEAP32[_yylval >> 2] = 267;
    var $_0 = 315;
    __label__ = 282;
    break;
   case 59:
    var $244 = HEAP32[_yyleng >> 2];
    var $245 = ($244 | 0) > 0;
    if ($245) {
      __label__ = 60;
      break;
    } else {
      __label__ = 61;
      break;
    }
   case 60:
    var $247 = $244 - 1 | 0;
    var $248 = $86 + $247 | 0;
    var $249 = HEAP8[$248];
    var $250 = $249 << 24 >> 24 == 10;
    var $251 = $250 & 1;
    var $252 = HEAP32[_yy_buffer_stack >> 2];
    var $253 = HEAP32[$252 >> 2];
    var $254 = $253 + 28 | 0;
    HEAP32[$254 >> 2] = $251;
    __label__ = 61;
    break;
   case 61:
    HEAP32[_yylval >> 2] = 268;
    var $_0 = 315;
    __label__ = 282;
    break;
   case 62:
    var $257 = HEAP32[_yyleng >> 2];
    var $258 = ($257 | 0) > 0;
    if ($258) {
      __label__ = 63;
      break;
    } else {
      __label__ = 64;
      break;
    }
   case 63:
    var $260 = $257 - 1 | 0;
    var $261 = $86 + $260 | 0;
    var $262 = HEAP8[$261];
    var $263 = $262 << 24 >> 24 == 10;
    var $264 = $263 & 1;
    var $265 = HEAP32[_yy_buffer_stack >> 2];
    var $266 = HEAP32[$265 >> 2];
    var $267 = $266 + 28 | 0;
    HEAP32[$267 >> 2] = $264;
    __label__ = 64;
    break;
   case 64:
    HEAP32[_yylval >> 2] = 261;
    var $_0 = 316;
    __label__ = 282;
    break;
   case 65:
    var $270 = HEAP32[_yyleng >> 2];
    var $271 = ($270 | 0) > 0;
    if ($271) {
      __label__ = 66;
      break;
    } else {
      __label__ = 67;
      break;
    }
   case 66:
    var $273 = $270 - 1 | 0;
    var $274 = $86 + $273 | 0;
    var $275 = HEAP8[$274];
    var $276 = $275 << 24 >> 24 == 10;
    var $277 = $276 & 1;
    var $278 = HEAP32[_yy_buffer_stack >> 2];
    var $279 = HEAP32[$278 >> 2];
    var $280 = $279 + 28 | 0;
    HEAP32[$280 >> 2] = $277;
    __label__ = 67;
    break;
   case 67:
    HEAP32[_yylval >> 2] = 262;
    var $_0 = 316;
    __label__ = 282;
    break;
   case 68:
    var $283 = HEAP32[_yyleng >> 2];
    var $284 = ($283 | 0) > 0;
    if ($284) {
      __label__ = 69;
      break;
    } else {
      __label__ = 70;
      break;
    }
   case 69:
    var $286 = $283 - 1 | 0;
    var $287 = $86 + $286 | 0;
    var $288 = HEAP8[$287];
    var $289 = $288 << 24 >> 24 == 10;
    var $290 = $289 & 1;
    var $291 = HEAP32[_yy_buffer_stack >> 2];
    var $292 = HEAP32[$291 >> 2];
    var $293 = $292 + 28 | 0;
    HEAP32[$293 >> 2] = $290;
    __label__ = 70;
    break;
   case 70:
    HEAP32[_yylval >> 2] = 265;
    var $_0 = 316;
    __label__ = 282;
    break;
   case 71:
    var $296 = HEAP32[_yyleng >> 2];
    var $297 = ($296 | 0) > 0;
    if ($297) {
      __label__ = 72;
      break;
    } else {
      __label__ = 73;
      break;
    }
   case 72:
    var $299 = $296 - 1 | 0;
    var $300 = $86 + $299 | 0;
    var $301 = HEAP8[$300];
    var $302 = $301 << 24 >> 24 == 10;
    var $303 = $302 & 1;
    var $304 = HEAP32[_yy_buffer_stack >> 2];
    var $305 = HEAP32[$304 >> 2];
    var $306 = $305 + 28 | 0;
    HEAP32[$306 >> 2] = $303;
    __label__ = 73;
    break;
   case 73:
    HEAP32[_yylval >> 2] = 264;
    var $_0 = 316;
    __label__ = 282;
    break;
   case 74:
    var $309 = HEAP32[_yyleng >> 2];
    var $310 = ($309 | 0) > 0;
    if ($310) {
      __label__ = 75;
      break;
    } else {
      __label__ = 76;
      break;
    }
   case 75:
    var $312 = $309 - 1 | 0;
    var $313 = $86 + $312 | 0;
    var $314 = HEAP8[$313];
    var $315 = $314 << 24 >> 24 == 10;
    var $316 = $315 & 1;
    var $317 = HEAP32[_yy_buffer_stack >> 2];
    var $318 = HEAP32[$317 >> 2];
    var $319 = $318 + 28 | 0;
    HEAP32[$319 >> 2] = $316;
    __label__ = 76;
    break;
   case 76:
    HEAP32[_yylval >> 2] = 263;
    var $_0 = 316;
    __label__ = 282;
    break;
   case 77:
    var $322 = HEAP32[_yyleng >> 2];
    var $323 = ($322 | 0) > 0;
    if ($323) {
      __label__ = 78;
      break;
    } else {
      __label__ = 79;
      break;
    }
   case 78:
    var $325 = $322 - 1 | 0;
    var $326 = $86 + $325 | 0;
    var $327 = HEAP8[$326];
    var $328 = $327 << 24 >> 24 == 10;
    var $329 = $328 & 1;
    var $330 = HEAP32[_yy_buffer_stack >> 2];
    var $331 = HEAP32[$330 >> 2];
    var $332 = $331 + 28 | 0;
    HEAP32[$332 >> 2] = $329;
    __label__ = 79;
    break;
   case 79:
    HEAP32[_yylval >> 2] = 269;
    var $_0 = 316;
    __label__ = 282;
    break;
   case 80:
    var $335 = HEAP32[_yyleng >> 2];
    var $336 = ($335 | 0) > 0;
    if ($336) {
      __label__ = 81;
      break;
    } else {
      __label__ = 82;
      break;
    }
   case 81:
    var $338 = $335 - 1 | 0;
    var $339 = $86 + $338 | 0;
    var $340 = HEAP8[$339];
    var $341 = $340 << 24 >> 24 == 10;
    var $342 = $341 & 1;
    var $343 = HEAP32[_yy_buffer_stack >> 2];
    var $344 = HEAP32[$343 >> 2];
    var $345 = $344 + 28 | 0;
    HEAP32[$345 >> 2] = $342;
    __label__ = 82;
    break;
   case 82:
    HEAP32[_yylval >> 2] = 328;
    var $_0 = 328;
    __label__ = 282;
    break;
   case 83:
    var $348 = HEAP32[_yyleng >> 2];
    var $349 = ($348 | 0) > 0;
    if ($349) {
      __label__ = 84;
      break;
    } else {
      __label__ = 85;
      break;
    }
   case 84:
    var $351 = $348 - 1 | 0;
    var $352 = $86 + $351 | 0;
    var $353 = HEAP8[$352];
    var $354 = $353 << 24 >> 24 == 10;
    var $355 = $354 & 1;
    var $356 = HEAP32[_yy_buffer_stack >> 2];
    var $357 = HEAP32[$356 >> 2];
    var $358 = $357 + 28 | 0;
    HEAP32[$358 >> 2] = $355;
    __label__ = 85;
    break;
   case 85:
    HEAP32[_yylval >> 2] = 327;
    var $_0 = 327;
    __label__ = 282;
    break;
   case 86:
    var $361 = HEAP32[_yyleng >> 2];
    var $362 = ($361 | 0) > 0;
    if ($362) {
      __label__ = 87;
      break;
    } else {
      __label__ = 88;
      break;
    }
   case 87:
    var $364 = $361 - 1 | 0;
    var $365 = $86 + $364 | 0;
    var $366 = HEAP8[$365];
    var $367 = $366 << 24 >> 24 == 10;
    var $368 = $367 & 1;
    var $369 = HEAP32[_yy_buffer_stack >> 2];
    var $370 = HEAP32[$369 >> 2];
    var $371 = $370 + 28 | 0;
    HEAP32[$371 >> 2] = $368;
    __label__ = 88;
    break;
   case 88:
    HEAP32[_yylval >> 2] = 277;
    var $_0 = 303;
    __label__ = 282;
    break;
   case 89:
    var $374 = HEAP32[_yyleng >> 2];
    var $375 = ($374 | 0) > 0;
    if ($375) {
      __label__ = 90;
      break;
    } else {
      __label__ = 91;
      break;
    }
   case 90:
    var $377 = $374 - 1 | 0;
    var $378 = $86 + $377 | 0;
    var $379 = HEAP8[$378];
    var $380 = $379 << 24 >> 24 == 10;
    var $381 = $380 & 1;
    var $382 = HEAP32[_yy_buffer_stack >> 2];
    var $383 = HEAP32[$382 >> 2];
    var $384 = $383 + 28 | 0;
    HEAP32[$384 >> 2] = $381;
    __label__ = 91;
    break;
   case 91:
    HEAP32[_yylval >> 2] = 278;
    var $_0 = 303;
    __label__ = 282;
    break;
   case 92:
    var $387 = HEAP32[_yyleng >> 2];
    var $388 = ($387 | 0) > 0;
    if ($388) {
      __label__ = 93;
      break;
    } else {
      __label__ = 94;
      break;
    }
   case 93:
    var $390 = $387 - 1 | 0;
    var $391 = $86 + $390 | 0;
    var $392 = HEAP8[$391];
    var $393 = $392 << 24 >> 24 == 10;
    var $394 = $393 & 1;
    var $395 = HEAP32[_yy_buffer_stack >> 2];
    var $396 = HEAP32[$395 >> 2];
    var $397 = $396 + 28 | 0;
    HEAP32[$397 >> 2] = $394;
    __label__ = 94;
    break;
   case 94:
    HEAP32[_yylval >> 2] = 279;
    var $_0 = 303;
    __label__ = 282;
    break;
   case 95:
    var $400 = HEAP32[_yyleng >> 2];
    var $401 = ($400 | 0) > 0;
    if ($401) {
      __label__ = 96;
      break;
    } else {
      __label__ = 97;
      break;
    }
   case 96:
    var $403 = $400 - 1 | 0;
    var $404 = $86 + $403 | 0;
    var $405 = HEAP8[$404];
    var $406 = $405 << 24 >> 24 == 10;
    var $407 = $406 & 1;
    var $408 = HEAP32[_yy_buffer_stack >> 2];
    var $409 = HEAP32[$408 >> 2];
    var $410 = $409 + 28 | 0;
    HEAP32[$410 >> 2] = $407;
    __label__ = 97;
    break;
   case 97:
    HEAP32[_yylval >> 2] = 280;
    var $_0 = 303;
    __label__ = 282;
    break;
   case 98:
    var $413 = HEAP32[_yyleng >> 2];
    var $414 = ($413 | 0) > 0;
    if ($414) {
      __label__ = 99;
      break;
    } else {
      __label__ = 100;
      break;
    }
   case 99:
    var $416 = $413 - 1 | 0;
    var $417 = $86 + $416 | 0;
    var $418 = HEAP8[$417];
    var $419 = $418 << 24 >> 24 == 10;
    var $420 = $419 & 1;
    var $421 = HEAP32[_yy_buffer_stack >> 2];
    var $422 = HEAP32[$421 >> 2];
    var $423 = $422 + 28 | 0;
    HEAP32[$423 >> 2] = $420;
    __label__ = 100;
    break;
   case 100:
    HEAP32[_yylval >> 2] = 281;
    var $_0 = 303;
    __label__ = 282;
    break;
   case 101:
    var $426 = HEAP32[_yyleng >> 2];
    var $427 = ($426 | 0) > 0;
    if ($427) {
      __label__ = 102;
      break;
    } else {
      __label__ = 103;
      break;
    }
   case 102:
    var $429 = $426 - 1 | 0;
    var $430 = $86 + $429 | 0;
    var $431 = HEAP8[$430];
    var $432 = $431 << 24 >> 24 == 10;
    var $433 = $432 & 1;
    var $434 = HEAP32[_yy_buffer_stack >> 2];
    var $435 = HEAP32[$434 >> 2];
    var $436 = $435 + 28 | 0;
    HEAP32[$436 >> 2] = $433;
    __label__ = 103;
    break;
   case 103:
    HEAP32[_yylval >> 2] = 276;
    var $_0 = 303;
    __label__ = 282;
    break;
   case 104:
    var $439 = HEAP32[_yyleng >> 2];
    var $440 = ($439 | 0) > 0;
    if ($440) {
      __label__ = 105;
      break;
    } else {
      __label__ = 106;
      break;
    }
   case 105:
    var $442 = $439 - 1 | 0;
    var $443 = $86 + $442 | 0;
    var $444 = HEAP8[$443];
    var $445 = $444 << 24 >> 24 == 10;
    var $446 = $445 & 1;
    var $447 = HEAP32[_yy_buffer_stack >> 2];
    var $448 = HEAP32[$447 >> 2];
    var $449 = $448 + 28 | 0;
    HEAP32[$449 >> 2] = $446;
    __label__ = 106;
    break;
   case 106:
    var $451 = $86 + 1 | 0;
    var $452 = _atoi($451);
    var $453 = ($452 | 0) == 0;
    if ($453) {
      __label__ = 107;
      break;
    } else {
      __label__ = 108;
      break;
    }
   case 107:
    var $455 = _lookup(STRING_TABLE.__str3321 | 0, _symtab | 0);
    var $456 = $455;
    HEAP32[_yylval >> 2] = $456;
    var $_0 = 322;
    __label__ = 282;
    break;
   case 108:
    var $458 = _fieldadr($452);
    var $459 = $458;
    HEAP32[_yylval >> 2] = $459;
    var $_0 = 334;
    __label__ = 282;
    break;
   case 109:
    var $461 = HEAP32[_yyleng >> 2];
    var $462 = ($461 | 0) > 0;
    if ($462) {
      __label__ = 110;
      break;
    } else {
      var $_0 = 333;
      __label__ = 282;
      break;
    }
   case 110:
    var $464 = $461 - 1 | 0;
    var $465 = $86 + $464 | 0;
    var $466 = HEAP8[$465];
    var $467 = $466 << 24 >> 24 == 10;
    var $468 = $467 & 1;
    var $469 = HEAP32[_yy_buffer_stack >> 2];
    var $470 = HEAP32[$469 >> 2];
    var $471 = $470 + 28 | 0;
    HEAP32[$471 >> 2] = $468;
    var $_0 = 333;
    __label__ = 282;
    break;
   case 111:
    var $473 = HEAP32[_yyleng >> 2];
    var $474 = ($473 | 0) > 0;
    if ($474) {
      __label__ = 112;
      break;
    } else {
      __label__ = 113;
      break;
    }
   case 112:
    var $476 = $473 - 1 | 0;
    var $477 = $86 + $476 | 0;
    var $478 = HEAP8[$477];
    var $479 = $478 << 24 >> 24 == 10;
    var $480 = $479 & 1;
    var $481 = HEAP32[_yy_buffer_stack >> 2];
    var $482 = HEAP32[$481 >> 2];
    var $483 = $482 + 28 | 0;
    HEAP32[$483 >> 2] = $480;
    __label__ = 113;
    break;
   case 113:
    HEAP8[_mustfld_b] = 1;
    var $485 = _setsymtab($86, _EMPTY | 0, 0, 2, _symtab | 0);
    var $486 = $485;
    HEAP32[_yylval >> 2] = $486;
    var $_0 = 312;
    __label__ = 282;
    break;
   case 114:
    var $488 = HEAP32[_yyleng >> 2];
    var $489 = ($488 | 0) > 0;
    if ($489) {
      __label__ = 115;
      break;
    } else {
      __label__ = 116;
      break;
    }
   case 115:
    var $491 = $488 - 1 | 0;
    var $492 = $86 + $491 | 0;
    var $493 = HEAP8[$492];
    var $494 = $493 << 24 >> 24 == 10;
    var $495 = $494 & 1;
    var $496 = HEAP32[_yy_buffer_stack >> 2];
    var $497 = HEAP32[$496 >> 2];
    var $498 = $497 + 28 | 0;
    HEAP32[$498 >> 2] = $495;
    __label__ = 116;
    break;
   case 116:
    var $500 = _atof($86);
    var $501 = _setsymtab($86, _EMPTY | 0, $500, 10, _symtab | 0);
    var $502 = $501;
    HEAP32[_yylval >> 2] = $502;
    var $_0 = 313;
    __label__ = 282;
    break;
   case 117:
    var $504 = HEAP32[_yyleng >> 2];
    var $505 = ($504 | 0) > 0;
    if ($505) {
      __label__ = 118;
      break;
    } else {
      __label__ = 119;
      break;
    }
   case 118:
    var $507 = $504 - 1 | 0;
    var $508 = $86 + $507 | 0;
    var $509 = HEAP8[$508];
    var $510 = $509 << 24 >> 24 == 10;
    var $511 = $510 & 1;
    var $512 = HEAP32[_yy_buffer_stack >> 2];
    var $513 = HEAP32[$512 >> 2];
    var $514 = $513 + 28 | 0;
    HEAP32[$514 >> 2] = $511;
    __label__ = 119;
    break;
   case 119:
    HEAP8[_yylex_sc_flag_b] = 1;
    var $st$1$0 = _lineno | 0;
    var $515$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = _lineno + 4 | 0;
    var $515$1 = HEAP32[$st$1$1 >> 2];
    var $$emscripten$temp$3$0 = 1;
    var $$emscripten$temp$3$1 = 0;
    var $516$0 = (i64Math.add($515$0, $515$1, $$emscripten$temp$3$0, $$emscripten$temp$3$1), i64Math.result[0]);
    var $516$1 = i64Math.result[1];
    var $st$8$0 = _lineno | 0;
    HEAP32[$st$8$0 >> 2] = $516$0;
    var $st$8$1 = _lineno + 4 | 0;
    HEAP32[$st$8$1 >> 2] = $516$1;
    var $_0 = 59;
    __label__ = 282;
    break;
   case 120:
    var $518 = HEAP32[_yyleng >> 2];
    var $519 = ($518 | 0) > 0;
    if ($519) {
      __label__ = 121;
      break;
    } else {
      __label__ = 122;
      break;
    }
   case 121:
    var $521 = $518 - 1 | 0;
    var $522 = $86 + $521 | 0;
    var $523 = HEAP8[$522];
    var $524 = $523 << 24 >> 24 == 10;
    var $525 = $524 & 1;
    var $526 = HEAP32[_yy_buffer_stack >> 2];
    var $527 = HEAP32[$526 >> 2];
    var $528 = $527 + 28 | 0;
    HEAP32[$528 >> 2] = $525;
    __label__ = 122;
    break;
   case 122:
    HEAP8[_yylex_sc_flag_b] = 1;
    var $_0 = 59;
    __label__ = 282;
    break;
   case 123:
    var $531 = HEAP32[_yyleng >> 2];
    var $532 = ($531 | 0) > 0;
    if ($532) {
      __label__ = 124;
      break;
    } else {
      __label__ = 125;
      break;
    }
   case 124:
    var $534 = $531 - 1 | 0;
    var $535 = $86 + $534 | 0;
    var $536 = HEAP8[$535];
    var $537 = $536 << 24 >> 24 == 10;
    var $538 = $537 & 1;
    var $539 = HEAP32[_yy_buffer_stack >> 2];
    var $540 = HEAP32[$539 >> 2];
    var $541 = $540 + 28 | 0;
    HEAP32[$541 >> 2] = $538;
    __label__ = 125;
    break;
   case 125:
    var $st$0$0 = _lineno | 0;
    var $542$0 = HEAP32[$st$0$0 >> 2];
    var $st$0$1 = _lineno + 4 | 0;
    var $542$1 = HEAP32[$st$0$1 >> 2];
    var $$emscripten$temp$4$0 = 1;
    var $$emscripten$temp$4$1 = 0;
    var $543$0 = (i64Math.add($542$0, $542$1, $$emscripten$temp$4$0, $$emscripten$temp$4$1), i64Math.result[0]);
    var $543$1 = i64Math.result[1];
    var $st$7$0 = _lineno | 0;
    HEAP32[$st$7$0 >> 2] = $543$0;
    var $st$7$1 = _lineno + 4 | 0;
    HEAP32[$st$7$1 >> 2] = $543$1;
    var $_0 = 59;
    __label__ = 282;
    break;
   case 126:
    var $545 = HEAP32[_yyleng >> 2];
    var $546 = ($545 | 0) > 0;
    if ($546) {
      __label__ = 127;
      break;
    } else {
      __label__ = 128;
      break;
    }
   case 127:
    var $548 = $545 - 1 | 0;
    var $549 = $86 + $548 | 0;
    var $550 = HEAP8[$549];
    var $551 = $550 << 24 >> 24 == 10;
    var $552 = $551 & 1;
    var $553 = HEAP32[_yy_buffer_stack >> 2];
    var $554 = HEAP32[$553 >> 2];
    var $555 = $554 + 28 | 0;
    HEAP32[$555 >> 2] = $552;
    __label__ = 128;
    break;
   case 128:
    var $st$0$0 = _lineno | 0;
    var $556$0 = HEAP32[$st$0$0 >> 2];
    var $st$0$1 = _lineno + 4 | 0;
    var $556$1 = HEAP32[$st$0$1 >> 2];
    var $$emscripten$temp$5$0 = 1;
    var $$emscripten$temp$5$1 = 0;
    var $557$0 = (i64Math.add($556$0, $556$1, $$emscripten$temp$5$0, $$emscripten$temp$5$1), i64Math.result[0]);
    var $557$1 = i64Math.result[1];
    var $st$7$0 = _lineno | 0;
    HEAP32[$st$7$0 >> 2] = $557$0;
    var $st$7$1 = _lineno + 4 | 0;
    HEAP32[$st$7$1 >> 2] = $557$1;
    var $_0 = 285;
    __label__ = 282;
    break;
   case 129:
    var $559 = HEAP32[_yyleng >> 2];
    var $560 = ($559 | 0) > 0;
    if ($560) {
      __label__ = 130;
      break;
    } else {
      var $_0 = 292;
      __label__ = 282;
      break;
    }
   case 130:
    var $562 = $559 - 1 | 0;
    var $563 = $86 + $562 | 0;
    var $564 = HEAP8[$563];
    var $565 = $564 << 24 >> 24 == 10;
    var $566 = $565 & 1;
    var $567 = HEAP32[_yy_buffer_stack >> 2];
    var $568 = HEAP32[$567 >> 2];
    var $569 = $568 + 28 | 0;
    HEAP32[$569 >> 2] = $566;
    var $_0 = 292;
    __label__ = 282;
    break;
   case 131:
    var $571 = HEAP32[_yyleng >> 2];
    var $572 = ($571 | 0) > 0;
    if ($572) {
      __label__ = 132;
      break;
    } else {
      var $_0 = 293;
      __label__ = 282;
      break;
    }
   case 132:
    var $574 = $571 - 1 | 0;
    var $575 = $86 + $574 | 0;
    var $576 = HEAP8[$575];
    var $577 = $576 << 24 >> 24 == 10;
    var $578 = $577 & 1;
    var $579 = HEAP32[_yy_buffer_stack >> 2];
    var $580 = HEAP32[$579 >> 2];
    var $581 = $580 + 28 | 0;
    HEAP32[$581 >> 2] = $578;
    var $_0 = 293;
    __label__ = 282;
    break;
   case 133:
    var $583 = HEAP32[_yyleng >> 2];
    var $584 = ($583 | 0) > 0;
    if ($584) {
      __label__ = 134;
      break;
    } else {
      var $_0 = 290;
      __label__ = 282;
      break;
    }
   case 134:
    var $586 = $583 - 1 | 0;
    var $587 = $86 + $586 | 0;
    var $588 = HEAP8[$587];
    var $589 = $588 << 24 >> 24 == 10;
    var $590 = $589 & 1;
    var $591 = HEAP32[_yy_buffer_stack >> 2];
    var $592 = HEAP32[$591 >> 2];
    var $593 = $592 + 28 | 0;
    HEAP32[$593 >> 2] = $590;
    var $_0 = 290;
    __label__ = 282;
    break;
   case 135:
    var $595 = HEAP32[_yyleng >> 2];
    var $596 = ($595 | 0) > 0;
    if ($596) {
      __label__ = 136;
      break;
    } else {
      var $_0 = 291;
      __label__ = 282;
      break;
    }
   case 136:
    var $598 = $595 - 1 | 0;
    var $599 = $86 + $598 | 0;
    var $600 = HEAP8[$599];
    var $601 = $600 << 24 >> 24 == 10;
    var $602 = $601 & 1;
    var $603 = HEAP32[_yy_buffer_stack >> 2];
    var $604 = HEAP32[$603 >> 2];
    var $605 = $604 + 28 | 0;
    HEAP32[$605 >> 2] = $602;
    var $_0 = 291;
    __label__ = 282;
    break;
   case 137:
    var $607 = HEAP32[_yyleng >> 2];
    var $608 = ($607 | 0) > 0;
    if ($608) {
      __label__ = 138;
      break;
    } else {
      var $_0 = 295;
      __label__ = 282;
      break;
    }
   case 138:
    var $610 = $607 - 1 | 0;
    var $611 = $86 + $610 | 0;
    var $612 = HEAP8[$611];
    var $613 = $612 << 24 >> 24 == 10;
    var $614 = $613 & 1;
    var $615 = HEAP32[_yy_buffer_stack >> 2];
    var $616 = HEAP32[$615 >> 2];
    var $617 = $616 + 28 | 0;
    HEAP32[$617 >> 2] = $614;
    var $_0 = 295;
    __label__ = 282;
    break;
   case 139:
    var $619 = HEAP32[_yyleng >> 2];
    var $620 = ($619 | 0) > 0;
    if ($620) {
      __label__ = 140;
      break;
    } else {
      var $_0 = 296;
      __label__ = 282;
      break;
    }
   case 140:
    var $622 = $619 - 1 | 0;
    var $623 = $86 + $622 | 0;
    var $624 = HEAP8[$623];
    var $625 = $624 << 24 >> 24 == 10;
    var $626 = $625 & 1;
    var $627 = HEAP32[_yy_buffer_stack >> 2];
    var $628 = HEAP32[$627 >> 2];
    var $629 = $628 + 28 | 0;
    HEAP32[$629 >> 2] = $626;
    var $_0 = 296;
    __label__ = 282;
    break;
   case 141:
    var $631 = HEAP32[_yyleng >> 2];
    var $632 = ($631 | 0) > 0;
    if ($632) {
      __label__ = 142;
      break;
    } else {
      var $_0 = 297;
      __label__ = 282;
      break;
    }
   case 142:
    var $634 = $631 - 1 | 0;
    var $635 = $86 + $634 | 0;
    var $636 = HEAP8[$635];
    var $637 = $636 << 24 >> 24 == 10;
    var $638 = $637 & 1;
    var $639 = HEAP32[_yy_buffer_stack >> 2];
    var $640 = HEAP32[$639 >> 2];
    var $641 = $640 + 28 | 0;
    HEAP32[$641 >> 2] = $638;
    var $_0 = 297;
    __label__ = 282;
    break;
   case 143:
    var $643 = HEAP32[_yyleng >> 2];
    var $644 = ($643 | 0) > 0;
    if ($644) {
      __label__ = 144;
      break;
    } else {
      var $_0 = 298;
      __label__ = 282;
      break;
    }
   case 144:
    var $646 = $643 - 1 | 0;
    var $647 = $86 + $646 | 0;
    var $648 = HEAP8[$647];
    var $649 = $648 << 24 >> 24 == 10;
    var $650 = $649 & 1;
    var $651 = HEAP32[_yy_buffer_stack >> 2];
    var $652 = HEAP32[$651 >> 2];
    var $653 = $652 + 28 | 0;
    HEAP32[$653 >> 2] = $650;
    var $_0 = 298;
    __label__ = 282;
    break;
   case 145:
    var $655 = HEAP32[_yyleng >> 2];
    var $656 = ($655 | 0) > 0;
    if ($656) {
      __label__ = 146;
      break;
    } else {
      __label__ = 147;
      break;
    }
   case 146:
    var $658 = $655 - 1 | 0;
    var $659 = $86 + $658 | 0;
    var $660 = HEAP8[$659];
    var $661 = $660 << 24 >> 24 == 10;
    var $662 = $661 & 1;
    var $663 = HEAP32[_yy_buffer_stack >> 2];
    var $664 = HEAP32[$663 >> 2];
    var $665 = $664 + 28 | 0;
    HEAP32[$665 >> 2] = $662;
    __label__ = 147;
    break;
   case 147:
    HEAP32[_yylval >> 2] = 286;
    var $_0 = 286;
    __label__ = 282;
    break;
   case 148:
    var $668 = HEAP32[_yyleng >> 2];
    var $669 = ($668 | 0) > 0;
    if ($669) {
      __label__ = 149;
      break;
    } else {
      __label__ = 150;
      break;
    }
   case 149:
    var $671 = $668 - 1 | 0;
    var $672 = $86 + $671 | 0;
    var $673 = HEAP8[$672];
    var $674 = $673 << 24 >> 24 == 10;
    var $675 = $674 & 1;
    var $676 = HEAP32[_yy_buffer_stack >> 2];
    var $677 = HEAP32[$676 >> 2];
    var $678 = $677 + 28 | 0;
    HEAP32[$678 >> 2] = $675;
    __label__ = 150;
    break;
   case 150:
    HEAP32[_yylval >> 2] = 287;
    var $_0 = 287;
    __label__ = 282;
    break;
   case 151:
    var $681 = HEAP32[_yyleng >> 2];
    var $682 = ($681 | 0) > 0;
    if ($682) {
      __label__ = 152;
      break;
    } else {
      __label__ = 153;
      break;
    }
   case 152:
    var $684 = $681 - 1 | 0;
    var $685 = $86 + $684 | 0;
    var $686 = HEAP8[$685];
    var $687 = $686 << 24 >> 24 == 10;
    var $688 = $687 & 1;
    var $689 = HEAP32[_yy_buffer_stack >> 2];
    var $690 = HEAP32[$689 >> 2];
    var $691 = $690 + 28 | 0;
    HEAP32[$691 >> 2] = $688;
    __label__ = 153;
    break;
   case 153:
    HEAP32[_yylval >> 2] = 288;
    var $_0 = 288;
    __label__ = 282;
    break;
   case 154:
    var $694 = HEAP32[_yyleng >> 2];
    var $695 = ($694 | 0) > 0;
    if ($695) {
      __label__ = 155;
      break;
    } else {
      __label__ = 156;
      break;
    }
   case 155:
    var $697 = $694 - 1 | 0;
    var $698 = $86 + $697 | 0;
    var $699 = HEAP8[$698];
    var $700 = $699 << 24 >> 24 == 10;
    var $701 = $700 & 1;
    var $702 = HEAP32[_yy_buffer_stack >> 2];
    var $703 = HEAP32[$702 >> 2];
    var $704 = $703 + 28 | 0;
    HEAP32[$704 >> 2] = $701;
    __label__ = 156;
    break;
   case 156:
    HEAP32[_yylval >> 2] = 289;
    var $_0 = 289;
    __label__ = 282;
    break;
   case 157:
    var $707 = HEAP32[_yyleng >> 2];
    var $708 = ($707 | 0) > 0;
    if ($708) {
      __label__ = 158;
      break;
    } else {
      var $_0 = 309;
      __label__ = 282;
      break;
    }
   case 158:
    var $710 = $707 - 1 | 0;
    var $711 = $86 + $710 | 0;
    var $712 = HEAP8[$711];
    var $713 = $712 << 24 >> 24 == 10;
    var $714 = $713 & 1;
    var $715 = HEAP32[_yy_buffer_stack >> 2];
    var $716 = HEAP32[$715 >> 2];
    var $717 = $716 + 28 | 0;
    HEAP32[$717 >> 2] = $714;
    var $_0 = 309;
    __label__ = 282;
    break;
   case 159:
    var $719 = HEAP32[_yyleng >> 2];
    var $720 = ($719 | 0) > 0;
    if ($720) {
      __label__ = 160;
      break;
    } else {
      var $_0 = 307;
      __label__ = 282;
      break;
    }
   case 160:
    var $722 = $719 - 1 | 0;
    var $723 = $86 + $722 | 0;
    var $724 = HEAP8[$723];
    var $725 = $724 << 24 >> 24 == 10;
    var $726 = $725 & 1;
    var $727 = HEAP32[_yy_buffer_stack >> 2];
    var $728 = HEAP32[$727 >> 2];
    var $729 = $728 + 28 | 0;
    HEAP32[$729 >> 2] = $726;
    var $_0 = 307;
    __label__ = 282;
    break;
   case 161:
    var $731 = HEAP32[_yyleng >> 2];
    var $732 = ($731 | 0) > 0;
    if ($732) {
      __label__ = 162;
      break;
    } else {
      var $_0 = 294;
      __label__ = 282;
      break;
    }
   case 162:
    var $734 = $731 - 1 | 0;
    var $735 = $86 + $734 | 0;
    var $736 = HEAP8[$735];
    var $737 = $736 << 24 >> 24 == 10;
    var $738 = $737 & 1;
    var $739 = HEAP32[_yy_buffer_stack >> 2];
    var $740 = HEAP32[$739 >> 2];
    var $741 = $740 + 28 | 0;
    HEAP32[$741 >> 2] = $738;
    var $_0 = 294;
    __label__ = 282;
    break;
   case 163:
    var $743 = HEAP32[_yyleng >> 2];
    var $744 = ($743 | 0) > 0;
    if ($744) {
      __label__ = 164;
      break;
    } else {
      var $_0 = 314;
      __label__ = 282;
      break;
    }
   case 164:
    var $746 = $743 - 1 | 0;
    var $747 = $86 + $746 | 0;
    var $748 = HEAP8[$747];
    var $749 = $748 << 24 >> 24 == 10;
    var $750 = $749 & 1;
    var $751 = HEAP32[_yy_buffer_stack >> 2];
    var $752 = HEAP32[$751 >> 2];
    var $753 = $752 + 28 | 0;
    HEAP32[$753 >> 2] = $750;
    var $_0 = 314;
    __label__ = 282;
    break;
   case 165:
    var $755 = HEAP32[_yyleng >> 2];
    var $756 = ($755 | 0) > 0;
    if ($756) {
      __label__ = 166;
      break;
    } else {
      __label__ = 167;
      break;
    }
   case 166:
    var $758 = $755 - 1 | 0;
    var $759 = $86 + $758 | 0;
    var $760 = HEAP8[$759];
    var $761 = $760 << 24 >> 24 == 10;
    var $762 = $761 & 1;
    var $763 = HEAP32[_yy_buffer_stack >> 2];
    var $764 = HEAP32[$763 >> 2];
    var $765 = $764 + 28 | 0;
    HEAP32[$765 >> 2] = $762;
    __label__ = 167;
    break;
   case 167:
    HEAP32[_yylval >> 2] = 1;
    var $_0 = 310;
    __label__ = 282;
    break;
   case 168:
    var $768 = HEAP32[_yyleng >> 2];
    var $769 = ($768 | 0) > 0;
    if ($769) {
      __label__ = 169;
      break;
    } else {
      __label__ = 170;
      break;
    }
   case 169:
    var $771 = $768 - 1 | 0;
    var $772 = $86 + $771 | 0;
    var $773 = HEAP8[$772];
    var $774 = $773 << 24 >> 24 == 10;
    var $775 = $774 & 1;
    var $776 = HEAP32[_yy_buffer_stack >> 2];
    var $777 = HEAP32[$776 >> 2];
    var $778 = $777 + 28 | 0;
    HEAP32[$778 >> 2] = $775;
    __label__ = 170;
    break;
   case 170:
    HEAP32[_yylval >> 2] = 4;
    var $_0 = 310;
    __label__ = 282;
    break;
   case 171:
    var $781 = HEAP32[_yyleng >> 2];
    var $782 = ($781 | 0) > 0;
    if ($782) {
      __label__ = 172;
      break;
    } else {
      __label__ = 173;
      break;
    }
   case 172:
    var $784 = $781 - 1 | 0;
    var $785 = $86 + $784 | 0;
    var $786 = HEAP8[$785];
    var $787 = $786 << 24 >> 24 == 10;
    var $788 = $787 & 1;
    var $789 = HEAP32[_yy_buffer_stack >> 2];
    var $790 = HEAP32[$789 >> 2];
    var $791 = $790 + 28 | 0;
    HEAP32[$791 >> 2] = $788;
    __label__ = 173;
    break;
   case 173:
    HEAP32[_yylval >> 2] = 5;
    var $_0 = 310;
    __label__ = 282;
    break;
   case 174:
    var $794 = HEAP32[_yyleng >> 2];
    var $795 = ($794 | 0) > 0;
    if ($795) {
      __label__ = 175;
      break;
    } else {
      __label__ = 176;
      break;
    }
   case 175:
    var $797 = $794 - 1 | 0;
    var $798 = $86 + $797 | 0;
    var $799 = HEAP8[$798];
    var $800 = $799 << 24 >> 24 == 10;
    var $801 = $800 & 1;
    var $802 = HEAP32[_yy_buffer_stack >> 2];
    var $803 = HEAP32[$802 >> 2];
    var $804 = $803 + 28 | 0;
    HEAP32[$804 >> 2] = $801;
    __label__ = 176;
    break;
   case 176:
    HEAP32[_yylval >> 2] = 3;
    var $_0 = 310;
    __label__ = 282;
    break;
   case 177:
    var $807 = HEAP32[_yyleng >> 2];
    var $808 = ($807 | 0) > 0;
    if ($808) {
      __label__ = 178;
      break;
    } else {
      __label__ = 179;
      break;
    }
   case 178:
    var $810 = $807 - 1 | 0;
    var $811 = $86 + $810 | 0;
    var $812 = HEAP8[$811];
    var $813 = $812 << 24 >> 24 == 10;
    var $814 = $813 & 1;
    var $815 = HEAP32[_yy_buffer_stack >> 2];
    var $816 = HEAP32[$815 >> 2];
    var $817 = $816 + 28 | 0;
    HEAP32[$817 >> 2] = $814;
    __label__ = 179;
    break;
   case 179:
    HEAP32[_yylval >> 2] = 2;
    var $_0 = 310;
    __label__ = 282;
    break;
   case 180:
    var $820 = HEAP32[_yyleng >> 2];
    var $821 = ($820 | 0) > 0;
    if ($821) {
      __label__ = 181;
      break;
    } else {
      __label__ = 182;
      break;
    }
   case 181:
    var $823 = $820 - 1 | 0;
    var $824 = $86 + $823 | 0;
    var $825 = HEAP8[$824];
    var $826 = $825 << 24 >> 24 == 10;
    var $827 = $826 & 1;
    var $828 = HEAP32[_yy_buffer_stack >> 2];
    var $829 = HEAP32[$828 >> 2];
    var $830 = $829 + 28 | 0;
    HEAP32[$830 >> 2] = $827;
    __label__ = 182;
    break;
   case 182:
    var $832 = _tostring(__str2320 | 0);
    var $833 = _setsymtab($86, $832, 0, 3, _symtab | 0);
    var $834 = $833;
    HEAP32[_yylval >> 2] = $834;
    var $_0 = 312;
    __label__ = 282;
    break;
   case 183:
    var $836 = HEAP32[_yyleng >> 2];
    var $837 = ($836 | 0) > 0;
    if ($837) {
      __label__ = 184;
      break;
    } else {
      __label__ = 185;
      break;
    }
   case 184:
    var $839 = $836 - 1 | 0;
    var $840 = $86 + $839 | 0;
    var $841 = HEAP8[$840];
    var $842 = $841 << 24 >> 24 == 10;
    var $843 = $842 & 1;
    var $844 = HEAP32[_yy_buffer_stack >> 2];
    var $845 = HEAP32[$844 >> 2];
    var $846 = $845 + 28 | 0;
    HEAP32[$846 >> 2] = $843;
    __label__ = 185;
    break;
   case 185:
    HEAP32[_yy_start >> 2] = 3;
    HEAP32[_clen >> 2] = 0;
    __label__ = 15;
    break;
   case 186:
    var $849 = HEAP32[_yyleng >> 2];
    var $850 = ($849 | 0) > 0;
    if ($850) {
      __label__ = 187;
      break;
    } else {
      __label__ = 188;
      break;
    }
   case 187:
    var $852 = $849 - 1 | 0;
    var $853 = $86 + $852 | 0;
    var $854 = HEAP8[$853];
    var $855 = $854 << 24 >> 24 == 10;
    var $856 = $855 & 1;
    var $857 = HEAP32[_yy_buffer_stack >> 2];
    var $858 = HEAP32[$857 >> 2];
    var $859 = $858 + 28 | 0;
    HEAP32[$859 >> 2] = $856;
    __label__ = 188;
    break;
   case 188:
    HEAP32[_yy_start >> 2] = 11;
    __label__ = 15;
    break;
   case 189:
    var $862 = HEAP32[_yyleng >> 2];
    var $863 = ($862 | 0) > 0;
    if ($863) {
      __label__ = 190;
      break;
    } else {
      __label__ = 191;
      break;
    }
   case 190:
    var $865 = $862 - 1 | 0;
    var $866 = $86 + $865 | 0;
    var $867 = HEAP8[$866];
    var $868 = $867 << 24 >> 24 == 10;
    var $869 = $868 & 1;
    var $870 = HEAP32[_yy_buffer_stack >> 2];
    var $871 = HEAP32[$870 >> 2];
    var $872 = $871 + 28 | 0;
    HEAP32[$872 >> 2] = $869;
    __label__ = 191;
    break;
   case 191:
    HEAP32[_yy_start >> 2] = 1;
    var $st$1$0 = _lineno | 0;
    var $873$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = _lineno + 4 | 0;
    var $873$1 = HEAP32[$st$1$1 >> 2];
    var $$emscripten$temp$6$0 = 1;
    var $$emscripten$temp$6$1 = 0;
    var $874$0 = (i64Math.add($873$0, $873$1, $$emscripten$temp$6$0, $$emscripten$temp$6$1), i64Math.result[0]);
    var $874$1 = i64Math.result[1];
    var $st$8$0 = _lineno | 0;
    HEAP32[$st$8$0 >> 2] = $874$0;
    var $st$8$1 = _lineno + 4 | 0;
    HEAP32[$st$8$1 >> 2] = $874$1;
    var $_0 = 285;
    __label__ = 282;
    break;
   case 192:
    var $876 = HEAP32[_yyleng >> 2];
    var $877 = ($876 | 0) > 0;
    if ($877) {
      __label__ = 193;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 193:
    var $879 = $876 - 1 | 0;
    var $880 = $86 + $879 | 0;
    var $881 = HEAP8[$880];
    var $882 = $881 << 24 >> 24 == 10;
    var $883 = $882 & 1;
    var $884 = HEAP32[_yy_buffer_stack >> 2];
    var $885 = HEAP32[$884 >> 2];
    var $886 = $885 + 28 | 0;
    HEAP32[$886 >> 2] = $883;
    __label__ = 15;
    break;
   case 194:
    var $888 = HEAP32[_yyleng >> 2];
    var $889 = ($888 | 0) > 0;
    if ($889) {
      __label__ = 195;
      break;
    } else {
      __label__ = 196;
      break;
    }
   case 195:
    var $891 = $888 - 1 | 0;
    var $892 = $86 + $891 | 0;
    var $893 = HEAP8[$892];
    var $894 = $893 << 24 >> 24 == 10;
    var $895 = $894 & 1;
    var $896 = HEAP32[_yy_buffer_stack >> 2];
    var $897 = HEAP32[$896 >> 2];
    var $898 = $897 + 28 | 0;
    HEAP32[$898 >> 2] = $895;
    __label__ = 196;
    break;
   case 196:
    var $900 = HEAP8[$86];
    var $901 = $900 << 24 >> 24;
    var $902 = $901;
    HEAP32[_yylval >> 2] = $902;
    var $_0 = $901;
    __label__ = 282;
    break;
   case 197:
    var $904 = HEAP32[_yyleng >> 2];
    var $905 = ($904 | 0) > 0;
    if ($905) {
      __label__ = 198;
      break;
    } else {
      __label__ = 199;
      break;
    }
   case 198:
    var $907 = $904 - 1 | 0;
    var $908 = $86 + $907 | 0;
    var $909 = HEAP8[$908];
    var $910 = $909 << 24 >> 24 == 10;
    var $911 = $910 & 1;
    var $912 = HEAP32[_yy_buffer_stack >> 2];
    var $913 = HEAP32[$912 >> 2];
    var $914 = $913 + 28 | 0;
    HEAP32[$914 >> 2] = $911;
    __label__ = 199;
    break;
   case 199:
    HEAP32[_yy_start >> 2] = 5;
    var $915 = HEAP8[$86];
    var $916 = HEAP32[_clen >> 2];
    var $917 = $916 + 1 | 0;
    HEAP32[_clen >> 2] = $917;
    var $918 = _cbuf + $916 | 0;
    HEAP8[$918] = $915;
    var $919 = ($917 | 0) > 798;
    if ($919) {
      __label__ = 200;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 200:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 201:
    var $922 = HEAP32[_yyleng >> 2];
    var $923 = ($922 | 0) > 0;
    if ($923) {
      __label__ = 202;
      break;
    } else {
      __label__ = 203;
      break;
    }
   case 202:
    var $925 = $922 - 1 | 0;
    var $926 = $86 + $925 | 0;
    var $927 = HEAP8[$926];
    var $928 = $927 << 24 >> 24 == 10;
    var $929 = $928 & 1;
    var $930 = HEAP32[_yy_buffer_stack >> 2];
    var $931 = HEAP32[$930 >> 2];
    var $932 = $931 + 28 | 0;
    HEAP32[$932 >> 2] = $929;
    __label__ = 203;
    break;
   case 203:
    HEAP32[_yy_start >> 2] = 5;
    var $933 = HEAP8[$86];
    var $934 = HEAP32[_clen >> 2];
    var $935 = $934 + 1 | 0;
    HEAP32[_clen >> 2] = $935;
    var $936 = _cbuf + $934 | 0;
    HEAP8[$936] = $933;
    var $937 = ($935 | 0) > 798;
    if ($937) {
      __label__ = 204;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 204:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 205:
    var $940 = HEAP32[_yyleng >> 2];
    var $941 = ($940 | 0) > 0;
    if ($941) {
      __label__ = 206;
      break;
    } else {
      __label__ = 207;
      break;
    }
   case 206:
    var $943 = $940 - 1 | 0;
    var $944 = $86 + $943 | 0;
    var $945 = HEAP8[$944];
    var $946 = $945 << 24 >> 24 == 10;
    var $947 = $946 & 1;
    var $948 = HEAP32[_yy_buffer_stack >> 2];
    var $949 = HEAP32[$948 >> 2];
    var $950 = $949 + 28 | 0;
    HEAP32[$950 >> 2] = $947;
    __label__ = 207;
    break;
   case 207:
    HEAP32[_yy_start >> 2] = 9;
    var $951 = HEAP8[$86];
    var $952 = HEAP32[_clen >> 2];
    var $953 = $952 + 1 | 0;
    HEAP32[_clen >> 2] = $953;
    var $954 = _cbuf + $952 | 0;
    HEAP8[$954] = $951;
    var $955 = ($953 | 0) > 798;
    if ($955) {
      __label__ = 208;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 208:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 209:
    var $958 = HEAP32[_yyleng >> 2];
    var $959 = ($958 | 0) > 0;
    if ($959) {
      __label__ = 210;
      break;
    } else {
      __label__ = 211;
      break;
    }
   case 210:
    var $961 = $958 - 1 | 0;
    var $962 = $86 + $961 | 0;
    var $963 = HEAP8[$962];
    var $964 = $963 << 24 >> 24 == 10;
    var $965 = $964 & 1;
    var $966 = HEAP32[_yy_buffer_stack >> 2];
    var $967 = HEAP32[$966 >> 2];
    var $968 = $967 + 28 | 0;
    HEAP32[$968 >> 2] = $965;
    __label__ = 211;
    break;
   case 211:
    HEAP32[_yy_start >> 2] = 1;
    var $969 = HEAP32[_clen >> 2];
    var $970 = _cbuf + $969 | 0;
    HEAP8[$970] = 0;
    var $971 = _tostring(_cbuf | 0);
    HEAP32[_yylval >> 2] = $971;
    var $972 = HEAP32[_yytext >> 2];
    _yyunput($972);
    var $_0 = 302;
    __label__ = 282;
    break;
   case 212:
    var $974 = HEAP32[_yyleng >> 2];
    var $975 = ($974 | 0) > 0;
    if ($975) {
      __label__ = 213;
      break;
    } else {
      __label__ = 214;
      break;
    }
   case 213:
    var $977 = $974 - 1 | 0;
    var $978 = $86 + $977 | 0;
    var $979 = HEAP8[$978];
    var $980 = $979 << 24 >> 24 == 10;
    var $981 = $980 & 1;
    var $982 = HEAP32[_yy_buffer_stack >> 2];
    var $983 = HEAP32[$982 >> 2];
    var $984 = $983 + 28 | 0;
    HEAP32[$984 >> 2] = $981;
    __label__ = 214;
    break;
   case 214:
    _yyerror(STRING_TABLE.__str3291 | 0);
    var $st$1$0 = _lineno | 0;
    var $986$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = _lineno + 4 | 0;
    var $986$1 = HEAP32[$st$1$1 >> 2];
    var $$emscripten$temp$7$0 = 1;
    var $$emscripten$temp$7$1 = 0;
    var $987$0 = (i64Math.add($986$0, $986$1, $$emscripten$temp$7$0, $$emscripten$temp$7$1), i64Math.result[0]);
    var $987$1 = i64Math.result[1];
    var $st$8$0 = _lineno | 0;
    HEAP32[$st$8$0 >> 2] = $987$0;
    var $st$8$1 = _lineno + 4 | 0;
    HEAP32[$st$8$1 >> 2] = $987$1;
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 215:
    var $989 = HEAP32[_yyleng >> 2];
    var $990 = ($989 | 0) > 0;
    if ($990) {
      __label__ = 216;
      break;
    } else {
      __label__ = 217;
      break;
    }
   case 216:
    var $992 = $989 - 1 | 0;
    var $993 = $86 + $992 | 0;
    var $994 = HEAP8[$993];
    var $995 = $994 << 24 >> 24 == 10;
    var $996 = $995 & 1;
    var $997 = HEAP32[_yy_buffer_stack >> 2];
    var $998 = HEAP32[$997 >> 2];
    var $999 = $998 + 28 | 0;
    HEAP32[$999 >> 2] = $996;
    __label__ = 217;
    break;
   case 217:
    var $1000 = HEAP8[$86];
    var $1001 = HEAP32[_clen >> 2];
    var $1002 = $1001 + 1 | 0;
    HEAP32[_clen >> 2] = $1002;
    var $1003 = _cbuf + $1001 | 0;
    HEAP8[$1003] = $1000;
    var $1004 = ($1002 | 0) > 798;
    if ($1004) {
      __label__ = 218;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 218:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 219:
    var $1007 = HEAP32[_yyleng >> 2];
    var $1008 = ($1007 | 0) > 0;
    if ($1008) {
      __label__ = 220;
      break;
    } else {
      __label__ = 221;
      break;
    }
   case 220:
    var $1010 = $1007 - 1 | 0;
    var $1011 = $86 + $1010 | 0;
    var $1012 = HEAP8[$1011];
    var $1013 = $1012 << 24 >> 24 == 10;
    var $1014 = $1013 & 1;
    var $1015 = HEAP32[_yy_buffer_stack >> 2];
    var $1016 = HEAP32[$1015 >> 2];
    var $1017 = $1016 + 28 | 0;
    HEAP32[$1017 >> 2] = $1014;
    __label__ = 221;
    break;
   case 221:
    HEAP32[_yy_start >> 2] = 1;
    var $1018 = HEAP32[_clen >> 2];
    var $1019 = _cbuf + $1018 | 0;
    HEAP8[$1019] = 0;
    var $1020 = _tostring(_cbuf | 0);
    var $1021 = HEAP32[_clen >> 2];
    var $1022 = _cbuf + $1021 | 0;
    HEAP8[$1022] = 32;
    var $1023 = $1021 + 1 | 0;
    HEAP32[_clen >> 2] = $1023;
    var $1024 = _cbuf + $1023 | 0;
    HEAP8[$1024] = 0;
    var $1025 = _setsymtab(_cbuf | 0, $1020, 0, 9, _symtab | 0);
    var $1026 = $1025;
    HEAP32[_yylval >> 2] = $1026;
    var $_0 = 322;
    __label__ = 282;
    break;
   case 222:
    var $1028 = HEAP32[_yyleng >> 2];
    var $1029 = ($1028 | 0) > 0;
    if ($1029) {
      __label__ = 223;
      break;
    } else {
      __label__ = 224;
      break;
    }
   case 223:
    var $1031 = $1028 - 1 | 0;
    var $1032 = $86 + $1031 | 0;
    var $1033 = HEAP8[$1032];
    var $1034 = $1033 << 24 >> 24 == 10;
    var $1035 = $1034 & 1;
    var $1036 = HEAP32[_yy_buffer_stack >> 2];
    var $1037 = HEAP32[$1036 >> 2];
    var $1038 = $1037 + 28 | 0;
    HEAP32[$1038 >> 2] = $1035;
    __label__ = 224;
    break;
   case 224:
    _yyerror(STRING_TABLE.__str4292 | 0);
    var $st$1$0 = _lineno | 0;
    var $1040$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = _lineno + 4 | 0;
    var $1040$1 = HEAP32[$st$1$1 >> 2];
    var $$emscripten$temp$8$0 = 1;
    var $$emscripten$temp$8$1 = 0;
    var $1041$0 = (i64Math.add($1040$0, $1040$1, $$emscripten$temp$8$0, $$emscripten$temp$8$1), i64Math.result[0]);
    var $1041$1 = i64Math.result[1];
    var $st$8$0 = _lineno | 0;
    HEAP32[$st$8$0 >> 2] = $1041$0;
    var $st$8$1 = _lineno + 4 | 0;
    HEAP32[$st$8$1 >> 2] = $1041$1;
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 225:
    var $1043 = HEAP32[_yyleng >> 2];
    var $1044 = ($1043 | 0) > 0;
    if ($1044) {
      __label__ = 226;
      break;
    } else {
      __label__ = 227;
      break;
    }
   case 226:
    var $1046 = $1043 - 1 | 0;
    var $1047 = $86 + $1046 | 0;
    var $1048 = HEAP8[$1047];
    var $1049 = $1048 << 24 >> 24 == 10;
    var $1050 = $1049 & 1;
    var $1051 = HEAP32[_yy_buffer_stack >> 2];
    var $1052 = HEAP32[$1051 >> 2];
    var $1053 = $1052 + 28 | 0;
    HEAP32[$1053 >> 2] = $1050;
    __label__ = 227;
    break;
   case 227:
    var $1054 = HEAP32[_clen >> 2];
    var $1055 = $1054 + 1 | 0;
    HEAP32[_clen >> 2] = $1055;
    var $1056 = _cbuf + $1054 | 0;
    HEAP8[$1056] = 34;
    __label__ = 15;
    break;
   case 228:
    var $1058 = HEAP32[_yyleng >> 2];
    var $1059 = ($1058 | 0) > 0;
    if ($1059) {
      __label__ = 229;
      break;
    } else {
      __label__ = 230;
      break;
    }
   case 229:
    var $1061 = $1058 - 1 | 0;
    var $1062 = $86 + $1061 | 0;
    var $1063 = HEAP8[$1062];
    var $1064 = $1063 << 24 >> 24 == 10;
    var $1065 = $1064 & 1;
    var $1066 = HEAP32[_yy_buffer_stack >> 2];
    var $1067 = HEAP32[$1066 >> 2];
    var $1068 = $1067 + 28 | 0;
    HEAP32[$1068 >> 2] = $1065;
    __label__ = 230;
    break;
   case 230:
    var $1069 = HEAP32[_clen >> 2];
    var $1070 = $1069 + 1 | 0;
    HEAP32[_clen >> 2] = $1070;
    var $1071 = _cbuf + $1069 | 0;
    HEAP8[$1071] = 10;
    __label__ = 15;
    break;
   case 231:
    var $1073 = HEAP32[_yyleng >> 2];
    var $1074 = ($1073 | 0) > 0;
    if ($1074) {
      __label__ = 232;
      break;
    } else {
      __label__ = 233;
      break;
    }
   case 232:
    var $1076 = $1073 - 1 | 0;
    var $1077 = $86 + $1076 | 0;
    var $1078 = HEAP8[$1077];
    var $1079 = $1078 << 24 >> 24 == 10;
    var $1080 = $1079 & 1;
    var $1081 = HEAP32[_yy_buffer_stack >> 2];
    var $1082 = HEAP32[$1081 >> 2];
    var $1083 = $1082 + 28 | 0;
    HEAP32[$1083 >> 2] = $1080;
    __label__ = 233;
    break;
   case 233:
    var $1084 = HEAP32[_clen >> 2];
    var $1085 = $1084 + 1 | 0;
    HEAP32[_clen >> 2] = $1085;
    var $1086 = _cbuf + $1084 | 0;
    HEAP8[$1086] = 9;
    __label__ = 15;
    break;
   case 234:
    var $1088 = HEAP32[_yyleng >> 2];
    var $1089 = ($1088 | 0) > 0;
    if ($1089) {
      __label__ = 235;
      break;
    } else {
      __label__ = 236;
      break;
    }
   case 235:
    var $1091 = $1088 - 1 | 0;
    var $1092 = $86 + $1091 | 0;
    var $1093 = HEAP8[$1092];
    var $1094 = $1093 << 24 >> 24 == 10;
    var $1095 = $1094 & 1;
    var $1096 = HEAP32[_yy_buffer_stack >> 2];
    var $1097 = HEAP32[$1096 >> 2];
    var $1098 = $1097 + 28 | 0;
    HEAP32[$1098 >> 2] = $1095;
    __label__ = 236;
    break;
   case 236:
    var $1099 = HEAP32[_clen >> 2];
    var $1100 = $1099 + 1 | 0;
    HEAP32[_clen >> 2] = $1100;
    var $1101 = _cbuf + $1099 | 0;
    HEAP8[$1101] = 13;
    __label__ = 15;
    break;
   case 237:
    var $1103 = HEAP32[_yyleng >> 2];
    var $1104 = ($1103 | 0) > 0;
    if ($1104) {
      __label__ = 238;
      break;
    } else {
      __label__ = 239;
      break;
    }
   case 238:
    var $1106 = $1103 - 1 | 0;
    var $1107 = $86 + $1106 | 0;
    var $1108 = HEAP8[$1107];
    var $1109 = $1108 << 24 >> 24 == 10;
    var $1110 = $1109 & 1;
    var $1111 = HEAP32[_yy_buffer_stack >> 2];
    var $1112 = HEAP32[$1111 >> 2];
    var $1113 = $1112 + 28 | 0;
    HEAP32[$1113 >> 2] = $1110;
    __label__ = 239;
    break;
   case 239:
    var $1114 = HEAP32[_clen >> 2];
    var $1115 = $1114 + 1 | 0;
    HEAP32[_clen >> 2] = $1115;
    var $1116 = _cbuf + $1114 | 0;
    HEAP8[$1116] = 8;
    __label__ = 15;
    break;
   case 240:
    var $1118 = HEAP32[_yyleng >> 2];
    var $1119 = ($1118 | 0) > 0;
    if ($1119) {
      __label__ = 241;
      break;
    } else {
      __label__ = 242;
      break;
    }
   case 241:
    var $1121 = $1118 - 1 | 0;
    var $1122 = $86 + $1121 | 0;
    var $1123 = HEAP8[$1122];
    var $1124 = $1123 << 24 >> 24 == 10;
    var $1125 = $1124 & 1;
    var $1126 = HEAP32[_yy_buffer_stack >> 2];
    var $1127 = HEAP32[$1126 >> 2];
    var $1128 = $1127 + 28 | 0;
    HEAP32[$1128 >> 2] = $1125;
    __label__ = 242;
    break;
   case 242:
    var $1129 = HEAP32[_clen >> 2];
    var $1130 = $1129 + 1 | 0;
    HEAP32[_clen >> 2] = $1130;
    var $1131 = _cbuf + $1129 | 0;
    HEAP8[$1131] = 12;
    __label__ = 15;
    break;
   case 243:
    var $1133 = HEAP32[_yyleng >> 2];
    var $1134 = ($1133 | 0) > 0;
    if ($1134) {
      __label__ = 244;
      break;
    } else {
      __label__ = 245;
      break;
    }
   case 244:
    var $1136 = $1133 - 1 | 0;
    var $1137 = $86 + $1136 | 0;
    var $1138 = HEAP8[$1137];
    var $1139 = $1138 << 24 >> 24 == 10;
    var $1140 = $1139 & 1;
    var $1141 = HEAP32[_yy_buffer_stack >> 2];
    var $1142 = HEAP32[$1141 >> 2];
    var $1143 = $1142 + 28 | 0;
    HEAP32[$1143 >> 2] = $1140;
    __label__ = 245;
    break;
   case 245:
    var $1144 = HEAP32[_clen >> 2];
    var $1145 = $1144 + 1 | 0;
    HEAP32[_clen >> 2] = $1145;
    var $1146 = _cbuf + $1144 | 0;
    HEAP8[$1146] = 92;
    __label__ = 15;
    break;
   case 246:
    var $1148 = HEAP32[_yyleng >> 2];
    var $1149 = ($1148 | 0) > 0;
    if ($1149) {
      __label__ = 247;
      break;
    } else {
      __label__ = 248;
      break;
    }
   case 247:
    var $1151 = $1148 - 1 | 0;
    var $1152 = $86 + $1151 | 0;
    var $1153 = HEAP8[$1152];
    var $1154 = $1153 << 24 >> 24 == 10;
    var $1155 = $1154 & 1;
    var $1156 = HEAP32[_yy_buffer_stack >> 2];
    var $1157 = HEAP32[$1156 >> 2];
    var $1158 = $1157 + 28 | 0;
    HEAP32[$1158 >> 2] = $1155;
    __label__ = 248;
    break;
   case 248:
    var $1159 = HEAP8[$86];
    var $1160 = HEAP32[_clen >> 2];
    var $1161 = $1160 + 1 | 0;
    HEAP32[_clen >> 2] = $1161;
    var $1162 = _cbuf + $1160 | 0;
    HEAP8[$1162] = $1159;
    var $1163 = ($1161 | 0) > 798;
    if ($1163) {
      __label__ = 249;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 249:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 250:
    var $1166 = HEAP32[_yyleng >> 2];
    var $1167 = ($1166 | 0) > 0;
    if ($1167) {
      __label__ = 251;
      break;
    } else {
      __label__ = 252;
      break;
    }
   case 251:
    var $1169 = $1166 - 1 | 0;
    var $1170 = $86 + $1169 | 0;
    var $1171 = HEAP8[$1170];
    var $1172 = $1171 << 24 >> 24 == 10;
    var $1173 = $1172 & 1;
    var $1174 = HEAP32[_yy_buffer_stack >> 2];
    var $1175 = HEAP32[$1174 >> 2];
    var $1176 = $1175 + 28 | 0;
    HEAP32[$1176 >> 2] = $1173;
    __label__ = 252;
    break;
   case 252:
    var $1177 = HEAP32[_clen >> 2];
    var $1178 = $1177 + 1 | 0;
    var $1179 = _cbuf + $1177 | 0;
    HEAP8[$1179] = 92;
    var $1180 = $1177 + 2 | 0;
    HEAP32[_clen >> 2] = $1180;
    var $1181 = _cbuf + $1178 | 0;
    HEAP8[$1181] = 93;
    __label__ = 15;
    break;
   case 253:
    var $1183 = HEAP32[_yyleng >> 2];
    var $1184 = ($1183 | 0) > 0;
    if ($1184) {
      __label__ = 254;
      break;
    } else {
      __label__ = 255;
      break;
    }
   case 254:
    var $1186 = $1183 - 1 | 0;
    var $1187 = $86 + $1186 | 0;
    var $1188 = HEAP8[$1187];
    var $1189 = $1188 << 24 >> 24 == 10;
    var $1190 = $1189 & 1;
    var $1191 = HEAP32[_yy_buffer_stack >> 2];
    var $1192 = HEAP32[$1191 >> 2];
    var $1193 = $1192 + 28 | 0;
    HEAP32[$1193 >> 2] = $1190;
    __label__ = 255;
    break;
   case 255:
    HEAP32[_yy_start >> 2] = 7;
    var $1194 = HEAP8[$86];
    var $1195 = HEAP32[_clen >> 2];
    var $1196 = $1195 + 1 | 0;
    HEAP32[_clen >> 2] = $1196;
    var $1197 = _cbuf + $1195 | 0;
    HEAP8[$1197] = $1194;
    var $1198 = ($1196 | 0) > 798;
    if ($1198) {
      __label__ = 256;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 256:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 257:
    var $1201 = HEAP32[_yyleng >> 2];
    var $1202 = ($1201 | 0) > 0;
    if ($1202) {
      __label__ = 258;
      break;
    } else {
      __label__ = 259;
      break;
    }
   case 258:
    var $1204 = $1201 - 1 | 0;
    var $1205 = $86 + $1204 | 0;
    var $1206 = HEAP8[$1205];
    var $1207 = $1206 << 24 >> 24 == 10;
    var $1208 = $1207 & 1;
    var $1209 = HEAP32[_yy_buffer_stack >> 2];
    var $1210 = HEAP32[$1209 >> 2];
    var $1211 = $1210 + 28 | 0;
    HEAP32[$1211 >> 2] = $1208;
    __label__ = 259;
    break;
   case 259:
    _yyerror(STRING_TABLE.__str5293 | 0);
    var $st$1$0 = _lineno | 0;
    var $1213$0 = HEAP32[$st$1$0 >> 2];
    var $st$1$1 = _lineno + 4 | 0;
    var $1213$1 = HEAP32[$st$1$1 >> 2];
    var $$emscripten$temp$9$0 = 1;
    var $$emscripten$temp$9$1 = 0;
    var $1214$0 = (i64Math.add($1213$0, $1213$1, $$emscripten$temp$9$0, $$emscripten$temp$9$1), i64Math.result[0]);
    var $1214$1 = i64Math.result[1];
    var $st$8$0 = _lineno | 0;
    HEAP32[$st$8$0 >> 2] = $1214$0;
    var $st$8$1 = _lineno + 4 | 0;
    HEAP32[$st$8$1 >> 2] = $1214$1;
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 260:
    var $1216 = HEAP32[_yyleng >> 2];
    var $1217 = ($1216 | 0) > 0;
    if ($1217) {
      __label__ = 261;
      break;
    } else {
      __label__ = 262;
      break;
    }
   case 261:
    var $1219 = $1216 - 1 | 0;
    var $1220 = $86 + $1219 | 0;
    var $1221 = HEAP8[$1220];
    var $1222 = $1221 << 24 >> 24 == 10;
    var $1223 = $1222 & 1;
    var $1224 = HEAP32[_yy_buffer_stack >> 2];
    var $1225 = HEAP32[$1224 >> 2];
    var $1226 = $1225 + 28 | 0;
    HEAP32[$1226 >> 2] = $1223;
    __label__ = 262;
    break;
   case 262:
    var $1227 = HEAP8[$86];
    var $1228 = HEAP32[_clen >> 2];
    var $1229 = $1228 + 1 | 0;
    HEAP32[_clen >> 2] = $1229;
    var $1230 = _cbuf + $1228 | 0;
    HEAP8[$1230] = $1227;
    var $1231 = ($1229 | 0) > 798;
    if ($1231) {
      __label__ = 263;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 263:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 264:
    var $1234 = HEAP32[_yyleng >> 2];
    var $1235 = ($1234 | 0) > 0;
    if ($1235) {
      __label__ = 265;
      break;
    } else {
      __label__ = 266;
      break;
    }
   case 265:
    var $1237 = $1234 - 1 | 0;
    var $1238 = $86 + $1237 | 0;
    var $1239 = HEAP8[$1238];
    var $1240 = $1239 << 24 >> 24 == 10;
    var $1241 = $1240 & 1;
    var $1242 = HEAP32[_yy_buffer_stack >> 2];
    var $1243 = HEAP32[$1242 >> 2];
    var $1244 = $1243 + 28 | 0;
    HEAP32[$1244 >> 2] = $1241;
    __label__ = 266;
    break;
   case 266:
    HEAP32[_yy_start >> 2] = 7;
    var $1245 = HEAP8[$86];
    var $1246 = HEAP32[_clen >> 2];
    var $1247 = $1246 + 1 | 0;
    HEAP32[_clen >> 2] = $1247;
    var $1248 = _cbuf + $1246 | 0;
    HEAP8[$1248] = $1245;
    var $1249 = ($1247 | 0) > 798;
    if ($1249) {
      __label__ = 267;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 267:
    _yyerror(STRING_TABLE.__str2290 | 0);
    HEAP32[_yy_start >> 2] = 1;
    __label__ = 15;
    break;
   case 268:
    var $1252 = HEAP32[_yyleng >> 2];
    var $1253 = ($1252 | 0) > 0;
    if ($1253) {
      __label__ = 269;
      break;
    } else {
      __label__ = 270;
      break;
    }
   case 269:
    var $1255 = $1252 - 1 | 0;
    var $1256 = $86 + $1255 | 0;
    var $1257 = HEAP8[$1256];
    var $1258 = $1257 << 24 >> 24 == 10;
    var $1259 = $1258 & 1;
    var $1260 = HEAP32[_yy_buffer_stack >> 2];
    var $1261 = HEAP32[$1260 >> 2];
    var $1262 = $1261 + 28 | 0;
    HEAP32[$1262 >> 2] = $1259;
    __label__ = 270;
    break;
   case 270:
    var $1263 = HEAP32[_yyout >> 2];
    var $1264 = _fwrite($86, $1252, 1, $1263);
    __label__ = 15;
    break;
   case 271:
    var $1266 = HEAP8[_yy_hold_char];
    HEAP8[$yy_cp_2] = $1266;
    var $1267 = HEAP32[_yy_buffer_stack >> 2];
    var $1268 = HEAP32[$1267 >> 2];
    var $1269 = $1268 + 44 | 0;
    var $1270 = HEAP32[$1269 >> 2];
    var $1271 = ($1270 | 0) == 0;
    if ($1271) {
      __label__ = 273;
      break;
    } else {
      __label__ = 272;
      break;
    }
   case 272:
    var $_pre28 = HEAP32[_yy_n_chars >> 2];
    var $1281 = $1268;
    var $1280 = $_pre28;
    __label__ = 274;
    break;
   case 273:
    var $1273 = $1268 + 16 | 0;
    var $1274 = HEAP32[$1273 >> 2];
    HEAP32[_yy_n_chars >> 2] = $1274;
    var $1275 = HEAP32[_yyin >> 2];
    var $1276 = $1268 | 0;
    HEAP32[$1276 >> 2] = $1275;
    var $1277 = HEAP32[$1267 >> 2];
    var $1278 = $1277 + 44 | 0;
    HEAP32[$1278 >> 2] = 1;
    var $_pre = HEAP32[$1267 >> 2];
    var $1281 = $_pre;
    var $1280 = $1274;
    __label__ = 274;
    break;
   case 274:
    var $1280;
    var $1281;
    var $1282 = $1281 + 4 | 0;
    var $1283 = HEAP32[$1282 >> 2];
    var $1284 = $1283 + $1280 | 0;
    var $1285 = $85 >>> 0 > $1284 >>> 0;
    if ($1285) {
      __label__ = 277;
      break;
    } else {
      __label__ = 275;
      break;
    }
   case 275:
    var $1287 = $86;
    var $1288 = $81 - $1287 | 0;
    var $1289 = $1288 - 1 | 0;
    var $1290 = $86 + $1289 | 0;
    HEAP32[_yy_c_buf_p >> 2] = $1290;
    var $1291 = _yy_get_previous_state();
    var $1292 = _yy_try_NUL_trans($1291);
    var $1293 = ($1292 | 0) == 0;
    if ($1293) {
      var $yy_current_state_2_ph = $1291;
      var $yy_cp_1_ph = $1290;
      var $yy_bp_1_ph = $86;
      __label__ = 24;
      break;
    } else {
      __label__ = 276;
      break;
    }
   case 276:
    var $1295 = $86 + $1288 | 0;
    HEAP32[_yy_c_buf_p >> 2] = $1295;
    var $yy_current_state_0_ph = $1292;
    var $yy_cp_0_ph = $1295;
    var $yy_bp_0_ph = $86;
    __label__ = 16;
    break;
   case 277:
    var $1297 = _yy_get_next_buffer();
    if (($1297 | 0) == 1) {
      __label__ = 278;
      break;
    } else if (($1297 | 0) == 0) {
      __label__ = 279;
      break;
    } else if (($1297 | 0) == 2) {
      __label__ = 280;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 278:
    var $1299 = HEAP32[_yytext >> 2];
    HEAP32[_yy_c_buf_p >> 2] = $1299;
    var $1300 = HEAP32[_yy_start >> 2];
    var $1301 = $1300 - 1 | 0;
    var $1302 = ($1301 | 0) / 2 & -1;
    var $1303 = $1302 + 86 | 0;
    var $yy_act_1 = $1303;
    var $86 = $1299;
    var $85 = $1299;
    __label__ = 28;
    break;
   case 279:
    var $1305 = $86;
    var $1306 = $81 - $1305 | 0;
    var $1307 = $1306 - 1 | 0;
    var $1308 = HEAP32[_yytext >> 2];
    var $1309 = $1308 + $1307 | 0;
    HEAP32[_yy_c_buf_p >> 2] = $1309;
    var $1310 = _yy_get_previous_state();
    var $yy_current_state_0_ph = $1310;
    var $yy_cp_0_ph = $1309;
    var $yy_bp_0_ph = $1308;
    __label__ = 16;
    break;
   case 280:
    var $1312 = HEAP32[_yy_n_chars >> 2];
    var $1313 = HEAP32[_yy_buffer_stack >> 2];
    var $1314 = HEAP32[$1313 >> 2];
    var $1315 = $1314 + 4 | 0;
    var $1316 = HEAP32[$1315 >> 2];
    var $1317 = $1316 + $1312 | 0;
    HEAP32[_yy_c_buf_p >> 2] = $1317;
    var $1318 = _yy_get_previous_state();
    var $1319 = HEAP32[_yytext >> 2];
    var $yy_current_state_2_ph = $1318;
    var $yy_cp_1_ph = $1317;
    var $yy_bp_1_ph = $1319;
    __label__ = 24;
    break;
   case 281:
    _yy_fatal_error(STRING_TABLE.__str6294 | 0);
   case 282:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_yylex["X"] = 1;
function _startreg() {
  HEAP32[_yy_start >> 2] = 7;
  HEAP32[_clen >> 2] = 0;
  return;
}
function _yy_load_buffer_state() {
  var $2 = HEAP32[HEAP32[_yy_buffer_stack >> 2] >> 2];
  HEAP32[_yy_n_chars >> 2] = HEAP32[$2 + 16 >> 2];
  var $6 = HEAP32[$2 + 8 >> 2];
  HEAP32[_yy_c_buf_p >> 2] = $6;
  HEAP32[_yytext >> 2] = $6;
  HEAP32[_yyin >> 2] = HEAP32[$2 >> 2];
  HEAP8[_yy_hold_char] = HEAP8[$6];
  return;
}
function _yy_get_previous_state() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_yy_start >> 2];
    var $2 = HEAP32[_yy_buffer_stack >> 2];
    var $3 = HEAP32[$2 >> 2];
    var $4 = $3 + 28 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = $5 + $1 | 0;
    var $7 = HEAP32[_yytext >> 2];
    var $8 = HEAP32[_yy_c_buf_p >> 2];
    var $9 = $7 >>> 0 < $8 >>> 0;
    if ($9) {
      var $yy_cp_05 = $7;
      var $yy_current_state_06 = $6;
      __label__ = 3;
      break;
    } else {
      var $yy_current_state_0_lcssa = $6;
      __label__ = 12;
      break;
    }
   case 3:
    var $yy_current_state_06;
    var $yy_cp_05;
    var $10 = HEAP8[$yy_cp_05];
    var $11 = $10 << 24 >> 24 == 0;
    if ($11) {
      var $17 = 1;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $13 = $10 & 255;
    var $14 = _yy_ec + ($13 << 2) | 0;
    var $15 = HEAP32[$14 >> 2];
    var $17 = $15;
    __label__ = 5;
    break;
   case 5:
    var $17;
    var $18 = _yy_accept + ($yy_current_state_06 << 1) | 0;
    var $19 = HEAP16[$18 >> 1];
    var $20 = $19 << 16 >> 16 == 0;
    if ($20) {
      var $yy_current_state_1_ph = $yy_current_state_06;
      var $yy_c_0_ph = $17;
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    HEAP32[_yy_last_accepting_state >> 2] = $yy_current_state_06;
    HEAP32[_yy_last_accepting_cpos >> 2] = $yy_cp_05;
    var $yy_current_state_1_ph = $yy_current_state_06;
    var $yy_c_0_ph = $17;
    __label__ = 7;
    break;
   case 7:
    var $yy_c_0_ph;
    var $yy_current_state_1_ph;
    var $22 = $yy_c_0_ph & 255;
    var $yy_current_state_1 = $yy_current_state_1_ph;
    __label__ = 8;
    break;
   case 8:
    var $yy_current_state_1;
    var $24 = _yy_base + ($yy_current_state_1 << 1) | 0;
    var $25 = HEAP16[$24 >> 1];
    var $26 = $25 << 16 >> 16;
    var $27 = $26 + $22 | 0;
    var $28 = _yy_chk + ($27 << 1) | 0;
    var $29 = HEAP16[$28 >> 1];
    var $30 = $29 << 16 >> 16;
    var $31 = ($30 | 0) == ($yy_current_state_1 | 0);
    if ($31) {
      __label__ = 11;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $33 = _yy_def + ($yy_current_state_1 << 1) | 0;
    var $34 = HEAP16[$33 >> 1];
    var $35 = $34 << 16 >> 16;
    var $36 = $34 << 16 >> 16 > 196;
    if ($36) {
      __label__ = 10;
      break;
    } else {
      var $yy_current_state_1 = $35;
      __label__ = 8;
      break;
    }
   case 10:
    var $38 = _yy_meta + ($22 << 2) | 0;
    var $39 = HEAP32[$38 >> 2];
    var $yy_current_state_1_ph = $35;
    var $yy_c_0_ph = $39;
    __label__ = 7;
    break;
   case 11:
    var $41 = _yy_nxt + ($27 << 1) | 0;
    var $42 = HEAP16[$41 >> 1];
    var $43 = $42 << 16 >> 16;
    var $44 = $yy_cp_05 + 1 | 0;
    var $45 = $44 >>> 0 < $8 >>> 0;
    if ($45) {
      var $yy_cp_05 = $44;
      var $yy_current_state_06 = $43;
      __label__ = 3;
      break;
    } else {
      var $yy_current_state_0_lcssa = $43;
      __label__ = 12;
      break;
    }
   case 12:
    var $yy_current_state_0_lcssa;
    return $yy_current_state_0_lcssa;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_yy_get_previous_state["X"] = 1;
function _yy_try_NUL_trans($yy_current_state) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _yy_accept + ($yy_current_state << 1) | 0;
    var $2 = HEAP16[$1 >> 1];
    var $3 = $2 << 16 >> 16 == 0;
    if ($3) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = HEAP32[_yy_c_buf_p >> 2];
    HEAP32[_yy_last_accepting_state >> 2] = $yy_current_state;
    HEAP32[_yy_last_accepting_cpos >> 2] = $5;
    __label__ = 4;
    break;
   case 4:
    var $6 = _yy_base + ($yy_current_state << 1) | 0;
    var $7 = HEAP16[$6 >> 1];
    var $8 = $7 << 16 >> 16;
    var $9 = $8 + 1 | 0;
    var $10 = _yy_chk + ($9 << 1) | 0;
    var $11 = HEAP16[$10 >> 1];
    var $12 = $11 << 16 >> 16;
    var $13 = ($12 | 0) == ($yy_current_state | 0);
    if ($13) {
      var $_lcssa = $8;
      __label__ = 6;
      break;
    } else {
      var $_01 = $yy_current_state;
      __label__ = 5;
      break;
    }
   case 5:
    var $_01;
    var $14 = _yy_def + ($_01 << 1) | 0;
    var $15 = HEAP16[$14 >> 1];
    var $16 = $15 << 16 >> 16;
    var $17 = _yy_base + ($16 << 1) | 0;
    var $18 = HEAP16[$17 >> 1];
    var $19 = $18 << 16 >> 16;
    var $20 = $19 + 1 | 0;
    var $21 = _yy_chk + ($20 << 1) | 0;
    var $22 = HEAP16[$21 >> 1];
    var $23 = $22 << 16 >> 16 == $15 << 16 >> 16;
    if ($23) {
      var $_lcssa = $19;
      __label__ = 6;
      break;
    } else {
      var $_01 = $16;
      __label__ = 5;
      break;
    }
   case 6:
    var $_lcssa;
    var $24 = $_lcssa + 1 | 0;
    var $25 = _yy_nxt + ($24 << 1) | 0;
    var $26 = HEAP16[$25 >> 1];
    var $27 = $26 << 16 >> 16;
    var $28 = $26 << 16 >> 16 == 196;
    var $29 = $28 ? 0 : $27;
    return $29;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yyrestart($input_file) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_yy_buffer_stack >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $4 = HEAP32[$1 >> 2];
    var $5 = ($4 | 0) == 0;
    if ($5) {
      __label__ = 4;
      break;
    } else {
      var $11 = $4;
      __label__ = 5;
      break;
    }
   case 4:
    _yyensure_buffer_stack();
    var $7 = HEAP32[_yyin >> 2];
    var $8 = _yy_create_buffer($7);
    var $9 = HEAP32[_yy_buffer_stack >> 2];
    HEAP32[$9 >> 2] = $8;
    var $10 = ($9 | 0) == 0;
    if ($10) {
      var $13 = 0;
      __label__ = 6;
      break;
    } else {
      var $11 = $8;
      __label__ = 5;
      break;
    }
   case 5:
    var $11;
    var $13 = $11;
    __label__ = 6;
    break;
   case 6:
    var $13;
    _yy_init_buffer($13, $input_file);
    _yy_load_buffer_state();
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yy_init_buffer($b, $file) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ___errno();
    var $2 = HEAP32[$1 >> 2];
    _yy_flush_buffer($b);
    var $3 = $b | 0;
    HEAP32[$3 >> 2] = $file;
    var $4 = $b + 40 | 0;
    HEAP32[$4 >> 2] = 1;
    var $5 = HEAP32[_yy_buffer_stack >> 2];
    var $6 = ($5 | 0) == 0;
    if ($6) {
      var $10 = 0;
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $8 = HEAP32[$5 >> 2];
    var $10 = $8;
    __label__ = 4;
    break;
   case 4:
    var $10;
    var $11 = ($10 | 0) == ($b | 0);
    if ($11) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $13 = $b + 32 | 0;
    HEAP32[$13 >> 2] = 1;
    var $14 = $b + 36 | 0;
    HEAP32[$14 >> 2] = 0;
    __label__ = 6;
    break;
   case 6:
    var $16 = ($file | 0) == 0;
    if ($16) {
      var $23 = 0;
      __label__ = 8;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $18 = _fileno($file);
    var $19 = _isatty($18);
    var $20 = ($19 | 0) > 0;
    var $21 = $20 & 1;
    var $23 = $21;
    __label__ = 8;
    break;
   case 8:
    var $23;
    var $24 = $b + 24 | 0;
    HEAP32[$24 >> 2] = $23;
    var $25 = ___errno();
    HEAP32[$25 >> 2] = $2;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yyalloc($size) {
  var $1 = _malloc($size);
  return $1;
}
function _yy_flush_buffer($b) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($b | 0) == 0;
    if ($1) {
      __label__ = 7;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = $b + 16 | 0;
    HEAP32[$3 >> 2] = 0;
    var $4 = $b + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    HEAP8[$5] = 0;
    var $6 = HEAP32[$4 >> 2];
    var $7 = $6 + 1 | 0;
    HEAP8[$7] = 0;
    var $8 = HEAP32[$4 >> 2];
    var $9 = $b + 8 | 0;
    HEAP32[$9 >> 2] = $8;
    var $10 = $b + 28 | 0;
    HEAP32[$10 >> 2] = 1;
    var $11 = $b + 44 | 0;
    HEAP32[$11 >> 2] = 0;
    var $12 = HEAP32[_yy_buffer_stack >> 2];
    var $13 = ($12 | 0) == 0;
    if ($13) {
      var $17 = 0;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $15 = HEAP32[$12 >> 2];
    var $17 = $15;
    __label__ = 5;
    break;
   case 5:
    var $17;
    var $18 = ($17 | 0) == ($b | 0);
    if ($18) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    _yy_load_buffer_state();
    __label__ = 7;
    break;
   case 7:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yyrealloc($ptr, $size) {
  var $1 = _realloc($ptr, $size);
  return $1;
}
function _syminit() {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _tostring(STRING_TABLE.__str316 | 0);
    var $2 = _setsymtab(STRING_TABLE.__str316 | 0, $1, 0, 15, _symtab | 0);
    var $3 = _tostring(__str2320 | 0);
    var $4 = _setsymtab(STRING_TABLE.__str1319 | 0, $3, 0, 15, _symtab | 0);
    var $5 = HEAP32[_record >> 2];
    var $6 = _setsymtab(STRING_TABLE.__str3321 | 0, $5, 0, 5, _symtab | 0);
    HEAP32[_recloc >> 2] = $6;
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $8 = $6;
    var $9 = _lookup(STRING_TABLE.__str3321 | 0, _symtab | 0);
    var $10 = $9;
    var $11 = _printf(STRING_TABLE.__str4324 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $8, HEAP32[tempInt + 4 >> 2] = $10, tempInt));
    __label__ = 4;
    break;
   case 4:
    var $13 = _tostring(STRING_TABLE.__str6326 | 0);
    var $14 = _setsymtab(STRING_TABLE.__str5325 | 0, $13, 0, 5, _symtab | 0);
    var $15 = $14 + 4 | 0;
    HEAP32[_FS >> 2] = $15;
    var $16 = _tostring(STRING_TABLE.__str8330 | 0);
    var $17 = _setsymtab(STRING_TABLE.__str7329 | 0, $16, 0, 5, _symtab | 0);
    var $18 = $17 + 4 | 0;
    HEAP32[_RS >> 2] = $18;
    var $19 = _tostring(STRING_TABLE.__str6326 | 0);
    var $20 = _setsymtab(STRING_TABLE.__str9333 | 0, $19, 0, 5, _symtab | 0);
    var $21 = $20 + 4 | 0;
    HEAP32[_OFS >> 2] = $21;
    var $22 = _tostring(STRING_TABLE.__str8330 | 0);
    var $23 = _setsymtab(STRING_TABLE.__str10336 | 0, $22, 0, 5, _symtab | 0);
    var $24 = $23 + 4 | 0;
    HEAP32[_ORS >> 2] = $24;
    var $25 = _tostring(STRING_TABLE.__str12340 | 0);
    var $26 = _setsymtab(STRING_TABLE.__str11339 | 0, $25, 0, 5, _symtab | 0);
    var $27 = $26 + 4 | 0;
    HEAP32[_OFMT >> 2] = $27;
    var $28 = _setsymtab(STRING_TABLE.__str13341 | 0, _EMPTY | 0, 0, 5, _symtab | 0);
    var $29 = $28 + 4 | 0;
    HEAP32[_FILENAME >> 2] = $29;
    var $30 = _setsymtab(STRING_TABLE.__str14344 | 0, _EMPTY | 0, 0, 2, _symtab | 0);
    var $31 = $30 + 8 | 0;
    HEAP32[_NF >> 2] = $31;
    var $32 = _setsymtab(STRING_TABLE.__str15347 | 0, _EMPTY | 0, 0, 2, _symtab | 0);
    HEAP32[_nrloc >> 2] = $32;
    var $33 = $32 + 8 | 0;
    HEAP32[_NR >> 2] = $33;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _lookup($s, $tab) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _hash($s);
    var $2 = $tab + ($1 << 2) | 0;
    var $p_0_in = $2;
    __label__ = 3;
    break;
   case 3:
    var $p_0_in;
    var $p_0 = HEAP32[$p_0_in >> 2];
    var $4 = ($p_0 | 0) == 0;
    if ($4) {
      var $_0 = 0;
      __label__ = 6;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $6 = $p_0 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = _strcmp($s, $7);
    var $9 = ($8 | 0) == 0;
    if ($9) {
      var $_0 = $p_0;
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $11 = $p_0 + 20 | 0;
    var $p_0_in = $11;
    __label__ = 3;
    break;
   case 6:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _freesymtab($ap) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $ap + 16 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $2 & 16;
    var $4 = ($3 | 0) == 0;
    if ($4) {
      __label__ = 13;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $6 = $ap + 4 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = $7;
    var $i_03 = 0;
    __label__ = 4;
    break;
   case 4:
    var $i_03;
    var $10 = $8 + ($i_03 << 2) | 0;
    var $11 = HEAP32[$10 >> 2];
    var $12 = ($11 | 0) == 0;
    if ($12) {
      __label__ = 10;
      break;
    } else {
      var $cp_02 = $11;
      __label__ = 5;
      break;
    }
   case 5:
    var $cp_02;
    var $13 = $cp_02 | 0;
    var $14 = HEAP32[$13 >> 2];
    var $15 = ($14 | 0) == 0;
    var $16 = ($14 | 0) == (_EMPTY | 0);
    var $or_cond = $15 | $16;
    if ($or_cond) {
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    _free($14);
    __label__ = 7;
    break;
   case 7:
    HEAP32[$13 >> 2] = _EMPTY | 0;
    var $19 = $cp_02 + 4 | 0;
    var $20 = HEAP32[$19 >> 2];
    var $21 = ($20 | 0) == 0;
    var $22 = ($20 | 0) == (_EMPTY | 0);
    var $or_cond1 = $21 | $22;
    if ($or_cond1) {
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    _free($20);
    __label__ = 9;
    break;
   case 9:
    HEAP32[$19 >> 2] = _EMPTY | 0;
    var $25 = $cp_02 + 20 | 0;
    var $26 = HEAP32[$25 >> 2];
    var $27 = $cp_02;
    _free($27);
    var $28 = ($26 | 0) == 0;
    if ($28) {
      __label__ = 10;
      break;
    } else {
      var $cp_02 = $26;
      __label__ = 5;
      break;
    }
   case 10:
    var $29 = $i_03 + 1 | 0;
    var $exitcond = ($29 | 0) == 50;
    if ($exitcond) {
      __label__ = 11;
      break;
    } else {
      var $i_03 = $29;
      __label__ = 4;
      break;
    }
   case 11:
    var $31 = ($7 | 0) == 0;
    if ($31) {
      __label__ = 13;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    _free($7);
    __label__ = 13;
    break;
   case 13:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yyensure_buffer_stack() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_yy_buffer_stack >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 3:
    var $4 = _yyalloc(4);
    var $5 = $4;
    HEAP32[_yy_buffer_stack >> 2] = $5;
    var $6 = ($4 | 0) == 0;
    if ($6) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    _yy_fatal_error(STRING_TABLE.__str18306 | 0);
   case 5:
    tempBigInt = 0;
    HEAP8[$5] = tempBigInt & 255;
    tempBigInt >>= 8;
    HEAP8[$5 + 1] = tempBigInt & 255;
    tempBigInt >>= 8;
    HEAP8[$5 + 2] = tempBigInt & 255;
    tempBigInt >>= 8;
    HEAP8[$5 + 3] = tempBigInt & 255;
    HEAP32[_yy_buffer_stack_max >> 2] = 1;
    __label__ = 10;
    break;
   case 6:
    var $10 = HEAP32[_yy_buffer_stack_max >> 2];
    var $11 = ($10 | 0) == 1;
    if ($11) {
      __label__ = 7;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 7:
    var $13 = $1;
    var $14 = _yyrealloc($13, 36);
    var $15 = $14;
    HEAP32[_yy_buffer_stack >> 2] = $15;
    var $16 = ($14 | 0) == 0;
    if ($16) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    _yy_fatal_error(STRING_TABLE.__str18306 | 0);
   case 9:
    var $19 = HEAP32[_yy_buffer_stack_max >> 2];
    var $20 = $15 + ($19 << 2) | 0;
    var $21 = $20;
    _memset($21, 0, 32, 1);
    HEAP32[_yy_buffer_stack_max >> 2] = 9;
    __label__ = 10;
    break;
   case 10:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yy_create_buffer($file) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _yyalloc(48);
    var $2 = $1;
    var $3 = ($1 | 0) == 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _yy_fatal_error(STRING_TABLE.__str7295 | 0);
   case 4:
    var $6 = $1 + 12 | 0;
    var $7 = $6;
    HEAP32[$7 >> 2] = 16384;
    var $8 = _yyalloc(16386);
    var $9 = $1 + 4 | 0;
    var $10 = $9;
    HEAP32[$10 >> 2] = $8;
    var $11 = ($8 | 0) == 0;
    if ($11) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    _yy_fatal_error(STRING_TABLE.__str7295 | 0);
   case 6:
    var $14 = $1 + 20 | 0;
    var $15 = $14;
    HEAP32[$15 >> 2] = 1;
    _yy_init_buffer($2, $file);
    return $2;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _yyunput($yy_bp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_yy_c_buf_p >> 2];
    var $2 = HEAP8[_yy_hold_char];
    HEAP8[$1] = $2;
    var $3 = HEAP32[_yy_buffer_stack >> 2];
    var $4 = HEAP32[$3 >> 2];
    var $5 = $4 + 4 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $6 + 2 | 0;
    var $8 = $1 >>> 0 < $7 >>> 0;
    if ($8) {
      __label__ = 3;
      break;
    } else {
      var $_0 = $yy_bp;
      var $yy_cp_0 = $1;
      __label__ = 8;
      break;
    }
   case 3:
    var $10 = HEAP32[_yy_n_chars >> 2];
    var $11 = $10 + 2 | 0;
    var $12 = $4 + 12 | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $13 + 2 | 0;
    var $15 = $6 + $14 | 0;
    var $16 = $6 + $11 | 0;
    var $17 = ($11 | 0) > 0;
    if ($17) {
      var $dest_01 = $15;
      var $source_02 = $16;
      __label__ = 4;
      break;
    } else {
      var $dest_0_lcssa = $15;
      var $source_0_lcssa = $16;
      var $26 = $4;
      var $25 = $13;
      __label__ = 6;
      break;
    }
   case 4:
    var $source_02;
    var $dest_01;
    var $18 = $source_02 - 1 | 0;
    var $19 = HEAP8[$18];
    var $20 = $dest_01 - 1 | 0;
    HEAP8[$20] = $19;
    var $21 = HEAP32[$3 >> 2];
    var $22 = $21 + 4 | 0;
    var $23 = HEAP32[$22 >> 2];
    var $24 = $18 >>> 0 > $23 >>> 0;
    if ($24) {
      var $dest_01 = $20;
      var $source_02 = $18;
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $_phi_trans_insert = $21 + 12 | 0;
    var $_pre = HEAP32[$_phi_trans_insert >> 2];
    var $dest_0_lcssa = $20;
    var $source_0_lcssa = $18;
    var $26 = $21;
    var $25 = $_pre;
    __label__ = 6;
    break;
   case 6:
    var $25;
    var $26;
    var $source_0_lcssa;
    var $dest_0_lcssa;
    var $27 = $dest_0_lcssa;
    var $28 = $source_0_lcssa;
    var $29 = $27 - $28 | 0;
    var $30 = $1 + $29 | 0;
    var $31 = $yy_bp + $29 | 0;
    HEAP32[_yy_n_chars >> 2] = $25;
    var $32 = $26 + 16 | 0;
    HEAP32[$32 >> 2] = $25;
    var $33 = HEAP32[$3 >> 2];
    var $34 = $33 + 4 | 0;
    var $35 = HEAP32[$34 >> 2];
    var $36 = $35 + 2 | 0;
    var $37 = $30 >>> 0 < $36 >>> 0;
    if ($37) {
      __label__ = 7;
      break;
    } else {
      var $_0 = $31;
      var $yy_cp_0 = $30;
      __label__ = 8;
      break;
    }
   case 7:
    _yy_fatal_error(STRING_TABLE.__str19307 | 0);
   case 8:
    var $yy_cp_0;
    var $_0;
    var $40 = $yy_cp_0 - 1 | 0;
    HEAP8[$40] = 47;
    HEAP32[_yytext >> 2] = $_0;
    HEAP8[_yy_hold_char] = 47;
    HEAP32[_yy_c_buf_p >> 2] = $40;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_yyunput["X"] = 1;
function _yy_get_next_buffer() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_yy_buffer_stack >> 2];
    var $2 = HEAP32[$1 >> 2];
    var $3 = $2 + 4 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = HEAP32[_yytext >> 2];
    var $6 = HEAP32[_yy_c_buf_p >> 2];
    var $7 = HEAP32[_yy_n_chars >> 2];
    var $8 = $7 + 1 | 0;
    var $9 = $4 + $8 | 0;
    var $10 = $6 >>> 0 > $9 >>> 0;
    if ($10) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _yy_fatal_error(STRING_TABLE.__str20308 | 0);
   case 4:
    var $13 = $2 + 40 | 0;
    var $14 = HEAP32[$13 >> 2];
    var $15 = ($14 | 0) == 0;
    var $16 = $6;
    var $17 = $5;
    var $18 = $16 - $17 | 0;
    if ($15) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $20 = ($18 | 0) == 1;
    var $_ = $20 ? 1 : 2;
    var $_0 = $_;
    __label__ = 36;
    break;
   case 6:
    var $22 = $18 - 1 | 0;
    var $23 = ($22 | 0) > 0;
    if ($23) {
      __label__ = 7;
      break;
    } else {
      var $30 = $2;
      __label__ = 10;
      break;
    }
   case 7:
    var $24 = $16 - 1 | 0;
    var $25 = $24 - $17 | 0;
    var $lftr_limit = $4 + $25 | 0;
    var $source_07 = $5;
    var $dest_08 = $4;
    __label__ = 8;
    break;
   case 8:
    var $dest_08;
    var $source_07;
    var $27 = $source_07 + 1 | 0;
    var $28 = HEAP8[$source_07];
    var $29 = $dest_08 + 1 | 0;
    HEAP8[$dest_08] = $28;
    var $exitcond = ($29 | 0) == ($lftr_limit | 0);
    if ($exitcond) {
      __label__ = 9;
      break;
    } else {
      var $source_07 = $27;
      var $dest_08 = $29;
      __label__ = 8;
      break;
    }
   case 9:
    var $_pre = HEAP32[$1 >> 2];
    var $30 = $_pre;
    __label__ = 10;
    break;
   case 10:
    var $30;
    var $31 = $30 + 44 | 0;
    var $32 = HEAP32[$31 >> 2];
    var $33 = ($32 | 0) == 2;
    if ($33) {
      __label__ = 11;
      break;
    } else {
      var $37 = $30;
      var $36 = $1;
      var $35 = $6;
      __label__ = 12;
      break;
    }
   case 11:
    HEAP32[_yy_n_chars >> 2] = 0;
    var $34 = $30 + 16 | 0;
    HEAP32[$34 >> 2] = 0;
    var $104 = $1;
    var $103 = 0;
    __label__ = 27;
    break;
   case 12:
    var $35;
    var $36;
    var $37;
    var $_pn_in = $37 + 12 | 0;
    var $_pn = HEAP32[$_pn_in >> 2];
    var $num_to_read_0_in = $_pn - $22 | 0;
    var $num_to_read_0 = $num_to_read_0_in - 1 | 0;
    var $38 = ($num_to_read_0 | 0) < 1;
    if ($38) {
      __label__ = 13;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 13:
    var $40 = ($36 | 0) == 0;
    var $41 = $40 ? 0 : $37;
    var $42 = $41 + 4 | 0;
    var $43 = HEAP32[$42 >> 2];
    var $44 = $35;
    var $45 = $43;
    var $46 = $44 - $45 | 0;
    var $47 = $41 + 20 | 0;
    var $48 = HEAP32[$47 >> 2];
    var $49 = ($48 | 0) == 0;
    if ($49) {
      __label__ = 14;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 14:
    HEAP32[$42 >> 2] = 0;
    __label__ = 18;
    break;
   case 15:
    var $51 = $41 + 12 | 0;
    var $52 = HEAP32[$51 >> 2];
    var $53 = $52 << 1;
    var $54 = ($53 | 0) < 1;
    if ($54) {
      __label__ = 16;
      break;
    } else {
      var $storemerge1 = $53;
      __label__ = 17;
      break;
    }
   case 16:
    var $56 = $52 >>> 3;
    var $57 = $56 + $52 | 0;
    var $storemerge1 = $57;
    __label__ = 17;
    break;
   case 17:
    var $storemerge1;
    HEAP32[$51 >> 2] = $storemerge1;
    var $59 = $storemerge1 + 2 | 0;
    var $60 = _yyrealloc($43, $59);
    HEAP32[$42 >> 2] = $60;
    var $61 = ($60 | 0) == 0;
    if ($61) {
      __label__ = 18;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 18:
    _yy_fatal_error(STRING_TABLE.__str21309 | 0);
   case 19:
    var $63 = $60 + $46 | 0;
    HEAP32[_yy_c_buf_p >> 2] = $63;
    var $64 = HEAP32[_yy_buffer_stack >> 2];
    var $65 = HEAP32[$64 >> 2];
    var $37 = $65;
    var $36 = $64;
    var $35 = $63;
    __label__ = 12;
    break;
   case 20:
    var $67 = ($num_to_read_0 | 0) > 8192;
    var $num_to_read_1 = $67 ? 8192 : $num_to_read_0;
    var $68 = HEAP32[_lexprog >> 2];
    var $69 = ($68 | 0) == 0;
    if ($69) {
      __label__ = 25;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $71 = _strlen($68);
    HEAP32[_yy_n_chars >> 2] = $71;
    var $72 = $71 >>> 0 > $num_to_read_1 >>> 0;
    if ($72) {
      __label__ = 22;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 22:
    HEAP32[_yy_n_chars >> 2] = $num_to_read_1;
    var $74 = $37 + 4 | 0;
    var $75 = HEAP32[$74 >> 2];
    var $76 = $75 + $22 | 0;
    var $77 = _strncpy($76, $68, $num_to_read_1);
    __label__ = 24;
    break;
   case 23:
    var $79 = $37 + 4 | 0;
    var $80 = HEAP32[$79 >> 2];
    var $81 = $80 + $22 | 0;
    var $82 = _strcpy($81, $68);
    __label__ = 24;
    break;
   case 24:
    var $84 = HEAP32[_yy_n_chars >> 2];
    var $85 = HEAP32[_lexprog >> 2];
    var $86 = $85 + $84 | 0;
    HEAP32[_lexprog >> 2] = $86;
    var $97 = $84;
    __label__ = 26;
    break;
   case 25:
    var $88 = HEAP32[_yyin >> 2];
    var $89 = _fileno($88);
    var $90 = HEAP32[_yy_buffer_stack >> 2];
    var $91 = HEAP32[$90 >> 2];
    var $92 = $91 + 4 | 0;
    var $93 = HEAP32[$92 >> 2];
    var $94 = $93 + $22 | 0;
    var $95 = _read($89, $94, $num_to_read_1);
    HEAP32[_yy_n_chars >> 2] = $95;
    var $97 = $95;
    __label__ = 26;
    break;
   case 26:
    var $97;
    var $98 = HEAP32[_yy_buffer_stack >> 2];
    var $99 = HEAP32[$98 >> 2];
    var $100 = $99 + 16 | 0;
    HEAP32[$100 >> 2] = $97;
    var $101 = ($97 | 0) == 0;
    if ($101) {
      var $104 = $98;
      var $103 = $97;
      __label__ = 27;
      break;
    } else {
      var $ret_val_0 = 0;
      var $113 = $97;
      var $112 = $98;
      __label__ = 30;
      break;
    }
   case 27:
    var $103;
    var $104;
    var $105 = ($22 | 0) == 0;
    if ($105) {
      __label__ = 28;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 28:
    var $107 = HEAP32[_yyin >> 2];
    _yyrestart($107);
    var $_pre1 = HEAP32[_yy_n_chars >> 2];
    var $_pre2 = HEAP32[_yy_buffer_stack >> 2];
    var $ret_val_0 = 1;
    var $113 = $_pre1;
    var $112 = $_pre2;
    __label__ = 30;
    break;
   case 29:
    var $109 = HEAP32[$104 >> 2];
    var $110 = $109 + 44 | 0;
    HEAP32[$110 >> 2] = 2;
    var $ret_val_0 = 2;
    var $113 = $103;
    var $112 = $104;
    __label__ = 30;
    break;
   case 30:
    var $112;
    var $113;
    var $ret_val_0;
    var $114 = $113 + $22 | 0;
    var $115 = HEAP32[$112 >> 2];
    var $116 = $115 + 12 | 0;
    var $117 = HEAP32[$116 >> 2];
    var $118 = $114 >>> 0 > $117 >>> 0;
    if ($118) {
      __label__ = 32;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 31:
    var $_phi_trans_insert = $115 + 4 | 0;
    var $_pre6 = HEAP32[$_phi_trans_insert >> 2];
    var $136 = $112;
    var $135 = $113;
    var $134 = $_pre6;
    __label__ = 35;
    break;
   case 32:
    var $120 = $113 >> 1;
    var $121 = $114 + $120 | 0;
    var $122 = $115 + 4 | 0;
    var $123 = HEAP32[$122 >> 2];
    var $124 = _yyrealloc($123, $121);
    var $125 = HEAP32[_yy_buffer_stack >> 2];
    var $126 = HEAP32[$125 >> 2];
    var $127 = $126 + 4 | 0;
    HEAP32[$127 >> 2] = $124;
    var $128 = HEAP32[$125 >> 2];
    var $129 = $128 + 4 | 0;
    var $130 = HEAP32[$129 >> 2];
    var $131 = ($130 | 0) == 0;
    if ($131) {
      __label__ = 34;
      break;
    } else {
      __label__ = 33;
      break;
    }
   case 33:
    var $_pre5 = HEAP32[_yy_n_chars >> 2];
    var $136 = $125;
    var $135 = $_pre5;
    var $134 = $130;
    __label__ = 35;
    break;
   case 34:
    _yy_fatal_error(STRING_TABLE.__str22310 | 0);
   case 35:
    var $134;
    var $135;
    var $136;
    var $137 = $135 + $22 | 0;
    HEAP32[_yy_n_chars >> 2] = $137;
    var $138 = $134 + $137 | 0;
    HEAP8[$138] = 0;
    var $139 = $135 + $18 | 0;
    var $140 = HEAP32[$136 >> 2];
    var $141 = $140 + 4 | 0;
    var $142 = HEAP32[$141 >> 2];
    var $143 = $142 + $139 | 0;
    HEAP8[$143] = 0;
    var $144 = HEAP32[$136 >> 2];
    var $145 = $144 + 4 | 0;
    var $146 = HEAP32[$145 >> 2];
    HEAP32[_yytext >> 2] = $146;
    var $_0 = $ret_val_0;
    __label__ = 36;
    break;
   case 36:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_yy_get_next_buffer["X"] = 1;
function _yy_fatal_error($msg) {
  _fprintf(HEAP32[_stderr >> 2], STRING_TABLE.__str17305 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $msg, tempInt));
  _exit(2);
}
function _setsymtab($n, $s, $f, $t, $tab) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($n | 0) == 0;
    if ($1) {
      __label__ = 9;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = _lookup($n, $tab);
    var $4 = ($3 | 0) == 0;
    if ($4) {
      __label__ = 9;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $6 = ($s | 0) != (_EMPTY | 0);
    var $7 = ($s | 0) != 0;
    var $or_cond = $6 & $7;
    if ($or_cond) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    _free($s);
    __label__ = 6;
    break;
   case 6:
    var $_b1 = HEAP8[_dbg_b];
    if ($_b1) {
      __label__ = 7;
      break;
    } else {
      var $_0 = $3;
      __label__ = 14;
      break;
    }
   case 7:
    var $11 = $3;
    var $12 = $3 | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = _printf(STRING_TABLE.__str17353 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $11, HEAP32[tempInt + 4 >> 2] = $13, tempInt));
    var $_pr_b = HEAP8[_dbg_b];
    if ($_pr_b) {
      __label__ = 8;
      break;
    } else {
      var $_0 = $3;
      __label__ = 14;
      break;
    }
   case 8:
    var $16 = $3 + 4 | 0;
    var $17 = HEAP32[$16 >> 2];
    var $18 = $3 + 8 | 0;
    var $19 = (tempDoubleI32[0] = HEAP32[$18 >> 2], tempDoubleI32[1] = HEAP32[$18 + 4 >> 2], tempDoubleF64[0]);
    var $20 = $3 + 16 | 0;
    var $21 = HEAP32[$20 >> 2];
    var $22 = _printf(STRING_TABLE.__str18354 | 0, (tempInt = STACKTOP, STACKTOP += 16, HEAP32[tempInt >> 2] = $17, tempDoubleF64[0] = $19, HEAP32[tempInt + 4 >> 2] = tempDoubleI32[0], HEAP32[tempInt + 8 >> 2] = tempDoubleI32[1], HEAP32[tempInt + 12 >> 2] = $21, tempInt));
    var $_0 = $3;
    __label__ = 14;
    break;
   case 9:
    var $24 = _malloc(24);
    var $25 = $24;
    var $26 = ($24 | 0) == 0;
    if ($26) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    _error(STRING_TABLE.__str19355 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $n, tempInt));
   case 11:
    var $29 = _tostring($n);
    var $30 = $24;
    HEAP32[$30 >> 2] = $29;
    var $31 = $24 + 4 | 0;
    var $32 = $31;
    HEAP32[$32 >> 2] = $s;
    var $33 = $24 + 8 | 0;
    var $34 = $33;
    tempDoubleF64[0] = $f, HEAP32[$34 >> 2] = tempDoubleI32[0], HEAP32[$34 + 4 >> 2] = tempDoubleI32[1];
    var $35 = $24 + 16 | 0;
    var $36 = $35;
    HEAP32[$36 >> 2] = $t;
    var $37 = _hash($n);
    var $38 = $tab + ($37 << 2) | 0;
    var $39 = HEAP32[$38 >> 2];
    var $40 = $24 + 20 | 0;
    var $41 = $40;
    HEAP32[$41 >> 2] = $39;
    HEAP32[$38 >> 2] = $25;
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 12;
      break;
    } else {
      var $_0 = $25;
      __label__ = 14;
      break;
    }
   case 12:
    var $43 = $24;
    var $44 = HEAP32[$30 >> 2];
    var $45 = _printf(STRING_TABLE.__str20356 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $43, HEAP32[tempInt + 4 >> 2] = $44, tempInt));
    var $_pr2_b = HEAP8[_dbg_b];
    if ($_pr2_b) {
      __label__ = 13;
      break;
    } else {
      var $_0 = $25;
      __label__ = 14;
      break;
    }
   case 13:
    var $47 = HEAP32[$32 >> 2];
    var $48 = (tempDoubleI32[0] = HEAP32[$34 >> 2], tempDoubleI32[1] = HEAP32[$34 + 4 >> 2], tempDoubleF64[0]);
    var $49 = HEAP32[$36 >> 2];
    var $50 = _printf(STRING_TABLE.__str18354 | 0, (tempInt = STACKTOP, STACKTOP += 16, HEAP32[tempInt >> 2] = $47, tempDoubleF64[0] = $48, HEAP32[tempInt + 4 >> 2] = tempDoubleI32[0], HEAP32[tempInt + 8 >> 2] = tempDoubleI32[1], HEAP32[tempInt + 12 >> 2] = $49, tempInt));
    var $_0 = $25;
    __label__ = 14;
    break;
   case 14:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_setsymtab["X"] = 1;
function _tostring($s) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($s | 0) == 0;
    if ($1) {
      __label__ = 3;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 3:
    var $3 = _malloc(1);
    var $4 = ($3 | 0) == 0;
    if ($4) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    _error(STRING_TABLE.__str31367 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = 0, tempInt));
   case 5:
    HEAP8[$3] = 0;
    var $p_0 = $3;
    __label__ = 9;
    break;
   case 6:
    var $8 = _strlen($s);
    var $9 = $8 + 1 | 0;
    var $10 = _malloc($9);
    var $11 = ($10 | 0) == 0;
    if ($11) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    _error(STRING_TABLE.__str31367 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $s, tempInt));
   case 8:
    var $14 = _strcpy($10, $s);
    var $p_0 = $10;
    __label__ = 9;
    break;
   case 9:
    var $p_0;
    STACKTOP = __stackBase__;
    return $p_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _makesymtab() {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _malloc(200);
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _error(STRING_TABLE.__str16352 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 4:
    var $5 = $1;
    for (var $$dest = $1 >> 2, $$stop = $$dest + 50; $$dest < $$stop; $$dest++) {
      HEAP32[$$dest] = 0;
    }
    STACKTOP = __stackBase__;
    return $5;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _hash($s) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP8[$s];
    var $2 = $1 << 24 >> 24 == 0;
    if ($2) {
      var $hashval_0_lcssa = 0;
      __label__ = 5;
      break;
    } else {
      var $hashval_01 = 0;
      var $_02 = $s;
      var $3 = $1;
      __label__ = 3;
      break;
    }
   case 3:
    var $3;
    var $_02;
    var $hashval_01;
    var $4 = $3 & 255;
    var $5 = $_02 + 1 | 0;
    var $6 = $4 + $hashval_01 | 0;
    var $7 = HEAP8[$5];
    var $8 = $7 << 24 >> 24 == 0;
    if ($8) {
      __label__ = 4;
      break;
    } else {
      var $hashval_01 = $6;
      var $_02 = $5;
      var $3 = $7;
      __label__ = 3;
      break;
    }
   case 4:
    var $phitmp = ($6 | 0) % 50;
    var $hashval_0_lcssa = $phitmp;
    __label__ = 5;
    break;
   case 5:
    var $hashval_0_lcssa;
    return $hashval_0_lcssa;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _getfval($vp) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $vp + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = HEAP32[_record >> 2];
    var $4 = ($2 | 0) == ($3 | 0);
    var $_b = HEAP8[_donerec_b];
    var $5 = $_b ^ 1;
    var $or_cond = $4 & $5;
    if ($or_cond) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _recbld();
    __label__ = 4;
    break;
   case 4:
    var $_b2 = HEAP8[_dbg_b];
    if ($_b2) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $9 = $vp;
    var $10 = _printf(STRING_TABLE.__str24360 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $9, tempInt));
    __label__ = 6;
    break;
   case 6:
    _checkval($vp);
    var $12 = $vp + 16 | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $13 & 2;
    var $15 = ($14 | 0) == 0;
    if ($15) {
      __label__ = 7;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 7:
    var $17 = HEAP32[$1 >> 2];
    var $18 = _isanumber($17);
    var $19 = ($18 | 0) == 0;
    if ($19) {
      __label__ = 10;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $21 = _atof($17);
    var $22 = $vp + 8 | 0;
    tempDoubleF64[0] = $21, HEAP32[$22 >> 2] = tempDoubleI32[0], HEAP32[$22 + 4 >> 2] = tempDoubleI32[1];
    var $23 = $13 & 8;
    var $24 = ($23 | 0) == 0;
    if ($24) {
      __label__ = 9;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 9:
    var $26 = $13 | 2;
    HEAP32[$12 >> 2] = $26;
    __label__ = 11;
    break;
   case 10:
    var $28 = $vp + 8 | 0;
    tempDoubleF64[0] = 0, HEAP32[$28 >> 2] = tempDoubleI32[0], HEAP32[$28 + 4 >> 2] = tempDoubleI32[1];
    __label__ = 11;
    break;
   case 11:
    var $_b1 = HEAP8[_dbg_b];
    var $30 = $vp + 8 | 0;
    if ($_b1) {
      __label__ = 12;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 12:
    var $32 = (tempDoubleI32[0] = HEAP32[$30 >> 2], tempDoubleI32[1] = HEAP32[$30 + 4 >> 2], tempDoubleF64[0]);
    var $33 = _printf(STRING_TABLE.__str25361 | 0, (tempInt = STACKTOP, STACKTOP += 8, tempDoubleF64[0] = $32, HEAP32[tempInt >> 2] = tempDoubleI32[0], HEAP32[tempInt + 4 >> 2] = tempDoubleI32[1], tempInt));
    __label__ = 13;
    break;
   case 13:
    var $34 = (tempDoubleI32[0] = HEAP32[$30 >> 2], tempDoubleI32[1] = HEAP32[$30 + 4 >> 2], tempDoubleF64[0]);
    STACKTOP = __stackBase__;
    return $34;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _getsval($vp) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 100;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $s = __stackBase__;
    var $1 = $vp + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = HEAP32[_record >> 2];
    var $4 = ($2 | 0) == ($3 | 0);
    var $_b = HEAP8[_donerec_b];
    var $5 = $_b ^ 1;
    var $or_cond = $4 & $5;
    if ($or_cond) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _recbld();
    __label__ = 4;
    break;
   case 4:
    var $_b2 = HEAP8[_dbg_b];
    if ($_b2) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $9 = $vp;
    var $10 = _printf(STRING_TABLE.__str26362 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $9, tempInt));
    __label__ = 6;
    break;
   case 6:
    _checkval($vp);
    var $12 = $vp + 16 | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $13 & 1;
    var $15 = ($14 | 0) == 0;
    if ($15) {
      __label__ = 7;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 7:
    var $17 = $13 & 4;
    var $18 = ($17 | 0) == 0;
    if ($18) {
      __label__ = 8;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 8:
    var $20 = HEAP32[$1 >> 2];
    var $21 = ($20 | 0) == 0;
    var $22 = ($20 | 0) == (_EMPTY | 0);
    var $or_cond2 = $21 | $22;
    if ($or_cond2) {
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    _free($20);
    __label__ = 10;
    break;
   case 10:
    HEAP32[$1 >> 2] = _EMPTY | 0;
    __label__ = 11;
    break;
   case 11:
    var $26 = $vp + 8 | 0;
    var $27 = (tempDoubleI32[0] = HEAP32[$26 >> 2], tempDoubleI32[1] = HEAP32[$26 + 4 >> 2], tempDoubleF64[0]);
    var $28$0 = $27 >>> 0;
    var $28$1 = Math.min(Math.floor($27 / 4294967296), 4294967295);
    var $29 = $28$0 + $28$1 * 4294967296;
    var $30 = $29 == $27;
    var $31 = $s | 0;
    if ($30) {
      __label__ = 12;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 12:
    var $33 = _snprintf($31, 100, STRING_TABLE.__str27363 | 0, (tempInt = STACKTOP, STACKTOP += 8, tempDoubleF64[0] = $27, HEAP32[tempInt >> 2] = tempDoubleI32[0], HEAP32[tempInt + 4 >> 2] = tempDoubleI32[1], tempInt));
    __label__ = 14;
    break;
   case 13:
    var $35 = HEAP32[_OFMT >> 2];
    var $36 = HEAP32[$35 >> 2];
    var $37 = _snprintf($31, 100, $36, (tempInt = STACKTOP, STACKTOP += 8, tempDoubleF64[0] = $27, HEAP32[tempInt >> 2] = tempDoubleI32[0], HEAP32[tempInt + 4 >> 2] = tempDoubleI32[1], tempInt));
    __label__ = 14;
    break;
   case 14:
    var $39 = _tostring($31);
    HEAP32[$1 >> 2] = $39;
    var $40 = HEAP32[$12 >> 2];
    var $41 = $40 & -6;
    var $42 = $41 | 1;
    HEAP32[$12 >> 2] = $42;
    __label__ = 15;
    break;
   case 15:
    var $_b1 = HEAP8[_dbg_b];
    if ($_b1) {
      __label__ = 16;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 16:
    var $45 = HEAP32[$1 >> 2];
    var $46 = _printf(STRING_TABLE.__str28364 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $45, tempInt));
    __label__ = 17;
    break;
   case 17:
    var $47 = HEAP32[$1 >> 2];
    STACKTOP = __stackBase__;
    return $47;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_getsval["X"] = 1;
function _libuxre_regdeldfa($dp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $dp + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = $2;
    _free($5);
    __label__ = 4;
    break;
   case 4:
    var $7 = $dp + 8 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = ($8 | 0) == 0;
    if ($9) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $11 = $8;
    _free($11);
    __label__ = 6;
    break;
   case 6:
    var $13 = $dp + 12 | 0;
    var $14 = HEAP32[$13 >> 2];
    var $15 = ($14 | 0) == 0;
    if ($15) {
      __label__ = 8;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $17 = $14;
    _free($17);
    __label__ = 8;
    break;
   case 8:
    var $19 = $dp + 16 | 0;
    var $20 = HEAP32[$19 >> 2];
    var $21 = ($20 | 0) == 0;
    if ($21) {
      __label__ = 14;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $23 = $dp + 20 | 0;
    var $24 = HEAP32[$23 >> 2];
    var $np_0 = $24;
    var $pp_0 = $20;
    __label__ = 10;
    break;
   case 10:
    var $pp_0;
    var $np_0;
    var $26 = $pp_0 + 12 | 0;
    var $27 = HEAP32[$26 >> 2];
    var $28 = ($27 | 0) == -9;
    if ($28) {
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 11:
    var $30 = $pp_0 | 0;
    var $31 = HEAP32[$30 >> 2];
    _libuxre_bktfree($31);
    var $32 = HEAP32[$30 >> 2];
    var $33 = $32;
    _free($33);
    __label__ = 12;
    break;
   case 12:
    var $35 = $pp_0 + 16 | 0;
    var $36 = $np_0 - 1 | 0;
    var $37 = ($36 | 0) == 0;
    if ($37) {
      __label__ = 13;
      break;
    } else {
      var $np_0 = $36;
      var $pp_0 = $35;
      __label__ = 10;
      break;
    }
   case 13:
    var $39 = HEAP32[$19 >> 2];
    var $40 = $39;
    _free($40);
    __label__ = 14;
    break;
   case 14:
    var $42 = $dp;
    _free($42);
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_regdeldfa["X"] = 1;
function _libuxre_bktfree($bp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $bp + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = $2;
    _free($5);
    __label__ = 4;
    break;
   case 4:
    var $7 = $bp + 8 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = ($8 | 0) == 0;
    if ($9) {
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $11 = $8;
    _free($11);
    __label__ = 6;
    break;
   case 6:
    var $13 = $bp + 12 | 0;
    var $14 = HEAP32[$13 >> 2];
    var $15 = ($14 | 0) == 0;
    if ($15) {
      __label__ = 8;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $17 = $14;
    _free($17);
    __label__ = 8;
    break;
   case 8:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _regtrans($dp, $st, $wc, $mb_cur_max) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $dp + 36 + ($st << 2) | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $5 = $st + 1 | 0;
    var $_0 = $5;
    __label__ = 30;
    break;
   case 4:
    var $7 = $dp | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = $dp + 20 | 0;
    var $10 = HEAP32[$9 >> 2];
    _memset($8, 0, $10, 1);
    var $11 = $dp + 32 | 0;
    HEAP32[$11 >> 2] = 0;
    var $12 = $dp + 164 + ($st << 2) | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $dp + 8 | 0;
    var $15 = HEAP32[$14 >> 2];
    var $16 = $15 + ($13 << 2) | 0;
    var $17 = $dp + 16 | 0;
    var $18 = $dp + 4 | 0;
    var $19 = ($wc | 0) == 0;
    var $20 = $dp + 329 | 0;
    var $21 = ($wc | 0) > 0;
    var $22 = ($wc | 0) == 10;
    var $23 = ($wc | 0) < 1;
    var $or_cond = $22 | $23;
    var $n_0 = $2;
    var $fp_0 = $16;
    __label__ = 5;
    break;
   case 5:
    var $fp_0;
    var $n_0;
    var $25 = HEAP32[$fp_0 >> 2];
    var $26 = HEAP32[$17 >> 2];
    var $27 = $26 + ($25 << 4) + 12 | 0;
    var $28 = HEAP32[$27 >> 2];
    if (($28 | 0) == -3) {
      __label__ = 6;
      break;
    } else if (($28 | 0) == -6) {
      __label__ = 9;
      break;
    } else if (($28 | 0) == -5) {
      __label__ = 10;
      break;
    } else if (($28 | 0) == -4) {
      __label__ = 11;
      break;
    } else if (($28 | 0) == -10 || ($28 | 0) == -9) {
      __label__ = 12;
      break;
    } else if (($28 | 0) == -14 || ($28 | 0) == -8) {
      __label__ = 19;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 6:
    if ($19) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $31 = HEAP8[$20];
    var $32 = $31 & 2;
    var $33 = $32 << 24 >> 24 == 0;
    var $34 = ($28 | 0) == ($wc | 0);
    var $or_cond7 = $33 | $34;
    if ($or_cond7) {
      __label__ = 14;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 8:
    var $_old = ($28 | 0) == ($wc | 0);
    if ($_old) {
      __label__ = 14;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 9:
    if ($or_cond) {
      __label__ = 19;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 10:
    if ($23) {
      __label__ = 19;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 11:
    if ($19) {
      __label__ = 19;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 12:
    if ($21) {
      __label__ = 13;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 13:
    var $41 = $26 + ($25 << 4) | 0;
    var $42 = HEAP32[$41 >> 2];
    var $43 = _libuxre_bktmbexec($42, $wc, 0, $mb_cur_max);
    var $44 = ($43 | 0) == 0;
    if ($44) {
      __label__ = 14;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 14:
    var $45 = $26 + ($25 << 4) + 4 | 0;
    var $46 = HEAP32[$45 >> 2];
    var $47 = $26 + ($25 << 4) + 8 | 0;
    var $48 = HEAP32[$47 >> 2];
    var $49 = HEAP32[$18 >> 2];
    var $50 = $49 + ($48 << 2) | 0;
    var $i_0 = $46;
    var $sp_0 = $50;
    __label__ = 15;
    break;
   case 15:
    var $sp_0;
    var $i_0;
    var $52 = HEAP32[$sp_0 >> 2];
    var $53 = HEAP32[$7 >> 2];
    var $54 = $53 + $52 | 0;
    var $55 = HEAP8[$54];
    var $56 = $55 << 24 >> 24 == 0;
    if ($56) {
      __label__ = 16;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 16:
    HEAP8[$54] = 1;
    var $58 = HEAP32[$11 >> 2];
    var $59 = $58 + 1 | 0;
    HEAP32[$11 >> 2] = $59;
    __label__ = 17;
    break;
   case 17:
    var $61 = $i_0 - 1 | 0;
    var $62 = ($61 | 0) == 0;
    if ($62) {
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $63 = $sp_0 + 4 | 0;
    var $i_0 = $61;
    var $sp_0 = $63;
    __label__ = 15;
    break;
   case 19:
    var $64 = $n_0 - 1 | 0;
    var $65 = ($64 | 0) == 0;
    if ($65) {
      __label__ = 21;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 20:
    var $66 = $fp_0 + 4 | 0;
    var $n_0 = $64;
    var $fp_0 = $66;
    __label__ = 5;
    break;
   case 21:
    var $68 = HEAP32[$11 >> 2];
    var $69 = ($68 | 0) == 0;
    if ($69) {
      __label__ = 26;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    var $71 = $dp + 12 | 0;
    var $72 = HEAP32[$71 >> 2];
    var $73 = HEAP32[$7 >> 2];
    var $n_1 = 0;
    var $i_1 = $68;
    var $s_0 = $73;
    var $fp_1 = $72;
    __label__ = 23;
    break;
   case 23:
    var $fp_1;
    var $s_0;
    var $i_1;
    var $n_1;
    var $75 = $s_0 + 1 | 0;
    var $76 = HEAP8[$s_0];
    var $77 = $76 << 24 >> 24 == 0;
    if ($77) {
      var $i_2 = $i_1;
      var $fp_2 = $fp_1;
      __label__ = 25;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 24:
    var $79 = $fp_1 + 4 | 0;
    HEAP32[$fp_1 >> 2] = $n_1;
    var $80 = $i_1 - 1 | 0;
    var $81 = ($80 | 0) == 0;
    if ($81) {
      __label__ = 26;
      break;
    } else {
      var $i_2 = $80;
      var $fp_2 = $79;
      __label__ = 25;
      break;
    }
   case 25:
    var $fp_2;
    var $i_2;
    var $83 = $n_1 + 1 | 0;
    var $n_1 = $83;
    var $i_1 = $i_2;
    var $s_0 = $75;
    var $fp_1 = $fp_2;
    __label__ = 23;
    break;
   case 26:
    var $84 = _addstate($dp);
    var $85 = ($84 | 0) < 0;
    if ($85) {
      __label__ = 27;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 27:
    var $87 = -$84 | 0;
    var $_0 = $87;
    __label__ = 30;
    break;
   case 28:
    var $89 = ($84 | 0) > 0;
    var $90 = $wc >>> 0 < 256;
    var $or_cond2 = $89 & $90;
    if ($or_cond2) {
      __label__ = 29;
      break;
    } else {
      var $_0 = $84;
      __label__ = 30;
      break;
    }
   case 29:
    var $92 = $84 & 255;
    var $93 = $dp + 330 + ($st << 8) + $wc | 0;
    HEAP8[$93] = $92;
    var $_0 = $84;
    __label__ = 30;
    break;
   case 30:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_regtrans["X"] = 1;
function _setfval($vp, $f) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $2 = $vp;
    var $3 = _printf(STRING_TABLE.__str21357 | 0, (tempInt = STACKTOP, STACKTOP += 12, HEAP32[tempInt >> 2] = $2, tempDoubleF64[0] = $f, HEAP32[tempInt + 4 >> 2] = tempDoubleI32[0], HEAP32[tempInt + 8 >> 2] = tempDoubleI32[1], tempInt));
    __label__ = 4;
    break;
   case 4:
    _checkval($vp);
    var $5 = HEAP32[_recloc >> 2];
    var $6 = ($5 | 0) == ($vp | 0);
    if ($6) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    _error(STRING_TABLE.__str22358 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 6:
    var $9 = $vp + 16 | 0;
    var $10 = HEAP32[$9 >> 2];
    var $11 = $10 & -4;
    var $12 = $11 | 2;
    HEAP32[$9 >> 2] = $12;
    var $13 = $10 & 4;
    var $14 = ($13 | 0) == 0;
    if ($14) {
      __label__ = 9;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $16 = $vp | 0;
    var $17 = HEAP32[$16 >> 2];
    var $18 = ($17 | 0) == (_EMPTY | 0);
    var $19 = ($17 | 0) == 0;
    var $or_cond = $18 | $19;
    if ($or_cond) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    HEAP8[_donerec_b] = 0;
    __label__ = 9;
    break;
   case 9:
    var $22 = $vp + 8 | 0;
    tempDoubleF64[0] = $f, HEAP32[$22 >> 2] = tempDoubleI32[0], HEAP32[$22 + 4 >> 2] = tempDoubleI32[1];
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _checkval($vp) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $vp + 16 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $2 & 16;
    var $4 = ($3 | 0) == 0;
    if ($4) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $6 = $vp | 0;
    var $7 = HEAP32[$6 >> 2];
    _error(STRING_TABLE.__str29365 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $7, tempInt));
   case 4:
    var $9 = $2 & 3;
    var $10 = ($9 | 0) == 0;
    if ($10) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $12 = $vp | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $vp + 4 | 0;
    var $15 = HEAP32[$14 >> 2];
    var $16 = $vp + 8 | 0;
    var $17 = (tempDoubleI32[0] = HEAP32[$16 >> 2], tempDoubleI32[1] = HEAP32[$16 + 4 >> 2], tempDoubleF64[0]);
    _error(STRING_TABLE.__str30366 | 0, (tempInt = STACKTOP, STACKTOP += 24, HEAP32[tempInt >> 2] = $vp, HEAP32[tempInt + 4 >> 2] = $13, HEAP32[tempInt + 8 >> 2] = $15, tempDoubleF64[0] = $17, HEAP32[tempInt + 12 >> 2] = tempDoubleI32[0], HEAP32[tempInt + 16 >> 2] = tempDoubleI32[1], HEAP32[tempInt + 20 >> 2] = $2, tempInt));
   case 6:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _setsval($vp, $s) {
  var __stackBase__ = STACKTOP;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $_b = HEAP8[_dbg_b];
    if ($_b) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $2 = $vp;
    var $3 = _printf(STRING_TABLE.__str23359 | 0, (tempInt = STACKTOP, STACKTOP += 8, HEAP32[tempInt >> 2] = $2, HEAP32[tempInt + 4 >> 2] = $s, tempInt));
    __label__ = 4;
    break;
   case 4:
    _checkval($vp);
    var $5 = HEAP32[_recloc >> 2];
    var $6 = ($5 | 0) == ($vp | 0);
    if ($6) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    _error(STRING_TABLE.__str22358 | 0, (tempInt = STACKTOP, STACKTOP += 1, STACKTOP = STACKTOP + 3 >> 2 << 2, HEAP32[tempInt >> 2] = 0, tempInt));
   case 6:
    var $9 = $vp + 16 | 0;
    var $10 = HEAP32[$9 >> 2];
    var $11 = $10 & -4;
    var $12 = $11 | 1;
    HEAP32[$9 >> 2] = $12;
    var $13 = $10 & 4;
    var $14 = ($13 | 0) == 0;
    if ($14) {
      __label__ = 9;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $16 = $vp | 0;
    var $17 = HEAP32[$16 >> 2];
    var $18 = ($17 | 0) == (_EMPTY | 0);
    var $19 = ($17 | 0) == 0;
    var $or_cond = $18 | $19;
    if ($or_cond) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    HEAP8[_donerec_b] = 0;
    __label__ = 9;
    break;
   case 9:
    var $22 = $10 & 4;
    var $23 = ($22 | 0) == 0;
    var $24 = $vp + 4 | 0;
    if ($23) {
      __label__ = 10;
      break;
    } else {
      var $31 = $12;
      var $_pre_phi = $24;
      __label__ = 13;
      break;
    }
   case 10:
    var $26 = HEAP32[$24 >> 2];
    var $27 = ($26 | 0) == 0;
    var $28 = ($26 | 0) == (_EMPTY | 0);
    var $or_cond1 = $27 | $28;
    if ($or_cond1) {
      var $_pre = $12;
      __label__ = 12;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    _free($26);
    var $_pre_pre = HEAP32[$9 >> 2];
    var $_pre = $_pre_pre;
    __label__ = 12;
    break;
   case 12:
    var $_pre;
    HEAP32[$24 >> 2] = _EMPTY | 0;
    var $31 = $_pre;
    var $_pre_phi = $24;
    __label__ = 13;
    break;
   case 13:
    var $_pre_phi;
    var $31;
    var $32 = $31 & -5;
    HEAP32[$9 >> 2] = $32;
    var $33 = _tostring($s);
    HEAP32[$_pre_phi >> 2] = $33;
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _libuxre_bktmbexec($bp, $wc, $str, $mb_cur_max) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 28;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $mcbuf = __stackBase__;
    var $1 = $mcbuf + 4 | 0;
    HEAP32[$1 >> 2] = $str;
    var $2 = $mcbuf + 20 | 0;
    HEAP32[$2 >> 2] = $wc;
    var $3 = $bp + 208 | 0;
    var $4 = HEAP16[$3 >> 1];
    var $5 = $4 << 16 >> 16 == 0;
    if ($5) {
      __label__ = 11;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $7 = $bp + 216 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = $8 & 2;
    var $10 = ($9 | 0) == 0;
    if ($10) {
      __label__ = 8;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $12 = ($mb_cur_max | 0) > 1;
    if ($12) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    _towlower();
   case 6:
    var $15 = _tolower($wc);
    var $16 = HEAP32[$2 >> 2];
    var $17 = ($15 | 0) == ($16 | 0);
    if ($17) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $19 = _toupper($15);
    HEAP32[$2 >> 2] = $19;
    __label__ = 8;
    break;
   case 8:
    var $21 = ($mb_cur_max | 0) == 1;
    if ($21) {
      __label__ = 9;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 9:
    _btowc();
   case 10:
    _iswctype();
   case 11:
    var $25 = $mcbuf | 0;
    HEAP32[$25 >> 2] = 0;
    var $26 = $mcbuf + 8 | 0;
    HEAP32[$26 >> 2] = $bp;
    var $27 = $bp | 0;
    var $28 = HEAP32[$27 >> 2];
    var $29 = $mcbuf + 12 | 0;
    HEAP32[$29 >> 2] = $28;
    var $30 = $mcbuf + 16 | 0;
    HEAP32[$30 >> 2] = 0;
    var $31 = _mcce($mcbuf, 0, $str, $mb_cur_max);
    var $32 = HEAP32[$30 >> 2];
    var $magicptr = $32;
    if (($magicptr | 0) == -1) {
      __label__ = 13;
      break;
    } else if (($magicptr | 0) == 0) {
      var $_0 = -1;
      __label__ = 52;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $34 = $32 + 4 | 0;
    var $35 = HEAP32[$34 >> 2];
    var $36 = $mcbuf + 24 | 0;
    HEAP32[$36 >> 2] = $35;
    __label__ = 13;
    break;
   case 13:
    var $38 = $bp + 216 | 0;
    var $39 = HEAP32[$38 >> 2];
    var $40 = $39 & 2;
    var $41 = ($40 | 0) == 0;
    if ($41) {
      __label__ = 17;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $43 = ($mb_cur_max | 0) > 1;
    var $44 = $mcbuf + 24 | 0;
    if ($43) {
      __label__ = 15;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 15:
    _towlower();
   case 16:
    var $47 = HEAP32[$44 >> 2];
    var $48 = _tolower($47);
    var $49 = HEAP32[$44 >> 2];
    var $50 = _toupper($49);
    var $_pre = HEAP32[$44 >> 2];
    var $lc_0 = $48;
    var $uc_0 = $50;
    var $55 = $_pre;
    __label__ = 18;
    break;
   case 17:
    var $52 = $mcbuf + 24 | 0;
    var $53 = HEAP32[$52 >> 2];
    var $lc_0 = $53;
    var $uc_0 = $53;
    var $55 = $53;
    __label__ = 18;
    break;
   case 18:
    var $55;
    var $uc_0;
    var $lc_0;
    var $56 = $mcbuf + 24 | 0;
    var $57 = ($55 | 0) < 256;
    if ($57) {
      __label__ = 19;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 19:
    var $59 = $lc_0 >> 4;
    var $60 = $bp + 176 + ($59 << 1) | 0;
    var $61 = HEAP16[$60 >> 1];
    var $62 = $61 & 65535;
    var $63 = $lc_0 & 15;
    var $64 = 1 << $63;
    var $65 = $62 & $64;
    var $66 = ($65 | 0) == 0;
    if ($66) {
      __label__ = 20;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 20:
    var $68 = ($lc_0 | 0) == ($uc_0 | 0);
    if ($68) {
      __label__ = 39;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $70 = $uc_0 >> 4;
    var $71 = $bp + 176 + ($70 << 1) | 0;
    var $72 = HEAP16[$71 >> 1];
    var $73 = $72 & 65535;
    var $74 = $uc_0 & 15;
    var $75 = 1 << $74;
    var $76 = $73 & $75;
    var $77 = ($76 | 0) == 0;
    if ($77) {
      __label__ = 39;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 22:
    var $79 = $bp + 212 | 0;
    var $80 = HEAP16[$79 >> 1];
    var $81 = $80 << 16 >> 16 == 0;
    if ($81) {
      __label__ = 39;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $83 = $80 & 65535;
    var $84 = $bp + 48 | 0;
    var $85 = ($lc_0 | 0) != ($uc_0 | 0);
    var $86 = $bp + 176 | 0;
    var $87 = $bp + 12 | 0;
    var $wcp_0 = $84;
    var $i_1 = $83;
    __label__ = 24;
    break;
   case 24:
    var $i_1;
    var $wcp_0;
    var $88 = HEAP32[$wcp_0 >> 2];
    var $89 = $lc_0 - $88 | 0;
    var $90 = ($lc_0 | 0) == ($88 | 0);
    if ($90) {
      __label__ = 50;
      break;
    } else {
      __label__ = 25;
      break;
    }
   case 25:
    var $92 = $uc_0 - $88 | 0;
    var $93 = ($uc_0 | 0) == ($88 | 0);
    var $or_cond = $85 & $93;
    if ($or_cond) {
      __label__ = 50;
      break;
    } else {
      __label__ = 26;
      break;
    }
   case 26:
    var $95 = $i_1 - 1 | 0;
    var $96 = ($95 | 0) == 0;
    if ($96) {
      __label__ = 39;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $98 = $wcp_0 + 4 | 0;
    var $99 = ($98 | 0) == ($86 | 0);
    if ($99) {
      __label__ = 28;
      break;
    } else {
      var $wcp_1 = $98;
      __label__ = 29;
      break;
    }
   case 28:
    var $101 = HEAP32[$87 >> 2];
    var $wcp_1 = $101;
    __label__ = 29;
    break;
   case 29:
    var $wcp_1;
    var $103 = HEAP32[$wcp_1 >> 2];
    var $104 = ($103 | 0) == 45;
    if ($104) {
      __label__ = 30;
      break;
    } else {
      var $wcp_0 = $wcp_1;
      var $i_1 = $95;
      __label__ = 24;
      break;
    }
   case 30:
    var $106 = $wcp_1 + 4 | 0;
    var $107 = ($106 | 0) == ($86 | 0);
    if ($107) {
      __label__ = 31;
      break;
    } else {
      var $wcp_2 = $106;
      __label__ = 32;
      break;
    }
   case 31:
    var $109 = HEAP32[$87 >> 2];
    var $wcp_2 = $109;
    __label__ = 32;
    break;
   case 32:
    var $wcp_2;
    var $111 = ($89 | 0) > 0;
    if ($111) {
      __label__ = 33;
      break;
    } else {
      __label__ = 34;
      break;
    }
   case 33:
    var $113 = HEAP32[$wcp_2 >> 2];
    var $114 = ($lc_0 | 0) > ($113 | 0);
    if ($114) {
      __label__ = 34;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 34:
    var $116 = ($92 | 0) > 0;
    var $or_cond2 = $85 & $116;
    if ($or_cond2) {
      __label__ = 35;
      break;
    } else {
      __label__ = 36;
      break;
    }
   case 35:
    var $118 = HEAP32[$wcp_2 >> 2];
    var $119 = ($uc_0 | 0) < ($118 | 0);
    if ($119) {
      __label__ = 50;
      break;
    } else {
      __label__ = 36;
      break;
    }
   case 36:
    var $121 = $i_1 - 3 | 0;
    var $122 = ($121 | 0) == 0;
    if ($122) {
      __label__ = 39;
      break;
    } else {
      __label__ = 37;
      break;
    }
   case 37:
    var $124 = $wcp_2 + 4 | 0;
    var $125 = ($124 | 0) == ($86 | 0);
    if ($125) {
      __label__ = 38;
      break;
    } else {
      var $wcp_0 = $124;
      var $i_1 = $121;
      __label__ = 24;
      break;
    }
   case 38:
    var $127 = HEAP32[$87 >> 2];
    var $wcp_0 = $127;
    var $i_1 = $121;
    __label__ = 24;
    break;
   case 39:
    var $128 = $bp + 210 | 0;
    var $129 = HEAP16[$128 >> 1];
    var $130 = $129 & 65535;
    var $131 = $129 << 16 >> 16 == 0;
    if ($131) {
      __label__ = 46;
      break;
    } else {
      __label__ = 40;
      break;
    }
   case 40:
    var $133 = HEAP32[$30 >> 2];
    var $134 = ($133 | 0) == -1;
    if ($134) {
      __label__ = 46;
      break;
    } else {
      __label__ = 41;
      break;
    }
   case 41:
    var $136 = $bp + 32 | 0;
    var $137 = $133 + 8 | 0;
    var $138 = HEAP32[$137 >> 2];
    HEAP32[$56 >> 2] = $138;
    var $139 = $bp + 48 | 0;
    var $140 = $bp + 8 | 0;
    var $wucp_0 = $136;
    var $i_2 = $130;
    __label__ = 42;
    break;
   case 42:
    var $i_2;
    var $wucp_0;
    var $141 = HEAP32[$wucp_0 >> 2];
    var $142 = ($138 | 0) == ($141 | 0);
    if ($142) {
      __label__ = 50;
      break;
    } else {
      __label__ = 43;
      break;
    }
   case 43:
    var $144 = $i_2 - 1 | 0;
    var $145 = ($144 | 0) == 0;
    if ($145) {
      __label__ = 46;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 44:
    var $147 = $wucp_0 + 4 | 0;
    var $148 = ($147 | 0) == ($139 | 0);
    if ($148) {
      __label__ = 45;
      break;
    } else {
      var $wucp_0 = $147;
      var $i_2 = $144;
      __label__ = 42;
      break;
    }
   case 45:
    var $150 = HEAP32[$140 >> 2];
    var $wucp_0 = $150;
    var $i_2 = $144;
    __label__ = 42;
    break;
   case 46:
    var $151 = HEAP32[$38 >> 2];
    var $152 = $151 & 1;
    var $153 = ($152 | 0) == 0;
    if ($153) {
      var $_0 = -1;
      __label__ = 52;
      break;
    } else {
      __label__ = 47;
      break;
    }
   case 47:
    var $155 = ($wc | 0) == 10;
    if ($155) {
      __label__ = 48;
      break;
    } else {
      __label__ = 49;
      break;
    }
   case 48:
    var $157 = $151 & 4;
    var $158 = ($157 | 0) == 0;
    if ($158) {
      __label__ = 49;
      break;
    } else {
      var $_0 = -1;
      __label__ = 52;
      break;
    }
   case 49:
    var $160 = HEAP32[$1 >> 2];
    var $161 = $160;
    var $162 = $str;
    var $163 = $161 - $162 | 0;
    var $_0 = $163;
    __label__ = 52;
    break;
   case 50:
    var $164 = HEAP32[$38 >> 2];
    var $165 = $164 & 1;
    var $166 = ($165 | 0) == 0;
    if ($166) {
      __label__ = 51;
      break;
    } else {
      var $_0 = -1;
      __label__ = 52;
      break;
    }
   case 51:
    var $168 = HEAP32[$1 >> 2];
    var $169 = $168;
    var $170 = $str;
    var $171 = $169 - $170 | 0;
    var $_0 = $171;
    __label__ = 52;
    break;
   case 52:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_bktmbexec["X"] = 1;
function _addstate($dp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $dp + 328 | 0;
    var $2 = HEAP8[$1];
    var $3 = $2 & 255;
    var $4 = $dp + 32 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = ($5 | 0) == 0;
    var $7 = $dp + 8 | 0;
    var $8 = $dp + 12 | 0;
    var $t_0 = $3;
    __label__ = 3;
    break;
   case 3:
    var $t_0;
    var $10 = $t_0 - 1 | 0;
    var $11 = $dp + 36 + ($10 << 2) | 0;
    var $12 = HEAP32[$11 >> 2];
    var $13 = ($12 | 0) == ($5 | 0);
    if ($13) {
      __label__ = 4;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 4:
    if ($6) {
      var $_0 = $t_0;
      __label__ = 23;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $16 = $dp + 164 + ($10 << 2) | 0;
    var $17 = HEAP32[$16 >> 2];
    var $18 = HEAP32[$7 >> 2];
    var $19 = $18 + ($17 << 2) | 0;
    var $20 = HEAP32[$8 >> 2];
    var $sp_0 = $20;
    var $fp_0 = $19;
    var $n_0 = $5;
    __label__ = 6;
    break;
   case 6:
    var $n_0;
    var $fp_0;
    var $sp_0;
    var $22 = HEAP32[$fp_0 >> 2];
    var $23 = HEAP32[$sp_0 >> 2];
    var $24 = ($22 | 0) == ($23 | 0);
    if ($24) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $26 = $sp_0 + 4 | 0;
    var $27 = $fp_0 + 4 | 0;
    var $28 = $n_0 - 1 | 0;
    var $29 = ($28 | 0) == 0;
    if ($29) {
      var $_0 = $t_0;
      __label__ = 23;
      break;
    } else {
      var $sp_0 = $26;
      var $fp_0 = $27;
      var $n_0 = $28;
      __label__ = 6;
      break;
    }
   case 8:
    var $30 = ($10 | 0) == 0;
    if ($30) {
      __label__ = 9;
      break;
    } else {
      var $t_0 = $10;
      __label__ = 3;
      break;
    }
   case 9:
    var $32 = ($2 & 255) > 31;
    if ($32) {
      __label__ = 11;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $_pre3 = $dp + 28 | 0;
    var $flushed_0 = 0;
    var $t_1 = $3;
    var $56 = $2;
    var $55 = $5;
    var $_pre_phi = $_pre3;
    __label__ = 12;
    break;
   case 11:
    var $34 = $dp + 326 | 0;
    var $35 = HEAP8[$34];
    var $36 = $35 & 255;
    var $37 = $dp + 164 + ($36 << 2) | 0;
    var $38 = HEAP32[$37 >> 2];
    var $39 = $dp + 36 + ($36 << 2) | 0;
    var $40 = HEAP32[$39 >> 2];
    var $41 = $40 + $38 | 0;
    var $42 = $dp + 24 | 0;
    var $43 = HEAP32[$42 >> 2];
    var $44 = $dp + 28 | 0;
    var $45 = HEAP32[$44 >> 2];
    var $46 = $43 - $41 | 0;
    var $47 = $46 + $45 | 0;
    HEAP32[$44 >> 2] = $47;
    HEAP32[$42 >> 2] = $41;
    var $48 = $dp + 327 | 0;
    var $49 = HEAP8[$48];
    var $50 = $49 & 255;
    HEAP8[$1] = $49;
    var $51 = $dp + 330 | 0;
    _memset($51, 0, 8192, 1);
    var $52 = $50 + ($dp + 292) | 0;
    var $53 = 32 - $50 | 0;
    _memset($52, 0, $53, 1);
    var $_pre = HEAP8[$1];
    var $_pre2 = HEAP32[$4 >> 2];
    var $flushed_0 = 1;
    var $t_1 = $50;
    var $56 = $_pre;
    var $55 = $_pre2;
    var $_pre_phi = $44;
    __label__ = 12;
    break;
   case 12:
    var $_pre_phi;
    var $55;
    var $56;
    var $t_1;
    var $flushed_0;
    var $57 = $56 + 1 & 255;
    HEAP8[$1] = $57;
    var $58 = HEAP32[$7 >> 2];
    var $59 = HEAP32[$_pre_phi >> 2];
    var $60 = $55 >>> 0 > $59 >>> 0;
    if ($60) {
      __label__ = 13;
      break;
    } else {
      var $fp_1 = $58;
      __label__ = 15;
      break;
    }
   case 13:
    var $62 = $59 + $55 | 0;
    var $63 = $62 << 1;
    var $64 = $58;
    var $65 = $dp + 24 | 0;
    var $66 = HEAP32[$65 >> 2];
    var $67 = $66 + $63 | 0;
    var $68 = $67 << 2;
    var $69 = _realloc($64, $68);
    var $70 = $69;
    var $71 = ($69 | 0) == 0;
    if ($71) {
      var $_0 = 0;
      __label__ = 23;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    HEAP32[$_pre_phi >> 2] = $63;
    HEAP32[$7 >> 2] = $70;
    var $fp_1 = $70;
    __label__ = 15;
    break;
   case 15:
    var $fp_1;
    var $74 = $t_1 + ($dp + 292) | 0;
    HEAP8[$74] = 0;
    var $75 = $dp + 36 + ($t_1 << 2) | 0;
    HEAP32[$75 >> 2] = $55;
    var $76 = ($55 | 0) == 0;
    if ($76) {
      __label__ = 20;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $78 = HEAP32[$8 >> 2];
    var $79 = HEAP32[$78 >> 2];
    var $80 = ($79 | 0) == 0;
    if ($80) {
      __label__ = 17;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 17:
    HEAP8[$74] = 1;
    __label__ = 18;
    break;
   case 18:
    var $83 = $dp + 24 | 0;
    var $84 = HEAP32[$83 >> 2];
    var $85 = $dp + 164 + ($t_1 << 2) | 0;
    HEAP32[$85 >> 2] = $84;
    var $86 = HEAP32[$83 >> 2];
    var $87 = $86 + $55 | 0;
    HEAP32[$83 >> 2] = $87;
    var $88 = HEAP32[$_pre_phi >> 2];
    var $89 = $88 - $55 | 0;
    HEAP32[$_pre_phi >> 2] = $89;
    var $90 = $fp_1 + ($84 << 2) | 0;
    var $sp_1 = $78;
    var $fp_2 = $90;
    var $n_1 = $55;
    __label__ = 19;
    break;
   case 19:
    var $n_1;
    var $fp_2;
    var $sp_1;
    var $92 = $sp_1 + 4 | 0;
    var $93 = HEAP32[$sp_1 >> 2];
    var $94 = $fp_2 + 4 | 0;
    HEAP32[$fp_2 >> 2] = $93;
    var $95 = $n_1 - 1 | 0;
    var $96 = ($95 | 0) == 0;
    if ($96) {
      __label__ = 20;
      break;
    } else {
      var $sp_1 = $92;
      var $fp_2 = $94;
      var $n_1 = $95;
      __label__ = 19;
      break;
    }
   case 20:
    var $97 = ($flushed_0 | 0) == 0;
    if ($97) {
      __label__ = 22;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $99 = $t_1 ^ -1;
    var $_0 = $99;
    __label__ = 23;
    break;
   case 22:
    var $101 = $t_1 + 1 | 0;
    var $_0 = $101;
    __label__ = 23;
    break;
   case 23:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_addstate["X"] = 1;
function _libuxre_regdelnfa($np) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $np | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    _delgraph($2);
    __label__ = 4;
    break;
   case 4:
    var $6 = $np + 12 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = ($7 | 0) == 0;
    if ($8) {
      __label__ = 6;
      break;
    } else {
      var $cp_02 = $7;
      __label__ = 5;
      break;
    }
   case 5:
    var $cp_02;
    var $9 = $cp_02 | 0;
    var $10 = HEAP32[$9 >> 2];
    var $11 = $cp_02;
    _free($11);
    var $12 = ($10 | 0) == 0;
    if ($12) {
      __label__ = 6;
      break;
    } else {
      var $cp_02 = $10;
      __label__ = 5;
      break;
    }
   case 6:
    var $13 = $np + 8 | 0;
    var $14 = HEAP32[$13 >> 2];
    var $15 = ($14 | 0) == 0;
    if ($15) {
      __label__ = 8;
      break;
    } else {
      var $sp_01 = $14;
      __label__ = 7;
      break;
    }
   case 7:
    var $sp_01;
    var $16 = $sp_01 | 0;
    var $17 = HEAP32[$16 >> 2];
    var $18 = $sp_01;
    _free($18);
    var $19 = ($17 | 0) == 0;
    if ($19) {
      __label__ = 8;
      break;
    } else {
      var $sp_01 = $17;
      __label__ = 7;
      break;
    }
   case 8:
    var $20 = $np;
    _free($20);
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _delgraph($gp) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $gp2 = __stackBase__;
    var $end = __stackBase__ + 4;
    HEAP32[$gp2 >> 2] = $end;
    _deltolist($gp, $gp2);
    var $1 = HEAP32[$gp2 >> 2];
    var $2 = ($1 | 0) == ($end | 0);
    if ($2) {
      __label__ = 4;
      break;
    } else {
      var $3 = $1;
      __label__ = 3;
      break;
    }
   case 3:
    var $3;
    var $4 = $3 | 0;
    var $5 = HEAP32[$4 >> 2];
    HEAP32[$gp2 >> 2] = $5;
    var $6 = $3;
    _free($6);
    var $7 = HEAP32[$gp2 >> 2];
    var $8 = ($7 | 0) == ($end | 0);
    if ($8) {
      __label__ = 4;
      break;
    } else {
      var $3 = $7;
      __label__ = 3;
      break;
    }
   case 4:
    STACKTOP = __stackBase__;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _regcomp($ep, $pat) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 52;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $lex = __stackBase__;
    var $1 = _libuxre_regparse($lex, $pat);
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $3 = $lex + 44 | 0;
    var $45 = $3;
    __label__ = 13;
    break;
   case 4:
    var $5 = $lex + 28 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $ep | 0;
    HEAP32[$7 >> 2] = $6;
    var $8 = $lex + 16 | 0;
    var $9 = HEAP32[$8 >> 2];
    var $10 = $9 & -8;
    var $11 = $ep + 4 | 0;
    HEAP32[$11 >> 2] = $10;
    var $12 = $lex + 12 | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $ep + 16 | 0;
    HEAP32[$14 >> 2] = $13;
    var $15 = $lex + 48 | 0;
    var $16 = HEAP32[$15 >> 2];
    var $17 = $ep + 20 | 0;
    HEAP32[$17 >> 2] = $16;
    var $18 = $9 & 536870912;
    var $19 = ($18 | 0) == 0;
    if ($19) {
      var $26 = $9;
      __label__ = 7;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $21 = $10 | 536870912;
    HEAP32[$11 >> 2] = $21;
    var $22 = _libuxre_regnfacomp($ep, $1, $lex);
    var $23 = $lex + 44 | 0;
    HEAP32[$23 >> 2] = $22;
    var $24 = ($22 | 0) == 0;
    if ($24) {
      __label__ = 6;
      break;
    } else {
      var $_pre_phi = $23;
      __label__ = 12;
      break;
    }
   case 6:
    var $_pre = HEAP32[$8 >> 2];
    var $26 = $_pre;
    __label__ = 7;
    break;
   case 7:
    var $26;
    var $27 = $26 & 536870912;
    var $28 = ($27 | 0) == 0;
    if ($28) {
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $_pre3 = $lex + 44 | 0;
    var $_pre_phi = $_pre3;
    __label__ = 12;
    break;
   case 9:
    var $30 = HEAP32[$11 >> 2];
    var $31 = $30 | 1073741824;
    HEAP32[$11 >> 2] = $31;
    var $32 = _libuxre_regdfacomp($ep, $1, $lex);
    var $33 = $lex + 44 | 0;
    HEAP32[$33 >> 2] = $32;
    var $34 = ($32 | 0) == 0;
    if ($34) {
      var $_pre_phi = $33;
      __label__ = 12;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $36 = HEAP32[$11 >> 2];
    var $37 = $36 & 536870912;
    var $38 = ($37 | 0) == 0;
    if ($38) {
      var $_pre_phi = $33;
      __label__ = 12;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $40 = $ep + 12 | 0;
    var $41 = HEAP32[$40 >> 2];
    _libuxre_regdelnfa($41);
    var $_pre_phi = $33;
    __label__ = 12;
    break;
   case 12:
    var $_pre_phi;
    var $43 = HEAP32[$_pre_phi >> 2];
    _libuxre_regdeltree($1, $43);
    var $45 = $_pre_phi;
    __label__ = 13;
    break;
   case 13:
    var $45;
    var $46 = HEAP32[$45 >> 2];
    STACKTOP = __stackBase__;
    return $46;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_regcomp["X"] = 1;
function _libuxre_regparse($lxp, $pat) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $lxp + 8 | 0;
    HEAP32[$1 >> 2] = 0;
    var $2 = $lxp + 12 | 0;
    HEAP32[$2 >> 2] = 0;
    var $3 = $lxp + 44 | 0;
    HEAP32[$3 >> 2] = 0;
    var $4 = $lxp + 24 | 0;
    HEAP32[$4 >> 2] = 0;
    var $5 = $lxp + 28 | 0;
    HEAP32[$5 >> 2] = 0;
    var $6 = $lxp + 32 | 0;
    HEAP32[$6 >> 2] = 0;
    var $7 = $lxp + 36 | 0;
    HEAP32[$7 >> 2] = 0;
    var $8 = $lxp + 48 | 0;
    HEAP32[$8 >> 2] = 1;
    var $9 = HEAP8[$pat];
    var $10 = $9 << 24 >> 24 == 124;
    var $11 = $pat + 1 | 0;
    var $_0 = $10 ? $11 : $pat;
    var $12 = $lxp + 4 | 0;
    HEAP32[$12 >> 2] = $_0;
    var $13 = $lxp + 16 | 0;
    HEAP32[$13 >> 2] = 264536823;
    var $14 = $lxp + 20 | 0;
    HEAP32[$14 >> 2] = -33;
    var $15 = _lex($lxp);
    var $16 = ($15 | 0) == 0;
    if ($16) {
      __label__ = 7;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 3:
    var $18 = ($lp_2 | 0) == 0;
    if ($18) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    _libuxre_regdeltree($lp_2, 1);
    __label__ = 5;
    break;
   case 5:
    var $_pr = HEAP32[$3 >> 2];
    var $20 = ($_pr | 0) == 0;
    if ($20) {
      __label__ = 6;
      break;
    } else {
      var $lp_3 = 0;
      __label__ = 16;
      break;
    }
   case 6:
    HEAP32[$3 >> 2] = 17;
    var $lp_3 = 0;
    __label__ = 16;
    break;
   case 7:
    var $23 = HEAP32[$14 >> 2];
    var $24 = ($23 | 0) == -14;
    if ($24) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    HEAP32[$3 >> 2] = 12;
    var $lp_3 = 0;
    __label__ = 16;
    break;
   case 9:
    var $26 = _alt($lxp);
    var $27 = ($26 | 0) == 0;
    if ($27) {
      __label__ = 5;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $29 = HEAP32[$4 >> 2];
    var $30 = ($29 | 0) == 0;
    if ($30) {
      var $lp_2 = $26;
      __label__ = 13;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $32 = _libuxre_reg1tree(-21, $26);
    var $33 = ($32 | 0) == 0;
    if ($33) {
      __label__ = 5;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $35 = $32 + 4 | 0;
    HEAP32[$35 >> 2] = 0;
    var $lp_2 = $32;
    __label__ = 13;
    break;
   case 13:
    var $lp_2;
    var $37 = _libuxre_reg1tree(-14, 0);
    var $38 = ($37 | 0) == 0;
    if ($38) {
      __label__ = 3;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $40 = _libuxre_reg2tree(-34, $lp_2, $37);
    var $41 = ($40 | 0) == 0;
    if ($41) {
      __label__ = 5;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $43 = $40 + 8 | 0;
    HEAP32[$43 >> 2] = 0;
    var $lp_3 = $40;
    __label__ = 16;
    break;
   case 16:
    var $lp_3;
    var $45 = HEAP32[$1 >> 2];
    var $46 = ($45 | 0) == 0;
    if ($46) {
      __label__ = 18;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    _free($45);
    __label__ = 18;
    break;
   case 18:
    return $lp_3;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_regparse["X"] = 1;
function _libuxre_regnfacomp($ep, $tp, $lxp) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $gp = __stackBase__;
    var $end = __stackBase__ + 4;
    var $1 = _malloc(52);
    var $2 = $1;
    var $cond = ($1 | 0) == 0;
    if ($cond) {
      var $_0 = 17;
      __label__ = 15;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $4 = $1;
    HEAP32[$4 >> 2] = 0;
    var $5 = _mkgraph($tp, $4, $gp);
    var $6 = ($5 | 0) < 0;
    if ($6) {
      __label__ = 12;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $8 = HEAP32[$gp >> 2];
    var $9 = $8 + 4 | 0;
    HEAP32[$9 >> 2] = 0;
    var $10 = $1 + 36 | 0;
    var $11 = $10;
    HEAP32[$11 >> 2] = 0;
    var $12 = $ep + 4 | 0;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $13 & 512;
    var $15 = ($14 | 0) == 0;
    if ($15) {
      __label__ = 5;
      break;
    } else {
      var $21 = 0;
      __label__ = 6;
      break;
    }
   case 5:
    var $17 = $ep | 0;
    var $18 = HEAP32[$17 >> 2];
    var $19 = $18 + 1 | 0;
    HEAP32[$11 >> 2] = $19;
    var $21 = $19;
    __label__ = 6;
    break;
   case 6:
    var $21;
    var $22 = $1 + 40 | 0;
    var $23 = $22;
    HEAP32[$23 >> 2] = 0;
    var $24 = $lxp + 24 | 0;
    var $25 = HEAP32[$24 >> 2];
    var $26 = ($25 | 0) == 0;
    if ($26) {
      __label__ = 9;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $28 = $25 + 1 | 0;
    HEAP32[$23 >> 2] = $28;
    var $29 = $28 >>> 0 > $21 >>> 0;
    if ($29) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    HEAP32[$11 >> 2] = $28;
    __label__ = 9;
    break;
   case 9:
    HEAP32[$gp >> 2] = $end;
    var $32 = HEAP32[$4 >> 2];
    var $33 = _nopskip($32, $gp);
    HEAP32[$4 >> 2] = $33;
    var $34 = HEAP32[$gp >> 2];
    var $35 = ($34 | 0) == ($end | 0);
    if ($35) {
      __label__ = 11;
      break;
    } else {
      var $36 = $34;
      __label__ = 10;
      break;
    }
   case 10:
    var $36;
    var $37 = $36 | 0;
    var $38 = HEAP32[$37 >> 2];
    HEAP32[$gp >> 2] = $38;
    var $39 = $36;
    _free($39);
    var $40 = HEAP32[$gp >> 2];
    var $41 = ($40 | 0) == ($end | 0);
    if ($41) {
      __label__ = 11;
      break;
    } else {
      var $36 = $40;
      __label__ = 10;
      break;
    }
   case 11:
    var $42 = $1 + 4 | 0;
    var $43 = $42;
    HEAP32[$43 >> 2] = 0;
    var $44 = $1 + 8 | 0;
    var $45 = $44;
    HEAP32[$45 >> 2] = 0;
    var $46 = $1 + 24 | 0;
    var $47 = $46;
    HEAP32[$47 >> 2] = 0;
    var $48 = $1 + 12 | 0;
    var $49 = $48;
    HEAP32[$49 >> 2] = 0;
    var $50 = $ep + 12 | 0;
    HEAP32[$50 >> 2] = $2;
    var $51 = _firstop($tp);
    var $52 = $1 + 48 | 0;
    var $53 = $52;
    HEAP32[$53 >> 2] = $51;
    var $_0 = 0;
    __label__ = 15;
    break;
   case 12:
    var $55 = HEAP32[$4 >> 2];
    var $56 = ($55 | 0) == 0;
    if ($56) {
      __label__ = 14;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 13:
    _delgraph($55);
    __label__ = 14;
    break;
   case 14:
    _free($1);
    var $_0 = 17;
    __label__ = 15;
    break;
   case 15:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_regnfacomp["X"] = 1;
function _libuxre_regdfacomp($ep, $tp, $lxp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _libuxre_reg1tree(-4, 0);
    var $2 = ($1 | 0) == 0;
    if ($2) {
      var $_0 = 17;
      __label__ = 19;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $4 = _libuxre_reg1tree(-17, $1);
    var $5 = ($4 | 0) == 0;
    if ($5) {
      var $_0 = 17;
      __label__ = 19;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $7 = $tp | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = _libuxre_reg2tree(-34, $4, $8);
    HEAP32[$7 >> 2] = $9;
    var $10 = ($9 | 0) == 0;
    if ($10) {
      var $_0 = 17;
      __label__ = 19;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $12 = $9 + 8 | 0;
    HEAP32[$12 >> 2] = $tp;
    var $13 = _calloc();
    var $14 = $13;
    var $15 = ($13 | 0) == 0;
    if ($15) {
      var $_0 = 17;
      __label__ = 19;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $17 = $ep + 8 | 0;
    HEAP32[$17 >> 2] = $14;
    var $18 = $13 + 4 | 0;
    var $19 = $18;
    HEAP32[$19 >> 2] = 0;
    var $20 = $13 + 8 | 0;
    var $21 = $20;
    HEAP32[$21 >> 2] = 0;
    var $22 = $13 + 12 | 0;
    var $23 = $22;
    HEAP32[$23 >> 2] = 0;
    var $24 = $13 + 16 | 0;
    var $25 = $24;
    HEAP32[$25 >> 2] = 0;
    var $26 = $lxp + 48 | 0;
    var $27 = HEAP32[$26 >> 2];
    var $28 = _findposn($ep, $tp, $27);
    var $29 = ($28 | 0) == 0;
    if ($29) {
      __label__ = 18;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $31 = $13 + 20 | 0;
    var $32 = $31;
    var $33 = HEAP32[$32 >> 2];
    var $34 = $33 * 17 | 0;
    var $35 = _malloc($34);
    var $36 = $35;
    HEAP32[$25 >> 2] = $36;
    var $37 = ($35 | 0) == 0;
    if ($37) {
      __label__ = 18;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $39 = HEAP32[$32 >> 2];
    var $40 = $36 + ($39 << 4) | 0;
    var $41 = $40;
    var $42 = $13;
    HEAP32[$42 >> 2] = $41;
    var $43 = _posnfoll($14, $28);
    var $44 = ($43 | 0) == 0;
    if ($44) {
      __label__ = 9;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 9:
    var $46 = $13 + 24 | 0;
    var $47 = $46;
    var $48 = HEAP32[$47 >> 2];
    var $49 = $13 + 28 | 0;
    var $50 = $49;
    var $51 = HEAP32[$50 >> 2];
    var $52 = $51 + $48 | 0;
    HEAP32[$50 >> 2] = $52;
    HEAP32[$47 >> 2] = 0;
    var $53 = $52 << 2;
    var $54 = _malloc($53);
    var $55 = $54;
    HEAP32[$21 >> 2] = $55;
    var $56 = ($54 | 0) == 0;
    if ($56) {
      __label__ = 18;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $58 = HEAP32[$32 >> 2];
    var $59 = $58 - 1 | 0;
    var $60 = HEAP32[$25 >> 2];
    var $61 = $60 + ($59 << 4) + 8 | 0;
    var $62 = HEAP32[$61 >> 2];
    var $63 = HEAP32[$19 >> 2];
    var $64 = $63 + ($62 << 2) | 0;
    HEAP32[$23 >> 2] = $64;
    var $65 = $60 + ($59 << 4) + 4 | 0;
    var $66 = HEAP32[$65 >> 2];
    var $67 = $13 + 32 | 0;
    var $68 = $67;
    HEAP32[$68 >> 2] = $66;
    var $69 = $13 + 328 | 0;
    HEAP8[$69] = 1;
    var $70 = _addstate($14);
    var $71 = HEAP32[$32 >> 2];
    var $72 = $71 << 2;
    var $73 = _malloc($72);
    var $74 = $73;
    HEAP32[$23 >> 2] = $74;
    var $75 = ($73 | 0) == 0;
    if ($75) {
      __label__ = 18;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $77 = $13 + 327 | 0;
    HEAP8[$77] = 2;
    var $78 = HEAP32[$26 >> 2];
    var $79 = _regtrans($14, 1, -2, $78);
    var $80 = ($79 | 0) == 0;
    if ($80) {
      __label__ = 18;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $82 = $79 + 255 | 0;
    var $83 = $82 & 255;
    var $84 = $13 + 326 | 0;
    HEAP8[$84] = $83;
    var $85 = $82 & 255;
    var $86 = ($85 | 0) == 2;
    if ($86) {
      __label__ = 13;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 13:
    HEAP8[$77] = 3;
    __label__ = 14;
    break;
   case 14:
    var $89 = $ep + 4 | 0;
    var $90 = HEAP32[$89 >> 2];
    var $91 = $90 & 512;
    var $92 = ($91 | 0) == 0;
    if ($92) {
      __label__ = 15;
      break;
    } else {
      var $_0 = 0;
      __label__ = 19;
      break;
    }
   case 15:
    var $94 = HEAP8[$77];
    var $95 = $94 & 255;
    var $96 = $13 + 164 | 0;
    var $97 = $96;
    var $98 = $97 + ($95 << 2) | 0;
    HEAP32[$98 >> 2] = 0;
    var $99 = $13 + 36 | 0;
    var $100 = $99;
    var $101 = $13 + 40 | 0;
    var $102 = $101;
    var $103 = HEAP32[$102 >> 2];
    var $104 = $103 - 1 | 0;
    var $105 = HEAP8[$77];
    var $106 = $105 & 255;
    var $107 = $100 + ($106 << 2) | 0;
    HEAP32[$107 >> 2] = $104;
    var $108 = $13 + 293 | 0;
    var $109 = HEAP8[$108];
    var $110 = HEAP8[$77];
    var $111 = $110 & 255;
    var $_sum = $111 + 292 | 0;
    var $112 = $13 + $_sum | 0;
    HEAP8[$112] = $109;
    var $113 = HEAP8[$77];
    var $114 = $13 + 324 | 0;
    HEAP8[$114] = $113;
    var $115 = $13 + 325 | 0;
    HEAP8[$115] = $113;
    var $116 = $113 + 1 & 255;
    HEAP8[$77] = $116;
    var $117 = HEAP8[$84];
    var $118 = $117 << 24 >> 24 == 1;
    if ($118) {
      var $140 = $116;
      __label__ = 17;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $120 = $13 + 172 | 0;
    var $121 = $120;
    var $122 = HEAP32[$121 >> 2];
    var $123 = $116 & 255;
    var $124 = $97 + ($123 << 2) | 0;
    HEAP32[$124 >> 2] = $122;
    var $125 = $13 + 44 | 0;
    var $126 = $125;
    var $127 = HEAP32[$126 >> 2];
    var $128 = $127 - 1 | 0;
    var $129 = HEAP8[$77];
    var $130 = $129 & 255;
    var $131 = $100 + ($130 << 2) | 0;
    HEAP32[$131 >> 2] = $128;
    var $132 = $13 + 294 | 0;
    var $133 = HEAP8[$132];
    var $134 = HEAP8[$77];
    var $135 = $134 & 255;
    var $_sum1 = $135 + 292 | 0;
    var $136 = $13 + $_sum1 | 0;
    HEAP8[$136] = $133;
    var $137 = HEAP8[$77];
    HEAP8[$115] = $137;
    var $138 = $137 + 1 & 255;
    HEAP8[$77] = $138;
    var $140 = $138;
    __label__ = 17;
    break;
   case 17:
    var $140;
    HEAP8[$69] = $140;
    var $_0 = 0;
    __label__ = 19;
    break;
   case 18:
    _libuxre_regdeldfa($14);
    var $_0 = 17;
    __label__ = 19;
    break;
   case 19:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_regdfacomp["X"] = 1;
function _libuxre_regdeltree($tp, $all) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($tp | 0) == 0;
    if ($1) {
      __label__ = 10;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = $tp + 12 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = ($4 | 0) < 0;
    if ($5) {
      __label__ = 4;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 4:
    var $7 = -$4 | 0;
    var $8 = $7 >> 4;
    if (($8 | 0) == 2) {
      __label__ = 5;
      break;
    } else if (($8 | 0) == 1) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 5:
    var $10 = $tp + 4 | 0;
    var $11 = HEAP32[$10 >> 2];
    _libuxre_regdeltree($11, $all);
    __label__ = 6;
    break;
   case 6:
    var $13 = $tp | 0;
    var $14 = HEAP32[$13 >> 2];
    _libuxre_regdeltree($14, $all);
    __label__ = 9;
    break;
   case 7:
    var $16 = ($4 | 0) != -9;
    var $17 = ($all | 0) == 0;
    var $or_cond = $16 | $17;
    if ($or_cond) {
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $19 = $tp + 4 | 0;
    var $20 = $19;
    var $21 = HEAP32[$20 >> 2];
    _libuxre_bktfree($21);
    var $22 = HEAP32[$20 >> 2];
    var $23 = $22;
    _free($23);
    __label__ = 9;
    break;
   case 9:
    var $25 = $tp;
    _free($25);
    __label__ = 10;
    break;
   case 10:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _regexec($ep, $s) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 20;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $ex = __stackBase__;
    var $1 = $ep + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $2 & 268436736;
    var $4 = $ex + 12 | 0;
    HEAP32[$4 >> 2] = $3;
    var $5 = $ex | 0;
    HEAP32[$5 >> 2] = $s;
    var $6 = $ex + 4 | 0;
    HEAP32[$6 >> 2] = 0;
    var $7 = $ep + 20 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = $ex + 16 | 0;
    HEAP32[$9 >> 2] = $8;
    var $10 = $ex + 8 | 0;
    HEAP32[$10 >> 2] = 0;
    var $11 = $2 & 1073741824;
    var $12 = ($11 | 0) == 0;
    if ($12) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $14 = $ep + 8 | 0;
    var $15 = HEAP32[$14 >> 2];
    var $16 = _libuxre_regdfaexec($15, $ex);
    var $ret_0 = $16;
    __label__ = 5;
    break;
   case 4:
    var $18 = $ep + 12 | 0;
    var $19 = HEAP32[$18 >> 2];
    var $20 = _libuxre_regnfaexec($19, $ex);
    var $ret_0 = $20;
    __label__ = 5;
    break;
   case 5:
    var $ret_0;
    var $22 = ($ret_0 | 0) == 0;
    if ($22) {
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    HEAP32[$10 >> 2] = 0;
    __label__ = 7;
    break;
   case 7:
    STACKTOP = __stackBase__;
    return $ret_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _libuxre_regdfaexec($dp, $xp) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 4;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $wc = __stackBase__;
    var $1 = $xp + 12 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $_tr = $2 & 255;
    var $3 = $_tr & 2;
    var $4 = $dp + 329 | 0;
    HEAP8[$4] = $3;
    var $5 = $xp + 16 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $xp + 8 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = ($8 | 0) == 0;
    if ($9) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $11 = _leftmost($dp, $xp);
    var $_0 = $11;
    __label__ = 23;
    break;
   case 4:
    var $13 = ($6 | 0) == 1;
    var $14 = HEAP32[$1 >> 2];
    if ($13) {
      __label__ = 5;
      break;
    } else {
      var $20 = $14;
      __label__ = 7;
      break;
    }
   case 5:
    var $16 = $14 & 1024;
    var $17 = ($16 | 0) == 0;
    if ($17) {
      __label__ = 6;
      break;
    } else {
      var $20 = $14;
      __label__ = 7;
      break;
    }
   case 6:
    var $xp_idx = $xp | 0;
    var $xp_idx_val = HEAP32[$xp_idx >> 2];
    var $19 = _regdfaexec_opt($dp, $xp_idx_val, $14);
    var $_0 = $19;
    __label__ = 23;
    break;
   case 7:
    var $20;
    var $21 = $xp | 0;
    var $22 = HEAP32[$21 >> 2];
    var $23 = $dp + 326 | 0;
    var $24 = HEAP8[$23];
    var $25 = $24 & 255;
    var $26 = $20 & 1;
    var $27 = ($26 | 0) == 0;
    var $st_0 = $27 ? $25 : 1;
    var $28 = $st_0 + ($dp + 292) | 0;
    var $29 = HEAP8[$28];
    var $30 = $29 << 24 >> 24 == 0;
    if ($30) {
      var $st_1 = $st_0;
      var $s_0 = $22;
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $32 = $20 & 4;
    var $33 = ($32 | 0) == 0;
    if ($33) {
      var $_0 = 0;
      __label__ = 23;
      break;
    } else {
      var $st_1 = $st_0;
      var $s_0 = $22;
      __label__ = 9;
      break;
    }
   case 9:
    var $s_0;
    var $st_1;
    var $34 = $s_0 + 1 | 0;
    var $35 = HEAP8[$s_0];
    var $36 = $35 & 255;
    HEAP32[$wc >> 2] = $36;
    var $37 = $35 << 24 >> 24 == 10;
    if ($37) {
      __label__ = 10;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 10:
    var $39 = HEAP32[$1 >> 2];
    var $40 = $39 & 1024;
    var $41 = ($40 | 0) == 0;
    if ($41) {
      var $s_1_ph = $34;
      __label__ = 15;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    HEAP32[$wc >> 2] = -3;
    var $s_11 = $34;
    var $57 = -3;
    __label__ = 17;
    break;
   case 12:
    var $43 = $36 & 128;
    var $44 = ($43 | 0) == 0;
    var $brmerge = $44 | $13;
    if ($brmerge) {
      var $s_1_ph = $34;
      __label__ = 15;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 13:
    var $46 = _libuxre_mb2wc($wc, $34);
    var $47 = ($46 | 0) > 0;
    if ($47) {
      __label__ = 14;
      break;
    } else {
      var $s_1_ph = $34;
      __label__ = 15;
      break;
    }
   case 14:
    var $_sum = $46 + 1 | 0;
    var $49 = $s_0 + $_sum | 0;
    var $s_1_ph = $49;
    __label__ = 15;
    break;
   case 15:
    var $s_1_ph;
    var $_pr = HEAP32[$wc >> 2];
    var $50 = $_pr >>> 0 > 255;
    if ($50) {
      var $s_11 = $s_1_ph;
      var $57 = $_pr;
      __label__ = 17;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $52 = $dp + 330 + ($st_1 << 8) + $_pr | 0;
    var $53 = HEAP8[$52];
    var $54 = $53 & 255;
    var $55 = $53 << 24 >> 24 == 0;
    if ($55) {
      var $s_11 = $s_1_ph;
      var $57 = $_pr;
      __label__ = 17;
      break;
    } else {
      var $nst_0 = $54;
      var $s_12 = $s_1_ph;
      var $74 = $_pr;
      __label__ = 21;
      break;
    }
   case 17:
    var $57;
    var $s_11;
    var $58 = _regtrans($dp, $st_1, $57, $6);
    var $59 = ($58 | 0) == 0;
    if ($59) {
      var $_0 = 17;
      __label__ = 23;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $61 = ($57 | 0) == -3;
    if ($61) {
      __label__ = 19;
      break;
    } else {
      var $nst_0 = $58;
      var $s_12 = $s_11;
      var $74 = $57;
      __label__ = 21;
      break;
    }
   case 19:
    var $63 = $58 - 1 | 0;
    var $64 = $63 + ($dp + 292) | 0;
    var $65 = HEAP8[$64];
    var $66 = $65 << 24 >> 24 == 0;
    if ($66) {
      __label__ = 20;
      break;
    } else {
      var $_0 = 0;
      __label__ = 23;
      break;
    }
   case 20:
    var $68 = HEAP8[$23];
    var $69 = $68 & 255;
    var $70 = $69 + ($dp + 292) | 0;
    var $71 = HEAP8[$70];
    var $72 = $71 << 24 >> 24 == 0;
    if ($72) {
      var $st_1 = $69;
      var $s_0 = $s_11;
      __label__ = 9;
      break;
    } else {
      var $_0 = 0;
      __label__ = 23;
      break;
    }
   case 21:
    var $74;
    var $s_12;
    var $nst_0;
    var $75 = $nst_0 - 1 | 0;
    var $76 = $75 + ($dp + 292) | 0;
    var $77 = HEAP8[$76];
    var $78 = $77 << 24 >> 24 == 0;
    if ($78) {
      __label__ = 22;
      break;
    } else {
      var $_0 = 0;
      __label__ = 23;
      break;
    }
   case 22:
    var $80 = ($74 | 0) == 0;
    if ($80) {
      var $_0 = 1;
      __label__ = 23;
      break;
    } else {
      var $st_1 = $75;
      var $s_0 = $s_12;
      __label__ = 9;
      break;
    }
   case 23:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_regdfaexec["X"] = 1;
function _libuxre_mb2wc($wt, $s) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 4;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $wc = __stackBase__;
    var $1 = $s - 1 | 0;
    var $2 = _mbtowc($wc, $1, 1);
    var $3 = ($2 | 0) > 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $5 = HEAP32[$wc >> 2];
    HEAP32[$wt >> 2] = $5;
    __label__ = 7;
    break;
   case 4:
    var $7 = ($2 | 0) == 0;
    if ($7) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    HEAP32[$wt >> 2] = 0;
    __label__ = 7;
    break;
   case 6:
    HEAP32[$wt >> 2] = -1;
    __label__ = 7;
    break;
   case 7:
    var $11 = $3 << 31 >> 31;
    var $12 = $11 + $2 | 0;
    STACKTOP = __stackBase__;
    return $12;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _libuxre_regnfaexec($np, $xp) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $wc = __stackBase__;
    var $pwc = __stackBase__ + 4;
    var $1 = $np + 16 | 0;
    HEAP32[$1 >> 2] = 0;
    var $2 = $np + 20 | 0;
    HEAP32[$2 >> 2] = 0;
    var $3 = $np + 28 | 0;
    HEAP32[$3 >> 2] = $1;
    var $4 = $np + 32 | 0;
    HEAP32[$4 >> 2] = $2;
    var $5 = $xp + 8 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $np + 44 | 0;
    HEAP32[$7 >> 2] = $6;
    var $8 = $np + 40 | 0;
    var $9 = HEAP32[$8 >> 2];
    var $10 = $6 >>> 0 < $9 >>> 0;
    if ($10) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    HEAP32[$7 >> 2] = $9;
    __label__ = 4;
    break;
   case 4:
    var $13 = $xp | 0;
    var $14 = HEAP32[$13 >> 2];
    var $15 = $xp + 16 | 0;
    var $16 = HEAP32[$15 >> 2];
    var $17 = ($16 | 0) == 1;
    var $18 = $np + 48 | 0;
    var $19 = $xp + 12 | 0;
    var $20 = $np | 0;
    var $21 = $np + 4 | 0;
    var $22 = ($16 | 0) > 1;
    var $23 = $np + 24 | 0;
    var $24 = $xp + 4 | 0;
    var $s_0_ph = $14;
    var $s1_0_ph = 0;
    var $rmso_0_ph = -1;
    __label__ = 5;
    break;
   case 5:
    var $rmso_0_ph;
    var $s1_0_ph;
    var $s_0_ph;
    var $s_0 = $s_0_ph;
    var $s1_0 = $s1_0_ph;
    __label__ = 6;
    break;
   case 6:
    var $s1_0;
    var $s_0;
    var $26 = $s_0 + 1 | 0;
    var $27 = HEAP8[$s_0];
    var $28 = $27 & 255;
    HEAP32[$wc >> 2] = $28;
    var $29 = $28 & 128;
    var $30 = ($29 | 0) == 0;
    var $or_cond3 = $30 | $17;
    if ($or_cond3) {
      var $s_1 = $26;
      __label__ = 9;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $32 = _libuxre_mb2wc($wc, $26);
    var $33 = ($32 | 0) > 0;
    if ($33) {
      __label__ = 8;
      break;
    } else {
      var $s_1 = $26;
      __label__ = 9;
      break;
    }
   case 8:
    var $_sum = $32 + 1 | 0;
    var $35 = $s_0 + $_sum | 0;
    var $s_1 = $35;
    __label__ = 9;
    break;
   case 9:
    var $s_1;
    var $36 = HEAP32[$1 >> 2];
    var $37 = ($36 | 0) == 0;
    if ($37) {
      __label__ = 10;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 10:
    var $39 = HEAP32[$18 >> 2];
    var $40 = HEAP32[$wc >> 2];
    var $41 = ($39 | 0) == ($40 | 0);
    var $42 = ($39 | 0) == 0;
    var $or_cond5 = $41 | $42;
    if ($or_cond5) {
      __label__ = 18;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $44 = ($39 | 0) == -2;
    if ($44) {
      __label__ = 12;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 12:
    var $46 = ($s1_0 | 0) == 0;
    var $47 = HEAP32[$19 >> 2];
    if ($46) {
      __label__ = 13;
      break;
    } else {
      var $51 = $47;
      __label__ = 14;
      break;
    }
   case 13:
    var $49 = $47 & 1;
    var $50 = ($49 | 0) == 0;
    if ($50) {
      __label__ = 18;
      break;
    } else {
      var $51 = $47;
      __label__ = 14;
      break;
    }
   case 14:
    var $51;
    var $52 = $51 & 1024;
    var $53 = ($52 | 0) == 0;
    if ($53) {
      __label__ = 118;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    if ($46) {
      __label__ = 17;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $56 = HEAP8[$s1_0];
    var $57 = $56 << 24 >> 24 == 10;
    if ($57) {
      __label__ = 18;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    var $59 = ($40 | 0) == 0;
    if ($59) {
      __label__ = 118;
      break;
    } else {
      var $s1_0 = $s_0;
      var $s_0 = $s_1;
      __label__ = 6;
      break;
    }
   case 18:
    var $61 = ($rmso_0_ph | 0) < 0;
    if ($61) {
      __label__ = 19;
      break;
    } else {
      var $67 = $36;
      __label__ = 21;
      break;
    }
   case 19:
    var $63 = HEAP32[$20 >> 2];
    var $64 = _newctxt($np, 0, $63);
    var $65 = ($64 | 0) == 0;
    if ($65) {
      __label__ = 20;
      break;
    } else {
      var $ret_0 = 17;
      __label__ = 119;
      break;
    }
   case 20:
    var $_pre22 = HEAP32[$1 >> 2];
    var $67 = $_pre22;
    __label__ = 21;
    break;
   case 21:
    var $67;
    var $68 = $s_0;
    var $69 = ($s1_0 | 0) == 0;
    var $70 = $s_1;
    var $71 = $70 - $68 | 0;
    var $72 = $s1_0 + 1 | 0;
    var $cp_0_ph = $67;
    var $rmso_1_ph = $rmso_0_ph;
    __label__ = 22;
    break;
   case 22:
    var $rmso_1_ph;
    var $cp_0_ph;
    var $cp_0 = $cp_0_ph;
    __label__ = 23;
    break;
   case 23:
    var $cp_0;
    var $74 = $cp_0 + 12 | 0;
    var $75 = $cp_0 + 16 | 0;
    var $76 = $cp_0 + 20 | 0;
    var $77 = $cp_0 + 24 | 0;
    var $78 = $cp_0 + 8 | 0;
    var $79 = $cp_0 + 28 | 0;
    var $gp_0_in = $74;
    __label__ = 24;
    break;
   case 24:
    var $gp_0_in;
    var $gp_0 = HEAP32[$gp_0_in >> 2];
    var $80 = $gp_0 + 8 | 0;
    var $81 = HEAP32[$80 >> 2];
    if (($81 | 0) == -20) {
      __label__ = 25;
      break;
    } else if (($81 | 0) == -34) {
      var $gp_1 = $gp_0;
      var $brace_0 = 0;
      __label__ = 26;
      break;
    } else if (($81 | 0) == -7) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else if (($81 | 0) == -33) {
      __label__ = 39;
      break;
    } else if (($81 | 0) == -21) {
      __label__ = 40;
      break;
    } else if (($81 | 0) == -22) {
      __label__ = 45;
      break;
    } else if (($81 | 0) == -2) {
      __label__ = 47;
      break;
    } else if (($81 | 0) == -3) {
      __label__ = 51;
      break;
    } else if (($81 | 0) == -6) {
      __label__ = 61;
      break;
    } else if (($81 | 0) == -5) {
      __label__ = 62;
      break;
    } else if (($81 | 0) == -8) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else if (($81 | 0) == -11) {
      __label__ = 64;
      break;
    } else if (($81 | 0) == -12) {
      __label__ = 76;
      break;
    } else if (($81 | 0) == -9 || ($81 | 0) == -10) {
      __label__ = 80;
      break;
    } else if (($81 | 0) == -13) {
      __label__ = 86;
      break;
    } else if (($81 | 0) == -14) {
      __label__ = 93;
      break;
    } else {
      __label__ = 54;
      break;
    }
   case 25:
    var $83 = $gp_0 + 4 | 0;
    var $84 = HEAP32[$83 >> 2];
    var $gp_1 = $84;
    var $brace_0 = $gp_0;
    __label__ = 26;
    break;
   case 26:
    var $brace_0;
    var $gp_1;
    var $85 = HEAP32[$75 >> 2];
    var $86 = ($85 | 0) == ($gp_1 | 0);
    if ($86) {
      __label__ = 28;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $88 = _mkstck($np, $cp_0, $gp_1);
    var $89 = ($88 | 0) == 0;
    if ($89) {
      __label__ = 29;
      break;
    } else {
      var $ret_0 = 17;
      __label__ = 119;
      break;
    }
   case 28:
    var $91 = HEAP32[$76 >> 2];
    var $92 = ($91 | 0) == ($s_1 | 0);
    if ($92) {
      var $gp_2 = $gp_1;
      __label__ = 36;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    HEAP32[$76 >> 2] = $s_1;
    var $94 = ($brace_0 | 0) == 0;
    if ($94) {
      __label__ = 35;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    var $96 = HEAP16[$77 >> 1];
    var $97 = $brace_0;
    var $98 = $97 + 2 | 0;
    var $99 = HEAP16[$98 >> 1];
    var $100 = ($96 & 65535) < ($99 & 65535);
    if ($100) {
      __label__ = 31;
      break;
    } else {
      var $gp_2 = $gp_1;
      __label__ = 36;
      break;
    }
   case 31:
    var $102 = $96 + 1 & 65535;
    HEAP16[$77 >> 1] = $102;
    var $103 = $brace_0;
    var $104 = HEAP16[$103 >> 1];
    var $105 = ($102 & 65535) > ($104 & 65535);
    if ($105) {
      __label__ = 33;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    var $107 = $gp_1 | 0;
    var $gp_0_in = $107;
    __label__ = 24;
    break;
   case 33:
    var $109 = ($102 & 65535) > 5100;
    if ($109) {
      __label__ = 34;
      break;
    } else {
      __label__ = 35;
      break;
    }
   case 34:
    HEAP16[$77 >> 1] = 5100;
    __label__ = 35;
    break;
   case 35:
    var $112 = $gp_1 | 0;
    var $113 = HEAP32[$112 >> 2];
    var $114 = _newctxt($np, $cp_0, $113);
    var $115 = ($114 | 0) == 0;
    if ($115) {
      var $gp_2 = $gp_1;
      __label__ = 36;
      break;
    } else {
      var $ret_0 = 17;
      __label__ = 119;
      break;
    }
   case 36:
    var $gp_2;
    HEAP32[$75 >> 2] = 0;
    var $116 = HEAP32[$78 >> 2];
    var $117 = ($116 | 0) == 0;
    if ($117) {
      var $gp_3 = $gp_2;
      __label__ = 38;
      break;
    } else {
      __label__ = 37;
      break;
    }
   case 37:
    var $119 = $116 + 4 | 0;
    var $120 = HEAP32[$119 >> 2];
    HEAP32[$78 >> 2] = $120;
    var $121 = $116 + 8 | 0;
    var $122 = HEAP32[$121 >> 2];
    HEAP32[$75 >> 2] = $122;
    var $123 = $116 + 12 | 0;
    var $124 = HEAP32[$123 >> 2];
    HEAP32[$76 >> 2] = $124;
    var $125 = $116 + 16 | 0;
    var $126 = HEAP16[$125 >> 1];
    HEAP16[$77 >> 1] = $126;
    var $127 = HEAP32[$21 >> 2];
    HEAP32[$119 >> 2] = $127;
    HEAP32[$21 >> 2] = $116;
    var $gp_3 = $gp_2;
    __label__ = 38;
    break;
   case 38:
    var $gp_3;
    var $129 = $gp_3 + 4 | 0;
    var $gp_0_in = $129;
    __label__ = 24;
    break;
   case 39:
    var $131 = $gp_0 | 0;
    var $132 = HEAP32[$131 >> 2];
    var $133 = _newctxt($np, $cp_0, $132);
    var $134 = ($133 | 0) == 0;
    if ($134) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else {
      var $ret_0 = 17;
      __label__ = 119;
      break;
    }
   case 40:
    var $136 = $gp_0;
    var $137 = HEAP32[$136 >> 2];
    var $138 = HEAP32[$7 >> 2];
    var $139 = $137 >>> 0 < $138 >>> 0;
    if ($139) {
      __label__ = 41;
      break;
    } else {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    }
   case 41:
    var $141 = HEAP32[$13 >> 2];
    var $142 = $141;
    var $143 = $68 - $142 | 0;
    var $144 = $cp_0 + 32 + ($137 << 3) | 0;
    HEAP32[$144 >> 2] = $143;
    var $145 = $cp_0 + 32 + ($137 << 3) + 4 | 0;
    HEAP32[$145 >> 2] = -1;
    var $146 = HEAP32[$79 >> 2];
    var $147 = $146 >>> 0 < $137 >>> 0;
    if ($147) {
      __label__ = 42;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 42:
    var $149 = $cp_0 + 32 + ($146 << 3) | 0;
    var $150 = $149 | 0;
    HEAP32[$150 >> 2] = -1;
    var $151 = $cp_0 + 32 + ($146 << 3) + 4 | 0;
    HEAP32[$151 >> 2] = -1;
    var $152 = $146 + 1 | 0;
    var $153 = $152 >>> 0 < $137 >>> 0;
    if ($153) {
      var $rmp_028 = $149;
      var $154 = $152;
      __label__ = 43;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 43:
    var $154;
    var $rmp_028;
    var $155 = $rmp_028 + 8 | 0;
    var $156 = $155 | 0;
    HEAP32[$156 >> 2] = -1;
    var $157 = $rmp_028 + 12 | 0;
    HEAP32[$157 >> 2] = -1;
    var $158 = $154 + 1 | 0;
    var $exitcond = ($158 | 0) == ($137 | 0);
    if ($exitcond) {
      __label__ = 44;
      break;
    } else {
      var $rmp_028 = $155;
      var $154 = $158;
      __label__ = 43;
      break;
    }
   case 44:
    var $159 = $137 + 1 | 0;
    HEAP32[$79 >> 2] = $159;
    var $gp_3 = $gp_0;
    __label__ = 38;
    break;
   case 45:
    var $161 = $gp_0;
    var $162 = HEAP32[$161 >> 2];
    var $163 = HEAP32[$7 >> 2];
    var $164 = $162 >>> 0 < $163 >>> 0;
    if ($164) {
      __label__ = 46;
      break;
    } else {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    }
   case 46:
    var $166 = HEAP32[$13 >> 2];
    var $167 = $166;
    var $168 = $68 - $167 | 0;
    var $169 = $cp_0 + 32 + ($162 << 3) + 4 | 0;
    HEAP32[$169 >> 2] = $168;
    var $gp_3 = $gp_0;
    __label__ = 38;
    break;
   case 47:
    var $171 = HEAP32[$19 >> 2];
    if ($69) {
      __label__ = 48;
      break;
    } else {
      __label__ = 49;
      break;
    }
   case 48:
    var $173 = $171 & 1;
    var $174 = ($173 | 0) == 0;
    if ($174) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 49:
    var $176 = $171 & 1024;
    var $177 = ($176 | 0) == 0;
    if ($177) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 50:
    var $179 = HEAP8[$s1_0];
    var $180 = $179 << 24 >> 24 == 10;
    if ($180) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 51:
    var $182 = HEAP32[$wc >> 2];
    var $183 = ($182 | 0) == 0;
    var $184 = HEAP32[$19 >> 2];
    if ($183) {
      __label__ = 52;
      break;
    } else {
      __label__ = 53;
      break;
    }
   case 52:
    var $186 = $184 & 2;
    var $187 = ($186 | 0) == 0;
    if ($187) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 53:
    var $189 = $184 & 1024;
    var $190 = ($189 | 0) != 0;
    var $191 = ($182 | 0) == 10;
    var $or_cond7 = $190 & $191;
    if ($or_cond7) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 54:
    var $193 = HEAP32[$wc >> 2];
    var $194 = ($81 | 0) == ($193 | 0);
    if ($194) {
      __label__ = 59;
      break;
    } else {
      __label__ = 55;
      break;
    }
   case 55:
    var $196 = HEAP32[$19 >> 2];
    var $197 = $196 & 256;
    var $198 = ($197 | 0) == 0;
    if ($198) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 56;
      break;
    }
   case 56:
    if ($22) {
      __label__ = 57;
      break;
    } else {
      __label__ = 58;
      break;
    }
   case 57:
    _towlower();
   case 58:
    var $202 = _tolower($193);
    var $203 = ($81 | 0) == ($202 | 0);
    if ($203) {
      __label__ = 59;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 59:
    var $205 = $gp_0 + 4 | 0;
    var $206 = HEAP32[$205 >> 2];
    HEAP32[$74 >> 2] = $206;
    __label__ = 60;
    break;
   case 60:
    var $207 = $cp_0 + 4 | 0;
    var $208 = HEAP32[$207 >> 2];
    HEAP32[$207 >> 2] = 0;
    var $209 = HEAP32[$4 >> 2];
    HEAP32[$209 >> 2] = $cp_0;
    HEAP32[$4 >> 2] = $207;
    var $210 = ($208 | 0) == 0;
    if ($210) {
      var $rmso_4 = $rmso_1_ph;
      __label__ = 112;
      break;
    } else {
      var $cp_0 = $208;
      __label__ = 23;
      break;
    }
   case 61:
    var $212 = HEAP32[$wc >> 2];
    var $213 = ($212 | 0) != 10;
    var $214 = ($212 | 0) > 0;
    var $or_cond = $213 & $214;
    if ($or_cond) {
      __label__ = 59;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 62:
    var $_old = HEAP32[$wc >> 2];
    var $_old1 = ($_old | 0) > 0;
    if ($_old1) {
      __label__ = 59;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 63:
    var $rmso_2;
    var $216 = $cp_0 + 4 | 0;
    var $217 = HEAP32[$216 >> 2];
    var $218 = HEAP32[$23 >> 2];
    HEAP32[$216 >> 2] = $218;
    HEAP32[$23 >> 2] = $cp_0;
    var $219 = ($217 | 0) == 0;
    if ($219) {
      var $rmso_4 = $rmso_2;
      __label__ = 112;
      break;
    } else {
      var $cp_0_ph = $217;
      var $rmso_1_ph = $rmso_2;
      __label__ = 22;
      break;
    }
   case 64:
    if ($69) {
      __label__ = 65;
      break;
    } else {
      __label__ = 66;
      break;
    }
   case 65:
    var $222 = HEAP32[$19 >> 2];
    var $223 = $222 & 1;
    var $224 = ($223 | 0) == 0;
    if ($224) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 66:
    var $226 = HEAP32[$wc >> 2];
    var $227 = ($226 | 0) == 95;
    if ($227) {
      __label__ = 70;
      break;
    } else {
      __label__ = 67;
      break;
    }
   case 67:
    if ($17) {
      __label__ = 68;
      break;
    } else {
      __label__ = 69;
      break;
    }
   case 68:
    _btowc();
   case 69:
    _iswalnum();
   case 70:
    var $232 = HEAP8[$s1_0];
    var $233 = $232 & 255;
    HEAP32[$pwc >> 2] = $233;
    var $234 = $233 & 128;
    var $235 = ($234 | 0) == 0;
    var $or_cond9 = $235 | $17;
    if ($or_cond9) {
      var $239 = $233;
      __label__ = 72;
      break;
    } else {
      __label__ = 71;
      break;
    }
   case 71:
    var $237 = _libuxre_mb2wc($pwc, $72);
    var $_pr = HEAP32[$pwc >> 2];
    var $239 = $_pr;
    __label__ = 72;
    break;
   case 72:
    var $239;
    var $240 = ($239 | 0) == 95;
    if ($240) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 73;
      break;
    }
   case 73:
    if ($17) {
      __label__ = 74;
      break;
    } else {
      __label__ = 75;
      break;
    }
   case 74:
    _btowc();
   case 75:
    _iswalnum();
   case 76:
    var $245 = HEAP32[$wc >> 2];
    var $246 = ($245 | 0) == 95;
    if ($246) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 77;
      break;
    }
   case 77:
    if ($17) {
      __label__ = 78;
      break;
    } else {
      __label__ = 79;
      break;
    }
   case 78:
    _btowc();
   case 79:
    _iswalnum();
   case 80:
    var $250 = HEAP32[$75 >> 2];
    var $251 = ($250 | 0) == ($gp_0 | 0);
    if ($251) {
      __label__ = 81;
      break;
    } else {
      __label__ = 82;
      break;
    }
   case 81:
    var $252 = HEAP32[$76 >> 2];
    var $253 = $s_0 >>> 0 < $252 >>> 0;
    if ($253) {
      __label__ = 60;
      break;
    } else {
      var $gp_2 = $gp_0;
      __label__ = 36;
      break;
    }
   case 82:
    var $255 = $gp_0;
    var $256 = HEAP32[$255 >> 2];
    var $257 = HEAP32[$wc >> 2];
    var $258 = _libuxre_bktmbexec($256, $257, $s_1, $16);
    var $259 = ($258 | 0) < 0;
    if ($259) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 83;
      break;
    }
   case 83:
    var $261 = ($258 | 0) == 0;
    if ($261) {
      __label__ = 59;
      break;
    } else {
      var $n_0 = $258;
      __label__ = 84;
      break;
    }
   case 84:
    var $n_0;
    var $263 = _mkstck($np, $cp_0, $gp_0);
    var $264 = ($263 | 0) == 0;
    if ($264) {
      __label__ = 85;
      break;
    } else {
      var $ret_0 = 17;
      __label__ = 119;
      break;
    }
   case 85:
    HEAP32[$74 >> 2] = $gp_0;
    var $266 = $s_1 + $n_0 | 0;
    HEAP32[$76 >> 2] = $266;
    __label__ = 60;
    break;
   case 86:
    var $268 = HEAP32[$75 >> 2];
    var $269 = ($268 | 0) == ($gp_0 | 0);
    if ($269) {
      __label__ = 81;
      break;
    } else {
      __label__ = 87;
      break;
    }
   case 87:
    var $271 = $gp_0;
    var $272 = HEAP32[$271 >> 2];
    var $273 = HEAP32[$79 >> 2];
    var $274 = $272 >>> 0 < $273 >>> 0;
    if ($274) {
      __label__ = 88;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 88:
    var $276 = $cp_0 + 32 + ($272 << 3) + 4 | 0;
    var $277 = HEAP32[$276 >> 2];
    var $278 = ($277 | 0) < 0;
    if ($278) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 89;
      break;
    }
   case 89:
    var $280 = $cp_0 + 32 + ($272 << 3) | 0;
    var $281 = HEAP32[$280 >> 2];
    var $282 = ($277 | 0) == ($281 | 0);
    if ($282) {
      var $gp_3 = $gp_0;
      __label__ = 38;
      break;
    } else {
      __label__ = 90;
      break;
    }
   case 90:
    var $284 = $277 - $281 | 0;
    var $285 = _casecmp($s_0, $xp, $281, $284, $16);
    var $286 = ($285 | 0) == 0;
    if ($286) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 91;
      break;
    }
   case 91:
    var $288 = $71 >>> 0 < $284 >>> 0;
    if ($288) {
      __label__ = 92;
      break;
    } else {
      __label__ = 59;
      break;
    }
   case 92:
    var $290 = $284 - $71 | 0;
    var $n_0 = $290;
    __label__ = 84;
    break;
   case 93:
    var $292 = HEAP32[$19 >> 2];
    var $293 = $292 & 4;
    var $294 = ($293 | 0) != 0;
    var $or_cond11 = $294 & $69;
    if ($or_cond11) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 94;
      break;
    }
   case 94:
    var $296 = HEAP32[$5 >> 2];
    var $297 = ($296 | 0) == 0;
    if ($297) {
      var $ret_0 = 0;
      __label__ = 119;
      break;
    } else {
      __label__ = 95;
      break;
    }
   case 95:
    var $299 = HEAP32[$79 >> 2];
    var $300 = $299 >>> 0 < $296 >>> 0;
    if ($300) {
      var $n_1 = $299;
      __label__ = 96;
      break;
    } else {
      var $306 = $296;
      __label__ = 97;
      break;
    }
   case 96:
    var $n_1;
    var $301 = $cp_0 + 32 + ($n_1 << 3) | 0;
    HEAP32[$301 >> 2] = -1;
    var $302 = $cp_0 + 32 + ($n_1 << 3) + 4 | 0;
    HEAP32[$302 >> 2] = -1;
    var $303 = $n_1 + 1 | 0;
    var $304 = HEAP32[$5 >> 2];
    var $305 = $303 >>> 0 < $304 >>> 0;
    if ($305) {
      var $n_1 = $303;
      __label__ = 96;
      break;
    } else {
      var $306 = $304;
      __label__ = 97;
      break;
    }
   case 97:
    var $306;
    var $307 = $cp_0 + 32 | 0;
    var $308 = $307 | 0;
    var $309 = HEAP32[$308 >> 2];
    var $310 = ($rmso_1_ph | 0) < 0;
    var $311 = $309 >>> 0 < $rmso_1_ph >>> 0;
    var $or_cond13 = $310 | $311;
    if ($or_cond13) {
      __label__ = 98;
      break;
    } else {
      __label__ = 100;
      break;
    }
   case 98:
    var $_pre23 = HEAP32[$24 >> 2];
    var $rmso_3 = $309;
    var $312 = $_pre23;
    __label__ = 99;
    break;
   case 99:
    var $312;
    var $rmso_3;
    var $313 = $312;
    var $314 = $307;
    var $315 = $306 << 3;
    _memcpy($313, $314, $315, 1);
    var $rmso_2 = $rmso_3;
    __label__ = 63;
    break;
   case 100:
    var $317 = $rmso_1_ph >>> 0 < $309 >>> 0;
    if ($317) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 101;
      break;
    }
   case 101:
    var $319 = HEAP32[$24 >> 2];
    var $320 = $319 + 4 | 0;
    var $321 = HEAP32[$320 >> 2];
    var $322 = $cp_0 + 36 | 0;
    var $323 = HEAP32[$322 >> 2];
    var $324 = ($321 | 0) > ($323 | 0);
    if ($324) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 102;
      break;
    }
   case 102:
    var $326 = ($321 | 0) < ($323 | 0);
    if ($326) {
      var $rmso_3 = $rmso_1_ph;
      var $312 = $319;
      __label__ = 99;
      break;
    } else {
      var $n_2 = 1;
      __label__ = 103;
      break;
    }
   case 103:
    var $n_2;
    var $327 = $n_2 >>> 0 < $306 >>> 0;
    if ($327) {
      __label__ = 104;
      break;
    } else {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    }
   case 104:
    var $329 = HEAP32[$19 >> 2];
    var $330 = $329 & 268435456;
    var $331 = ($330 | 0) == 0;
    if ($331) {
      __label__ = 105;
      break;
    } else {
      __label__ = 106;
      break;
    }
   case 105:
    var $_phi_trans_insert = $319 + ($n_2 << 3) | 0;
    var $_pre24 = HEAP32[$_phi_trans_insert >> 2];
    var $_phi_trans_insert25 = $cp_0 + 32 + ($n_2 << 3) | 0;
    var $_pre26 = HEAP32[$_phi_trans_insert25 >> 2];
    var $use_0 = 0;
    var $346 = $_pre24;
    var $345 = $_pre26;
    __label__ = 107;
    break;
   case 106:
    var $333 = $cp_0 + 32 + ($n_2 << 3) + 4 | 0;
    var $334 = HEAP32[$333 >> 2];
    var $335 = $cp_0 + 32 + ($n_2 << 3) | 0;
    var $336 = HEAP32[$335 >> 2];
    var $337 = $334 - $336 | 0;
    var $338 = $319 + ($n_2 << 3) + 4 | 0;
    var $339 = HEAP32[$338 >> 2];
    var $340 = $319 + ($n_2 << 3) | 0;
    var $341 = HEAP32[$340 >> 2];
    var $342 = $339 - $341 | 0;
    var $not_ = ($337 | 0) >= ($342 | 0);
    var $_lobit = $341 >>> 31;
    var $not_18 = $not_ & 1;
    var $343 = $not_18 | $_lobit;
    var $phitmp = ($343 | 0) == 0;
    var $use_0 = $phitmp;
    var $346 = $341;
    var $345 = $336;
    __label__ = 107;
    break;
   case 107:
    var $345;
    var $346;
    var $use_0;
    var $347 = ($346 | 0) >= ($345 | 0);
    var $or_cond15 = $347 | $use_0;
    if ($or_cond15) {
      __label__ = 108;
      break;
    } else {
      var $rmso_3 = $rmso_1_ph;
      var $312 = $319;
      __label__ = 99;
      break;
    }
   case 108:
    var $349 = ($346 | 0) > ($345 | 0);
    if ($349) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 109;
      break;
    }
   case 109:
    var $351 = $319 + ($n_2 << 3) + 4 | 0;
    var $352 = HEAP32[$351 >> 2];
    var $353 = $cp_0 + 32 + ($n_2 << 3) + 4 | 0;
    var $354 = HEAP32[$353 >> 2];
    var $355 = ($352 | 0) >= ($354 | 0);
    var $or_cond17 = $355 | $use_0;
    if ($or_cond17) {
      __label__ = 110;
      break;
    } else {
      var $rmso_3 = $rmso_1_ph;
      var $312 = $319;
      __label__ = 99;
      break;
    }
   case 110:
    var $357 = ($352 | 0) > ($354 | 0);
    if ($357) {
      var $rmso_2 = $rmso_1_ph;
      __label__ = 63;
      break;
    } else {
      __label__ = 111;
      break;
    }
   case 111:
    var $359 = $n_2 + 1 | 0;
    var $n_2 = $359;
    __label__ = 103;
    break;
   case 112:
    var $rmso_4;
    var $360 = HEAP32[$wc >> 2];
    var $361 = ($360 | 0) == 0;
    if ($361) {
      __label__ = 113;
      break;
    } else {
      __label__ = 114;
      break;
    }
   case 113:
    var $363 = ($rmso_4 | 0) > -1;
    if ($363) {
      var $ret_0 = 0;
      __label__ = 119;
      break;
    } else {
      __label__ = 118;
      break;
    }
   case 114:
    var $365 = HEAP32[$4 >> 2];
    HEAP32[$3 >> 2] = $365;
    var $366 = HEAP32[$2 >> 2];
    HEAP32[$1 >> 2] = $366;
    var $367 = ($366 | 0) == 0;
    if ($367) {
      __label__ = 115;
      break;
    } else {
      __label__ = 117;
      break;
    }
   case 115:
    var $369 = ($rmso_4 | 0) > -1;
    if ($369) {
      var $ret_0 = 0;
      __label__ = 119;
      break;
    } else {
      __label__ = 116;
      break;
    }
   case 116:
    HEAP32[$3 >> 2] = $1;
    __label__ = 117;
    break;
   case 117:
    HEAP32[$2 >> 2] = 0;
    HEAP32[$4 >> 2] = $2;
    var $s_0_ph = $s_1;
    var $s1_0_ph = $s_0;
    var $rmso_0_ph = $rmso_4;
    __label__ = 5;
    break;
   case 118:
    var $ret_0 = 1;
    __label__ = 119;
    break;
   case 119:
    var $ret_0;
    HEAP32[$23 >> 2] = 0;
    var $372 = $np + 12 | 0;
    var $373 = HEAP32[$372 >> 2];
    var $374 = ($373 | 0) == 0;
    if ($374) {
      __label__ = 121;
      break;
    } else {
      var $cp_120 = $373;
      var $375 = 0;
      __label__ = 120;
      break;
    }
   case 120:
    var $375;
    var $cp_120;
    var $376 = $cp_120 | 0;
    var $377 = HEAP32[$376 >> 2];
    var $378 = $cp_120 + 4 | 0;
    HEAP32[$378 >> 2] = $375;
    HEAP32[$23 >> 2] = $cp_120;
    var $379 = ($377 | 0) == 0;
    if ($379) {
      __label__ = 121;
      break;
    } else {
      var $375 = $cp_120;
      var $cp_120 = $377;
      __label__ = 120;
      break;
    }
   case 121:
    HEAP32[$21 >> 2] = 0;
    var $380 = $np + 8 | 0;
    var $381 = HEAP32[$380 >> 2];
    var $382 = ($381 | 0) == 0;
    if ($382) {
      __label__ = 123;
      break;
    } else {
      var $sp_019 = $381;
      var $383 = 0;
      __label__ = 122;
      break;
    }
   case 122:
    var $383;
    var $sp_019;
    var $384 = $sp_019 | 0;
    var $385 = HEAP32[$384 >> 2];
    var $386 = $sp_019 + 4 | 0;
    HEAP32[$386 >> 2] = $383;
    HEAP32[$21 >> 2] = $sp_019;
    var $387 = ($385 | 0) == 0;
    if ($387) {
      __label__ = 123;
      break;
    } else {
      var $383 = $sp_019;
      var $sp_019 = $385;
      __label__ = 122;
      break;
    }
   case 123:
    STACKTOP = __stackBase__;
    return $ret_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_regnfaexec["X"] = 1;
function _newctxt($np, $cp, $gp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $np + 24 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      var $new_0 = $2;
      __label__ = 6;
      break;
    }
   case 3:
    var $5 = $np + 36 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $6 << 3;
    var $8 = $7 + 32 | 0;
    var $9 = $np + 12 | 0;
    var $10 = _malloc($8);
    var $11 = $10;
    var $12 = ($10 | 0) == 0;
    if ($12) {
      var $cpp_1 = $1;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $14 = HEAP32[$9 >> 2];
    var $15 = $10;
    HEAP32[$15 >> 2] = $14;
    HEAP32[$9 >> 2] = $11;
    HEAP32[$1 >> 2] = $11;
    var $16 = $10 + 4 | 0;
    var $17 = $16;
    var $18 = _malloc($8);
    var $19 = $18;
    var $20 = ($18 | 0) == 0;
    if ($20) {
      var $cpp_1 = $17;
      __label__ = 5;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 5:
    var $cpp_1;
    HEAP32[$cpp_1 >> 2] = 0;
    var $22 = HEAP32[$1 >> 2];
    var $23 = ($22 | 0) == 0;
    if ($23) {
      var $_0 = 17;
      __label__ = 14;
      break;
    } else {
      var $new_0 = $22;
      __label__ = 6;
      break;
    }
   case 6:
    var $new_0;
    var $25 = $new_0 + 4 | 0;
    var $26 = HEAP32[$25 >> 2];
    HEAP32[$1 >> 2] = $26;
    HEAP32[$25 >> 2] = 0;
    var $27 = $new_0 + 12 | 0;
    HEAP32[$27 >> 2] = $gp;
    var $28 = $new_0 + 8 | 0;
    HEAP32[$28 >> 2] = 0;
    var $29 = $new_0 + 16 | 0;
    HEAP32[$29 >> 2] = 0;
    var $30 = $new_0 + 28 | 0;
    HEAP32[$30 >> 2] = 0;
    var $31 = ($cp | 0) == 0;
    if ($31) {
      __label__ = 13;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $33 = $cp + 8 | 0;
    var $34 = HEAP32[$33 >> 2];
    var $35 = ($34 | 0) == 0;
    if ($35) {
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    HEAP32[$28 >> 2] = $34;
    var $37 = _mkstck($np, $new_0, 0);
    var $38 = ($37 | 0) == 0;
    if ($38) {
      __label__ = 9;
      break;
    } else {
      var $_0 = 17;
      __label__ = 14;
      break;
    }
   case 9:
    var $40 = $cp + 16 | 0;
    var $41 = HEAP32[$40 >> 2];
    HEAP32[$29 >> 2] = $41;
    var $42 = $cp + 20 | 0;
    var $43 = HEAP32[$42 >> 2];
    var $44 = $new_0 + 20 | 0;
    HEAP32[$44 >> 2] = $43;
    var $45 = $cp + 24 | 0;
    var $46 = HEAP16[$45 >> 1];
    var $47 = $new_0 + 24 | 0;
    HEAP16[$47 >> 1] = $46;
    var $48 = $np + 44 | 0;
    var $49 = HEAP32[$48 >> 2];
    var $50 = ($49 | 0) == 0;
    if ($50) {
      __label__ = 13;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $52 = $cp + 28 | 0;
    var $53 = HEAP32[$52 >> 2];
    var $54 = ($53 | 0) == 0;
    if ($54) {
      __label__ = 13;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $56 = $new_0 + 32 | 0;
    var $57 = $cp + 32 | 0;
    HEAP32[$30 >> 2] = $53;
    var $58 = $57 | 0;
    var $59 = HEAP32[$58 >> 2];
    var $60 = $56 | 0;
    HEAP32[$60 >> 2] = $59;
    var $61 = $cp + 36 | 0;
    var $62 = HEAP32[$61 >> 2];
    var $63 = $new_0 + 36 | 0;
    HEAP32[$63 >> 2] = $62;
    var $64 = $53 - 1 | 0;
    var $65 = ($64 | 0) == 0;
    if ($65) {
      __label__ = 13;
      break;
    } else {
      var $rmn_01 = $56;
      var $rmo_02 = $57;
      var $66 = $64;
      __label__ = 12;
      break;
    }
   case 12:
    var $66;
    var $rmo_02;
    var $rmn_01;
    var $67 = $rmn_01 + 8 | 0;
    var $68 = $rmo_02 + 8 | 0;
    var $69 = $68 | 0;
    var $70 = HEAP32[$69 >> 2];
    var $71 = $67 | 0;
    HEAP32[$71 >> 2] = $70;
    var $72 = $rmo_02 + 12 | 0;
    var $73 = HEAP32[$72 >> 2];
    var $74 = $rmn_01 + 12 | 0;
    HEAP32[$74 >> 2] = $73;
    var $75 = $66 - 1 | 0;
    var $76 = ($75 | 0) == 0;
    if ($76) {
      __label__ = 13;
      break;
    } else {
      var $rmn_01 = $67;
      var $rmo_02 = $68;
      var $66 = $75;
      __label__ = 12;
      break;
    }
   case 13:
    var $77 = $np + 28 | 0;
    var $78 = HEAP32[$77 >> 2];
    HEAP32[$78 >> 2] = $new_0;
    HEAP32[$77 >> 2] = $25;
    var $_0 = 0;
    __label__ = 14;
    break;
   case 14:
    var $_0;
    return $_0;
   case 15:
    var $81 = HEAP32[$9 >> 2];
    var $82 = $18;
    HEAP32[$82 >> 2] = $81;
    HEAP32[$9 >> 2] = $19;
    HEAP32[$17 >> 2] = $19;
    var $83 = $18 + 4 | 0;
    var $84 = $83;
    var $85 = _malloc($8);
    var $86 = $85;
    var $87 = ($85 | 0) == 0;
    if ($87) {
      var $cpp_1 = $84;
      __label__ = 5;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $89 = HEAP32[$9 >> 2];
    var $90 = $85;
    HEAP32[$90 >> 2] = $89;
    HEAP32[$9 >> 2] = $86;
    HEAP32[$84 >> 2] = $86;
    var $91 = $85 + 4 | 0;
    var $92 = $91;
    var $93 = _malloc($8);
    var $94 = $93;
    var $95 = ($93 | 0) == 0;
    if ($95) {
      var $cpp_1 = $92;
      __label__ = 5;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    var $97 = HEAP32[$9 >> 2];
    var $98 = $93;
    HEAP32[$98 >> 2] = $97;
    HEAP32[$9 >> 2] = $94;
    HEAP32[$92 >> 2] = $94;
    var $99 = $93 + 4 | 0;
    var $100 = $99;
    var $cpp_1 = $100;
    __label__ = 5;
    break;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_newctxt["X"] = 1;
function _mkstck($np, $cp, $gp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($gp | 0) == 0;
    if ($1) {
      __label__ = 3;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 3:
    var $3 = $cp + 8 | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = $4 + 8 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $cp + 16 | 0;
    HEAP32[$7 >> 2] = $6;
    var $8 = $4 + 12 | 0;
    var $9 = HEAP32[$8 >> 2];
    var $10 = $cp + 20 | 0;
    HEAP32[$10 >> 2] = $9;
    var $11 = $4 + 16 | 0;
    var $12 = HEAP16[$11 >> 1];
    var $13 = $cp + 24 | 0;
    HEAP16[$13 >> 1] = $12;
    var $14 = $4 + 4 | 0;
    var $15 = HEAP32[$14 >> 2];
    HEAP32[$3 >> 2] = $15;
    var $16 = HEAP32[$14 >> 2];
    var $17 = ($16 | 0) == 0;
    if ($17) {
      __label__ = 4;
      break;
    } else {
      var $sp_0 = $16;
      var $new_0 = $4;
      __label__ = 5;
      break;
    }
   case 4:
    var $19 = $np + 4 | 0;
    var $20 = HEAP32[$19 >> 2];
    HEAP32[$14 >> 2] = $20;
    HEAP32[$19 >> 2] = $4;
    HEAP32[$3 >> 2] = 0;
    var $_0 = 0;
    __label__ = 13;
    break;
   case 5:
    var $new_0;
    var $sp_0;
    var $21 = $sp_0 + 8 | 0;
    var $22 = HEAP32[$21 >> 2];
    var $23 = $new_0 + 8 | 0;
    HEAP32[$23 >> 2] = $22;
    var $24 = $sp_0 + 12 | 0;
    var $25 = HEAP32[$24 >> 2];
    var $26 = $new_0 + 12 | 0;
    HEAP32[$26 >> 2] = $25;
    var $27 = $sp_0 + 16 | 0;
    var $28 = HEAP16[$27 >> 1];
    var $29 = $new_0 + 16 | 0;
    HEAP16[$29 >> 1] = $28;
    var $30 = $sp_0 + 4 | 0;
    var $31 = HEAP32[$30 >> 2];
    var $32 = $new_0 + 4 | 0;
    HEAP32[$32 >> 2] = $31;
    var $33 = ($31 | 0) == 0;
    if ($33) {
      var $_0 = 0;
      __label__ = 13;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $35 = _newstck($np);
    HEAP32[$32 >> 2] = $35;
    var $36 = ($35 | 0) == 0;
    if ($36) {
      var $_0 = 17;
      __label__ = 13;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $38 = HEAP32[$30 >> 2];
    var $sp_0 = $38;
    var $new_0 = $35;
    __label__ = 5;
    break;
   case 8:
    var $40 = $cp + 16 | 0;
    var $41 = HEAP32[$40 >> 2];
    var $42 = ($41 | 0) == 0;
    if ($42) {
      __label__ = 9;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 9:
    var $_pre = $cp + 20 | 0;
    var $_pre1 = $cp + 24 | 0;
    var $_pre_phi = $_pre;
    var $_pre_phi2 = $_pre1;
    __label__ = 12;
    break;
   case 10:
    var $44 = _newstck($np);
    var $45 = ($44 | 0) == 0;
    if ($45) {
      var $_0 = 17;
      __label__ = 13;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $47 = $cp + 8 | 0;
    var $48 = HEAP32[$47 >> 2];
    var $49 = $44 + 4 | 0;
    HEAP32[$49 >> 2] = $48;
    HEAP32[$47 >> 2] = $44;
    var $50 = HEAP32[$40 >> 2];
    var $51 = $44 + 8 | 0;
    HEAP32[$51 >> 2] = $50;
    var $52 = $cp + 20 | 0;
    var $53 = HEAP32[$52 >> 2];
    var $54 = $44 + 12 | 0;
    HEAP32[$54 >> 2] = $53;
    var $55 = $cp + 24 | 0;
    var $56 = HEAP16[$55 >> 1];
    var $57 = $44 + 16 | 0;
    HEAP16[$57 >> 1] = $56;
    var $_pre_phi = $52;
    var $_pre_phi2 = $55;
    __label__ = 12;
    break;
   case 12:
    var $_pre_phi2;
    var $_pre_phi;
    HEAP32[$40 >> 2] = $gp;
    HEAP32[$_pre_phi >> 2] = 0;
    HEAP16[$_pre_phi2 >> 1] = 0;
    var $_0 = 0;
    __label__ = 13;
    break;
   case 13:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_mkstck["X"] = 1;
function _newstck($np) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $np + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      var $sp_0 = $2;
      __label__ = 6;
      break;
    }
   case 3:
    var $5 = $np + 8 | 0;
    var $6 = _malloc(20);
    var $7 = $6;
    var $8 = ($6 | 0) == 0;
    if ($8) {
      var $spp_1 = $1;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $10 = HEAP32[$5 >> 2];
    var $11 = $6;
    HEAP32[$11 >> 2] = $10;
    HEAP32[$5 >> 2] = $7;
    HEAP32[$1 >> 2] = $7;
    var $12 = $6 + 4 | 0;
    var $13 = $12;
    var $14 = _malloc(20);
    var $15 = $14;
    var $16 = ($14 | 0) == 0;
    if ($16) {
      var $spp_1 = $13;
      __label__ = 5;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 5:
    var $spp_1;
    HEAP32[$spp_1 >> 2] = 0;
    var $18 = HEAP32[$1 >> 2];
    var $19 = ($18 | 0) == 0;
    if ($19) {
      var $_0 = 0;
      __label__ = 7;
      break;
    } else {
      var $sp_0 = $18;
      __label__ = 6;
      break;
    }
   case 6:
    var $sp_0;
    var $21 = $sp_0 + 4 | 0;
    var $22 = HEAP32[$21 >> 2];
    HEAP32[$1 >> 2] = $22;
    var $_0 = $sp_0;
    __label__ = 7;
    break;
   case 7:
    var $_0;
    return $_0;
   case 8:
    var $25 = HEAP32[$5 >> 2];
    var $26 = $14;
    HEAP32[$26 >> 2] = $25;
    HEAP32[$5 >> 2] = $15;
    HEAP32[$13 >> 2] = $15;
    var $27 = $14 + 4 | 0;
    var $28 = $27;
    var $29 = _malloc(20);
    var $30 = $29;
    var $31 = ($29 | 0) == 0;
    if ($31) {
      var $spp_1 = $28;
      __label__ = 5;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $33 = HEAP32[$5 >> 2];
    var $34 = $29;
    HEAP32[$34 >> 2] = $33;
    HEAP32[$5 >> 2] = $30;
    HEAP32[$28 >> 2] = $30;
    var $35 = $29 + 4 | 0;
    var $36 = $35;
    var $37 = _malloc(20);
    var $38 = $37;
    var $39 = ($37 | 0) == 0;
    if ($39) {
      var $spp_1 = $36;
      __label__ = 5;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $41 = HEAP32[$5 >> 2];
    var $42 = $37;
    HEAP32[$42 >> 2] = $41;
    HEAP32[$5 >> 2] = $38;
    HEAP32[$36 >> 2] = $38;
    var $43 = $37 + 4 | 0;
    var $44 = $43;
    var $spp_1 = $44;
    __label__ = 5;
    break;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_newstck["X"] = 1;
function _leftmost($dp, $xp) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 4;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $wc = __stackBase__;
    var $1 = $xp + 16 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $xp | 0;
    var $4 = HEAP32[$3 >> 2];
    var $5 = $dp + 325 | 0;
    var $6 = $xp + 12 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = $7 & 1;
    var $9 = ($8 | 0) == 0;
    var $10 = $dp + 324 | 0;
    var $st_0_in_in = $9 ? $5 : $10;
    var $st_0_in = HEAP8[$st_0_in_in];
    var $st_0 = $st_0_in & 255;
    var $11 = $st_0 + ($dp + 292) | 0;
    var $12 = HEAP8[$11];
    var $13 = $12 << 24 >> 24 == 0;
    if ($13) {
      var $end_0_ph = 0;
      __label__ = 5;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $15 = $7 & 4;
    var $16 = ($15 | 0) == 0;
    if ($16) {
      __label__ = 4;
      break;
    } else {
      var $end_0_ph = 0;
      __label__ = 5;
      break;
    }
   case 4:
    var $end_0_ph = $4;
    __label__ = 5;
    break;
   case 5:
    var $end_0_ph;
    var $18 = ($2 | 0) == 1;
    var $st_1_ph = $st_0;
    var $s_0_ph = $4;
    var $beg_0_ph = $4;
    var $end_0_ph9 = $end_0_ph;
    __label__ = 6;
    break;
   case 6:
    var $end_0_ph9;
    var $beg_0_ph;
    var $s_0_ph;
    var $st_1_ph;
    var $19 = ($end_0_ph9 | 0) == 0;
    var $st_1 = $st_1_ph;
    var $s_0 = $s_0_ph;
    var $beg_0 = $beg_0_ph;
    __label__ = 7;
    break;
   case 7:
    var $beg_0;
    var $s_0;
    var $st_1;
    var $20 = $s_0 + 1 | 0;
    var $21 = HEAP8[$s_0];
    var $22 = $21 & 255;
    HEAP32[$wc >> 2] = $22;
    var $23 = $21 << 24 >> 24 == 10;
    if ($23) {
      __label__ = 8;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 8:
    var $25 = HEAP32[$6 >> 2];
    var $26 = $25 & 1024;
    var $27 = ($26 | 0) == 0;
    if ($27) {
      var $s_1_ph = $20;
      __label__ = 13;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    HEAP32[$wc >> 2] = -3;
    var $s_16 = $20;
    var $43 = -3;
    __label__ = 15;
    break;
   case 10:
    var $29 = $22 & 128;
    var $30 = ($29 | 0) == 0;
    var $or_cond = $30 | $18;
    if ($or_cond) {
      var $s_1_ph = $20;
      __label__ = 13;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $32 = _libuxre_mb2wc($wc, $20);
    var $33 = ($32 | 0) > 0;
    if ($33) {
      __label__ = 12;
      break;
    } else {
      var $s_1_ph = $20;
      __label__ = 13;
      break;
    }
   case 12:
    var $_sum1 = $32 + 1 | 0;
    var $35 = $s_0 + $_sum1 | 0;
    var $s_1_ph = $35;
    __label__ = 13;
    break;
   case 13:
    var $s_1_ph;
    var $_pr = HEAP32[$wc >> 2];
    var $36 = $_pr >>> 0 > 255;
    if ($36) {
      var $s_16 = $s_1_ph;
      var $43 = $_pr;
      __label__ = 15;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $38 = $dp + 330 + ($st_1 << 8) + $_pr | 0;
    var $39 = HEAP8[$38];
    var $40 = $39 & 255;
    var $41 = $39 << 24 >> 24 == 0;
    if ($41) {
      var $s_16 = $s_1_ph;
      var $43 = $_pr;
      __label__ = 15;
      break;
    } else {
      var $nst_0 = $40;
      var $s_17 = $s_1_ph;
      var $60 = $_pr;
      __label__ = 21;
      break;
    }
   case 15:
    var $43;
    var $s_16;
    var $44 = _regtrans($dp, $st_1, $43, $2);
    var $45 = ($44 | 0) == 0;
    if ($45) {
      var $_0 = 17;
      __label__ = 36;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $47 = ($43 | 0) == -3;
    if ($47) {
      __label__ = 17;
      break;
    } else {
      var $nst_0 = $44;
      var $s_17 = $s_16;
      var $60 = $43;
      __label__ = 21;
      break;
    }
   case 17:
    var $49 = $44 - 1 | 0;
    var $50 = $49 + ($dp + 292) | 0;
    var $51 = HEAP8[$50];
    var $52 = $51 << 24 >> 24 == 0;
    if ($52) {
      __label__ = 20;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $54 = $end_0_ph9 >>> 0 < $s_16 >>> 0;
    var $or_cond2 = $19 | $54;
    if ($or_cond2) {
      __label__ = 19;
      break;
    } else {
      var $end_1 = $end_0_ph9;
      __label__ = 35;
      break;
    }
   case 19:
    var $end_1 = $s_16;
    __label__ = 35;
    break;
   case 20:
    var $57 = HEAP8[$5];
    var $58 = $57 & 255;
    var $st_2 = $58;
    var $s_2 = $s_16;
    var $beg_2 = $s_16;
    __label__ = 33;
    break;
   case 21:
    var $60;
    var $s_17;
    var $nst_0;
    var $61 = $nst_0 - 1 | 0;
    var $62 = ($61 | 0) == 0;
    if ($62) {
      __label__ = 22;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 22:
    if ($19) {
      __label__ = 23;
      break;
    } else {
      var $end_1 = $end_0_ph9;
      __label__ = 35;
      break;
    }
   case 23:
    var $65 = $beg_0 + 1 | 0;
    var $66 = HEAP8[$beg_0];
    var $67 = $66 & 255;
    HEAP32[$wc >> 2] = $67;
    var $68 = $66 << 24 >> 24 == 0;
    if ($68) {
      var $_0 = 1;
      __label__ = 36;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 24:
    var $70 = $67 & 128;
    var $71 = ($70 | 0) == 0;
    var $or_cond3 = $71 | $18;
    if ($or_cond3) {
      var $beg_1 = $65;
      __label__ = 27;
      break;
    } else {
      __label__ = 25;
      break;
    }
   case 25:
    var $73 = _libuxre_mb2wc($wc, $65);
    var $74 = ($73 | 0) > 0;
    if ($74) {
      __label__ = 26;
      break;
    } else {
      var $beg_1 = $65;
      __label__ = 27;
      break;
    }
   case 26:
    var $_sum = $73 + 1 | 0;
    var $76 = $beg_0 + $_sum | 0;
    var $beg_1 = $76;
    __label__ = 27;
    break;
   case 27:
    var $beg_1;
    var $77 = HEAP8[$10];
    var $78 = $77 & 255;
    var $st_2 = $78;
    var $s_2 = $beg_1;
    var $beg_2 = $beg_1;
    __label__ = 33;
    break;
   case 28:
    var $80 = ($60 | 0) == 0;
    if ($80) {
      __label__ = 29;
      break;
    } else {
      var $st_2 = $61;
      var $s_2 = $s_17;
      var $beg_2 = $beg_0;
      __label__ = 33;
      break;
    }
   case 29:
    var $82 = $61 + ($dp + 292) | 0;
    var $83 = HEAP8[$82];
    var $84 = $83 << 24 >> 24 == 0;
    if ($84) {
      __label__ = 32;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    var $86 = $s_17 - 1 | 0;
    var $87 = $end_0_ph9 >>> 0 < $86 >>> 0;
    var $or_cond4 = $19 | $87;
    if ($or_cond4) {
      __label__ = 31;
      break;
    } else {
      var $end_1 = $end_0_ph9;
      __label__ = 35;
      break;
    }
   case 31:
    var $end_1 = $86;
    __label__ = 35;
    break;
   case 32:
    if ($19) {
      var $_0 = 1;
      __label__ = 36;
      break;
    } else {
      var $end_1 = $end_0_ph9;
      __label__ = 35;
      break;
    }
   case 33:
    var $beg_2;
    var $s_2;
    var $st_2;
    var $91 = $st_2 + ($dp + 292) | 0;
    var $92 = HEAP8[$91];
    var $93 = $92 << 24 >> 24 == 0;
    if ($93) {
      var $st_1 = $st_2;
      var $s_0 = $s_2;
      var $beg_0 = $beg_2;
      __label__ = 7;
      break;
    } else {
      __label__ = 34;
      break;
    }
   case 34:
    var $95 = $end_0_ph9 >>> 0 < $s_2 >>> 0;
    var $or_cond5 = $19 | $95;
    if ($or_cond5) {
      var $st_1_ph = $st_2;
      var $s_0_ph = $s_2;
      var $beg_0_ph = $beg_2;
      var $end_0_ph9 = $s_2;
      __label__ = 6;
      break;
    } else {
      var $st_1 = $st_2;
      var $s_0 = $s_2;
      var $beg_0 = $beg_2;
      __label__ = 7;
      break;
    }
   case 35:
    var $end_1;
    var $96 = HEAP32[$3 >> 2];
    var $97 = $beg_0;
    var $98 = $96;
    var $99 = $97 - $98 | 0;
    var $100 = $xp + 4 | 0;
    var $101 = HEAP32[$100 >> 2];
    var $102 = $101 | 0;
    HEAP32[$102 >> 2] = $99;
    var $103 = HEAP32[$3 >> 2];
    var $104 = $end_1;
    var $105 = $103;
    var $106 = $104 - $105 | 0;
    var $107 = HEAP32[$100 >> 2];
    var $108 = $107 + 4 | 0;
    HEAP32[$108 >> 2] = $106;
    var $_0 = 0;
    __label__ = 36;
    break;
   case 36:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_leftmost["X"] = 1;
function _regdfaexec_opt($dp, $xp_0_0_val, $xp_0_3_val) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $dp + 326 | 0;
    var $2 = HEAP8[$1];
    var $3 = $2 & 255;
    var $4 = $xp_0_3_val & 1;
    var $5 = ($4 | 0) == 0;
    var $st_0 = $5 ? $3 : 1;
    var $6 = $st_0 + ($dp + 292) | 0;
    var $7 = HEAP8[$6];
    var $8 = $7 << 24 >> 24 == 0;
    if ($8) {
      var $st_1 = $st_0;
      var $s_0 = $xp_0_0_val;
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $10 = $xp_0_3_val & 4;
    var $11 = ($10 | 0) == 0;
    if ($11) {
      var $_0 = 0;
      __label__ = 8;
      break;
    } else {
      var $st_1 = $st_0;
      var $s_0 = $xp_0_0_val;
      __label__ = 4;
      break;
    }
   case 4:
    var $s_0;
    var $st_1;
    var $12 = HEAP8[$s_0];
    var $13 = $12 & 255;
    var $14 = $dp + 330 + ($st_1 << 8) + $13 | 0;
    var $15 = HEAP8[$14];
    var $16 = $15 & 255;
    var $17 = $15 << 24 >> 24 == 0;
    if ($17) {
      __label__ = 5;
      break;
    } else {
      var $nst_0 = $16;
      __label__ = 6;
      break;
    }
   case 5:
    var $19 = _regtrans($dp, $st_1, $13, 1);
    var $20 = ($19 | 0) == 0;
    if ($20) {
      var $_0 = 17;
      __label__ = 8;
      break;
    } else {
      var $nst_0 = $19;
      __label__ = 6;
      break;
    }
   case 6:
    var $nst_0;
    var $22 = $nst_0 - 1 | 0;
    var $23 = $22 + ($dp + 292) | 0;
    var $24 = HEAP8[$23];
    var $25 = $24 << 24 >> 24 == 0;
    if ($25) {
      __label__ = 7;
      break;
    } else {
      var $_0 = 0;
      __label__ = 8;
      break;
    }
   case 7:
    var $27 = $s_0 + 1 | 0;
    var $28 = HEAP8[$s_0];
    var $29 = $28 << 24 >> 24 == 0;
    if ($29) {
      var $_0 = 1;
      __label__ = 8;
      break;
    } else {
      var $st_1 = $22;
      var $s_0 = $27;
      __label__ = 4;
      break;
    }
   case 8:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _libuxre_reg1tree($op, $lp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _malloc(16);
    var $2 = $1;
    var $3 = ($1 | 0) == 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 3:
    var $5 = ($lp | 0) == 0;
    if ($5) {
      var $_0 = 0;
      __label__ = 7;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    _libuxre_regdeltree($lp, 1);
    var $_0 = 0;
    __label__ = 7;
    break;
   case 5:
    var $8 = $1 + 12 | 0;
    var $9 = $8;
    HEAP32[$9 >> 2] = $op;
    var $10 = $1;
    HEAP32[$10 >> 2] = $lp;
    var $11 = ($lp | 0) == 0;
    if ($11) {
      var $_0 = $2;
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $13 = $lp + 8 | 0;
    HEAP32[$13 >> 2] = $2;
    var $_0 = $2;
    __label__ = 7;
    break;
   case 7:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _libuxre_reg2tree($op, $lp, $rp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _malloc(16);
    var $2 = $1;
    var $3 = ($1 | 0) == 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _libuxre_regdeltree($lp, 1);
    _libuxre_regdeltree($rp, 1);
    var $_0 = 0;
    __label__ = 5;
    break;
   case 4:
    var $6 = $1 + 12 | 0;
    var $7 = $6;
    HEAP32[$7 >> 2] = $op;
    var $8 = $1;
    HEAP32[$8 >> 2] = $lp;
    var $9 = $lp + 8 | 0;
    HEAP32[$9 >> 2] = $2;
    var $10 = $1 + 4 | 0;
    var $11 = $10;
    HEAP32[$11 >> 2] = $rp;
    var $12 = $rp + 8 | 0;
    HEAP32[$12 >> 2] = $2;
    var $_0 = $2;
    __label__ = 5;
    break;
   case 5:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _casecmp($s, $xp, $i, $n, $mb_cur_max) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $wc1 = __stackBase__;
    var $wc2 = __stackBase__ + 4;
    var $1 = $xp | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $2 + $i | 0;
    var $4 = _strncmp($s, $3, $n);
    var $5 = ($4 | 0) == 0;
    if ($5) {
      var $_0 = 1;
      __label__ = 17;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $7 = $xp + 12 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = $8 & 256;
    var $10 = ($9 | 0) == 0;
    if ($10) {
      var $_0 = 0;
      __label__ = 17;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $_sum = $n + $i | 0;
    var $12 = $2 + $_sum | 0;
    var $13 = ($mb_cur_max | 0) == 1;
    var $14 = ($mb_cur_max | 0) > 1;
    var $_01 = $s;
    var $p_0 = $3;
    __label__ = 5;
    break;
   case 5:
    var $p_0;
    var $_01;
    var $16 = $_01 + 1 | 0;
    var $17 = HEAP8[$_01];
    var $18 = $17 & 255;
    HEAP32[$wc1 >> 2] = $18;
    var $19 = $17 << 24 >> 24 == 0;
    if ($19) {
      var $_0 = 0;
      __label__ = 17;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $21 = $18 & 128;
    var $22 = ($21 | 0) == 0;
    var $or_cond = $22 | $13;
    if ($or_cond) {
      var $_1 = $16;
      __label__ = 9;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $24 = _libuxre_mb2wc($wc1, $16);
    var $25 = ($24 | 0) > 0;
    if ($25) {
      __label__ = 8;
      break;
    } else {
      var $_1 = $16;
      __label__ = 9;
      break;
    }
   case 8:
    var $_sum3 = $24 + 1 | 0;
    var $27 = $_01 + $_sum3 | 0;
    var $_1 = $27;
    __label__ = 9;
    break;
   case 9:
    var $_1;
    var $29 = $p_0 + 1 | 0;
    var $30 = HEAP8[$p_0];
    var $31 = $30 & 255;
    HEAP32[$wc2 >> 2] = $31;
    var $32 = $31 & 128;
    var $33 = ($32 | 0) == 0;
    var $or_cond4 = $33 | $13;
    if ($or_cond4) {
      var $p_1 = $29;
      __label__ = 12;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $35 = _libuxre_mb2wc($wc2, $29);
    var $36 = ($35 | 0) > 0;
    if ($36) {
      __label__ = 11;
      break;
    } else {
      var $p_1 = $29;
      __label__ = 12;
      break;
    }
   case 11:
    var $_sum2 = $35 + 1 | 0;
    var $38 = $p_0 + $_sum2 | 0;
    var $p_1 = $38;
    __label__ = 12;
    break;
   case 12:
    var $p_1;
    var $39 = HEAP32[$wc1 >> 2];
    var $40 = HEAP32[$wc2 >> 2];
    var $41 = ($39 | 0) == ($40 | 0);
    if ($41) {
      __label__ = 16;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 13:
    if ($14) {
      __label__ = 14;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 14:
    _towlower();
   case 15:
    var $45 = _tolower($39);
    HEAP32[$wc1 >> 2] = $45;
    var $46 = _tolower($40);
    HEAP32[$wc2 >> 2] = $46;
    var $47 = ($45 | 0) == ($46 | 0);
    if ($47) {
      __label__ = 16;
      break;
    } else {
      var $_0 = 0;
      __label__ = 17;
      break;
    }
   case 16:
    var $49 = $p_1 >>> 0 < $12 >>> 0;
    if ($49) {
      var $_01 = $_1;
      var $p_0 = $p_1;
      __label__ = 5;
      break;
    } else {
      var $_0 = 1;
      __label__ = 17;
      break;
    }
   case 17:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_casecmp["X"] = 1;
function _posnfoll($dp, $tp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $tp_tr = $tp;
    __label__ = 3;
    break;
   case 3:
    var $tp_tr;
    var $1 = $tp_tr + 12 | 0;
    var $2 = HEAP32[$1 >> 2];
    if (($2 | 0) == -33 || ($2 | 0) == -34) {
      __label__ = 4;
      break;
    } else if (($2 | 0) == -17 || ($2 | 0) == -18 || ($2 | 0) == -19 || ($2 | 0) == -21) {
      __label__ = 5;
      break;
    } else if (($2 | 0) == -14) {
      __label__ = 6;
      break;
    } else if (($2 | 0) == -9 || ($2 | 0) == -10) {
      __label__ = 7;
      break;
    } else if (($2 | 0) == -2) {
      __label__ = 8;
      break;
    } else if (($2 | 0) == -3) {
      __label__ = 9;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 4:
    var $4 = $tp_tr + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = _posnfoll($dp, $5);
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 5;
      break;
    } else {
      var $_0 = $6;
      __label__ = 21;
      break;
    }
   case 5:
    var $9 = $tp_tr | 0;
    var $10 = HEAP32[$9 >> 2];
    var $tp_tr = $10;
    __label__ = 3;
    break;
   case 6:
    var $12 = $tp_tr;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $dp + 16 | 0;
    var $15 = HEAP32[$14 >> 2];
    var $16 = $15 + ($13 << 4) + 12 | 0;
    HEAP32[$16 >> 2] = -14;
    var $17 = $15 + ($13 << 4) + 8 | 0;
    HEAP32[$17 >> 2] = 0;
    var $18 = $15 + ($13 << 4) + 4 | 0;
    HEAP32[$18 >> 2] = 0;
    var $_0 = 0;
    __label__ = 21;
    break;
   case 7:
    var $20 = $tp_tr;
    var $21 = HEAP32[$20 >> 2];
    var $22 = $dp + 16 | 0;
    var $23 = HEAP32[$22 >> 2];
    var $24 = $23 + ($21 << 4) | 0;
    var $25 = $tp_tr + 4 | 0;
    var $26 = $25;
    var $27 = HEAP32[$26 >> 2];
    var $28 = $24 | 0;
    HEAP32[$28 >> 2] = $27;
    var $p_0 = $24;
    __label__ = 11;
    break;
   case 8:
    var $30 = $dp + 329 | 0;
    var $31 = HEAP8[$30];
    var $32 = $31 | 1;
    HEAP8[$30] = $32;
    __label__ = 10;
    break;
   case 9:
    var $34 = $dp + 329 | 0;
    var $35 = HEAP8[$34];
    var $36 = $35 | 2;
    HEAP8[$34] = $36;
    __label__ = 10;
    break;
   case 10:
    var $37 = $tp_tr;
    var $38 = HEAP32[$37 >> 2];
    var $39 = $dp + 16 | 0;
    var $40 = HEAP32[$39 >> 2];
    var $41 = $40 + ($38 << 4) | 0;
    var $p_0 = $41;
    __label__ = 11;
    break;
   case 11:
    var $p_0;
    var $43 = HEAP32[$1 >> 2];
    var $44 = $p_0 + 12 | 0;
    HEAP32[$44 >> 2] = $43;
    var $45 = $dp | 0;
    var $46 = HEAP32[$45 >> 2];
    var $47 = $dp + 20 | 0;
    var $48 = HEAP32[$47 >> 2];
    _memset($46, 0, $48, 1);
    var $49 = $dp + 32 | 0;
    HEAP32[$49 >> 2] = 0;
    _follow($dp, $tp_tr);
    var $50 = $dp + 329 | 0;
    var $51 = HEAP8[$50];
    var $52 = $51 & -4;
    HEAP8[$50] = $52;
    var $53 = $dp + 4 | 0;
    var $54 = HEAP32[$53 >> 2];
    var $55 = HEAP32[$49 >> 2];
    var $56 = $p_0 + 4 | 0;
    HEAP32[$56 >> 2] = $55;
    var $57 = $dp + 28 | 0;
    var $58 = HEAP32[$57 >> 2];
    var $59 = $55 >>> 0 > $58 >>> 0;
    if ($59) {
      __label__ = 13;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $_pre = $dp + 24 | 0;
    var $fp_0 = $54;
    var $_pre_phi = $_pre;
    __label__ = 15;
    break;
   case 13:
    var $61 = $55 << 1;
    var $62 = HEAP32[$47 >> 2];
    var $63 = $61 >>> 0 < $62 >>> 0;
    var $n_0 = $63 ? $62 : $61;
    var $64 = $n_0 + $58 | 0;
    HEAP32[$57 >> 2] = $64;
    var $65 = HEAP32[$53 >> 2];
    var $66 = $65;
    var $67 = $dp + 24 | 0;
    var $68 = HEAP32[$67 >> 2];
    var $69 = $64 + $68 | 0;
    var $70 = $69 << 2;
    var $71 = _realloc($66, $70);
    var $72 = $71;
    var $73 = ($71 | 0) == 0;
    if ($73) {
      var $_0 = 17;
      __label__ = 21;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    HEAP32[$53 >> 2] = $72;
    var $fp_0 = $72;
    var $_pre_phi = $67;
    __label__ = 15;
    break;
   case 15:
    var $_pre_phi;
    var $fp_0;
    var $76 = HEAP32[$_pre_phi >> 2];
    var $77 = $p_0 + 8 | 0;
    HEAP32[$77 >> 2] = $76;
    var $78 = HEAP32[$49 >> 2];
    var $79 = ($78 | 0) == 0;
    if ($79) {
      var $_0 = 0;
      __label__ = 21;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $81 = HEAP32[$_pre_phi >> 2];
    var $82 = $81 + $78 | 0;
    HEAP32[$_pre_phi >> 2] = $82;
    var $83 = HEAP32[$57 >> 2];
    var $84 = $83 - $78 | 0;
    HEAP32[$57 >> 2] = $84;
    var $85 = HEAP32[$77 >> 2];
    var $86 = $fp_0 + ($85 << 2) | 0;
    var $87 = HEAP32[$45 >> 2];
    var $s_0 = $87;
    var $i_0 = $78;
    var $n_1 = 0;
    var $fp_1 = $86;
    __label__ = 17;
    break;
   case 17:
    var $fp_1;
    var $n_1;
    var $i_0;
    var $s_0;
    var $89 = $s_0 + 1 | 0;
    var $90 = HEAP8[$s_0];
    var $91 = $90 << 24 >> 24 == 0;
    if ($91) {
      var $i_1 = $i_0;
      var $fp_2 = $fp_1;
      __label__ = 20;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    HEAP32[$fp_1 >> 2] = $n_1;
    var $93 = $i_0 - 1 | 0;
    var $94 = ($93 | 0) == 0;
    if ($94) {
      var $_0 = 0;
      __label__ = 21;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 19:
    var $95 = $fp_1 + 4 | 0;
    var $i_1 = $93;
    var $fp_2 = $95;
    __label__ = 20;
    break;
   case 20:
    var $fp_2;
    var $i_1;
    var $96 = $n_1 + 1 | 0;
    var $97 = HEAP32[$47 >> 2];
    var $98 = ($96 | 0) == ($97 | 0);
    if ($98) {
      var $_0 = 0;
      __label__ = 21;
      break;
    } else {
      var $s_0 = $89;
      var $i_0 = $i_1;
      var $n_1 = $96;
      var $fp_1 = $fp_2;
      __label__ = 17;
      break;
    }
   case 21:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_posnfoll["X"] = 1;
function _follow($dp, $tp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $tp_tr = $tp;
    __label__ = 3;
    break;
   case 3:
    var $tp_tr;
    var $1 = $tp_tr + 8 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $2 + 12 | 0;
    var $4 = HEAP32[$3 >> 2];
    if (($4 | 0) == -33 || ($4 | 0) == -19 || ($4 | 0) == -21) {
      var $tp_tr = $2;
      __label__ = 3;
      break;
    } else if (($4 | 0) == -34) {
      __label__ = 4;
      break;
    } else if (($4 | 0) == -17 || ($4 | 0) == -18 || ($4 | 0) == -20) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 4:
    var $6 = $2 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = ($7 | 0) == ($tp_tr | 0);
    if ($8) {
      __label__ = 5;
      break;
    } else {
      var $tp_tr = $2;
      __label__ = 3;
      break;
    }
   case 5:
    var $10 = $2 + 4 | 0;
    var $11 = HEAP32[$10 >> 2];
    var $12 = _first($dp, $11);
    var $13 = ($12 | 0) == 0;
    if ($13) {
      var $tp_tr = $2;
      __label__ = 3;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    var $15 = _first($dp, $tp_tr);
    var $tp_tr = $2;
    __label__ = 3;
    break;
   case 7:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _first($dp, $tp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $tp_tr = $tp;
    __label__ = 3;
    break;
   case 3:
    var $tp_tr;
    var $1 = $tp_tr + 12 | 0;
    var $2 = HEAP32[$1 >> 2];
    if (($2 | 0) == -2) {
      __label__ = 4;
      break;
    } else if (($2 | 0) == -3) {
      __label__ = 5;
      break;
    } else if (($2 | 0) == -33) {
      __label__ = 6;
      break;
    } else if (($2 | 0) == -34) {
      __label__ = 7;
      break;
    } else if (($2 | 0) == -20) {
      __label__ = 10;
      break;
    } else if (($2 | 0) == -17 || ($2 | 0) == -19) {
      __label__ = 12;
      break;
    } else if (($2 | 0) == -21 || ($2 | 0) == -18) {
      __label__ = 13;
      break;
    } else if (($2 | 0) == -7) {
      var $_0 = 0;
      __label__ = 16;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 4:
    var $4 = $dp + 329 | 0;
    var $5 = HEAP8[$4];
    var $6 = $5 & 1;
    var $7 = $6 << 24 >> 24 == 0;
    if ($7) {
      __label__ = 14;
      break;
    } else {
      var $_0 = 0;
      __label__ = 16;
      break;
    }
   case 5:
    var $9 = $dp + 329 | 0;
    var $10 = HEAP8[$9];
    var $11 = $10 & 2;
    var $12 = $11 << 24 >> 24 == 0;
    if ($12) {
      __label__ = 14;
      break;
    } else {
      var $_0 = 0;
      __label__ = 16;
      break;
    }
   case 6:
    var $14 = $tp_tr | 0;
    var $15 = HEAP32[$14 >> 2];
    var $16 = _first($dp, $15);
    var $17 = $tp_tr + 4 | 0;
    var $18 = HEAP32[$17 >> 2];
    var $19 = _first($dp, $18);
    var $20 = $19 & $16;
    return $20;
   case 7:
    var $22 = $tp_tr | 0;
    var $23 = HEAP32[$22 >> 2];
    var $24 = _first($dp, $23);
    var $25 = ($24 | 0) == 0;
    if ($25) {
      __label__ = 8;
      break;
    } else {
      var $_0 = 1;
      __label__ = 16;
      break;
    }
   case 8:
    var $27 = $tp_tr + 4 | 0;
    var $tp_tr_be_in = $27;
    __label__ = 9;
    break;
   case 9:
    var $tp_tr_be_in;
    var $tp_tr_be = HEAP32[$tp_tr_be_in >> 2];
    var $tp_tr = $tp_tr_be;
    __label__ = 3;
    break;
   case 10:
    var $29 = $tp_tr + 4 | 0;
    var $30 = $29;
    var $31 = HEAP16[$30 >> 1];
    var $32 = $31 << 16 >> 16 == 0;
    if ($32) {
      __label__ = 12;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $34 = $tp_tr | 0;
    var $35 = HEAP32[$34 >> 2];
    var $36 = _first($dp, $35);
    var $37 = ($36 | 0) == 0;
    if ($37) {
      __label__ = 12;
      break;
    } else {
      var $_0 = 1;
      __label__ = 16;
      break;
    }
   case 12:
    var $38 = $tp_tr | 0;
    var $39 = HEAP32[$38 >> 2];
    var $40 = _first($dp, $39);
    return 0;
   case 13:
    var $42 = $tp_tr | 0;
    var $tp_tr_be_in = $42;
    __label__ = 9;
    break;
   case 14:
    var $43 = $tp_tr;
    var $44 = HEAP32[$43 >> 2];
    var $45 = $dp | 0;
    var $46 = HEAP32[$45 >> 2];
    var $47 = $46 + $44 | 0;
    var $48 = HEAP8[$47];
    var $49 = $48 << 24 >> 24 == 0;
    if ($49) {
      __label__ = 15;
      break;
    } else {
      var $_0 = 1;
      __label__ = 16;
      break;
    }
   case 15:
    HEAP8[$47] = 1;
    var $51 = $dp + 32 | 0;
    var $52 = HEAP32[$51 >> 2];
    var $53 = $52 + 1 | 0;
    HEAP32[$51 >> 2] = $53;
    var $_0 = 1;
    __label__ = 16;
    break;
   case 16:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_first["X"] = 1;
function _copy($ep, $tp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _malloc(16);
    var $2 = $1;
    var $3 = ($1 | 0) == 0;
    if ($3) {
      var $_0 = 0;
      __label__ = 13;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = $tp + 12 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $1 + 12 | 0;
    var $8 = $7;
    HEAP32[$8 >> 2] = $6;
    if (($6 | 0) == -9) {
      __label__ = 4;
      break;
    } else if (($6 | 0) == -10) {
      __label__ = 5;
      break;
    } else if (($6 | 0) == -34 || ($6 | 0) == -33) {
      __label__ = 7;
      break;
    } else if (($6 | 0) == -17 || ($6 | 0) == -18 || ($6 | 0) == -19 || ($6 | 0) == -21) {
      __label__ = 10;
      break;
    } else if (($6 | 0) == -7) {
      var $_0 = $2;
      __label__ = 13;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 4:
    HEAP32[$8 >> 2] = -10;
    __label__ = 5;
    break;
   case 5:
    var $11 = $tp + 4 | 0;
    var $12 = $11;
    var $13 = HEAP32[$12 >> 2];
    var $14 = $1 + 4 | 0;
    var $15 = $14;
    HEAP32[$15 >> 2] = $13;
    __label__ = 6;
    break;
   case 6:
    var $17 = $ep + 8 | 0;
    var $18 = HEAP32[$17 >> 2];
    var $19 = $18 + 20 | 0;
    var $20 = HEAP32[$19 >> 2];
    var $21 = $20 + 1 | 0;
    HEAP32[$19 >> 2] = $21;
    var $22 = $1;
    HEAP32[$22 >> 2] = $20;
    var $_0 = $2;
    __label__ = 13;
    break;
   case 7:
    var $24 = $tp + 4 | 0;
    var $25 = HEAP32[$24 >> 2];
    var $26 = _copy($ep, $25);
    var $27 = $1 + 4 | 0;
    var $28 = $27;
    HEAP32[$28 >> 2] = $26;
    var $29 = ($26 | 0) == 0;
    if ($29) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    _free($1);
    var $_0 = 0;
    __label__ = 13;
    break;
   case 9:
    var $32 = $26 + 8 | 0;
    HEAP32[$32 >> 2] = $2;
    __label__ = 10;
    break;
   case 10:
    var $34 = $tp | 0;
    var $35 = HEAP32[$34 >> 2];
    var $36 = _copy($ep, $35);
    var $37 = $1;
    HEAP32[$37 >> 2] = $36;
    var $38 = ($36 | 0) == 0;
    if ($38) {
      __label__ = 12;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $40 = $36 + 8 | 0;
    HEAP32[$40 >> 2] = $2;
    var $_0 = $2;
    __label__ = 13;
    break;
   case 12:
    _libuxre_regdeltree($2, 1);
    var $_0 = 0;
    __label__ = 13;
    break;
   case 13:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_copy["X"] = 1;
function _mkgraph($tp, $first, $last) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 16;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $lf = __stackBase__;
    var $ll = __stackBase__ + 4;
    var $rf = __stackBase__ + 8;
    var $rl = __stackBase__ + 12;
    var $1 = $tp + 12 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == -34;
    if ($3) {
      var $new_06 = 0;
      __label__ = 10;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = _malloc(12);
    var $6 = ($5 | 0) == 0;
    if ($6) {
      var $_0 = 0;
      __label__ = 35;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $8 = $5;
    var $9 = HEAP32[$1 >> 2];
    var $10 = $5 + 8 | 0;
    var $11 = $10;
    HEAP32[$11 >> 2] = $9;
    var $_pr = HEAP32[$1 >> 2];
    if (($_pr | 0) == -13) {
      __label__ = 5;
      break;
    } else if (($_pr | 0) == -9) {
      __label__ = 6;
      break;
    } else if (($_pr | 0) == -10) {
      __label__ = 7;
      break;
    } else if (($_pr | 0) == -7) {
      __label__ = 9;
      break;
    } else if (($_pr | 0) == -33 || ($_pr | 0) == -34) {
      var $new_06 = $8;
      __label__ = 10;
      break;
    } else if (($_pr | 0) == -17 || ($_pr | 0) == -18 || ($_pr | 0) == -19 || ($_pr | 0) == -20 || ($_pr | 0) == -21) {
      var $rmt_0 = 0;
      var $new_04 = $8;
      __label__ = 11;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 5:
    var $13 = $tp + 4 | 0;
    var $14 = $13;
    var $15 = HEAP32[$14 >> 2];
    var $16 = $5;
    var $_c3 = $15;
    HEAP32[$16 >> 2] = $_c3;
    HEAP32[$first >> 2] = $8;
    HEAP32[$last >> 2] = $8;
    var $_0 = 1;
    __label__ = 35;
    break;
   case 6:
    HEAP32[$1 >> 2] = -10;
    __label__ = 7;
    break;
   case 7:
    var $19 = $tp + 4 | 0;
    var $20 = $19;
    var $21 = HEAP32[$20 >> 2];
    var $22 = $5;
    var $_c2 = $21;
    HEAP32[$22 >> 2] = $_c2;
    __label__ = 8;
    break;
   case 8:
    HEAP32[$first >> 2] = $8;
    HEAP32[$last >> 2] = $8;
    var $_0 = 0;
    __label__ = 35;
    break;
   case 9:
    HEAP32[$11 >> 2] = -1;
    var $25 = $5;
    HEAP32[$25 >> 2] = 0;
    HEAP32[$first >> 2] = $8;
    HEAP32[$last >> 2] = $8;
    var $_0 = 1;
    __label__ = 35;
    break;
   case 10:
    var $new_06;
    HEAP32[$lf >> 2] = 0;
    var $26 = $tp + 4 | 0;
    var $27 = HEAP32[$26 >> 2];
    var $28 = _mkgraph($27, $rf, $rl);
    var $29 = ($28 | 0) < 0;
    if ($29) {
      var $new_05 = $new_06;
      __label__ = 28;
      break;
    } else {
      var $rmt_0 = $28;
      var $new_04 = $new_06;
      __label__ = 11;
      break;
    }
   case 11:
    var $new_04;
    var $rmt_0;
    var $31 = $tp | 0;
    var $32 = HEAP32[$31 >> 2];
    var $33 = _mkgraph($32, $lf, $ll);
    var $34 = ($33 | 0) < 0;
    if ($34) {
      var $new_05 = $new_04;
      __label__ = 28;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $36 = HEAP32[$1 >> 2];
    if (($36 | 0) == -33) {
      __label__ = 13;
      break;
    } else if (($36 | 0) == -34) {
      __label__ = 15;
      break;
    } else if (($36 | 0) == -19) {
      __label__ = 16;
      break;
    } else if (($36 | 0) == -17) {
      var $rmt_1 = 1;
      var $storemerge1 = $new_04;
      __label__ = 18;
      break;
    } else if (($36 | 0) == -18) {
      __label__ = 19;
      break;
    } else if (($36 | 0) == -20) {
      __label__ = 20;
      break;
    } else if (($36 | 0) == -21) {
      __label__ = 26;
      break;
    } else {
      var $new_05 = $new_04;
      __label__ = 28;
      break;
    }
   case 13:
    var $38 = _malloc(12);
    var $39 = $38;
    var $40 = ($38 | 0) == 0;
    if ($40) {
      var $new_05 = $new_04;
      __label__ = 28;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $42 = $38 + 8 | 0;
    var $43 = $42;
    HEAP32[$43 >> 2] = -1;
    var $44 = $38;
    HEAP32[$44 >> 2] = 0;
    var $45 = HEAP32[$ll >> 2];
    var $46 = $45 + 4 | 0;
    HEAP32[$46 >> 2] = $39;
    var $47 = HEAP32[$rl >> 2];
    var $48 = $47 + 4 | 0;
    HEAP32[$48 >> 2] = $39;
    var $49 = HEAP32[$lf >> 2];
    var $50 = $new_04 + 4 | 0;
    HEAP32[$50 >> 2] = $49;
    var $51 = HEAP32[$rf >> 2];
    var $52 = $new_04 | 0;
    HEAP32[$52 >> 2] = $51;
    HEAP32[$first >> 2] = $new_04;
    HEAP32[$last >> 2] = $39;
    var $53 = $33 | $rmt_0;
    var $_0 = $53;
    __label__ = 35;
    break;
   case 15:
    var $55 = HEAP32[$rf >> 2];
    var $56 = HEAP32[$ll >> 2];
    var $57 = $56 + 4 | 0;
    HEAP32[$57 >> 2] = $55;
    var $58 = HEAP32[$lf >> 2];
    HEAP32[$first >> 2] = $58;
    var $59 = HEAP32[$rl >> 2];
    HEAP32[$last >> 2] = $59;
    var $60 = $33 & $rmt_0;
    var $_0 = $60;
    __label__ = 35;
    break;
   case 16:
    var $62 = _malloc(12);
    var $63 = $62;
    var $64 = ($62 | 0) == 0;
    if ($64) {
      var $new_05 = $new_04;
      __label__ = 28;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    var $66 = $62 + 8 | 0;
    var $67 = $66;
    HEAP32[$67 >> 2] = -1;
    var $68 = $62;
    HEAP32[$68 >> 2] = 0;
    var $69 = $new_04 + 8 | 0;
    HEAP32[$69 >> 2] = -33;
    var $70 = HEAP32[$lf >> 2];
    var $71 = $new_04 + 4 | 0;
    HEAP32[$71 >> 2] = $70;
    var $72 = $new_04 | 0;
    HEAP32[$72 >> 2] = $63;
    var $73 = HEAP32[$ll >> 2];
    var $74 = $73 + 4 | 0;
    HEAP32[$74 >> 2] = $63;
    HEAP32[$first >> 2] = $new_04;
    HEAP32[$last >> 2] = $63;
    var $_0 = 1;
    __label__ = 35;
    break;
   case 18:
    var $storemerge1;
    var $rmt_1;
    HEAP32[$first >> 2] = $storemerge1;
    var $76 = ($33 | 0) != 0;
    var $77 = $76 ? -34 : -33;
    var $78 = $new_04 + 8 | 0;
    HEAP32[$78 >> 2] = $77;
    var $79 = HEAP32[$lf >> 2];
    var $80 = $new_04 | 0;
    HEAP32[$80 >> 2] = $79;
    var $81 = HEAP32[$ll >> 2];
    var $82 = $81 + 4 | 0;
    HEAP32[$82 >> 2] = $new_04;
    HEAP32[$last >> 2] = $new_04;
    var $_0 = $rmt_1;
    __label__ = 35;
    break;
   case 19:
    var $84 = HEAP32[$lf >> 2];
    var $rmt_1 = $33;
    var $storemerge1 = $84;
    __label__ = 18;
    break;
   case 20:
    var $86 = _malloc(12);
    var $87 = $86;
    var $88 = ($86 | 0) == 0;
    if ($88) {
      var $new_05 = $new_04;
      __label__ = 28;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $90 = $86 + 8 | 0;
    var $91 = $90;
    HEAP32[$91 >> 2] = -34;
    var $92 = HEAP32[$lf >> 2];
    var $93 = $86;
    HEAP32[$93 >> 2] = $92;
    var $94 = HEAP32[$ll >> 2];
    var $95 = $94 + 4 | 0;
    HEAP32[$95 >> 2] = $new_04;
    var $96 = $new_04 + 4 | 0;
    HEAP32[$96 >> 2] = $87;
    var $97 = $tp + 4 | 0;
    var $98 = $97;
    var $99 = $98 + 2 | 0;
    var $100 = HEAP16[$99 >> 1];
    var $101 = $new_04;
    var $102 = $101 + 2 | 0;
    HEAP16[$102 >> 1] = $100;
    var $103 = $97;
    var $104 = HEAP16[$103 >> 1];
    var $105 = $new_04;
    HEAP16[$105 >> 1] = $104;
    var $106 = $104 << 16 >> 16 == 0;
    if ($106) {
      var $lmt_0 = 1;
      var $storemerge = $new_04;
      __label__ = 25;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    var $108 = $104 - 1 & 65535;
    HEAP16[$105 >> 1] = $108;
    var $109 = $100 << 16 >> 16 == -1;
    if ($109) {
      __label__ = 24;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $111 = $100 - 1 & 65535;
    HEAP16[$102 >> 1] = $111;
    __label__ = 24;
    break;
   case 24:
    var $113 = HEAP32[$lf >> 2];
    var $lmt_0 = $33;
    var $storemerge = $113;
    __label__ = 25;
    break;
   case 25:
    var $storemerge;
    var $lmt_0;
    HEAP32[$first >> 2] = $storemerge;
    HEAP32[$last >> 2] = $87;
    var $_0 = $lmt_0;
    __label__ = 35;
    break;
   case 26:
    var $116 = _malloc(12);
    var $117 = $116;
    var $118 = ($116 | 0) == 0;
    if ($118) {
      var $new_05 = $new_04;
      __label__ = 28;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $120 = $116 + 8 | 0;
    var $121 = $120;
    HEAP32[$121 >> 2] = -22;
    var $122 = $tp + 4 | 0;
    var $123 = $122;
    var $124 = HEAP32[$123 >> 2];
    var $125 = $116;
    HEAP32[$125 >> 2] = $124;
    var $126 = HEAP32[$123 >> 2];
    var $127 = $new_04 | 0;
    var $_c = $126;
    HEAP32[$127 >> 2] = $_c;
    var $128 = HEAP32[$lf >> 2];
    var $129 = $new_04 + 4 | 0;
    HEAP32[$129 >> 2] = $128;
    var $130 = HEAP32[$ll >> 2];
    var $131 = $130 + 4 | 0;
    HEAP32[$131 >> 2] = $117;
    HEAP32[$first >> 2] = $new_04;
    HEAP32[$last >> 2] = $117;
    var $_0 = $33;
    __label__ = 35;
    break;
   case 28:
    var $new_05;
    var $132 = HEAP32[$1 >> 2];
    var $133 = -$132 | 0;
    var $_mask = $133 & -16;
    var $134 = ($_mask | 0) == 32;
    if ($134) {
      __label__ = 29;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 29:
    var $136 = HEAP32[$rf >> 2];
    var $137 = ($136 | 0) == 0;
    if ($137) {
      __label__ = 31;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    _delgraph($136);
    __label__ = 31;
    break;
   case 31:
    var $139 = HEAP32[$lf >> 2];
    var $140 = ($139 | 0) == 0;
    if ($140) {
      __label__ = 33;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    _delgraph($139);
    __label__ = 33;
    break;
   case 33:
    var $142 = HEAP32[$1 >> 2];
    var $143 = ($142 | 0) == -34;
    if ($143) {
      var $_0 = -1;
      __label__ = 35;
      break;
    } else {
      __label__ = 34;
      break;
    }
   case 34:
    var $145 = $new_05;
    _free($145);
    var $_0 = -1;
    __label__ = 35;
    break;
   case 35:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_mkgraph["X"] = 1;
function _findposn($ep, $tp, $mb_cur_max) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $tp + 12 | 0;
    var $2 = HEAP32[$1 >> 2];
    if (($2 | 0) == -2 || ($2 | 0) == -3 || ($2 | 0) == -4 || ($2 | 0) == -5 || ($2 | 0) == -6 || ($2 | 0) == -8 || ($2 | 0) == -9 || ($2 | 0) == -10 || ($2 | 0) == -14) {
      __label__ = 10;
      break;
    } else if (($2 | 0) == -33 || ($2 | 0) == -34) {
      __label__ = 11;
      break;
    } else if (($2 | 0) == -17 || ($2 | 0) == -18 || ($2 | 0) == -19 || ($2 | 0) == -21) {
      __label__ = 12;
      break;
    } else if (($2 | 0) == -20) {
      __label__ = 13;
      break;
    } else if (($2 | 0) == -7) {
      var $_0 = $tp;
      __label__ = 32;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $4 = $ep + 4 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = $5 & 256;
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 10;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $9 = ($mb_cur_max | 0) > 1;
    if ($9) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    _towupper();
   case 6:
    var $12 = _toupper($2);
    var $13 = HEAP32[$1 >> 2];
    var $14 = ($12 | 0) == ($13 | 0);
    if ($14) {
      __label__ = 10;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $16 = _libuxre_reg1tree($13, 0);
    var $17 = ($16 | 0) == 0;
    if ($17) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $19 = $16 + 8 | 0;
    HEAP32[$19 >> 2] = $tp;
    var $20 = $ep + 8 | 0;
    var $21 = HEAP32[$20 >> 2];
    var $22 = $21 + 20 | 0;
    var $23 = HEAP32[$22 >> 2];
    var $24 = $23 + 1 | 0;
    HEAP32[$22 >> 2] = $24;
    var $25 = $16 | 0;
    var $_c2 = $23;
    HEAP32[$25 >> 2] = $_c2;
    HEAP32[$1 >> 2] = -33;
    var $26 = $tp | 0;
    HEAP32[$26 >> 2] = $16;
    var $27 = _libuxre_reg1tree($12, 0);
    var $28 = $tp + 4 | 0;
    HEAP32[$28 >> 2] = $27;
    var $29 = ($27 | 0) == 0;
    if ($29) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $31 = $27 + 8 | 0;
    HEAP32[$31 >> 2] = $tp;
    var $32 = HEAP32[$20 >> 2];
    var $33 = $32 + 20 | 0;
    var $34 = HEAP32[$33 >> 2];
    var $35 = $34 + 1 | 0;
    HEAP32[$33 >> 2] = $35;
    var $36 = $27 | 0;
    var $_c3 = $34;
    HEAP32[$36 >> 2] = $_c3;
    var $_0 = $tp;
    __label__ = 32;
    break;
   case 10:
    var $38 = $ep + 8 | 0;
    var $39 = HEAP32[$38 >> 2];
    var $40 = $39 + 20 | 0;
    var $41 = HEAP32[$40 >> 2];
    var $42 = $41 + 1 | 0;
    HEAP32[$40 >> 2] = $42;
    var $43 = $tp | 0;
    var $_c = $41;
    HEAP32[$43 >> 2] = $_c;
    var $_0 = $tp;
    __label__ = 32;
    break;
   case 11:
    var $45 = $tp + 4 | 0;
    var $46 = HEAP32[$45 >> 2];
    var $47 = _findposn($ep, $46, $mb_cur_max);
    HEAP32[$45 >> 2] = $47;
    var $48 = ($47 | 0) == 0;
    if ($48) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $50 = $tp | 0;
    var $51 = HEAP32[$50 >> 2];
    var $52 = _findposn($ep, $51, $mb_cur_max);
    HEAP32[$50 >> 2] = $52;
    var $53 = ($52 | 0) == 0;
    var $_tp = $53 ? 0 : $tp;
    return $_tp;
   case 13:
    var $55 = $tp | 0;
    var $56 = HEAP32[$55 >> 2];
    var $57 = _findposn($ep, $56, $mb_cur_max);
    HEAP32[$55 >> 2] = $57;
    var $58 = ($57 | 0) == 0;
    if ($58) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $60 = $tp + 8 | 0;
    var $61 = HEAP32[$60 >> 2];
    var $62 = $tp + 4 | 0;
    var $63 = $62;
    var $64 = $62;
    var $65 = HEAP16[$64 >> 1];
    var $66 = $65 & 65535;
    var $67 = $63 + 2 | 0;
    var $68 = HEAP16[$67 >> 1];
    var $69 = $68 & 65535;
    var $70 = _copy($ep, $57);
    var $71 = ($70 | 0) == 0;
    if ($71) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $73 = $70 + 8 | 0;
    HEAP32[$73 >> 2] = $tp;
    HEAP32[$1 >> 2] = -34;
    var $74 = $62 | 0;
    HEAP32[$74 >> 2] = $70;
    var $75 = $65 << 16 >> 16 == 0;
    if ($75) {
      __label__ = 16;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 16:
    var $77 = HEAP32[$55 >> 2];
    var $78 = _libuxre_reg1tree(-19, $77);
    HEAP32[$55 >> 2] = $78;
    var $79 = ($78 | 0) == 0;
    if ($79) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    var $81 = $78 + 8 | 0;
    HEAP32[$81 >> 2] = $tp;
    var $_1 = $tp;
    var $hi_2 = $69;
    __label__ = 24;
    break;
   case 18:
    var $83 = $68 << 16 >> 16 == -1;
    if ($83) {
      var $hi_0 = $69;
      __label__ = 20;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 19:
    var $85 = $69 - $66 | 0;
    var $86 = $68 << 16 >> 16 == $65 << 16 >> 16;
    if ($86) {
      var $hi_0 = $85;
      __label__ = 20;
      break;
    } else {
      var $hi_1_ph = $85;
      var $lo_0_ph = $66;
      __label__ = 21;
      break;
    }
   case 20:
    var $hi_0;
    var $88 = $66 - 1 | 0;
    var $hi_1_ph = $hi_0;
    var $lo_0_ph = $88;
    __label__ = 21;
    break;
   case 21:
    var $lo_0_ph;
    var $hi_1_ph;
    var $_01 = $tp;
    var $lo_0 = $lo_0_ph;
    __label__ = 22;
    break;
   case 22:
    var $lo_0;
    var $_01;
    var $90 = $lo_0 - 1 | 0;
    var $91 = ($90 | 0) == 0;
    if ($91) {
      var $_1 = $_01;
      var $hi_2 = $hi_1_ph;
      __label__ = 24;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $93 = _copy($ep, $70);
    var $94 = _libuxre_reg2tree(-34, $_01, $93);
    var $95 = ($94 | 0) == 0;
    if ($95) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      var $_01 = $94;
      var $lo_0 = $90;
      __label__ = 22;
      break;
    }
   case 24:
    var $hi_2;
    var $_1;
    if (($hi_2 | 0) == 65535) {
      __label__ = 25;
      break;
    } else if (($hi_2 | 0) == 0) {
      var $_3 = $_1;
      __label__ = 31;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 25:
    var $97 = $_1 + 4 | 0;
    var $98 = HEAP32[$97 >> 2];
    var $99 = _libuxre_reg1tree(-18, $98);
    HEAP32[$97 >> 2] = $99;
    var $100 = ($99 | 0) == 0;
    if ($100) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 26;
      break;
    }
   case 26:
    var $102 = $99 + 8 | 0;
    HEAP32[$102 >> 2] = $_1;
    var $_3 = $_1;
    __label__ = 31;
    break;
   case 27:
    var $104 = $_1 + 4 | 0;
    var $105 = HEAP32[$104 >> 2];
    var $106 = _libuxre_reg1tree(-19, $105);
    HEAP32[$104 >> 2] = $106;
    var $107 = ($106 | 0) == 0;
    if ($107) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 28:
    var $109 = $106 + 8 | 0;
    HEAP32[$109 >> 2] = $_1;
    var $_2 = $_1;
    var $hi_3 = $hi_2;
    __label__ = 29;
    break;
   case 29:
    var $hi_3;
    var $_2;
    var $111 = $hi_3 - 1 | 0;
    var $112 = ($111 | 0) == 0;
    if ($112) {
      var $_3 = $_2;
      __label__ = 31;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    var $114 = _copy($ep, $106);
    var $115 = _libuxre_reg2tree(-34, $_2, $114);
    var $116 = ($115 | 0) == 0;
    if ($116) {
      var $_0 = 0;
      __label__ = 32;
      break;
    } else {
      var $_2 = $115;
      var $hi_3 = $111;
      __label__ = 29;
      break;
    }
   case 31:
    var $_3;
    var $117 = $_3 + 8 | 0;
    HEAP32[$117 >> 2] = $61;
    var $_0 = $_3;
    __label__ = 32;
    break;
   case 32:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_findposn["X"] = 1;
function _nopskip($gp, $nop) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $gp + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 9;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = $gp + 8 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = ($6 | 0) == -1;
    if ($7) {
      __label__ = 4;
      break;
    } else {
      var $15 = $6;
      __label__ = 6;
      break;
    }
   case 4:
    var $9 = $gp | 0;
    var $10 = HEAP32[$9 >> 2];
    var $11 = ($10 | 0) == 0;
    if ($11) {
      __label__ = 5;
      break;
    } else {
      var $_0 = $2;
      __label__ = 10;
      break;
    }
   case 5:
    var $13 = HEAP32[$nop >> 2];
    HEAP32[$9 >> 2] = $13;
    HEAP32[$nop >> 2] = $gp;
    var $_pre = HEAP32[$5 >> 2];
    var $15 = $_pre;
    __label__ = 6;
    break;
   case 6:
    var $15;
    HEAP32[$1 >> 2] = 0;
    var $_off = $15 + 34 | 0;
    var $switch = $_off >>> 0 < 2;
    if ($switch) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $17 = $gp | 0;
    var $18 = HEAP32[$17 >> 2];
    var $19 = _nopskip($18, $nop);
    HEAP32[$17 >> 2] = $19;
    __label__ = 8;
    break;
   case 8:
    var $21 = _nopskip($2, $nop);
    HEAP32[$1 >> 2] = $21;
    var $22 = HEAP32[$5 >> 2];
    var $23 = ($22 | 0) == -1;
    if ($23) {
      var $_0 = $21;
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $_0 = $gp;
    __label__ = 10;
    break;
   case 10:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _firstop($tp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $tp_tr = $tp;
    __label__ = 3;
    break;
   case 3:
    var $tp_tr;
    var $1 = $tp_tr + 12 | 0;
    var $2 = HEAP32[$1 >> 2];
    if (($2 | 0) == -33) {
      __label__ = 4;
      break;
    } else if (($2 | 0) == -20) {
      __label__ = 7;
      break;
    } else if (($2 | 0) == -34 || ($2 | 0) == -18 || ($2 | 0) == -21) {
      __label__ = 8;
      break;
    } else if (($2 | 0) == -2) {
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 4:
    var $4 = $tp_tr | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = _firstop($5);
    var $7 = ($6 | 0) == 0;
    if ($7) {
      var $_0 = 0;
      __label__ = 11;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $9 = $tp_tr + 4 | 0;
    var $10 = HEAP32[$9 >> 2];
    var $11 = _firstop($10);
    var $12 = ($6 | 0) == ($11 | 0);
    if ($12) {
      __label__ = 6;
      break;
    } else {
      var $_0 = 0;
      __label__ = 11;
      break;
    }
   case 6:
    var $_0 = $6;
    __label__ = 11;
    break;
   case 7:
    var $15 = $tp_tr + 4 | 0;
    var $16 = $15;
    var $17 = HEAP16[$16 >> 1];
    var $18 = $17 << 16 >> 16 == 0;
    if ($18) {
      var $_0 = 0;
      __label__ = 11;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $20 = $tp_tr | 0;
    var $21 = HEAP32[$20 >> 2];
    var $tp_tr = $21;
    __label__ = 3;
    break;
   case 9:
    var $23 = ($2 | 0) < 0;
    if ($23) {
      var $_0 = 0;
      __label__ = 11;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $_0 = $2;
    __label__ = 11;
    break;
   case 11:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _lex($lxp) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 4;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $wc = __stackBase__;
    var $1 = $lxp + 48 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $lxp + 4 | 0;
    var $4 = $lxp + 16 | 0;
    var $5 = $lxp + 20 | 0;
    var $_pre = HEAP32[$3 >> 2];
    var $6 = $_pre;
    __label__ = 3;
    break;
   case 3:
    var $6;
    var $7 = $6 + 1 | 0;
    HEAP32[$3 >> 2] = $7;
    var $8 = HEAP8[$6];
    var $9 = $8 & 255;
    HEAP32[$wc >> 2] = $9;
    if (($9 | 0) == 0) {
      __label__ = 4;
      break;
    } else if (($9 | 0) == 40) {
      __label__ = 5;
      break;
    } else if (($9 | 0) == 41) {
      __label__ = 14;
      break;
    } else if (($9 | 0) == 46) {
      __label__ = 22;
      break;
    } else if (($9 | 0) == 42) {
      __label__ = 24;
      break;
    } else if (($9 | 0) == 94) {
      __label__ = 30;
      break;
    } else if (($9 | 0) == 36) {
      __label__ = 41;
      break;
    } else if (($9 | 0) == 43) {
      __label__ = 54;
      break;
    } else if (($9 | 0) == 63) {
      __label__ = 60;
      break;
    } else if (($9 | 0) == 10) {
      __label__ = 66;
      break;
    } else if (($9 | 0) == 124) {
      __label__ = 72;
      break;
    } else if (($9 | 0) == 91) {
      __label__ = 74;
      break;
    } else if (($9 | 0) == 123) {
      __label__ = 92;
      break;
    } else if (($9 | 0) == 92) {
      __label__ = 122;
      break;
    } else {
      var $598 = $9;
      var $597 = $7;
      __label__ = 183;
      break;
    }
   case 4:
    HEAP32[$3 >> 2] = $6;
    HEAP32[$wc >> 2] = -14;
    __label__ = 192;
    break;
   case 5:
    var $12 = HEAP32[$4 >> 2];
    var $13 = $12 & 16;
    var $14 = ($13 | 0) == 0;
    if ($14) {
      __label__ = 192;
      break;
    } else {
      var $16 = $12;
      __label__ = 6;
      break;
    }
   case 6:
    var $16;
    var $17 = $16 & 64;
    var $18 = ($17 | 0) == 0;
    var $19 = $lxp + 28 | 0;
    if ($18) {
      __label__ = 7;
      break;
    } else {
      var $_pre_phi = $19;
      __label__ = 13;
      break;
    }
   case 7:
    var $21 = HEAP32[$19 >> 2];
    var $22 = $lxp + 36 | 0;
    var $23 = HEAP32[$22 >> 2];
    var $24 = $21 >>> 0 < $23 >>> 0;
    if ($24) {
      __label__ = 8;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 8:
    var $_phi_trans_insert = $lxp + 8 | 0;
    var $_pre16 = HEAP32[$_phi_trans_insert >> 2];
    var $36 = $21;
    var $35 = $_pre16;
    __label__ = 12;
    break;
   case 9:
    var $26 = $23 + 8 | 0;
    HEAP32[$22 >> 2] = $26;
    var $27 = $lxp + 8 | 0;
    var $28 = HEAP32[$27 >> 2];
    var $29 = _realloc($28, $26);
    var $30 = ($29 | 0) == 0;
    if ($30) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    var $32 = $lxp + 44 | 0;
    HEAP32[$32 >> 2] = 17;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 11:
    HEAP32[$27 >> 2] = $29;
    var $_pre6 = HEAP32[$19 >> 2];
    var $36 = $_pre6;
    var $35 = $29;
    __label__ = 12;
    break;
   case 12:
    var $35;
    var $36;
    var $37 = $35 + $36 | 0;
    HEAP8[$37] = 0;
    var $_pre_phi = $19;
    __label__ = 13;
    break;
   case 13:
    var $_pre_phi;
    var $38 = HEAP32[$_pre_phi >> 2];
    var $39 = $38 + 1 | 0;
    HEAP32[$_pre_phi >> 2] = $39;
    HEAP32[$wc >> 2] = -21;
    __label__ = 192;
    break;
   case 14:
    var $41 = HEAP32[$4 >> 2];
    var $42 = $41 & 16;
    var $43 = ($42 | 0) == 0;
    if ($43) {
      __label__ = 192;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $45 = $lxp + 32 | 0;
    var $46 = HEAP32[$45 >> 2];
    var $47 = $lxp + 28 | 0;
    var $48 = HEAP32[$47 >> 2];
    var $49 = $46 >>> 0 < $48 >>> 0;
    if ($49) {
      __label__ = 16;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 16:
    var $51 = $46 + 1 | 0;
    HEAP32[$45 >> 2] = $51;
    var $54 = $41;
    var $53 = $48;
    __label__ = 17;
    break;
   case 17:
    var $53;
    var $54;
    var $55 = $54 & 64;
    var $56 = ($55 | 0) == 0;
    if ($56) {
      __label__ = 18;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 18:
    var $58 = $lxp + 8 | 0;
    var $59 = HEAP32[$58 >> 2];
    var $num_0 = $53;
    __label__ = 19;
    break;
   case 19:
    var $num_0;
    var $61 = $num_0 - 1 | 0;
    var $62 = $59 + $61 | 0;
    var $63 = HEAP8[$62];
    var $64 = $63 << 24 >> 24 == 0;
    if ($64) {
      __label__ = 20;
      break;
    } else {
      var $num_0 = $61;
      __label__ = 19;
      break;
    }
   case 20:
    HEAP8[$62] = 1;
    __label__ = 21;
    break;
   case 21:
    HEAP32[$wc >> 2] = -22;
    __label__ = 192;
    break;
   case 22:
    HEAP32[$wc >> 2] = -5;
    var $68 = HEAP32[$4 >> 2];
    var $69 = $68 & 1024;
    var $70 = ($69 | 0) == 0;
    if ($70) {
      __label__ = 192;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    HEAP32[$wc >> 2] = -6;
    __label__ = 192;
    break;
   case 24:
    var $73 = HEAP32[$4 >> 2];
    var $74 = $73 & 33554432;
    var $75 = ($74 | 0) == 0;
    if ($75) {
      __label__ = 29;
      break;
    } else {
      var $76 = $7;
      __label__ = 25;
      break;
    }
   case 25:
    var $76;
    var $77 = HEAP8[$76];
    var $78 = $77 & 255;
    if (($78 | 0) == 43) {
      __label__ = 26;
      break;
    } else if (($78 | 0) == 42) {
      __label__ = 27;
      break;
    } else if (($78 | 0) == 63) {
      __label__ = 28;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 26:
    var $80 = $73 & 2;
    var $81 = ($80 | 0) == 0;
    if ($81) {
      __label__ = 29;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $storemerge = $76 + 1 | 0;
    HEAP32[$3 >> 2] = $storemerge;
    var $76 = $storemerge;
    __label__ = 25;
    break;
   case 28:
    var $83 = $73 & 4;
    var $84 = ($83 | 0) == 0;
    if ($84) {
      __label__ = 29;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 29:
    HEAP32[$wc >> 2] = -17;
    __label__ = 192;
    break;
   case 30:
    var $86 = HEAP32[$4 >> 2];
    var $87 = $86 & 32;
    var $88 = ($87 | 0) == 0;
    if ($88) {
      __label__ = 31;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 31:
    var $90 = HEAP32[$5 >> 2];
    var $91 = ($90 | 0) == -33;
    if ($91) {
      __label__ = 32;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 32:
    var $93 = $86 & 33554432;
    var $94 = ($93 | 0) == 0;
    if ($94) {
      __label__ = 40;
      break;
    } else {
      var $optional_0_ph = 0;
      var $95 = $7;
      __label__ = 33;
      break;
    }
   case 33:
    var $95;
    var $optional_0_ph;
    var $97 = $95;
    __label__ = 34;
    break;
   case 34:
    var $97;
    var $98 = HEAP8[$97];
    var $99 = $98 & 255;
    if (($99 | 0) == 43) {
      __label__ = 35;
      break;
    } else if (($99 | 0) == 63) {
      __label__ = 37;
      break;
    } else if (($99 | 0) == 42) {
      __label__ = 38;
      break;
    } else {
      __label__ = 39;
      break;
    }
   case 35:
    var $101 = $86 & 2;
    var $102 = ($101 | 0) == 0;
    if ($102) {
      __label__ = 39;
      break;
    } else {
      __label__ = 36;
      break;
    }
   case 36:
    var $104 = $97 + 1 | 0;
    HEAP32[$3 >> 2] = $104;
    var $97 = $104;
    __label__ = 34;
    break;
   case 37:
    var $106 = $86 & 4;
    var $107 = ($106 | 0) == 0;
    if ($107) {
      __label__ = 39;
      break;
    } else {
      __label__ = 38;
      break;
    }
   case 38:
    var $108 = $97 + 1 | 0;
    HEAP32[$3 >> 2] = $108;
    var $optional_0_ph = 1;
    var $95 = $108;
    __label__ = 33;
    break;
   case 39:
    var $109 = ($optional_0_ph | 0) == 0;
    if ($109) {
      __label__ = 40;
      break;
    } else {
      var $6 = $97;
      __label__ = 3;
      break;
    }
   case 40:
    HEAP32[$wc >> 2] = -2;
    __label__ = 192;
    break;
   case 41:
    var $112 = HEAP32[$4 >> 2];
    var $113 = $112 & 32;
    var $114 = ($113 | 0) == 0;
    if ($114) {
      __label__ = 42;
      break;
    } else {
      __label__ = 45;
      break;
    }
   case 42:
    var $116 = HEAP8[$7];
    var $117 = $116 << 24 >> 24 == 0;
    if ($117) {
      __label__ = 45;
      break;
    } else {
      __label__ = 43;
      break;
    }
   case 43:
    var $119 = $112 & 1;
    var $120 = ($119 | 0) != 0;
    var $121 = $116 << 24 >> 24 == 124;
    var $or_cond = $120 & $121;
    if ($or_cond) {
      __label__ = 45;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 44:
    var $123 = $112 & 2097152;
    var $124 = ($123 | 0) != 0;
    var $125 = $116 << 24 >> 24 == 10;
    var $or_cond15 = $124 & $125;
    if ($or_cond15) {
      __label__ = 45;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 45:
    var $127 = $112 & 33554432;
    var $128 = ($127 | 0) == 0;
    if ($128) {
      __label__ = 53;
      break;
    } else {
      var $optional1_0_ph = 0;
      var $129 = $7;
      __label__ = 46;
      break;
    }
   case 46:
    var $129;
    var $optional1_0_ph;
    var $131 = $129;
    __label__ = 47;
    break;
   case 47:
    var $131;
    var $132 = HEAP8[$131];
    var $133 = $132 & 255;
    if (($133 | 0) == 43) {
      __label__ = 48;
      break;
    } else if (($133 | 0) == 63) {
      __label__ = 50;
      break;
    } else if (($133 | 0) == 42) {
      __label__ = 51;
      break;
    } else {
      __label__ = 52;
      break;
    }
   case 48:
    var $135 = $112 & 2;
    var $136 = ($135 | 0) == 0;
    if ($136) {
      __label__ = 52;
      break;
    } else {
      __label__ = 49;
      break;
    }
   case 49:
    var $138 = $131 + 1 | 0;
    HEAP32[$3 >> 2] = $138;
    var $131 = $138;
    __label__ = 47;
    break;
   case 50:
    var $140 = $112 & 4;
    var $141 = ($140 | 0) == 0;
    if ($141) {
      __label__ = 52;
      break;
    } else {
      __label__ = 51;
      break;
    }
   case 51:
    var $142 = $131 + 1 | 0;
    HEAP32[$3 >> 2] = $142;
    var $optional1_0_ph = 1;
    var $129 = $142;
    __label__ = 46;
    break;
   case 52:
    var $143 = ($optional1_0_ph | 0) == 0;
    if ($143) {
      __label__ = 53;
      break;
    } else {
      var $6 = $131;
      __label__ = 3;
      break;
    }
   case 53:
    HEAP32[$wc >> 2] = -3;
    __label__ = 192;
    break;
   case 54:
    var $146 = HEAP32[$4 >> 2];
    var $147 = $146 & 2;
    var $148 = ($147 | 0) == 0;
    if ($148) {
      __label__ = 192;
      break;
    } else {
      __label__ = 55;
      break;
    }
   case 55:
    HEAP32[$wc >> 2] = -18;
    var $150 = $146 & 33554432;
    var $151 = ($150 | 0) == 0;
    if ($151) {
      __label__ = 192;
      break;
    } else {
      var $152 = $7;
      __label__ = 56;
      break;
    }
   case 56:
    var $152;
    var $153 = HEAP8[$152];
    var $154 = $153 & 255;
    if (($154 | 0) == 63) {
      __label__ = 57;
      break;
    } else if (($154 | 0) == 42) {
      __label__ = 58;
      break;
    } else if (($154 | 0) == 43) {
      __label__ = 59;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 57:
    var $156 = $146 & 4;
    var $157 = ($156 | 0) == 0;
    if ($157) {
      __label__ = 192;
      break;
    } else {
      __label__ = 58;
      break;
    }
   case 58:
    HEAP32[$wc >> 2] = -17;
    __label__ = 59;
    break;
   case 59:
    var $160 = $152 + 1 | 0;
    HEAP32[$3 >> 2] = $160;
    var $152 = $160;
    __label__ = 56;
    break;
   case 60:
    var $162 = HEAP32[$4 >> 2];
    var $163 = $162 & 4;
    var $164 = ($163 | 0) == 0;
    if ($164) {
      __label__ = 192;
      break;
    } else {
      __label__ = 61;
      break;
    }
   case 61:
    HEAP32[$wc >> 2] = -19;
    var $166 = $162 & 33554432;
    var $167 = ($166 | 0) == 0;
    if ($167) {
      __label__ = 192;
      break;
    } else {
      var $168 = $7;
      __label__ = 62;
      break;
    }
   case 62:
    var $168;
    var $169 = HEAP8[$168];
    var $170 = $169 & 255;
    if (($170 | 0) == 43) {
      __label__ = 63;
      break;
    } else if (($170 | 0) == 42) {
      __label__ = 64;
      break;
    } else if (($170 | 0) == 63) {
      __label__ = 65;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 63:
    var $172 = $162 & 2;
    var $173 = ($172 | 0) == 0;
    if ($173) {
      __label__ = 192;
      break;
    } else {
      __label__ = 64;
      break;
    }
   case 64:
    HEAP32[$wc >> 2] = -17;
    __label__ = 65;
    break;
   case 65:
    var $176 = $168 + 1 | 0;
    HEAP32[$3 >> 2] = $176;
    var $168 = $176;
    __label__ = 62;
    break;
   case 66:
    var $178 = HEAP32[$4 >> 2];
    var $179 = $178 & 2097152;
    var $180 = ($179 | 0) == 0;
    if ($180) {
      __label__ = 70;
      break;
    } else {
      __label__ = 67;
      break;
    }
   case 67:
    var $182 = $lxp + 28 | 0;
    var $183 = HEAP32[$182 >> 2];
    var $184 = $lxp + 32 | 0;
    var $185 = HEAP32[$184 >> 2];
    var $186 = ($183 | 0) == ($185 | 0);
    if ($186) {
      __label__ = 69;
      break;
    } else {
      __label__ = 68;
      break;
    }
   case 68:
    var $188 = $lxp + 44 | 0;
    HEAP32[$188 >> 2] = 13;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 69:
    HEAP32[$wc >> 2] = -33;
    __label__ = 192;
    break;
   case 70:
    var $191 = $178 & 1024;
    var $192 = ($191 | 0) == 0;
    if ($192) {
      __label__ = 192;
      break;
    } else {
      __label__ = 71;
      break;
    }
   case 71:
    var $194 = $178 | 536870912;
    HEAP32[$4 >> 2] = $194;
    __label__ = 192;
    break;
   case 72:
    var $196 = HEAP32[$4 >> 2];
    var $197 = $196 & 1;
    var $198 = ($197 | 0) == 0;
    if ($198) {
      __label__ = 192;
      break;
    } else {
      __label__ = 73;
      break;
    }
   case 73:
    HEAP32[$wc >> 2] = -33;
    __label__ = 192;
    break;
   case 74:
    var $201 = _malloc(220);
    var $202 = $201;
    var $203 = $lxp | 0;
    HEAP32[$203 >> 2] = $202;
    var $204 = ($201 | 0) == 0;
    if ($204) {
      __label__ = 75;
      break;
    } else {
      __label__ = 76;
      break;
    }
   case 75:
    var $206 = $lxp + 44 | 0;
    HEAP32[$206 >> 2] = 17;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 76:
    var $208 = HEAP32[$4 >> 2];
    var $209 = ($208 | 0) > -1;
    if ($209) {
      __label__ = 78;
      break;
    } else {
      __label__ = 77;
      break;
    }
   case 77:
    var $_phi_trans_insert17 = $lxp + 40 | 0;
    var $_pre18 = HEAP32[$_phi_trans_insert17 >> 2];
    var $266 = $_pre18;
    __label__ = 83;
    break;
   case 78:
    var $211 = $208 | -2147483648;
    HEAP32[$4 >> 2] = $211;
    var $212 = $lxp + 40 | 0;
    var $213 = $208 & 256;
    var $214 = ($213 | 0) == 0;
    var $storemerge30 = $214 ? 0 : 2;
    var $215 = $208 & 1024;
    var $216 = $storemerge30 | 4;
    var $217 = ($215 | 0) == 0;
    var $storemerge30_ = $217 ? $storemerge30 : $216;
    var $218 = $208 & 16384;
    var $219 = ($218 | 0) == 0;
    var $220 = $storemerge30_ | 8;
    var $storemerge32 = $219 ? $storemerge30_ : $220;
    var $221 = $208 & 32768;
    var $222 = $storemerge32 | 4096;
    var $223 = ($221 | 0) == 0;
    var $storemerge32_ = $223 ? $storemerge32 : $222;
    var $224 = $208 & 65536;
    var $225 = ($224 | 0) == 0;
    var $226 = $storemerge32_ | 16;
    var $storemerge34 = $225 ? $storemerge32_ : $226;
    var $227 = $208 & 131072;
    var $228 = $storemerge34 | 512;
    var $229 = ($227 | 0) == 0;
    var $storemerge34_ = $229 ? $storemerge34 : $228;
    var $230 = $208 & 262144;
    var $231 = ($230 | 0) == 0;
    var $232 = $storemerge34_ | 128;
    var $storemerge36 = $231 ? $storemerge34_ : $232;
    var $233 = $208 & 1048576;
    var $234 = $storemerge36 | 1024;
    var $235 = ($233 | 0) == 0;
    var $storemerge36_ = $235 ? $storemerge36 : $234;
    var $236 = $208 & 2097152;
    var $237 = ($236 | 0) == 0;
    var $238 = $storemerge36_ | 32;
    var $storemerge38 = $237 ? $storemerge36_ : $238;
    var $239 = $208 & 4194304;
    var $240 = $storemerge38 | 2048;
    var $241 = ($239 | 0) == 0;
    var $storemerge38_ = $241 ? $storemerge38 : $240;
    var $242 = $208 & 8388608;
    var $243 = ($242 | 0) == 0;
    var $244 = $storemerge38_ | 256;
    var $storemerge40 = $243 ? $storemerge38_ : $244;
    var $245 = $208 & 67108864;
    var $246 = $storemerge40 | 8192;
    var $247 = ($245 | 0) == 0;
    var $storemerge40_ = $247 ? $storemerge40 : $246;
    var $248 = $208 & 134217728;
    var $249 = ($248 | 0) == 0;
    var $250 = $storemerge40_ | 16384;
    var $storemerge42 = $249 ? $storemerge40_ : $250;
    HEAP32[$212 >> 2] = $storemerge42;
    var $251 = HEAP32[_libuxre_lc_collate_curinfo + 8 >> 2];
    var $252 = ($251 | 0) == 0;
    if ($252) {
      var $col_0 = 0;
      __label__ = 82;
      break;
    } else {
      __label__ = 79;
      break;
    }
   case 79:
    var $254 = HEAP16[_libuxre_lc_collate_curinfo + 34 >> 1];
    var $255 = $254 & 65535;
    var $256 = $255 & 1;
    var $257 = ($256 | 0) == 0;
    if ($257) {
      __label__ = 80;
      break;
    } else {
      var $col_0 = 0;
      __label__ = 82;
      break;
    }
   case 80:
    var $259 = $255 & 4;
    var $260 = ($259 | 0) == 0;
    if ($260) {
      var $col_0 = _libuxre_lc_collate_curinfo;
      __label__ = 82;
      break;
    } else {
      __label__ = 81;
      break;
    }
   case 81:
    var $262 = $208 | -1610612736;
    HEAP32[$4 >> 2] = $262;
    var $col_0 = _libuxre_lc_collate_curinfo;
    __label__ = 82;
    break;
   case 82:
    var $col_0;
    var $264 = $lxp + 12 | 0;
    HEAP32[$264 >> 2] = $col_0;
    var $266 = $storemerge42;
    __label__ = 83;
    break;
   case 83:
    var $266;
    var $267 = HEAP32[$3 >> 2];
    var $268 = HEAP8[$267];
    var $269 = $268 << 24 >> 24 == 94;
    if ($269) {
      __label__ = 84;
      break;
    } else {
      var $n_0 = $266;
      __label__ = 85;
      break;
    }
   case 84:
    var $271 = $266 | 1;
    var $272 = $267 + 1 | 0;
    HEAP32[$3 >> 2] = $272;
    var $n_0 = $271;
    __label__ = 85;
    break;
   case 85:
    var $n_0;
    var $273 = $lxp + 12 | 0;
    var $274 = HEAP32[$273 >> 2];
    var $275 = $201;
    HEAP32[$275 >> 2] = $274;
    var $276 = HEAP32[$203 >> 2];
    var $277 = HEAP32[$3 >> 2];
    var $278 = _libuxre_bktmbcomp($276, $277, $n_0, $2);
    var $279 = ($278 | 0) < 0;
    if ($279) {
      __label__ = 86;
      break;
    } else {
      __label__ = 87;
      break;
    }
   case 86:
    var $281 = HEAP32[$203 >> 2];
    var $282 = $281;
    _free($282);
    var $283 = -$278 | 0;
    var $284 = $lxp + 44 | 0;
    HEAP32[$284 >> 2] = $283;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 87:
    var $286 = HEAP32[$4 >> 2];
    var $287 = $286 & 536871936;
    var $288 = ($287 | 0) == 1024;
    if ($288) {
      __label__ = 88;
      break;
    } else {
      __label__ = 91;
      break;
    }
   case 88:
    var $290 = HEAP32[$3 >> 2];
    var $291 = $290 - 1 | 0;
    var $292 = HEAP8[$291];
    var $293 = $292 << 24 >> 24 == 91;
    if ($293) {
      __label__ = 89;
      break;
    } else {
      __label__ = 91;
      break;
    }
   case 89:
    var $295 = HEAP32[$203 >> 2];
    var $296 = _libuxre_bktmbexec($295, 10, 0, 1);
    var $297 = ($296 | 0) == 0;
    if ($297) {
      __label__ = 90;
      break;
    } else {
      __label__ = 91;
      break;
    }
   case 90:
    var $299 = HEAP32[$4 >> 2];
    var $300 = $299 | 536870912;
    HEAP32[$4 >> 2] = $300;
    __label__ = 91;
    break;
   case 91:
    var $301 = HEAP32[$3 >> 2];
    var $302 = $301 + $278 | 0;
    HEAP32[$3 >> 2] = $302;
    HEAP32[$wc >> 2] = -9;
    __label__ = 192;
    break;
   case 92:
    var $304 = HEAP32[$4 >> 2];
    var $305 = $304 & 16777224;
    var $306 = ($305 | 0) == 8;
    if ($306) {
      var $309 = $7;
      var $308 = $304;
      __label__ = 93;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 93:
    var $308;
    var $309;
    var $310 = HEAP8[$309];
    var $311 = $310 & 255;
    var $isdigittmp = $311 - 48 | 0;
    var $isdigit = $isdigittmp >>> 0 < 10;
    if ($isdigit) {
      var $num_1 = $isdigittmp;
      var $318 = $309;
      __label__ = 96;
      break;
    } else {
      var $312 = $309;
      __label__ = 94;
      break;
    }
   case 94:
    var $312;
    var $313 = $lxp + 44 | 0;
    HEAP32[$313 >> 2] = 15;
    var $314 = HEAP8[$312];
    var $315 = $314 << 24 >> 24 == 0;
    if ($315) {
      __label__ = 95;
      break;
    } else {
      var $_0 = -1;
      __label__ = 193;
      break;
    }
   case 95:
    HEAP32[$313 >> 2] = 14;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 96:
    var $318;
    var $num_1;
    var $319 = $318 + 1 | 0;
    HEAP32[$3 >> 2] = $319;
    var $320 = HEAP8[$319];
    var $321 = $320 & 255;
    HEAP32[$wc >> 2] = $321;
    var $isdigittmp7 = $321 - 48 | 0;
    var $isdigit8 = $isdigittmp7 >>> 0 < 10;
    if ($isdigit8) {
      __label__ = 97;
      break;
    } else {
      __label__ = 98;
      break;
    }
   case 97:
    var $323 = $num_1 * 10 | 0;
    var $324 = $323 - 48 | 0;
    var $325 = $324 + $321 | 0;
    var $326 = $325 >>> 0 > 5100;
    if ($326) {
      var $312 = $319;
      __label__ = 94;
      break;
    } else {
      var $num_1 = $325;
      var $318 = $319;
      __label__ = 96;
      break;
    }
   case 98:
    var $328 = $num_1 & 65535;
    var $329 = $lxp;
    var $330 = $lxp;
    HEAP16[$330 >> 1] = $328;
    var $331 = $329 + 2 | 0;
    HEAP16[$331 >> 1] = $328;
    var $332 = $320 << 24 >> 24 == 44;
    if ($332) {
      __label__ = 99;
      break;
    } else {
      var $355 = $321;
      var $354 = $319;
      var $353 = $328;
      __label__ = 104;
      break;
    }
   case 99:
    HEAP16[$331 >> 1] = -1;
    var $334 = $318 + 2 | 0;
    HEAP32[$3 >> 2] = $334;
    var $335 = HEAP8[$334];
    var $336 = $335 & 255;
    HEAP32[$wc >> 2] = $336;
    var $isdigittmp9 = $336 - 48 | 0;
    var $isdigit10 = $isdigittmp9 >>> 0 < 10;
    if ($isdigit10) {
      var $num_2 = $isdigittmp9;
      var $338 = $334;
      __label__ = 100;
      break;
    } else {
      var $355 = $336;
      var $354 = $334;
      var $353 = -1;
      __label__ = 104;
      break;
    }
   case 100:
    var $338;
    var $num_2;
    var $339 = $338 + 1 | 0;
    HEAP32[$3 >> 2] = $339;
    var $340 = HEAP8[$339];
    var $341 = $340 & 255;
    HEAP32[$wc >> 2] = $341;
    var $isdigittmp11 = $341 - 48 | 0;
    var $isdigit12 = $isdigittmp11 >>> 0 < 10;
    if ($isdigit12) {
      __label__ = 101;
      break;
    } else {
      __label__ = 102;
      break;
    }
   case 101:
    var $343 = $num_2 * 10 | 0;
    var $344 = $343 - 48 | 0;
    var $345 = $344 + $341 | 0;
    var $346 = $345 >>> 0 > 5100;
    if ($346) {
      var $312 = $339;
      __label__ = 94;
      break;
    } else {
      var $num_2 = $345;
      var $338 = $339;
      __label__ = 100;
      break;
    }
   case 102:
    var $348 = $num_1 & 65535;
    var $349 = $num_2 >>> 0 < $348 >>> 0;
    if ($349) {
      var $312 = $339;
      __label__ = 94;
      break;
    } else {
      __label__ = 103;
      break;
    }
   case 103:
    var $351 = $num_2 & 65535;
    HEAP16[$331 >> 1] = $351;
    var $355 = $341;
    var $354 = $339;
    var $353 = $351;
    __label__ = 104;
    break;
   case 104:
    var $353;
    var $354;
    var $355;
    var $356 = $308 & 8;
    var $357 = ($356 | 0) == 0;
    if ($357) {
      __label__ = 105;
      break;
    } else {
      var $365 = $355;
      var $364 = $354;
      __label__ = 107;
      break;
    }
   case 105:
    var $359 = ($355 | 0) == 92;
    if ($359) {
      __label__ = 106;
      break;
    } else {
      var $312 = $354;
      __label__ = 94;
      break;
    }
   case 106:
    var $361 = $354 + 1 | 0;
    HEAP32[$3 >> 2] = $361;
    var $362 = HEAP8[$361];
    var $363 = $362 & 255;
    HEAP32[$wc >> 2] = $363;
    var $365 = $363;
    var $364 = $361;
    __label__ = 107;
    break;
   case 107:
    var $364;
    var $365;
    var $366 = ($365 | 0) == 125;
    if ($366) {
      __label__ = 108;
      break;
    } else {
      var $312 = $364;
      __label__ = 94;
      break;
    }
   case 108:
    var $368 = $364 + 1 | 0;
    HEAP32[$3 >> 2] = $368;
    HEAP32[$wc >> 2] = -20;
    var $369 = ($353 & 65535) < 2;
    if ($369) {
      __label__ = 109;
      break;
    } else {
      __label__ = 114;
      break;
    }
   case 109:
    var $371 = $328 << 16 >> 16 == 1;
    if ($371) {
      __label__ = 110;
      break;
    } else {
      __label__ = 111;
      break;
    }
   case 110:
    HEAP32[$wc >> 2] = -1;
    __label__ = 192;
    break;
   case 111:
    var $374 = $353 << 16 >> 16 == 0;
    if ($374) {
      __label__ = 112;
      break;
    } else {
      __label__ = 113;
      break;
    }
   case 112:
    HEAP32[$wc >> 2] = -7;
    __label__ = 192;
    break;
   case 113:
    HEAP32[$wc >> 2] = -19;
    __label__ = 192;
    break;
   case 114:
    var $378 = $353 << 16 >> 16 == -1;
    if ($378) {
      __label__ = 115;
      break;
    } else {
      __label__ = 120;
      break;
    }
   case 115:
    if ($328 << 16 >> 16 == 0) {
      __label__ = 116;
      break;
    } else if ($328 << 16 >> 16 == 1) {
      __label__ = 117;
      break;
    } else {
      __label__ = 118;
      break;
    }
   case 116:
    HEAP32[$wc >> 2] = -17;
    __label__ = 192;
    break;
   case 117:
    HEAP32[$wc >> 2] = -18;
    __label__ = 192;
    break;
   case 118:
    var $383 = ($328 & 65535) > 255;
    if ($383) {
      __label__ = 119;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 119:
    var $385 = $308 | 536870912;
    HEAP32[$4 >> 2] = $385;
    __label__ = 192;
    break;
   case 120:
    var $387 = ($353 & 65535) > 255;
    if ($387) {
      __label__ = 121;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 121:
    var $389 = $308 | 536870912;
    HEAP32[$4 >> 2] = $389;
    __label__ = 192;
    break;
   case 122:
    var $391 = $6 + 2 | 0;
    HEAP32[$3 >> 2] = $391;
    var $392 = HEAP8[$7];
    var $393 = $392 & 255;
    HEAP32[$wc >> 2] = $393;
    if (($393 | 0) == 0) {
      __label__ = 123;
      break;
    } else if (($393 | 0) == 60) {
      __label__ = 124;
      break;
    } else if (($393 | 0) == 62) {
      __label__ = 126;
      break;
    } else if (($393 | 0) == 40) {
      __label__ = 128;
      break;
    } else if (($393 | 0) == 41) {
      __label__ = 129;
      break;
    } else if (($393 | 0) == 123) {
      __label__ = 132;
      break;
    } else if (($393 | 0) == 49 || ($393 | 0) == 50 || ($393 | 0) == 51 || ($393 | 0) == 52 || ($393 | 0) == 53 || ($393 | 0) == 54 || ($393 | 0) == 55 || ($393 | 0) == 56 || ($393 | 0) == 57) {
      __label__ = 133;
      break;
    } else if (($393 | 0) == 48) {
      __label__ = 150;
      break;
    } else if (($393 | 0) == 97) {
      __label__ = 156;
      break;
    } else if (($393 | 0) == 98) {
      __label__ = 158;
      break;
    } else if (($393 | 0) == 102) {
      __label__ = 160;
      break;
    } else if (($393 | 0) == 110) {
      __label__ = 162;
      break;
    } else if (($393 | 0) == 114) {
      __label__ = 165;
      break;
    } else if (($393 | 0) == 116) {
      __label__ = 167;
      break;
    } else if (($393 | 0) == 118) {
      __label__ = 169;
      break;
    } else if (($393 | 0) == 120) {
      __label__ = 171;
      break;
    } else {
      var $598 = $393;
      var $597 = $391;
      __label__ = 183;
      break;
    }
   case 123:
    var $395 = $lxp + 44 | 0;
    HEAP32[$395 >> 2] = 7;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 124:
    var $397 = HEAP32[$4 >> 2];
    var $398 = $397 & 524288;
    var $399 = ($398 | 0) == 0;
    if ($399) {
      __label__ = 192;
      break;
    } else {
      __label__ = 125;
      break;
    }
   case 125:
    var $401 = $397 | 536870912;
    HEAP32[$4 >> 2] = $401;
    HEAP32[$wc >> 2] = -11;
    __label__ = 192;
    break;
   case 126:
    var $403 = HEAP32[$4 >> 2];
    var $404 = $403 & 524288;
    var $405 = ($404 | 0) == 0;
    if ($405) {
      __label__ = 192;
      break;
    } else {
      __label__ = 127;
      break;
    }
   case 127:
    var $407 = $403 | 536870912;
    HEAP32[$4 >> 2] = $407;
    HEAP32[$wc >> 2] = -12;
    __label__ = 192;
    break;
   case 128:
    var $409 = HEAP32[$4 >> 2];
    var $410 = $409 & 16;
    var $411 = ($410 | 0) == 0;
    if ($411) {
      var $16 = $409;
      __label__ = 6;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 129:
    var $413 = HEAP32[$4 >> 2];
    var $414 = $413 & 16;
    var $415 = ($414 | 0) == 0;
    if ($415) {
      __label__ = 130;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 130:
    var $417 = $lxp + 32 | 0;
    var $418 = HEAP32[$417 >> 2];
    var $419 = $418 + 1 | 0;
    HEAP32[$417 >> 2] = $419;
    var $420 = $lxp + 28 | 0;
    var $421 = HEAP32[$420 >> 2];
    var $422 = $419 >>> 0 > $421 >>> 0;
    if ($422) {
      __label__ = 131;
      break;
    } else {
      var $54 = $413;
      var $53 = $421;
      __label__ = 17;
      break;
    }
   case 131:
    var $424 = $lxp + 44 | 0;
    HEAP32[$424 >> 2] = 13;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 132:
    var $426 = HEAP32[$4 >> 2];
    var $427 = $426 & 16777224;
    var $428 = ($427 | 0) == 0;
    if ($428) {
      var $309 = $391;
      var $308 = $426;
      __label__ = 93;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 133:
    var $429 = $393 - 48 | 0;
    var $430 = HEAP32[$4 >> 2];
    var $431 = $430 & 64;
    var $432 = ($431 | 0) == 0;
    if ($432) {
      var $num_3 = $429;
      var $434 = $430;
      __label__ = 134;
      break;
    } else {
      var $num_4 = $429;
      var $457 = $430;
      var $456 = $391;
      __label__ = 140;
      break;
    }
   case 134:
    var $434;
    var $num_3;
    var $435 = $lxp + 28 | 0;
    var $436 = HEAP32[$435 >> 2];
    var $437 = $num_3 >>> 0 > $436 >>> 0;
    if ($437) {
      __label__ = 136;
      break;
    } else {
      __label__ = 135;
      break;
    }
   case 135:
    var $439 = $num_3 - 1 | 0;
    var $440 = $lxp + 8 | 0;
    var $441 = HEAP32[$440 >> 2];
    var $442 = $441 + $439 | 0;
    var $443 = HEAP8[$442];
    var $444 = $443 << 24 >> 24 == 0;
    if ($444) {
      __label__ = 136;
      break;
    } else {
      __label__ = 137;
      break;
    }
   case 136:
    var $446 = $lxp + 44 | 0;
    HEAP32[$446 >> 2] = 8;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 137:
    var $448 = $lxp | 0;
    var $num_3_c = $num_3;
    HEAP32[$448 >> 2] = $num_3_c;
    var $449 = $lxp + 24 | 0;
    var $450 = HEAP32[$449 >> 2];
    var $451 = $450 >>> 0 < $num_3 >>> 0;
    if ($451) {
      __label__ = 138;
      break;
    } else {
      __label__ = 139;
      break;
    }
   case 138:
    HEAP32[$449 >> 2] = $num_3;
    __label__ = 139;
    break;
   case 139:
    var $454 = $434 | 536870912;
    HEAP32[$4 >> 2] = $454;
    HEAP32[$wc >> 2] = -13;
    __label__ = 192;
    break;
   case 140:
    var $456;
    var $457;
    var $num_4;
    var $458 = $457 & 4194304;
    var $459 = ($458 | 0) == 0;
    if ($459) {
      __label__ = 192;
      break;
    } else {
      __label__ = 141;
      break;
    }
   case 141:
    var $461 = HEAP8[$456];
    var $462 = $461 & 255;
    HEAP32[$wc >> 2] = $462;
    var $_off = $461 - 48 & 255;
    var $463 = ($_off & 255) < 10;
    if ($463) {
      __label__ = 142;
      break;
    } else {
      __label__ = 146;
      break;
    }
   case 142:
    var $465 = $num_4 << 3;
    var $466 = $465 - 48 | 0;
    var $467 = $466 + $462 | 0;
    var $468 = $456 + 1 | 0;
    HEAP32[$3 >> 2] = $468;
    var $469 = HEAP8[$468];
    var $470 = $469 & 255;
    HEAP32[$wc >> 2] = $470;
    var $_off16 = $469 - 48 & 255;
    var $471 = ($_off16 & 255) < 10;
    if ($471) {
      __label__ = 143;
      break;
    } else {
      __label__ = 144;
      break;
    }
   case 143:
    var $473 = $467 << 3;
    var $474 = $473 - 48 | 0;
    var $475 = $474 + $470 | 0;
    var $476 = $456 + 2 | 0;
    HEAP32[$3 >> 2] = $476;
    var $num_5 = $475;
    __label__ = 148;
    break;
   case 144:
    var $478 = $457 & 134217728;
    var $479 = ($478 | 0) == 0;
    if ($479) {
      var $num_5 = $467;
      __label__ = 148;
      break;
    } else {
      __label__ = 145;
      break;
    }
   case 145:
    HEAP32[$3 >> 2] = $456;
    var $481 = $456 - 1 | 0;
    var $482 = HEAP8[$481];
    var $483 = $482 & 255;
    HEAP32[$wc >> 2] = $483;
    __label__ = 192;
    break;
   case 146:
    var $485 = $457 & 134217728;
    var $486 = ($485 | 0) == 0;
    if ($486) {
      var $num_5 = $num_4;
      __label__ = 148;
      break;
    } else {
      __label__ = 147;
      break;
    }
   case 147:
    var $488 = $456 - 1 | 0;
    var $489 = HEAP8[$488];
    var $490 = $489 & 255;
    HEAP32[$wc >> 2] = $490;
    __label__ = 192;
    break;
   case 148:
    var $num_5;
    HEAP32[$wc >> 2] = $num_5;
    var $492 = ($num_5 | 0) < 1;
    if ($492) {
      __label__ = 149;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 149:
    var $494 = $lxp + 44 | 0;
    HEAP32[$494 >> 2] = 19;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 150:
    var $496 = HEAP32[$4 >> 2];
    var $497 = $496 & 64;
    var $498 = ($497 | 0) == 0;
    if ($498) {
      __label__ = 151;
      break;
    } else {
      var $num_4 = 0;
      var $457 = $496;
      var $456 = $391;
      __label__ = 140;
      break;
    }
   case 151:
    var $500 = HEAP8[$391];
    var $_off17 = $500 - 48 & 255;
    var $501 = ($_off17 & 255) < 10;
    if ($501) {
      __label__ = 152;
      break;
    } else {
      var $num_4 = 0;
      var $457 = $496;
      var $456 = $391;
      __label__ = 140;
      break;
    }
   case 152:
    var $503 = $500 & 255;
    var $504 = $503 - 48 | 0;
    var $505 = $6 + 3 | 0;
    HEAP32[$3 >> 2] = $505;
    var $506 = HEAP8[$505];
    var $507 = $506 & 255;
    HEAP32[$wc >> 2] = $507;
    var $_off1819 = $506 - 48 & 255;
    var $508 = ($_off1819 & 255) < 10;
    if ($508) {
      var $n_120 = 1;
      var $num_621 = $504;
      var $510 = $507;
      var $509 = $505;
      __label__ = 153;
      break;
    } else {
      var $n_1_lcssa = 1;
      var $num_6_lcssa = $504;
      var $519 = $505;
      __label__ = 154;
      break;
    }
   case 153:
    var $509;
    var $510;
    var $num_621;
    var $n_120;
    var $511 = $num_621 * 10 | 0;
    var $512 = $511 - 48 | 0;
    var $513 = $512 + $510 | 0;
    var $514 = $n_120 + 1 | 0;
    var $515 = $509 + 1 | 0;
    HEAP32[$3 >> 2] = $515;
    var $516 = HEAP8[$515];
    var $517 = $516 & 255;
    HEAP32[$wc >> 2] = $517;
    var $_off18 = $516 - 48 & 255;
    var $518 = ($_off18 & 255) < 10;
    if ($518) {
      var $n_120 = $514;
      var $num_621 = $513;
      var $510 = $517;
      var $509 = $515;
      __label__ = 153;
      break;
    } else {
      var $n_1_lcssa = $514;
      var $num_6_lcssa = $513;
      var $519 = $515;
      __label__ = 154;
      break;
    }
   case 154:
    var $519;
    var $num_6_lcssa;
    var $n_1_lcssa;
    var $520 = ($num_6_lcssa | 0) == 0;
    if ($520) {
      __label__ = 155;
      break;
    } else {
      var $num_3 = $num_6_lcssa;
      var $434 = $496;
      __label__ = 134;
      break;
    }
   case 155:
    var $522 = -$n_1_lcssa | 0;
    var $523 = $519 + $522 | 0;
    HEAP32[$3 >> 2] = $523;
    var $num_4 = 0;
    var $457 = $496;
    var $456 = $523;
    __label__ = 140;
    break;
   case 156:
    var $525 = HEAP32[$4 >> 2];
    var $526 = $525 & 138412032;
    var $527 = ($526 | 0) == 4194304;
    if ($527) {
      __label__ = 157;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 157:
    HEAP32[$wc >> 2] = 7;
    __label__ = 192;
    break;
   case 158:
    var $530 = HEAP32[$4 >> 2];
    var $531 = $530 & 4194304;
    var $532 = ($531 | 0) == 0;
    if ($532) {
      __label__ = 192;
      break;
    } else {
      __label__ = 159;
      break;
    }
   case 159:
    HEAP32[$wc >> 2] = 8;
    __label__ = 192;
    break;
   case 160:
    var $535 = HEAP32[$4 >> 2];
    var $536 = $535 & 4194304;
    var $537 = ($536 | 0) == 0;
    if ($537) {
      __label__ = 192;
      break;
    } else {
      __label__ = 161;
      break;
    }
   case 161:
    HEAP32[$wc >> 2] = 12;
    __label__ = 192;
    break;
   case 162:
    var $540 = HEAP32[$4 >> 2];
    var $541 = $540 & 5242880;
    var $542 = ($541 | 0) == 0;
    if ($542) {
      __label__ = 192;
      break;
    } else {
      __label__ = 163;
      break;
    }
   case 163:
    HEAP32[$wc >> 2] = 10;
    var $544 = $540 & 1024;
    var $545 = ($544 | 0) == 0;
    if ($545) {
      __label__ = 192;
      break;
    } else {
      __label__ = 164;
      break;
    }
   case 164:
    var $547 = $540 | 536870912;
    HEAP32[$4 >> 2] = $547;
    __label__ = 192;
    break;
   case 165:
    var $549 = HEAP32[$4 >> 2];
    var $550 = $549 & 4194304;
    var $551 = ($550 | 0) == 0;
    if ($551) {
      __label__ = 192;
      break;
    } else {
      __label__ = 166;
      break;
    }
   case 166:
    HEAP32[$wc >> 2] = 13;
    __label__ = 192;
    break;
   case 167:
    var $554 = HEAP32[$4 >> 2];
    var $555 = $554 & 4194304;
    var $556 = ($555 | 0) == 0;
    if ($556) {
      __label__ = 192;
      break;
    } else {
      __label__ = 168;
      break;
    }
   case 168:
    HEAP32[$wc >> 2] = 9;
    __label__ = 192;
    break;
   case 169:
    var $559 = HEAP32[$4 >> 2];
    var $560 = $559 & 138412032;
    var $561 = ($560 | 0) == 4194304;
    if ($561) {
      __label__ = 170;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 170:
    HEAP32[$wc >> 2] = 11;
    __label__ = 192;
    break;
   case 171:
    var $564 = HEAP32[$4 >> 2];
    var $565 = $564 & 138412032;
    var $566 = ($565 | 0) == 4194304;
    if ($566) {
      __label__ = 172;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 172:
    var $568 = HEAP8[$391];
    var $569 = $568 & 255;
    var $570 = _isxdigit($569);
    var $571 = ($570 | 0) == 0;
    if ($571) {
      __label__ = 192;
      break;
    } else {
      __label__ = 173;
      break;
    }
   case 173:
    HEAP32[$wc >> 2] = $569;
    var $num_7 = 0;
    var $574 = $569;
    __label__ = 174;
    break;
   case 174:
    var $574;
    var $num_7;
    var $isdigittmp13 = $574 - 48 | 0;
    var $isdigit14 = $isdigittmp13 >>> 0 < 10;
    if ($isdigit14) {
      __label__ = 175;
      break;
    } else {
      __label__ = 176;
      break;
    }
   case 175:
    HEAP32[$wc >> 2] = $isdigittmp13;
    var $585 = $isdigittmp13;
    __label__ = 179;
    break;
   case 176:
    var $577 = _isupper($574);
    var $578 = ($577 | 0) == 0;
    var $579 = HEAP32[$wc >> 2];
    if ($578) {
      __label__ = 178;
      break;
    } else {
      __label__ = 177;
      break;
    }
   case 177:
    var $581 = $579 - 75 | 0;
    HEAP32[$wc >> 2] = $581;
    var $585 = $581;
    __label__ = 179;
    break;
   case 178:
    var $583 = $579 - 107 | 0;
    HEAP32[$wc >> 2] = $583;
    var $585 = $583;
    __label__ = 179;
    break;
   case 179:
    var $585;
    var $586 = $585 | $num_7;
    var $587 = HEAP32[$3 >> 2];
    var $588 = $587 + 1 | 0;
    HEAP32[$3 >> 2] = $588;
    var $589 = HEAP8[$588];
    var $590 = $589 & 255;
    HEAP32[$wc >> 2] = $590;
    var $591 = _isxdigit($590);
    var $592 = ($591 | 0) == 0;
    if ($592) {
      __label__ = 181;
      break;
    } else {
      __label__ = 180;
      break;
    }
   case 180:
    var $_pre19 = HEAP32[$wc >> 2];
    var $phitmp = $586 << 4;
    var $num_7 = $phitmp;
    var $574 = $_pre19;
    __label__ = 174;
    break;
   case 181:
    HEAP32[$wc >> 2] = $586;
    var $594 = ($586 | 0) < 1;
    if ($594) {
      __label__ = 182;
      break;
    } else {
      __label__ = 192;
      break;
    }
   case 182:
    var $596 = $lxp + 44 | 0;
    HEAP32[$596 >> 2] = 19;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 183:
    var $597;
    var $598;
    var $599 = $598 & 128;
    var $600 = ($599 | 0) == 0;
    var $601 = ($2 | 0) == 1;
    var $or_cond6 = $600 | $601;
    if ($or_cond6) {
      __label__ = 188;
      break;
    } else {
      __label__ = 184;
      break;
    }
   case 184:
    var $603 = _libuxre_mb2wc($wc, $597);
    var $604 = ($603 | 0) > 0;
    if ($604) {
      __label__ = 185;
      break;
    } else {
      __label__ = 186;
      break;
    }
   case 185:
    var $606 = HEAP32[$3 >> 2];
    var $607 = $606 + $603 | 0;
    HEAP32[$3 >> 2] = $607;
    __label__ = 188;
    break;
   case 186:
    var $609 = ($603 | 0) < 0;
    if ($609) {
      __label__ = 187;
      break;
    } else {
      __label__ = 188;
      break;
    }
   case 187:
    var $611 = $lxp + 44 | 0;
    HEAP32[$611 >> 2] = 20;
    var $_0 = -1;
    __label__ = 193;
    break;
   case 188:
    var $612 = HEAP32[$4 >> 2];
    var $613 = $612 & 256;
    var $614 = ($613 | 0) == 0;
    if ($614) {
      __label__ = 192;
      break;
    } else {
      __label__ = 189;
      break;
    }
   case 189:
    var $616 = ($2 | 0) > 1;
    if ($616) {
      __label__ = 190;
      break;
    } else {
      __label__ = 191;
      break;
    }
   case 190:
    _towlower();
   case 191:
    var $619 = HEAP32[$wc >> 2];
    var $620 = _tolower($619);
    HEAP32[$wc >> 2] = $620;
    __label__ = 192;
    break;
   case 192:
    var $621 = HEAP32[$wc >> 2];
    HEAP32[$5 >> 2] = $621;
    var $_0 = 0;
    __label__ = 193;
    break;
   case 193:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_lex["X"] = 1;
function _alt($lxp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _cat394($lxp);
    var $2 = ($1 | 0) == 0;
    if ($2) {
      var $_0 = 0;
      __label__ = 11;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = $lxp + 20 | 0;
    var $lp_0 = $1;
    __label__ = 4;
    break;
   case 4:
    var $lp_0;
    var $5 = HEAP32[$3 >> 2];
    var $6 = ($5 | 0) == -33;
    if ($6) {
      __label__ = 5;
      break;
    } else {
      var $_0 = $lp_0;
      __label__ = 11;
      break;
    }
   case 5:
    var $8 = _lex($lxp);
    var $9 = ($8 | 0) == 0;
    if ($9) {
      __label__ = 6;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 6:
    var $11 = HEAP32[$3 >> 2];
    var $12 = ($11 | 0) == -14;
    if ($12) {
      var $_0 = $lp_0;
      __label__ = 11;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $14 = _cat394($lxp);
    var $15 = ($14 | 0) == 0;
    if ($15) {
      __label__ = 10;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $17 = _libuxre_reg2tree(-33, $lp_0, $14);
    var $18 = ($17 | 0) == 0;
    if ($18) {
      __label__ = 9;
      break;
    } else {
      var $lp_0 = $17;
      __label__ = 4;
      break;
    }
   case 9:
    var $20 = $lxp + 44 | 0;
    HEAP32[$20 >> 2] = 17;
    var $_0 = 0;
    __label__ = 11;
    break;
   case 10:
    _libuxre_regdeltree($lp_0, 1);
    var $_0 = 0;
    __label__ = 11;
    break;
   case 11:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _cat394($lxp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _post($lxp);
    var $2 = ($1 | 0) == 0;
    if ($2) {
      var $_0 = 0;
      __label__ = 9;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = $lxp + 20 | 0;
    var $lp_0 = $1;
    __label__ = 4;
    break;
   case 4:
    var $lp_0;
    var $5 = HEAP32[$3 >> 2];
    if (($5 | 0) == -33 || ($5 | 0) == -22 || ($5 | 0) == -14) {
      var $_0 = $lp_0;
      __label__ = 9;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $7 = _post($lxp);
    var $8 = ($7 | 0) == 0;
    if ($8) {
      __label__ = 8;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $10 = _libuxre_reg2tree(-34, $lp_0, $7);
    var $11 = ($10 | 0) == 0;
    if ($11) {
      __label__ = 7;
      break;
    } else {
      var $lp_0 = $10;
      __label__ = 4;
      break;
    }
   case 7:
    var $13 = $lxp + 44 | 0;
    HEAP32[$13 >> 2] = 17;
    var $_0 = 0;
    __label__ = 9;
    break;
   case 8:
    _libuxre_regdeltree($lp_0, 1);
    var $_0 = 0;
    __label__ = 9;
    break;
   case 9:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _post($lxp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _leaf($lxp);
    var $2 = ($1 | 0) == 0;
    if ($2) {
      var $_0 = 0;
      __label__ = 11;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $4 = $lxp + 20 | 0;
    var $5 = HEAP32[$4 >> 2];
    if (($5 | 0) == -7) {
      __label__ = 4;
      break;
    } else if (($5 | 0) == -20 || ($5 | 0) == -17 || ($5 | 0) == -18 || ($5 | 0) == -19) {
      var $lp_0 = $1;
      var $8 = $5;
      __label__ = 5;
      break;
    } else if (($5 | 0) == -1) {
      var $lp_1 = $1;
      __label__ = 9;
      break;
    } else {
      var $_0 = $1;
      __label__ = 11;
      break;
    }
   case 4:
    _libuxre_regdeltree($1, 1);
    var $_pre = HEAP32[$4 >> 2];
    var $lp_0 = 0;
    var $8 = $_pre;
    __label__ = 5;
    break;
   case 5:
    var $8;
    var $lp_0;
    var $9 = _libuxre_reg1tree($8, $lp_0);
    var $10 = ($9 | 0) == 0;
    if ($10) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    var $12 = $lxp + 44 | 0;
    HEAP32[$12 >> 2] = 17;
    var $_0 = 0;
    __label__ = 11;
    break;
   case 7:
    var $14 = HEAP32[$4 >> 2];
    var $15 = ($14 | 0) == -20;
    if ($15) {
      __label__ = 8;
      break;
    } else {
      var $lp_1 = $9;
      __label__ = 9;
      break;
    }
   case 8:
    var $17 = $lxp;
    var $18 = HEAP32[$17 >> 2];
    var $19 = $9 + 4 | 0;
    HEAP32[$19 >> 2] = $18;
    var $lp_1 = $9;
    __label__ = 9;
    break;
   case 9:
    var $lp_1;
    var $21 = _lex($lxp);
    var $22 = ($21 | 0) == 0;
    if ($22) {
      var $_0 = $lp_1;
      __label__ = 11;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    _libuxre_regdeltree($lp_1, 1);
    var $_0 = 0;
    __label__ = 11;
    break;
   case 11:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _leaf($lxp) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _malloc(16);
    var $2 = $1;
    var $3 = ($1 | 0) == 0;
    if ($3) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $5 = $lxp + 44 | 0;
    HEAP32[$5 >> 2] = 17;
    var $_0 = 0;
    __label__ = 34;
    break;
   case 4:
    var $7 = $lxp + 20 | 0;
    var $8 = HEAP32[$7 >> 2];
    var $9 = $1 + 12 | 0;
    var $10 = $9;
    HEAP32[$10 >> 2] = $8;
    if (($8 | 0) == -17 || ($8 | 0) == -18 || ($8 | 0) == -19) {
      __label__ = 7;
      break;
    } else if (($8 | 0) == -20 || ($8 | 0) == -7 || ($8 | 0) == -1) {
      __label__ = 10;
      break;
    } else if (($8 | 0) == -2 || ($8 | 0) == -3 || ($8 | 0) == -11 || ($8 | 0) == -12) {
      __label__ = 12;
      break;
    } else if (($8 | 0) == -9) {
      __label__ = 18;
      break;
    } else if (($8 | 0) == -13) {
      __label__ = 19;
      break;
    } else if (($8 | 0) == -21) {
      __label__ = 20;
      break;
    } else if (($8 | 0) == -5 || ($8 | 0) == -6) {
      __label__ = 32;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $12 = ($8 | 0) < 0;
    if ($12) {
      __label__ = 6;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 6:
    var $14 = $lxp + 44 | 0;
    HEAP32[$14 >> 2] = 2;
    var $15 = $1 + 4 | 0;
    var $16 = $15;
    HEAP32[$16 >> 2] = 0;
    __label__ = 11;
    break;
   case 7:
    var $18 = $lxp + 16 | 0;
    var $19 = HEAP32[$18 >> 2];
    var $20 = $19 & 128;
    var $21 = ($20 | 0) == 0;
    if ($21) {
      __label__ = 8;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 8:
    var $23 = $lxp + 4 | 0;
    var $24 = HEAP32[$23 >> 2];
    var $25 = $24 - 1 | 0;
    var $26 = HEAP8[$25];
    var $27 = $26 << 24 >> 24 == 125;
    if ($27) {
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $29 = $26 & 255;
    HEAP32[$10 >> 2] = $29;
    __label__ = 32;
    break;
   case 10:
    var $31 = $lxp + 44 | 0;
    HEAP32[$31 >> 2] = 18;
    __label__ = 11;
    break;
   case 11:
    var $33 = $1;
    HEAP32[$33 >> 2] = 0;
    __label__ = 33;
    break;
   case 12:
    var $35 = _lex($lxp);
    var $36 = ($35 | 0) == 0;
    if ($36) {
      __label__ = 13;
      break;
    } else {
      __label__ = 33;
      break;
    }
   case 13:
    var $38 = HEAP32[$7 >> 2];
    if (($38 | 0) == -17 || ($38 | 0) == -18 || ($38 | 0) == -19) {
      __label__ = 14;
      break;
    } else if (($38 | 0) == -20 || ($38 | 0) == -7 || ($38 | 0) == -1) {
      __label__ = 17;
      break;
    } else {
      var $_0 = $2;
      __label__ = 34;
      break;
    }
   case 14:
    var $40 = $lxp + 16 | 0;
    var $41 = HEAP32[$40 >> 2];
    var $42 = $41 & 128;
    var $43 = ($42 | 0) == 0;
    if ($43) {
      __label__ = 15;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 15:
    var $45 = $lxp + 4 | 0;
    var $46 = HEAP32[$45 >> 2];
    var $47 = $46 - 1 | 0;
    var $48 = HEAP8[$47];
    var $49 = $48 << 24 >> 24 == 125;
    if ($49) {
      __label__ = 17;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $51 = $48 & 255;
    HEAP32[$7 >> 2] = $51;
    var $_0 = $2;
    __label__ = 34;
    break;
   case 17:
    var $53 = $lxp + 44 | 0;
    HEAP32[$53 >> 2] = 18;
    __label__ = 33;
    break;
   case 18:
    var $55 = $lxp | 0;
    var $56 = HEAP32[$55 >> 2];
    var $57 = $1 + 4 | 0;
    var $58 = $57;
    HEAP32[$58 >> 2] = $56;
    __label__ = 32;
    break;
   case 19:
    var $60 = $lxp;
    var $61 = HEAP32[$60 >> 2];
    var $62 = $1 + 4 | 0;
    var $63 = $62;
    HEAP32[$63 >> 2] = $61;
    __label__ = 32;
    break;
   case 20:
    var $65 = $lxp + 28 | 0;
    var $66 = HEAP32[$65 >> 2];
    var $67 = $1 + 4 | 0;
    var $68 = $67;
    HEAP32[$68 >> 2] = $66;
    var $69 = _lex($lxp);
    var $70 = ($69 | 0) == 0;
    if ($70) {
      __label__ = 21;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 21:
    var $72 = HEAP32[$7 >> 2];
    var $73 = ($72 | 0) == -22;
    if ($73) {
      __label__ = 22;
      break;
    } else {
      __label__ = 25;
      break;
    }
   case 22:
    var $75 = $lxp + 16 | 0;
    var $76 = HEAP32[$75 >> 2];
    var $77 = $76 & 8192;
    var $78 = ($77 | 0) == 0;
    if ($78) {
      __label__ = 24;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $80 = $lxp + 44 | 0;
    HEAP32[$80 >> 2] = 11;
    __label__ = 11;
    break;
   case 24:
    var $82 = $76 & 4096;
    var $83 = ($82 | 0) == 0;
    var $storemerge = $83 ? -7 : -8;
    HEAP32[$7 >> 2] = $storemerge;
    var $84 = _libuxre_reg1tree($storemerge, 0);
    var $85 = $1;
    HEAP32[$85 >> 2] = $84;
    var $86 = ($84 | 0) == 0;
    if ($86) {
      __label__ = 11;
      break;
    } else {
      var $108 = $84;
      __label__ = 31;
      break;
    }
   case 25:
    var $88 = _alt($lxp);
    var $89 = $1;
    HEAP32[$89 >> 2] = $88;
    var $90 = ($88 | 0) == 0;
    if ($90) {
      __label__ = 26;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 26:
    var $92 = $lxp + 44 | 0;
    var $93 = HEAP32[$92 >> 2];
    var $94 = ($93 | 0) == 2;
    if ($94) {
      __label__ = 29;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 27:
    var $96 = HEAP32[$7 >> 2];
    var $97 = ($96 | 0) == -22;
    if ($97) {
      var $108 = $88;
      __label__ = 31;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 28:
    var $99 = $lxp + 44 | 0;
    HEAP32[$99 >> 2] = 2;
    __label__ = 29;
    break;
   case 29:
    var $101 = HEAP32[$65 >> 2];
    var $102 = $lxp + 32 | 0;
    var $103 = HEAP32[$102 >> 2];
    var $104 = ($101 | 0) == ($103 | 0);
    if ($104) {
      __label__ = 11;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    var $106 = $lxp + 44 | 0;
    HEAP32[$106 >> 2] = 13;
    __label__ = 11;
    break;
   case 31:
    var $108;
    var $109 = $108 + 8 | 0;
    HEAP32[$109 >> 2] = $2;
    __label__ = 32;
    break;
   case 32:
    var $111 = _lex($lxp);
    var $112 = ($111 | 0) == 0;
    if ($112) {
      var $_0 = $2;
      __label__ = 34;
      break;
    } else {
      __label__ = 33;
      break;
    }
   case 33:
    _libuxre_regdeltree($2, 1);
    var $_0 = 0;
    __label__ = 34;
    break;
   case 34:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_leaf["X"] = 1;
function _libuxre_bktmbcomp($bp, $pat0, $flags, $mb_cur_max) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 4;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $wc = __stackBase__;
    var $1 = $bp | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $bp;
    for (var $$dest = $3 >> 2, $$stop = $$dest + 55; $$dest < $$stop; $$dest++) {
      HEAP32[$$dest] = 0;
    }
    HEAP32[$1 >> 2] = $2;
    var $4 = $flags & 4111;
    var $5 = $bp + 216 | 0;
    HEAP32[$5 >> 2] = $4;
    var $6 = HEAP8[$pat0];
    var $7 = $6 & 255;
    HEAP32[$wc >> 2] = $7;
    var $8 = $6 << 24 >> 24 == 93;
    if ($8) {
      __label__ = 3;
      break;
    } else {
      var $pat_0_ph23 = $pat0;
      var $_ph = $7;
      __label__ = 4;
      break;
    }
   case 3:
    var $10 = $flags & 128;
    var $11 = ($10 | 0) == 0;
    if ($11) {
      var $pat_0_ph23 = $pat0;
      var $_ph = $7;
      __label__ = 4;
      break;
    } else {
      var $_0 = 1;
      __label__ = 67;
      break;
    }
   case 4:
    var $_ph;
    var $pat_0_ph23;
    var $12 = ($mb_cur_max | 0) == 1;
    var $13 = $flags & 16;
    var $14 = ($13 | 0) == 0;
    var $15 = $flags & 32;
    var $16 = ($15 | 0) == 0;
    var $17 = $flags & 64;
    var $18 = ($17 | 0) == 0;
    var $19 = $flags & 3840;
    var $20 = ($19 | 0) == 0;
    var $_old = $flags & 256;
    var $_old14 = ($_old | 0) == 0;
    var $21 = $flags & 768;
    var $22 = ($21 | 0) == 0;
    var $23 = $flags & 18432;
    var $24 = ($23 | 0) == 2048;
    var $25 = $flags & 2048;
    var $26 = ($25 | 0) == 0;
    var $27 = $flags & 3072;
    var $28 = ($27 | 0) == 0;
    var $29 = $flags & 8192;
    var $30 = ($29 | 0) == 0;
    var $prev_0 = 0;
    var $pat_0 = $pat_0_ph23;
    var $31 = $_ph;
    __label__ = 5;
    break;
   case 5:
    var $31;
    var $pat_0;
    var $prev_0;
    if (($31 | 0) == 10) {
      __label__ = 6;
      break;
    } else if (($31 | 0) == 47) {
      __label__ = 7;
      break;
    } else if (($31 | 0) == 92) {
      __label__ = 8;
      break;
    } else if (($31 | 0) == 91) {
      __label__ = 41;
      break;
    } else if (($31 | 0) == 0) {
      var $n_6 = -9;
      __label__ = 66;
      break;
    } else {
      __label__ = 56;
      break;
    }
   case 6:
    if ($16) {
      var $pat_5 = $pat_0;
      __label__ = 59;
      break;
    } else {
      var $n_6 = -9;
      __label__ = 66;
      break;
    }
   case 7:
    if ($18) {
      var $pat_5 = $pat_0;
      __label__ = 59;
      break;
    } else {
      var $n_6 = -9;
      __label__ = 66;
      break;
    }
   case 8:
    if ($20) {
      var $pat_5 = $pat_0;
      __label__ = 59;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $36 = $pat_0 + 1 | 0;
    var $37 = HEAP8[$36];
    var $38 = $37 & 255;
    HEAP32[$wc >> 2] = $38;
    if (($38 | 0) == 92 || ($38 | 0) == 93 || ($38 | 0) == 45 || ($38 | 0) == 94) {
      __label__ = 12;
      break;
    } else if (($38 | 0) == 97) {
      __label__ = 13;
      break;
    } else if (($38 | 0) == 98) {
      __label__ = 15;
      break;
    } else if (($38 | 0) == 102) {
      __label__ = 17;
      break;
    } else if (($38 | 0) == 110) {
      __label__ = 19;
      break;
    } else if (($38 | 0) == 114) {
      __label__ = 21;
      break;
    } else if (($38 | 0) == 116) {
      __label__ = 23;
      break;
    } else if (($38 | 0) == 118) {
      __label__ = 25;
      break;
    } else if (($38 | 0) == 120) {
      __label__ = 27;
      break;
    } else if (($38 | 0) == 48 || ($38 | 0) == 49 || ($38 | 0) == 50 || ($38 | 0) == 51 || ($38 | 0) == 52 || ($38 | 0) == 53 || ($38 | 0) == 54 || ($38 | 0) == 55 || ($38 | 0) == 56 || ($38 | 0) == 57) {
      __label__ = 36;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    if ($_old14) {
      __label__ = 11;
      break;
    } else {
      var $pat_5 = $36;
      __label__ = 59;
      break;
    }
   case 11:
    HEAP32[$wc >> 2] = 92;
    var $pat_5 = $pat_0;
    __label__ = 59;
    break;
   case 12:
    if ($22) {
      __label__ = 11;
      break;
    } else {
      var $pat_5 = $36;
      __label__ = 59;
      break;
    }
   case 13:
    if ($24) {
      __label__ = 14;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 14:
    HEAP32[$wc >> 2] = 7;
    var $pat_5 = $36;
    __label__ = 59;
    break;
   case 15:
    if ($26) {
      __label__ = 10;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    HEAP32[$wc >> 2] = 8;
    var $pat_5 = $36;
    __label__ = 59;
    break;
   case 17:
    if ($26) {
      __label__ = 10;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    HEAP32[$wc >> 2] = 12;
    var $pat_5 = $36;
    __label__ = 59;
    break;
   case 19:
    if ($28) {
      __label__ = 10;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 20:
    HEAP32[$wc >> 2] = 10;
    var $pat_5 = $36;
    __label__ = 59;
    break;
   case 21:
    if ($26) {
      __label__ = 10;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    HEAP32[$wc >> 2] = 13;
    var $pat_5 = $36;
    __label__ = 59;
    break;
   case 23:
    if ($26) {
      __label__ = 10;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 24:
    HEAP32[$wc >> 2] = 9;
    var $pat_5 = $36;
    __label__ = 59;
    break;
   case 25:
    if ($24) {
      __label__ = 26;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 26:
    HEAP32[$wc >> 2] = 11;
    var $pat_5 = $36;
    __label__ = 59;
    break;
   case 27:
    if ($24) {
      __label__ = 28;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 28:
    var $58 = $pat_0 + 2 | 0;
    var $59 = HEAP8[$58];
    var $60 = $59 & 255;
    HEAP32[$wc >> 2] = $60;
    var $61 = _isxdigit($60);
    var $62 = ($61 | 0) == 0;
    if ($62) {
      __label__ = 10;
      break;
    } else {
      var $n_0 = 0;
      var $pat_2 = $58;
      __label__ = 29;
      break;
    }
   case 29:
    var $pat_2;
    var $n_0;
    var $63 = HEAP32[$wc >> 2];
    var $isdigittmp = $63 - 48 | 0;
    var $isdigit = $isdigittmp >>> 0 < 10;
    if ($isdigit) {
      __label__ = 30;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 30:
    HEAP32[$wc >> 2] = $isdigittmp;
    var $74 = $isdigittmp;
    __label__ = 34;
    break;
   case 31:
    var $66 = _isupper($63);
    var $67 = ($66 | 0) == 0;
    var $68 = HEAP32[$wc >> 2];
    if ($67) {
      __label__ = 33;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    var $70 = $68 - 75 | 0;
    HEAP32[$wc >> 2] = $70;
    var $74 = $70;
    __label__ = 34;
    break;
   case 33:
    var $72 = $68 - 107 | 0;
    HEAP32[$wc >> 2] = $72;
    var $74 = $72;
    __label__ = 34;
    break;
   case 34:
    var $74;
    var $75 = $n_0 << 4;
    var $76 = $74 | $75;
    var $77 = $pat_2 + 1 | 0;
    var $78 = HEAP8[$77];
    var $79 = $78 & 255;
    HEAP32[$wc >> 2] = $79;
    var $80 = _isxdigit($79);
    var $81 = ($80 | 0) == 0;
    if ($81) {
      __label__ = 35;
      break;
    } else {
      var $n_0 = $76;
      var $pat_2 = $77;
      __label__ = 29;
      break;
    }
   case 35:
    HEAP32[$wc >> 2] = $76;
    var $83 = ($76 | 0) < 1;
    if ($83) {
      var $n_6 = -19;
      __label__ = 66;
      break;
    } else {
      var $pat_5 = $pat_2;
      __label__ = 59;
      break;
    }
   case 36:
    if ($24) {
      __label__ = 37;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 37:
    var $86 = $38 - 48 | 0;
    var $87 = $pat_0 + 2 | 0;
    var $88 = HEAP8[$87];
    var $89 = $88 & 255;
    HEAP32[$wc >> 2] = $89;
    var $_off = $88 - 48 & 255;
    var $90 = ($_off & 255) < 10;
    if ($90) {
      __label__ = 38;
      break;
    } else {
      var $n_1 = $86;
      var $pat_3 = $87;
      __label__ = 40;
      break;
    }
   case 38:
    var $92 = $86 << 3;
    var $93 = $92 - 48 | 0;
    var $94 = $93 + $89 | 0;
    var $95 = $pat_0 + 3 | 0;
    var $96 = HEAP8[$95];
    var $97 = $96 & 255;
    HEAP32[$wc >> 2] = $97;
    var $_off16 = $96 - 48 & 255;
    var $98 = ($_off16 & 255) < 10;
    if ($98) {
      __label__ = 39;
      break;
    } else {
      var $n_1 = $94;
      var $pat_3 = $95;
      __label__ = 40;
      break;
    }
   case 39:
    var $100 = $94 << 3;
    var $101 = $100 - 48 | 0;
    var $102 = $101 + $97 | 0;
    var $n_1 = $102;
    var $pat_3 = $95;
    __label__ = 40;
    break;
   case 40:
    var $pat_3;
    var $n_1;
    var $104 = $pat_3 - 1 | 0;
    HEAP32[$wc >> 2] = $n_1;
    var $105 = ($n_1 | 0) < 1;
    if ($105) {
      var $n_6 = -19;
      __label__ = 66;
      break;
    } else {
      var $pat_5 = $104;
      __label__ = 59;
      break;
    }
   case 41:
    var $107 = $pat_0 + 1 | 0;
    var $108 = HEAP8[$107];
    var $109 = $108 & 255;
    HEAP32[$wc >> 2] = $109;
    if ($108 << 24 >> 24 == 58 || $108 << 24 >> 24 == 61 || $108 << 24 >> 24 == 46) {
      __label__ = 42;
      break;
    } else {
      __label__ = 55;
      break;
    }
   case 42:
    if ($30) {
      var $n_2 = 0;
      var $pat_4 = $107;
      __label__ = 43;
      break;
    } else {
      __label__ = 55;
      break;
    }
   case 43:
    var $pat_4;
    var $n_2;
    var $111 = $pat_4 + 1 | 0;
    var $112 = HEAP8[$111];
    var $113 = $112 << 24 >> 24 == $108 << 24 >> 24;
    if ($113) {
      __label__ = 44;
      break;
    } else {
      __label__ = 45;
      break;
    }
   case 44:
    var $115 = $pat_4 + 2 | 0;
    var $116 = HEAP8[$115];
    var $117 = $116 << 24 >> 24 == 93;
    if ($117) {
      __label__ = 49;
      break;
    } else {
      __label__ = 45;
      break;
    }
   case 45:
    if ($112 << 24 >> 24 == 47) {
      __label__ = 46;
      break;
    } else if ($112 << 24 >> 24 == 10) {
      __label__ = 47;
      break;
    } else if ($112 << 24 >> 24 == 0) {
      var $n_6 = -2;
      __label__ = 66;
      break;
    } else {
      __label__ = 48;
      break;
    }
   case 46:
    if ($18) {
      __label__ = 48;
      break;
    } else {
      var $n_6 = -2;
      __label__ = 66;
      break;
    }
   case 47:
    if ($16) {
      __label__ = 48;
      break;
    } else {
      var $n_6 = -2;
      __label__ = 66;
      break;
    }
   case 48:
    var $121 = $n_2 + 1 | 0;
    var $n_2 = $121;
    var $pat_4 = $111;
    __label__ = 43;
    break;
   case 49:
    var $123 = ($n_2 | 0) == 0;
    if ($123) {
      var $n_6 = -10;
      __label__ = 66;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 50:
    var $125 = $108 << 24 >> 24 == 58;
    if ($125) {
      __label__ = 51;
      break;
    } else {
      __label__ = 52;
      break;
    }
   case 51:
    _chcls($n_2);
    var $n_6 = -20;
    __label__ = 66;
    break;
   case 52:
    var $127 = $108 << 24 >> 24 == 61;
    var $_sum = 1 - $n_2 | 0;
    var $128 = $pat_4 + $_sum | 0;
    if ($127) {
      __label__ = 53;
      break;
    } else {
      __label__ = 54;
      break;
    }
   case 53:
    var $130 = _eqcls($bp, $128, $n_2, $prev_0, $mb_cur_max);
    var $n_4 = $130;
    var $pat_6 = $115;
    __label__ = 60;
    break;
   case 54:
    var $132 = _clsym($bp, $128, $n_2, $prev_0, $mb_cur_max);
    var $n_4 = $132;
    var $pat_6 = $115;
    __label__ = 60;
    break;
   case 55:
    HEAP32[$wc >> 2] = 91;
    var $pat_5 = $pat_0;
    __label__ = 59;
    break;
   case 56:
    var $135 = $31 & 128;
    var $136 = ($135 | 0) == 0;
    var $or_cond = $136 | $12;
    if ($or_cond) {
      var $pat_5 = $pat_0;
      __label__ = 59;
      break;
    } else {
      __label__ = 57;
      break;
    }
   case 57:
    var $138 = $pat_0 + 1 | 0;
    var $139 = _libuxre_mb2wc($wc, $138);
    var $140 = ($139 | 0) > 0;
    if ($140) {
      __label__ = 58;
      break;
    } else {
      var $pat_5 = $pat_0;
      __label__ = 59;
      break;
    }
   case 58:
    var $142 = $pat_0 + $139 | 0;
    var $pat_5 = $142;
    __label__ = 59;
    break;
   case 59:
    var $pat_5;
    var $143 = HEAP32[$wc >> 2];
    var $144 = _place($bp, $143, $prev_0);
    var $n_4 = $144;
    var $pat_6 = $pat_5;
    __label__ = 60;
    break;
   case 60:
    var $pat_6;
    var $n_4;
    var $146 = ($n_4 | 0) < 0;
    if ($146) {
      var $n_6 = -20;
      __label__ = 66;
      break;
    } else {
      __label__ = 61;
      break;
    }
   case 61:
    var $148 = $pat_6 + 1 | 0;
    var $149 = HEAP8[$148];
    var $150 = $149 & 255;
    HEAP32[$wc >> 2] = $150;
    if ($149 << 24 >> 24 == 45) {
      __label__ = 62;
      break;
    } else if ($149 << 24 >> 24 == 93) {
      __label__ = 65;
      break;
    } else {
      var $prev_0 = 0;
      var $pat_0 = $148;
      var $31 = $150;
      __label__ = 5;
      break;
    }
   case 62:
    var $152 = ($n_4 | 0) != 0;
    var $153 = ($prev_0 | 0) == 0;
    var $brmerge = $153 | $14;
    var $or_cond33 = $152 & $brmerge;
    if ($or_cond33) {
      __label__ = 63;
      break;
    } else {
      var $pat_0_ph23 = $148;
      var $_ph = $150;
      __label__ = 4;
      break;
    }
   case 63:
    var $155 = $pat_6 + 2 | 0;
    var $156 = HEAP8[$155];
    var $157 = $156 & 255;
    HEAP32[$wc >> 2] = $157;
    var $158 = $156 << 24 >> 24 == 93;
    if ($158) {
      __label__ = 64;
      break;
    } else {
      var $prev_0 = $n_4;
      var $pat_0 = $155;
      var $31 = $157;
      __label__ = 5;
      break;
    }
   case 64:
    HEAP32[$wc >> 2] = 45;
    var $prev_0 = 0;
    var $pat_0 = $148;
    var $31 = 45;
    __label__ = 5;
    break;
   case 65:
    var $161 = $148;
    var $162 = $pat0;
    var $163 = 1 - $162 | 0;
    var $164 = $163 + $161 | 0;
    var $_0 = $164;
    __label__ = 67;
    break;
   case 66:
    var $n_6;
    _libuxre_bktfree($bp);
    var $_0 = $n_6;
    __label__ = 67;
    break;
   case 67:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_bktmbcomp["X"] = 1;
function _eqcls($bp, $s, $n, $prev, $mb_cur_max) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 28;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $mcbuf = __stackBase__;
    var $1 = $s + $n | 0;
    var $2 = $mcbuf | 0;
    HEAP32[$2 >> 2] = $1;
    var $3 = $mcbuf + 4 | 0;
    HEAP32[$3 >> 2] = $s;
    var $4 = $mcbuf + 8 | 0;
    HEAP32[$4 >> 2] = $bp;
    var $5 = $bp | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $mcbuf + 12 | 0;
    HEAP32[$7 >> 2] = $6;
    var $8 = $mcbuf + 16 | 0;
    HEAP32[$8 >> 2] = 0;
    var $9 = $mcbuf + 20 | 0;
    HEAP32[$9 >> 2] = 0;
    var $10 = _mcce($mcbuf, 0, $s, $mb_cur_max);
    var $11 = ($10 | 0) == 0;
    if ($11) {
      __label__ = 3;
      break;
    } else {
      var $_0 = $10;
      __label__ = 25;
      break;
    }
   case 3:
    var $13 = HEAP32[$8 >> 2];
    var $14 = ($13 | 0) == 0;
    if ($14) {
      var $_0 = -5;
      __label__ = 25;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $16 = HEAP32[$3 >> 2];
    var $17 = HEAP32[$2 >> 2];
    var $18 = ($16 | 0) == ($17 | 0);
    if ($18) {
      __label__ = 5;
      break;
    } else {
      var $_0 = -5;
      __label__ = 25;
      break;
    }
   case 5:
    var $20 = $mcbuf + 24 | 0;
    var $21 = HEAP32[$20 >> 2];
    var $22 = ($13 | 0) == -1;
    if ($22) {
      var $last_1 = $21;
      var $85 = $21;
      __label__ = 21;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $24 = HEAP32[$7 >> 2];
    var $25 = $24 + 37 | 0;
    var $26 = HEAP8[$25];
    var $27 = ($26 & 255) > 1;
    if ($27) {
      __label__ = 7;
      break;
    } else {
      var $last_1 = $21;
      var $85 = $21;
      __label__ = 21;
      break;
    }
   case 7:
    var $29 = $13 + 4 | 0;
    var $30 = HEAP32[$29 >> 2];
    var $31 = HEAP32[$5 >> 2];
    var $32 = _libuxre_collmult($31, $13, 0);
    var $33 = ($32 | 0) == 0;
    if ($33) {
      var $last_0 = $30;
      var $83 = $30;
      __label__ = 20;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $35 = $32 + 8 | 0;
    var $36 = HEAP32[$35 >> 2];
    var $37 = ($36 | 0) == 0;
    if ($37) {
      var $last_0 = $30;
      var $83 = $30;
      __label__ = 20;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $39 = $32 + 2 | 0;
    var $40 = HEAP16[$39 >> 1];
    var $41 = $40 << 16 >> 16 == -32768;
    if ($41) {
      __label__ = 10;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 10:
    var $43 = ($prev | 0) > 0;
    if ($43) {
      __label__ = 11;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 11:
    var $45 = $32 + 4 | 0;
    var $46 = HEAP32[$45 >> 2];
    var $47 = ($46 | 0) == ($prev | 0);
    if ($47) {
      __label__ = 13;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $49 = _addrange($bp, $46, $prev);
    var $50 = ($49 | 0) == 0;
    if ($50) {
      __label__ = 13;
      break;
    } else {
      var $_0 = $49;
      __label__ = 25;
      break;
    }
   case 13:
    var $52 = $bp + 210 | 0;
    var $53 = HEAP16[$52 >> 1];
    var $54 = $53 & 65535;
    var $55 = ($53 & 65535) < 4;
    if ($55) {
      __label__ = 14;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 14:
    var $57 = HEAP32[$8 >> 2];
    var $58 = $57 + 8 | 0;
    var $59 = HEAP32[$58 >> 2];
    var $60 = $bp + 32 + ($54 << 2) | 0;
    HEAP32[$60 >> 2] = $59;
    __label__ = 18;
    break;
   case 15:
    var $62 = $54 & 3;
    var $63 = ($62 | 0) == 0;
    var $64 = $bp + 8 | 0;
    var $65 = HEAP32[$64 >> 2];
    if ($63) {
      __label__ = 16;
      break;
    } else {
      var $72 = $65;
      __label__ = 17;
      break;
    }
   case 16:
    var $67 = $65;
    var $68 = $54 << 2;
    var $69 = _realloc($67, $68);
    var $70 = $69;
    HEAP32[$64 >> 2] = $70;
    var $71 = ($69 | 0) == 0;
    if ($71) {
      var $_0 = 17;
      __label__ = 25;
      break;
    } else {
      var $72 = $70;
      __label__ = 17;
      break;
    }
   case 17:
    var $72;
    var $73 = $54 - 4 | 0;
    var $74 = HEAP32[$8 >> 2];
    var $75 = $74 + 8 | 0;
    var $76 = HEAP32[$75 >> 2];
    var $77 = $72 + ($73 << 2) | 0;
    HEAP32[$77 >> 2] = $76;
    __label__ = 18;
    break;
   case 18:
    var $79 = HEAP16[$52 >> 1];
    var $80 = $79 + 1 & 65535;
    HEAP16[$52 >> 1] = $80;
    var $_0 = $36;
    __label__ = 25;
    break;
   case 19:
    HEAP32[$8 >> 2] = $32;
    var $_phi_trans_insert = $32 + 4 | 0;
    var $_pre = HEAP32[$_phi_trans_insert >> 2];
    var $last_0 = $36;
    var $83 = $_pre;
    __label__ = 20;
    break;
   case 20:
    var $83;
    var $last_0;
    HEAP32[$20 >> 2] = $83;
    var $last_1 = $last_0;
    var $85 = $83;
    __label__ = 21;
    break;
   case 21:
    var $85;
    var $last_1;
    var $86 = ($prev | 0) < 1;
    if ($86) {
      __label__ = 22;
      break;
    } else {
      var $_01 = $prev;
      __label__ = 24;
      break;
    }
   case 22:
    var $88 = $85 - 1 | 0;
    var $89 = ($88 | 0) < 1;
    if ($89) {
      __label__ = 23;
      break;
    } else {
      var $_01 = $88;
      __label__ = 24;
      break;
    }
   case 23:
    var $91 = _addrange($bp, $85, 0);
    var $92 = ($91 | 0) == 0;
    if ($92) {
      var $_01 = 0;
      __label__ = 24;
      break;
    } else {
      var $_0 = $91;
      __label__ = 25;
      break;
    }
   case 24:
    var $_01;
    var $94 = _addrange($bp, $last_1, $_01);
    HEAP32[$20 >> 2] = $94;
    var $95 = ($94 | 0) == 0;
    var $last_1_ = $95 ? $last_1 : $94;
    var $_0 = $last_1_;
    __label__ = 25;
    break;
   case 25:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_eqcls["X"] = 1;
function _chcls($n) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($n | 0) > 127;
    if ($1) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    _wctype();
   case 4:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _libuxre_collelem($col, $spare, $wc) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($col | 0) == 0;
    if ($1) {
      var $_0 = -1;
      __label__ = 22;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = $col + 34 | 0;
    var $4 = HEAP16[$3 >> 1];
    var $5 = $4 & 65535;
    var $6 = $5 & 1;
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 4;
      break;
    } else {
      var $_0 = -1;
      __label__ = 22;
      break;
    }
   case 4:
    var $9 = $col + 8 | 0;
    var $10 = HEAP32[$9 >> 2];
    var $11 = $10;
    var $12 = ($10 | 0) == 0;
    if ($12) {
      var $_0 = -1;
      __label__ = 22;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $14 = $wc >>> 0 < 256;
    if ($14) {
      __label__ = 6;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 6:
    var $16 = $col + 36 | 0;
    var $17 = HEAP8[$16];
    var $18 = $17 & 255;
    var $19 = $18 * $wc | 0;
    var $_sum4 = $19 + 4 | 0;
    var $20 = $11 + $_sum4 | 0;
    var $21 = $20;
    var $22 = HEAP32[$21 >> 2];
    var $23 = ($22 | 0) == -2147483648;
    if ($23) {
      var $_0 = 0;
      __label__ = 22;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $25 = $11 + $19 | 0;
    var $26 = $25;
    var $_0 = $26;
    __label__ = 22;
    break;
   case 8:
    var $28 = $5 & 2;
    var $29 = ($28 | 0) == 0;
    if ($29) {
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $31 = $col + 28 | 0;
    var $32 = HEAP32[$31 >> 2];
    var $33 = $32 >>> 0 > $wc >>> 0;
    if ($33) {
      __label__ = 6;
      break;
    } else {
      var $_0 = 0;
      __label__ = 22;
      break;
    }
   case 10:
    var $35 = $col + 36 | 0;
    var $36 = HEAP8[$35];
    var $37 = $36 & 255;
    var $38 = $37 + 4 | 0;
    var $39 = $37 << 8;
    var $40 = $col + 28 | 0;
    var $41 = HEAP32[$40 >> 2];
    var $42 = $41 - 255 | 0;
    var $lo_0_ph = 0;
    var $hi_0_ph = $42;
    __label__ = 11;
    break;
   case 11:
    var $hi_0_ph;
    var $lo_0_ph;
    var $lo_0 = $lo_0_ph;
    __label__ = 12;
    break;
   case 12:
    var $lo_0;
    var $44 = $lo_0 >>> 0 < $hi_0_ph >>> 0;
    if ($44) {
      __label__ = 13;
      break;
    } else {
      var $_0 = 0;
      __label__ = 22;
      break;
    }
   case 13:
    var $46 = $lo_0 + $hi_0_ph | 0;
    var $47 = $46 >>> 1;
    var $48 = $47 | -2147483648;
    var $49 = $47 >>> 0 < $lo_0 >>> 0;
    var $_ = $49 ? $48 : $47;
    var $50 = $_ * $38 | 0;
    var $_sum = $50 + $39 | 0;
    var $51 = $11 + $_sum | 0;
    var $52 = $51;
    var $53 = HEAP32[$52 >> 2];
    var $54 = $wc - $53 | 0;
    var $55 = ($54 | 0) < 0;
    if ($55) {
      var $lo_0_ph = $lo_0;
      var $hi_0_ph = $_;
      __label__ = 11;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $_sum1 = $_sum + 4 | 0;
    var $57 = $11 + $_sum1 | 0;
    var $_sum2 = $_sum + 6 | 0;
    var $58 = $11 + $_sum2 | 0;
    var $59 = $58;
    var $60 = HEAP16[$59 >> 1];
    var $61 = $60 & 65535;
    var $62 = $61 & 32768;
    var $63 = ($62 | 0) == 0;
    if ($63) {
      __label__ = 21;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $65 = $61 & 32767;
    var $66 = ($54 | 0) > ($65 | 0);
    if ($66) {
      __label__ = 16;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 16:
    var $lo_0_be = $_ + 1 | 0;
    var $lo_0 = $lo_0_be;
    __label__ = 12;
    break;
   case 17:
    var $68 = $57;
    var $69 = HEAP16[$68 >> 1];
    var $70 = $spare | 0;
    HEAP16[$70 >> 1] = $69;
    var $71 = $spare + 2 | 0;
    HEAP16[$71 >> 1] = 0;
    var $_sum3 = $_sum + 8 | 0;
    var $72 = $11 + $_sum3 | 0;
    var $73 = $72;
    var $74 = $72;
    var $75 = HEAP32[$74 >> 2];
    var $76 = $75 + $54 | 0;
    var $77 = $spare + 4 | 0;
    HEAP32[$77 >> 2] = $76;
    var $78 = $col + 37 | 0;
    var $79 = HEAP8[$78];
    var $80 = ($79 & 255) > 1;
    if ($80) {
      var $lo_15 = 1;
      __label__ = 18;
      break;
    } else {
      var $_0 = $spare;
      __label__ = 22;
      break;
    }
   case 18:
    var $lo_15;
    var $81 = $73 + ($lo_15 << 2) | 0;
    var $82 = HEAP32[$81 >> 2];
    var $83 = ($82 | 0) == -2147483648;
    if ($83) {
      __label__ = 19;
      break;
    } else {
      var $w_0 = $82;
      __label__ = 20;
      break;
    }
   case 19:
    var $85 = HEAP32[$77 >> 2];
    var $w_0 = $85;
    __label__ = 20;
    break;
   case 20:
    var $w_0;
    var $87 = $spare + 4 + ($lo_15 << 2) | 0;
    HEAP32[$87 >> 2] = $w_0;
    var $88 = $lo_15 + 1 | 0;
    var $89 = HEAP8[$78];
    var $90 = $89 & 255;
    var $91 = $88 >>> 0 < $90 >>> 0;
    if ($91) {
      var $lo_15 = $88;
      __label__ = 18;
      break;
    } else {
      var $_0 = $spare;
      __label__ = 22;
      break;
    }
   case 21:
    var $93 = $57;
    var $94 = ($53 | 0) == ($wc | 0);
    if ($94) {
      var $_0 = $93;
      __label__ = 22;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 22:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_libuxre_collelem["X"] = 1;
function _libuxre_collmult($col, $cep, $wc) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($col | 0) == 0;
    if ($1) {
      var $_0 = 0;
      __label__ = 10;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = $cep | 0;
    var $4 = HEAP16[$3 >> 1];
    var $5 = $4 & 65535;
    var $6 = $4 << 16 >> 16 == 0;
    if ($6) {
      var $_0 = 0;
      __label__ = 10;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $8 = $col + 12 | 0;
    var $9 = HEAP32[$8 >> 2];
    var $10 = ($9 | 0) == 0;
    if ($10) {
      var $_0 = 0;
      __label__ = 10;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $12 = $9;
    var $13 = $col + 36 | 0;
    var $14 = HEAP8[$13];
    var $15 = $14 & 255;
    var $16 = $15 + 4 | 0;
    var $17 = $16 * $5 | 0;
    var $18 = $12 + $17 | 0;
    var $tbl_0 = $18;
    __label__ = 6;
    break;
   case 6:
    var $tbl_0;
    var $20 = $tbl_0;
    var $21 = HEAP32[$20 >> 2];
    var $22 = ($21 | 0) == ($wc | 0);
    if ($22) {
      __label__ = 9;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $24 = ($21 | 0) == 0;
    if ($24) {
      var $_0 = 0;
      __label__ = 10;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $26 = $tbl_0 + $16 | 0;
    var $tbl_0 = $26;
    __label__ = 6;
    break;
   case 9:
    var $28 = $tbl_0 + 4 | 0;
    var $29 = $28;
    var $_0 = $29;
    __label__ = 10;
    break;
   case 10:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _clsym($bp, $s, $n, $prev, $mb_cur_max) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 28;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $mcbuf = __stackBase__;
    var $1 = $s + $n | 0;
    var $2 = $mcbuf | 0;
    HEAP32[$2 >> 2] = $1;
    var $3 = $mcbuf + 4 | 0;
    HEAP32[$3 >> 2] = $s;
    var $4 = $mcbuf + 8 | 0;
    HEAP32[$4 >> 2] = $bp;
    var $5 = $bp | 0;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $mcbuf + 12 | 0;
    HEAP32[$7 >> 2] = $6;
    var $8 = $mcbuf + 16 | 0;
    HEAP32[$8 >> 2] = 0;
    var $9 = $mcbuf + 20 | 0;
    HEAP32[$9 >> 2] = 0;
    var $10 = _mcce($mcbuf, 0, $s, $mb_cur_max);
    var $11 = ($10 | 0) == 0;
    if ($11) {
      __label__ = 3;
      break;
    } else {
      var $_0 = $10;
      __label__ = 10;
      break;
    }
   case 3:
    var $13 = HEAP32[$8 >> 2];
    var $14 = ($13 | 0) == 0;
    if ($14) {
      var $_0 = -3;
      __label__ = 10;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $16 = HEAP32[$3 >> 2];
    var $17 = HEAP32[$2 >> 2];
    var $18 = ($16 | 0) == ($17 | 0);
    if ($18) {
      __label__ = 5;
      break;
    } else {
      var $_0 = -3;
      __label__ = 10;
      break;
    }
   case 5:
    var $20 = ($13 | 0) == -1;
    if ($20) {
      __label__ = 6;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 6:
    var $_phi_trans_insert = $mcbuf + 24 | 0;
    var $_pre = HEAP32[$_phi_trans_insert >> 2];
    var $26 = $_pre;
    __label__ = 8;
    break;
   case 7:
    var $22 = $13 + 4 | 0;
    var $23 = HEAP32[$22 >> 2];
    var $24 = $mcbuf + 24 | 0;
    HEAP32[$24 >> 2] = $23;
    var $26 = $23;
    __label__ = 8;
    break;
   case 8:
    var $26;
    var $27 = _addrange($bp, $26, $prev);
    var $28 = ($27 | 0) == 0;
    if ($28) {
      __label__ = 9;
      break;
    } else {
      var $_0 = $27;
      __label__ = 10;
      break;
    }
   case 9:
    var $30 = $mcbuf + 24 | 0;
    var $31 = HEAP32[$30 >> 2];
    var $_0 = $31;
    __label__ = 10;
    break;
   case 10:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _place($bp, $wc, $prev) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 8;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $spare = __stackBase__;
    var $1 = $bp | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = _libuxre_collelem($2, $spare, $wc);
    var $magicptr = $3;
    if (($magicptr | 0) == -1) {
      var $_01 = $wc;
      __label__ = 4;
      break;
    } else if (($magicptr | 0) == 0) {
      var $_0 = -6;
      __label__ = 5;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = $3 + 4 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $_01 = $6;
    __label__ = 4;
    break;
   case 4:
    var $_01;
    var $8 = _addrange($bp, $_01, $prev);
    var $9 = ($8 | 0) == 0;
    var $_01_ = $9 ? $_01 : $8;
    var $_0 = $_01_;
    __label__ = 5;
    break;
   case 5:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _addrange($bp, $ord, $prev) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($prev | 0) < 1;
    var $2 = ($prev | 0) == ($ord | 0);
    var $or_cond = $1 | $2;
    if ($or_cond) {
      __label__ = 15;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $4 = ($prev | 0) > ($ord | 0);
    if ($4) {
      __label__ = 4;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 4:
    var $6 = $bp + 216 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = $7 & 4096;
    var $9 = ($8 | 0) == 0;
    if ($9) {
      __label__ = 5;
      break;
    } else {
      var $_0 = 0;
      __label__ = 19;
      break;
    }
   case 5:
    var $11 = $7 & 8;
    var $12 = ($11 | 0) == 0;
    if ($12) {
      var $_0 = -16;
      __label__ = 19;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 6:
    var $14 = $prev + 1 | 0;
    var $15 = ($14 | 0) < 256;
    if ($15) {
      __label__ = 7;
      break;
    } else {
      var $_1 = $14;
      __label__ = 10;
      break;
    }
   case 7:
    var $16 = $prev - $ord | 0;
    var $17 = $prev - 255 | 0;
    var $18 = $16 >>> 0 > $17 >>> 0;
    var $umax = $18 ? $16 : $17;
    var $19 = $14 - $umax | 0;
    var $_01 = $14;
    __label__ = 8;
    break;
   case 8:
    var $_01;
    var $21 = $_01 & 15;
    var $22 = 1 << $21;
    var $23 = $_01 >> 4;
    var $24 = $bp + 176 + ($23 << 1) | 0;
    var $25 = HEAP16[$24 >> 1];
    var $26 = $25 & 65535;
    var $27 = $26 | $22;
    var $28 = $27 & 65535;
    HEAP16[$24 >> 1] = $28;
    var $29 = ($_01 | 0) == ($ord | 0);
    if ($29) {
      var $_0 = 0;
      __label__ = 19;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $31 = $_01 + 1 | 0;
    var $32 = ($31 | 0) < 256;
    if ($32) {
      var $_01 = $31;
      __label__ = 8;
      break;
    } else {
      var $_1 = $19;
      __label__ = 10;
      break;
    }
   case 10:
    var $_1;
    var $33 = _addwide($bp, $_1);
    var $34 = ($33 | 0) == 0;
    if ($34) {
      __label__ = 11;
      break;
    } else {
      var $_0 = $33;
      __label__ = 19;
      break;
    }
   case 11:
    var $36 = $_1 + 1 | 0;
    var $37 = ($36 | 0) > ($ord | 0);
    if ($37) {
      var $_0 = 0;
      __label__ = 19;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $39 = ($36 | 0) < ($ord | 0);
    if ($39) {
      __label__ = 13;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 13:
    var $41 = _addwide($bp, 45);
    var $42 = ($41 | 0) == 0;
    if ($42) {
      __label__ = 14;
      break;
    } else {
      var $_0 = $41;
      __label__ = 19;
      break;
    }
   case 14:
    var $44 = _addwide($bp, $ord);
    var $_0 = $44;
    __label__ = 19;
    break;
   case 15:
    var $46 = ($ord | 0) < 256;
    if ($46) {
      __label__ = 16;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 16:
    var $48 = $ord & 15;
    var $49 = 1 << $48;
    var $50 = $ord >> 4;
    var $51 = $bp + 176 + ($50 << 1) | 0;
    var $52 = HEAP16[$51 >> 1];
    var $53 = $52 & 65535;
    var $54 = $53 | $49;
    var $55 = $54 & 65535;
    HEAP16[$51 >> 1] = $55;
    var $_0 = 0;
    __label__ = 19;
    break;
   case 17:
    if ($2) {
      var $_0 = 0;
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $58 = _addwide($bp, $ord);
    var $_0 = $58;
    __label__ = 19;
    break;
   case 19:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_addrange["X"] = 1;
function _addwide($bp, $ord) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $bp + 212 | 0;
    var $2 = HEAP16[$1 >> 1];
    var $3 = $2 & 65535;
    var $4 = ($2 & 65535) < 32;
    if ($4) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $6 = $bp + 48 + ($3 << 2) | 0;
    HEAP32[$6 >> 2] = $ord;
    __label__ = 7;
    break;
   case 4:
    var $8 = $3 & 31;
    var $9 = ($8 | 0) == 0;
    var $10 = $bp + 12 | 0;
    var $11 = HEAP32[$10 >> 2];
    if ($9) {
      __label__ = 5;
      break;
    } else {
      var $18 = $11;
      __label__ = 6;
      break;
    }
   case 5:
    var $13 = $11;
    var $14 = $3 << 2;
    var $15 = _realloc($13, $14);
    var $16 = $15;
    HEAP32[$10 >> 2] = $16;
    var $17 = ($15 | 0) == 0;
    if ($17) {
      var $_0 = -17;
      __label__ = 8;
      break;
    } else {
      var $18 = $16;
      __label__ = 6;
      break;
    }
   case 6:
    var $18;
    var $19 = $3 - 32 | 0;
    var $20 = $18 + ($19 << 2) | 0;
    HEAP32[$20 >> 2] = $ord;
    __label__ = 7;
    break;
   case 7:
    var $22 = HEAP16[$1 >> 1];
    var $23 = $22 + 1 & 65535;
    HEAP16[$1 >> 1] = $23;
    var $_0 = 0;
    __label__ = 8;
    break;
   case 8:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _deltolist($gp, $list) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $gp + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 7;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    HEAP32[$1 >> 2] = 0;
    var $5 = $gp + 8 | 0;
    var $6 = HEAP32[$5 >> 2];
    var $_off = $6 + 34 | 0;
    var $switch = $_off >>> 0 < 2;
    if ($switch) {
      __label__ = 4;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 4:
    var $8 = $gp | 0;
    var $9 = HEAP32[$8 >> 2];
    _deltolist($9, $list);
    __label__ = 5;
    break;
   case 5:
    _deltolist($2, $list);
    var $11 = HEAP32[$5 >> 2];
    var $12 = ($11 | 0) == -9;
    if ($12) {
      __label__ = 6;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 6:
    var $14 = $gp;
    var $15 = HEAP32[$14 >> 2];
    _libuxre_bktfree($15);
    var $16 = HEAP32[$14 >> 2];
    var $17 = $16;
    _free($17);
    __label__ = 9;
    break;
   case 7:
    var $19 = $gp + 8 | 0;
    var $20 = HEAP32[$19 >> 2];
    var $21 = ($20 | 0) == -14;
    if ($21) {
      __label__ = 8;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 8:
    HEAP32[$19 >> 2] = -1;
    __label__ = 9;
    break;
   case 9:
    var $24 = HEAP32[$list >> 2];
    var $25 = $gp | 0;
    HEAP32[$25 >> 2] = $24;
    HEAP32[$list >> 2] = $gp;
    __label__ = 10;
    break;
   case 10:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _mcce($mcp, $cep, $s, $mb_cur_max) {
  var __stackBase__ = STACKTOP;
  STACKTOP += 12;
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $spare = __stackBase__;
    var $wc = __stackBase__ + 8;
    var $1 = $mcp + 20 | 0;
    var $2 = HEAP32[$1 >> 2];
    HEAP32[$wc >> 2] = $2;
    var $3 = ($2 | 0) == 0;
    if ($3) {
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    HEAP32[$1 >> 2] = 0;
    var $_01 = $s;
    __label__ = 9;
    break;
   case 4:
    var $6 = $s + 1 | 0;
    var $7 = HEAP8[$s];
    var $8 = $7 & 255;
    HEAP32[$wc >> 2] = $8;
    var $9 = $8 & 128;
    var $10 = ($9 | 0) == 0;
    var $11 = ($mb_cur_max | 0) == 1;
    var $or_cond = $10 | $11;
    if ($or_cond) {
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $13 = $7 << 24 >> 24 == 0;
    if ($13) {
      var $_0 = 0;
      __label__ = 31;
      break;
    } else {
      var $_01 = $6;
      __label__ = 9;
      break;
    }
   case 6:
    var $15 = _libuxre_mb2wc($wc, $6);
    var $16 = ($15 | 0) > 0;
    if ($16) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $_sum = $15 + 1 | 0;
    var $18 = $s + $_sum | 0;
    var $19 = $mcp | 0;
    var $20 = HEAP32[$19 >> 2];
    var $21 = ($20 | 0) != 0;
    var $22 = $18 >>> 0 > $20 >>> 0;
    var $or_cond1 = $21 & $22;
    if ($or_cond1) {
      var $_0 = 0;
      __label__ = 31;
      break;
    } else {
      var $_01 = $18;
      __label__ = 9;
      break;
    }
   case 8:
    var $24 = ($15 | 0) < 0;
    if ($24) {
      var $_0 = -20;
      __label__ = 31;
      break;
    } else {
      var $_01 = $6;
      __label__ = 9;
      break;
    }
   case 9:
    var $_01;
    var $25 = HEAP32[$wc >> 2];
    var $26 = $mcp + 8 | 0;
    var $27 = HEAP32[$26 >> 2];
    var $28 = $27 + 216 | 0;
    var $29 = HEAP32[$28 >> 2];
    var $30 = $29 & 2;
    var $31 = ($30 | 0) == 0;
    if ($31) {
      var $ch_0_ph = $25;
      var $40 = $25;
      __label__ = 14;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $33 = ($mb_cur_max | 0) > 1;
    if ($33) {
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 11:
    _towlower();
   case 12:
    var $36 = _tolower($25);
    HEAP32[$wc >> 2] = $36;
    var $37 = ($36 | 0) == ($25 | 0);
    if ($37) {
      __label__ = 13;
      break;
    } else {
      var $ch_0_ph = $25;
      var $40 = $36;
      __label__ = 14;
      break;
    }
   case 13:
    var $39 = _toupper($36);
    var $ch_0_ph = $39;
    var $40 = $36;
    __label__ = 14;
    break;
   case 14:
    var $40;
    var $ch_0_ph;
    var $41 = ($cep | 0) == 0;
    var $42 = $mcp + 12 | 0;
    var $43 = $mcp | 0;
    var $44 = $mcp + 4 | 0;
    var $45 = $mcp + 16 | 0;
    var $46 = $mcp + 24 | 0;
    var $48 = $40;
    __label__ = 15;
    break;
   case 15:
    var $48;
    var $49 = HEAP32[$42 >> 2];
    if ($41) {
      __label__ = 16;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 16:
    var $51 = _libuxre_collelem($49, $spare, $48);
    var $52 = ($51 | 0) == -1;
    if ($52) {
      __label__ = 19;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    var $54 = HEAP32[$42 >> 2];
    var $55 = $54 + 34 | 0;
    var $56 = HEAP16[$55 >> 1];
    var $57 = $56 & 4;
    var $58 = $57 << 16 >> 16 == 0;
    if ($58) {
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $60 = HEAP32[$43 >> 2];
    var $61 = ($_01 | 0) == ($60 | 0);
    if ($61) {
      __label__ = 19;
      break;
    } else {
      var $nxt_0 = $51;
      __label__ = 21;
      break;
    }
   case 19:
    HEAP32[$44 >> 2] = $_01;
    HEAP32[$45 >> 2] = $51;
    HEAP32[$46 >> 2] = $48;
    var $_0 = 0;
    __label__ = 31;
    break;
   case 20:
    var $64 = _libuxre_collmult($49, $cep, $48);
    var $nxt_0 = $64;
    __label__ = 21;
    break;
   case 21:
    var $nxt_0;
    var $66 = ($nxt_0 | 0) == 0;
    if ($66) {
      __label__ = 29;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    var $68 = $nxt_0 + 4 | 0;
    var $69 = HEAP32[$68 >> 2];
    var $70 = ($69 | 0) == 0;
    if ($70) {
      __label__ = 26;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $72 = HEAP32[$44 >> 2];
    var $73 = $72 >>> 0 < $_01 >>> 0;
    if ($73) {
      __label__ = 25;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 24:
    var $75 = HEAP32[$45 >> 2];
    var $76 = ($75 | 0) == 0;
    if ($76) {
      __label__ = 25;
      break;
    } else {
      __label__ = 26;
      break;
    }
   case 25:
    HEAP32[$44 >> 2] = $_01;
    HEAP32[$45 >> 2] = $nxt_0;
    HEAP32[$46 >> 2] = $48;
    __label__ = 26;
    break;
   case 26:
    var $79 = $nxt_0 | 0;
    var $80 = HEAP16[$79 >> 1];
    var $81 = $80 << 16 >> 16 == 0;
    if ($81) {
      __label__ = 29;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $83 = HEAP32[$43 >> 2];
    var $84 = ($83 | 0) == 0;
    var $85 = $_01 >>> 0 < $83 >>> 0;
    var $or_cond2 = $84 | $85;
    if ($or_cond2) {
      __label__ = 28;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 28:
    var $87 = _mcce($mcp, $nxt_0, $_01, $mb_cur_max);
    var $88 = ($87 | 0) == 0;
    if ($88) {
      __label__ = 29;
      break;
    } else {
      var $_0 = $87;
      __label__ = 31;
      break;
    }
   case 29:
    var $90 = ($48 | 0) == ($ch_0_ph | 0);
    if ($90) {
      var $_0 = 0;
      __label__ = 31;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    HEAP32[$wc >> 2] = $ch_0_ph;
    var $48 = $ch_0_ph;
    __label__ = 15;
    break;
   case 31:
    var $_0;
    STACKTOP = __stackBase__;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_mcce["X"] = 1;
function _ems_stub_error($func_name) {
  _fprintf(HEAP32[_stderr >> 2], STRING_TABLE.__str419 | 0, (tempInt = STACKTOP, STACKTOP += 4, HEAP32[tempInt >> 2] = $func_name, tempInt));
  _abort();
}
function _btowc() {
  _ems_stub_error(STRING_TABLE.__str1420 | 0);
}
function _iswctype() {
  _ems_stub_error(STRING_TABLE.__str2421 | 0);
}
function _iswalnum() {
  _ems_stub_error(STRING_TABLE.__str3422 | 0);
}
function _towlower() {
  _ems_stub_error(STRING_TABLE.__str4423 | 0);
}
function _towupper() {
  _ems_stub_error(STRING_TABLE.__str5424 | 0);
}
function _wctype() {
  _ems_stub_error(STRING_TABLE.__str6425 | 0);
}
function _malloc($bytes) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $bytes >>> 0 < 245;
    if ($1) {
      __label__ = 3;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 3:
    var $3 = $bytes >>> 0 < 11;
    if ($3) {
      var $8 = 16;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $5 = $bytes + 11 | 0;
    var $6 = $5 & -8;
    var $8 = $6;
    __label__ = 5;
    break;
   case 5:
    var $8;
    var $9 = $8 >>> 3;
    var $10 = HEAP32[__gm_ >> 2];
    var $11 = $10 >>> ($9 >>> 0);
    var $12 = $11 & 3;
    var $13 = ($12 | 0) == 0;
    if ($13) {
      __label__ = 12;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $15 = $11 & 1;
    var $16 = $15 ^ 1;
    var $17 = $16 + $9 | 0;
    var $18 = $17 << 1;
    var $19 = __gm_ + 40 + ($18 << 2) | 0;
    var $20 = $19;
    var $_sum10 = $18 + 2 | 0;
    var $21 = __gm_ + 40 + ($_sum10 << 2) | 0;
    var $22 = HEAP32[$21 >> 2];
    var $23 = $22 + 8 | 0;
    var $24 = HEAP32[$23 >> 2];
    var $25 = ($20 | 0) == ($24 | 0);
    if ($25) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $27 = 1 << $17;
    var $28 = $27 ^ -1;
    var $29 = $10 & $28;
    HEAP32[__gm_ >> 2] = $29;
    __label__ = 11;
    break;
   case 8:
    var $31 = $24;
    var $32 = HEAP32[__gm_ + 16 >> 2];
    var $33 = $31 >>> 0 < $32 >>> 0;
    if ($33) {
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    HEAP32[$21 >> 2] = $24;
    var $35 = $24 + 12 | 0;
    HEAP32[$35 >> 2] = $20;
    __label__ = 11;
    break;
   case 10:
    _abort();
   case 11:
    var $38 = $17 << 3;
    var $39 = $38 | 3;
    var $40 = $22 + 4 | 0;
    HEAP32[$40 >> 2] = $39;
    var $41 = $22;
    var $_sum1112 = $38 | 4;
    var $42 = $41 + $_sum1112 | 0;
    var $43 = $42;
    var $44 = HEAP32[$43 >> 2];
    var $45 = $44 | 1;
    HEAP32[$43 >> 2] = $45;
    var $46 = $23;
    var $mem_0 = $46;
    __label__ = 39;
    break;
   case 12:
    var $48 = HEAP32[__gm_ + 8 >> 2];
    var $49 = $8 >>> 0 > $48 >>> 0;
    if ($49) {
      __label__ = 13;
      break;
    } else {
      var $nb_0 = $8;
      __label__ = 31;
      break;
    }
   case 13:
    var $51 = ($11 | 0) == 0;
    if ($51) {
      __label__ = 26;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $53 = $11 << $9;
    var $54 = 2 << $9;
    var $55 = -$54 | 0;
    var $56 = $54 | $55;
    var $57 = $53 & $56;
    var $58 = -$57 | 0;
    var $59 = $57 & $58;
    var $60 = $59 - 1 | 0;
    var $61 = $60 >>> 12;
    var $62 = $61 & 16;
    var $63 = $60 >>> ($62 >>> 0);
    var $64 = $63 >>> 5;
    var $65 = $64 & 8;
    var $66 = $63 >>> ($65 >>> 0);
    var $67 = $66 >>> 2;
    var $68 = $67 & 4;
    var $69 = $66 >>> ($68 >>> 0);
    var $70 = $69 >>> 1;
    var $71 = $70 & 2;
    var $72 = $69 >>> ($71 >>> 0);
    var $73 = $72 >>> 1;
    var $74 = $73 & 1;
    var $75 = $65 | $62;
    var $76 = $75 | $68;
    var $77 = $76 | $71;
    var $78 = $77 | $74;
    var $79 = $72 >>> ($74 >>> 0);
    var $80 = $78 + $79 | 0;
    var $81 = $80 << 1;
    var $82 = __gm_ + 40 + ($81 << 2) | 0;
    var $83 = $82;
    var $_sum4 = $81 + 2 | 0;
    var $84 = __gm_ + 40 + ($_sum4 << 2) | 0;
    var $85 = HEAP32[$84 >> 2];
    var $86 = $85 + 8 | 0;
    var $87 = HEAP32[$86 >> 2];
    var $88 = ($83 | 0) == ($87 | 0);
    if ($88) {
      __label__ = 15;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 15:
    var $90 = 1 << $80;
    var $91 = $90 ^ -1;
    var $92 = $10 & $91;
    HEAP32[__gm_ >> 2] = $92;
    __label__ = 19;
    break;
   case 16:
    var $94 = $87;
    var $95 = HEAP32[__gm_ + 16 >> 2];
    var $96 = $94 >>> 0 < $95 >>> 0;
    if ($96) {
      __label__ = 18;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    HEAP32[$84 >> 2] = $87;
    var $98 = $87 + 12 | 0;
    HEAP32[$98 >> 2] = $83;
    __label__ = 19;
    break;
   case 18:
    _abort();
   case 19:
    var $101 = $80 << 3;
    var $102 = $101 - $8 | 0;
    var $103 = $8 | 3;
    var $104 = $85 + 4 | 0;
    HEAP32[$104 >> 2] = $103;
    var $105 = $85;
    var $106 = $105 + $8 | 0;
    var $107 = $106;
    var $108 = $102 | 1;
    var $_sum56 = $8 | 4;
    var $109 = $105 + $_sum56 | 0;
    var $110 = $109;
    HEAP32[$110 >> 2] = $108;
    var $111 = $105 + $101 | 0;
    var $112 = $111;
    HEAP32[$112 >> 2] = $102;
    var $113 = HEAP32[__gm_ + 8 >> 2];
    var $114 = ($113 | 0) == 0;
    if ($114) {
      __label__ = 25;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 20:
    var $116 = HEAP32[__gm_ + 20 >> 2];
    var $117 = $113 >>> 3;
    var $118 = $113 >>> 2;
    var $119 = $118 & 1073741822;
    var $120 = __gm_ + 40 + ($119 << 2) | 0;
    var $121 = $120;
    var $122 = HEAP32[__gm_ >> 2];
    var $123 = 1 << $117;
    var $124 = $122 & $123;
    var $125 = ($124 | 0) == 0;
    if ($125) {
      __label__ = 21;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 21:
    var $127 = $122 | $123;
    HEAP32[__gm_ >> 2] = $127;
    var $_sum8_pre = $119 + 2 | 0;
    var $_pre = __gm_ + 40 + ($_sum8_pre << 2) | 0;
    var $F4_0 = $121;
    var $_pre_phi = $_pre;
    __label__ = 24;
    break;
   case 22:
    var $_sum9 = $119 + 2 | 0;
    var $129 = __gm_ + 40 + ($_sum9 << 2) | 0;
    var $130 = HEAP32[$129 >> 2];
    var $131 = $130;
    var $132 = HEAP32[__gm_ + 16 >> 2];
    var $133 = $131 >>> 0 < $132 >>> 0;
    if ($133) {
      __label__ = 23;
      break;
    } else {
      var $F4_0 = $130;
      var $_pre_phi = $129;
      __label__ = 24;
      break;
    }
   case 23:
    _abort();
   case 24:
    var $_pre_phi;
    var $F4_0;
    HEAP32[$_pre_phi >> 2] = $116;
    var $136 = $F4_0 + 12 | 0;
    HEAP32[$136 >> 2] = $116;
    var $137 = $116 + 8 | 0;
    HEAP32[$137 >> 2] = $F4_0;
    var $138 = $116 + 12 | 0;
    HEAP32[$138 >> 2] = $121;
    __label__ = 25;
    break;
   case 25:
    HEAP32[__gm_ + 8 >> 2] = $102;
    HEAP32[__gm_ + 20 >> 2] = $107;
    var $140 = $86;
    var $mem_0 = $140;
    __label__ = 39;
    break;
   case 26:
    var $142 = HEAP32[__gm_ + 4 >> 2];
    var $143 = ($142 | 0) == 0;
    if ($143) {
      var $nb_0 = $8;
      __label__ = 31;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 27:
    var $145 = _tmalloc_small($8);
    var $146 = ($145 | 0) == 0;
    if ($146) {
      var $nb_0 = $8;
      __label__ = 31;
      break;
    } else {
      var $mem_0 = $145;
      __label__ = 39;
      break;
    }
   case 28:
    var $148 = $bytes >>> 0 > 4294967231;
    if ($148) {
      var $nb_0 = -1;
      __label__ = 31;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    var $150 = $bytes + 11 | 0;
    var $151 = $150 & -8;
    var $152 = HEAP32[__gm_ + 4 >> 2];
    var $153 = ($152 | 0) == 0;
    if ($153) {
      var $nb_0 = $151;
      __label__ = 31;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    var $155 = _tmalloc_large($151);
    var $156 = ($155 | 0) == 0;
    if ($156) {
      var $nb_0 = $151;
      __label__ = 31;
      break;
    } else {
      var $mem_0 = $155;
      __label__ = 39;
      break;
    }
   case 31:
    var $nb_0;
    var $157 = HEAP32[__gm_ + 8 >> 2];
    var $158 = $nb_0 >>> 0 > $157 >>> 0;
    if ($158) {
      __label__ = 36;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    var $160 = $157 - $nb_0 | 0;
    var $161 = HEAP32[__gm_ + 20 >> 2];
    var $162 = $160 >>> 0 > 15;
    if ($162) {
      __label__ = 33;
      break;
    } else {
      __label__ = 34;
      break;
    }
   case 33:
    var $164 = $161;
    var $165 = $164 + $nb_0 | 0;
    var $166 = $165;
    HEAP32[__gm_ + 20 >> 2] = $166;
    HEAP32[__gm_ + 8 >> 2] = $160;
    var $167 = $160 | 1;
    var $_sum2 = $nb_0 + 4 | 0;
    var $168 = $164 + $_sum2 | 0;
    var $169 = $168;
    HEAP32[$169 >> 2] = $167;
    var $170 = $164 + $157 | 0;
    var $171 = $170;
    HEAP32[$171 >> 2] = $160;
    var $172 = $nb_0 | 3;
    var $173 = $161 + 4 | 0;
    HEAP32[$173 >> 2] = $172;
    __label__ = 35;
    break;
   case 34:
    HEAP32[__gm_ + 8 >> 2] = 0;
    HEAP32[__gm_ + 20 >> 2] = 0;
    var $175 = $157 | 3;
    var $176 = $161 + 4 | 0;
    HEAP32[$176 >> 2] = $175;
    var $177 = $161;
    var $_sum1 = $157 + 4 | 0;
    var $178 = $177 + $_sum1 | 0;
    var $179 = $178;
    var $180 = HEAP32[$179 >> 2];
    var $181 = $180 | 1;
    HEAP32[$179 >> 2] = $181;
    __label__ = 35;
    break;
   case 35:
    var $183 = $161 + 8 | 0;
    var $184 = $183;
    var $mem_0 = $184;
    __label__ = 39;
    break;
   case 36:
    var $186 = HEAP32[__gm_ + 12 >> 2];
    var $187 = $nb_0 >>> 0 < $186 >>> 0;
    if ($187) {
      __label__ = 37;
      break;
    } else {
      __label__ = 38;
      break;
    }
   case 37:
    var $189 = $186 - $nb_0 | 0;
    HEAP32[__gm_ + 12 >> 2] = $189;
    var $190 = HEAP32[__gm_ + 24 >> 2];
    var $191 = $190;
    var $192 = $191 + $nb_0 | 0;
    var $193 = $192;
    HEAP32[__gm_ + 24 >> 2] = $193;
    var $194 = $189 | 1;
    var $_sum = $nb_0 + 4 | 0;
    var $195 = $191 + $_sum | 0;
    var $196 = $195;
    HEAP32[$196 >> 2] = $194;
    var $197 = $nb_0 | 3;
    var $198 = $190 + 4 | 0;
    HEAP32[$198 >> 2] = $197;
    var $199 = $190 + 8 | 0;
    var $200 = $199;
    var $mem_0 = $200;
    __label__ = 39;
    break;
   case 38:
    var $202 = _sys_alloc($nb_0);
    var $mem_0 = $202;
    __label__ = 39;
    break;
   case 39:
    var $mem_0;
    return $mem_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
Module["_malloc"] = _malloc;
_malloc["X"] = 1;
function _tmalloc_small($nb) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[__gm_ + 4 >> 2];
    var $2 = -$1 | 0;
    var $3 = $1 & $2;
    var $4 = $3 - 1 | 0;
    var $5 = $4 >>> 12;
    var $6 = $5 & 16;
    var $7 = $4 >>> ($6 >>> 0);
    var $8 = $7 >>> 5;
    var $9 = $8 & 8;
    var $10 = $7 >>> ($9 >>> 0);
    var $11 = $10 >>> 2;
    var $12 = $11 & 4;
    var $13 = $10 >>> ($12 >>> 0);
    var $14 = $13 >>> 1;
    var $15 = $14 & 2;
    var $16 = $13 >>> ($15 >>> 0);
    var $17 = $16 >>> 1;
    var $18 = $17 & 1;
    var $19 = $9 | $6;
    var $20 = $19 | $12;
    var $21 = $20 | $15;
    var $22 = $21 | $18;
    var $23 = $16 >>> ($18 >>> 0);
    var $24 = $22 + $23 | 0;
    var $25 = __gm_ + 304 + ($24 << 2) | 0;
    var $26 = HEAP32[$25 >> 2];
    var $27 = $26 + 4 | 0;
    var $28 = HEAP32[$27 >> 2];
    var $29 = $28 & -8;
    var $30 = $29 - $nb | 0;
    var $v_0_ph = $26;
    var $rsize_0_ph = $30;
    __label__ = 3;
    break;
   case 3:
    var $rsize_0_ph;
    var $v_0_ph;
    var $t_0 = $v_0_ph;
    __label__ = 4;
    break;
   case 4:
    var $t_0;
    var $32 = $t_0 + 16 | 0;
    var $33 = HEAP32[$32 >> 2];
    var $34 = ($33 | 0) == 0;
    if ($34) {
      __label__ = 5;
      break;
    } else {
      var $39 = $33;
      __label__ = 6;
      break;
    }
   case 5:
    var $36 = $t_0 + 20 | 0;
    var $37 = HEAP32[$36 >> 2];
    var $38 = ($37 | 0) == 0;
    if ($38) {
      __label__ = 7;
      break;
    } else {
      var $39 = $37;
      __label__ = 6;
      break;
    }
   case 6:
    var $39;
    var $40 = $39 + 4 | 0;
    var $41 = HEAP32[$40 >> 2];
    var $42 = $41 & -8;
    var $43 = $42 - $nb | 0;
    var $44 = $43 >>> 0 < $rsize_0_ph >>> 0;
    if ($44) {
      var $v_0_ph = $39;
      var $rsize_0_ph = $43;
      __label__ = 3;
      break;
    } else {
      var $t_0 = $39;
      __label__ = 4;
      break;
    }
   case 7:
    var $46 = $v_0_ph;
    var $47 = HEAP32[__gm_ + 16 >> 2];
    var $48 = $46 >>> 0 < $47 >>> 0;
    if ($48) {
      __label__ = 50;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $50 = $46 + $nb | 0;
    var $51 = $50;
    var $52 = $46 >>> 0 < $50 >>> 0;
    if ($52) {
      __label__ = 9;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 9:
    var $54 = $v_0_ph + 24 | 0;
    var $55 = HEAP32[$54 >> 2];
    var $56 = $v_0_ph + 12 | 0;
    var $57 = HEAP32[$56 >> 2];
    var $58 = ($57 | 0) == ($v_0_ph | 0);
    if ($58) {
      __label__ = 13;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $60 = $v_0_ph + 8 | 0;
    var $61 = HEAP32[$60 >> 2];
    var $62 = $61;
    var $63 = $62 >>> 0 < $47 >>> 0;
    if ($63) {
      __label__ = 12;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 11:
    var $65 = $61 + 12 | 0;
    HEAP32[$65 >> 2] = $57;
    var $66 = $57 + 8 | 0;
    HEAP32[$66 >> 2] = $61;
    var $R_1 = $57;
    __label__ = 20;
    break;
   case 12:
    _abort();
   case 13:
    var $69 = $v_0_ph + 20 | 0;
    var $70 = HEAP32[$69 >> 2];
    var $71 = ($70 | 0) == 0;
    if ($71) {
      __label__ = 14;
      break;
    } else {
      var $RP_0 = $69;
      var $R_0 = $70;
      __label__ = 15;
      break;
    }
   case 14:
    var $73 = $v_0_ph + 16 | 0;
    var $74 = HEAP32[$73 >> 2];
    var $75 = ($74 | 0) == 0;
    if ($75) {
      var $R_1 = 0;
      __label__ = 20;
      break;
    } else {
      var $RP_0 = $73;
      var $R_0 = $74;
      __label__ = 15;
      break;
    }
   case 15:
    var $R_0;
    var $RP_0;
    var $76 = $R_0 + 20 | 0;
    var $77 = HEAP32[$76 >> 2];
    var $78 = ($77 | 0) == 0;
    if ($78) {
      __label__ = 16;
      break;
    } else {
      var $RP_0 = $76;
      var $R_0 = $77;
      __label__ = 15;
      break;
    }
   case 16:
    var $80 = $R_0 + 16 | 0;
    var $81 = HEAP32[$80 >> 2];
    var $82 = ($81 | 0) == 0;
    if ($82) {
      __label__ = 17;
      break;
    } else {
      var $RP_0 = $80;
      var $R_0 = $81;
      __label__ = 15;
      break;
    }
   case 17:
    var $84 = $RP_0;
    var $85 = $84 >>> 0 < $47 >>> 0;
    if ($85) {
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    HEAP32[$RP_0 >> 2] = 0;
    var $R_1 = $R_0;
    __label__ = 20;
    break;
   case 19:
    _abort();
   case 20:
    var $R_1;
    var $89 = ($55 | 0) == 0;
    if ($89) {
      __label__ = 40;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $91 = $v_0_ph + 28 | 0;
    var $92 = HEAP32[$91 >> 2];
    var $93 = __gm_ + 304 + ($92 << 2) | 0;
    var $94 = HEAP32[$93 >> 2];
    var $95 = ($v_0_ph | 0) == ($94 | 0);
    if ($95) {
      __label__ = 22;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 22:
    HEAP32[$93 >> 2] = $R_1;
    var $cond = ($R_1 | 0) == 0;
    if ($cond) {
      __label__ = 23;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 23:
    var $97 = HEAP32[$91 >> 2];
    var $98 = 1 << $97;
    var $99 = $98 ^ -1;
    var $100 = HEAP32[__gm_ + 4 >> 2];
    var $101 = $100 & $99;
    HEAP32[__gm_ + 4 >> 2] = $101;
    __label__ = 40;
    break;
   case 24:
    var $103 = $55;
    var $104 = HEAP32[__gm_ + 16 >> 2];
    var $105 = $103 >>> 0 < $104 >>> 0;
    if ($105) {
      __label__ = 28;
      break;
    } else {
      __label__ = 25;
      break;
    }
   case 25:
    var $107 = $55 + 16 | 0;
    var $108 = HEAP32[$107 >> 2];
    var $109 = ($108 | 0) == ($v_0_ph | 0);
    if ($109) {
      __label__ = 26;
      break;
    } else {
      __label__ = 27;
      break;
    }
   case 26:
    HEAP32[$107 >> 2] = $R_1;
    __label__ = 29;
    break;
   case 27:
    var $112 = $55 + 20 | 0;
    HEAP32[$112 >> 2] = $R_1;
    __label__ = 29;
    break;
   case 28:
    _abort();
   case 29:
    var $115 = ($R_1 | 0) == 0;
    if ($115) {
      __label__ = 40;
      break;
    } else {
      __label__ = 30;
      break;
    }
   case 30:
    var $117 = $R_1;
    var $118 = HEAP32[__gm_ + 16 >> 2];
    var $119 = $117 >>> 0 < $118 >>> 0;
    if ($119) {
      __label__ = 39;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 31:
    var $121 = $R_1 + 24 | 0;
    HEAP32[$121 >> 2] = $55;
    var $122 = $v_0_ph + 16 | 0;
    var $123 = HEAP32[$122 >> 2];
    var $124 = ($123 | 0) == 0;
    if ($124) {
      __label__ = 35;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    var $126 = $123;
    var $127 = HEAP32[__gm_ + 16 >> 2];
    var $128 = $126 >>> 0 < $127 >>> 0;
    if ($128) {
      __label__ = 34;
      break;
    } else {
      __label__ = 33;
      break;
    }
   case 33:
    var $130 = $R_1 + 16 | 0;
    HEAP32[$130 >> 2] = $123;
    var $131 = $123 + 24 | 0;
    HEAP32[$131 >> 2] = $R_1;
    __label__ = 35;
    break;
   case 34:
    _abort();
   case 35:
    var $134 = $v_0_ph + 20 | 0;
    var $135 = HEAP32[$134 >> 2];
    var $136 = ($135 | 0) == 0;
    if ($136) {
      __label__ = 40;
      break;
    } else {
      __label__ = 36;
      break;
    }
   case 36:
    var $138 = $135;
    var $139 = HEAP32[__gm_ + 16 >> 2];
    var $140 = $138 >>> 0 < $139 >>> 0;
    if ($140) {
      __label__ = 38;
      break;
    } else {
      __label__ = 37;
      break;
    }
   case 37:
    var $142 = $R_1 + 20 | 0;
    HEAP32[$142 >> 2] = $135;
    var $143 = $135 + 24 | 0;
    HEAP32[$143 >> 2] = $R_1;
    __label__ = 40;
    break;
   case 38:
    _abort();
   case 39:
    _abort();
   case 40:
    var $147 = $rsize_0_ph >>> 0 < 16;
    if ($147) {
      __label__ = 41;
      break;
    } else {
      __label__ = 42;
      break;
    }
   case 41:
    var $149 = $rsize_0_ph + $nb | 0;
    var $150 = $149 | 3;
    var $151 = $v_0_ph + 4 | 0;
    HEAP32[$151 >> 2] = $150;
    var $_sum4 = $149 + 4 | 0;
    var $152 = $46 + $_sum4 | 0;
    var $153 = $152;
    var $154 = HEAP32[$153 >> 2];
    var $155 = $154 | 1;
    HEAP32[$153 >> 2] = $155;
    __label__ = 49;
    break;
   case 42:
    var $157 = $nb | 3;
    var $158 = $v_0_ph + 4 | 0;
    HEAP32[$158 >> 2] = $157;
    var $159 = $rsize_0_ph | 1;
    var $_sum = $nb + 4 | 0;
    var $160 = $46 + $_sum | 0;
    var $161 = $160;
    HEAP32[$161 >> 2] = $159;
    var $_sum1 = $rsize_0_ph + $nb | 0;
    var $162 = $46 + $_sum1 | 0;
    var $163 = $162;
    HEAP32[$163 >> 2] = $rsize_0_ph;
    var $164 = HEAP32[__gm_ + 8 >> 2];
    var $165 = ($164 | 0) == 0;
    if ($165) {
      __label__ = 48;
      break;
    } else {
      __label__ = 43;
      break;
    }
   case 43:
    var $167 = HEAP32[__gm_ + 20 >> 2];
    var $168 = $164 >>> 3;
    var $169 = $164 >>> 2;
    var $170 = $169 & 1073741822;
    var $171 = __gm_ + 40 + ($170 << 2) | 0;
    var $172 = $171;
    var $173 = HEAP32[__gm_ >> 2];
    var $174 = 1 << $168;
    var $175 = $173 & $174;
    var $176 = ($175 | 0) == 0;
    if ($176) {
      __label__ = 44;
      break;
    } else {
      __label__ = 45;
      break;
    }
   case 44:
    var $178 = $173 | $174;
    HEAP32[__gm_ >> 2] = $178;
    var $_sum2_pre = $170 + 2 | 0;
    var $_pre = __gm_ + 40 + ($_sum2_pre << 2) | 0;
    var $F1_0 = $172;
    var $_pre_phi = $_pre;
    __label__ = 47;
    break;
   case 45:
    var $_sum3 = $170 + 2 | 0;
    var $180 = __gm_ + 40 + ($_sum3 << 2) | 0;
    var $181 = HEAP32[$180 >> 2];
    var $182 = $181;
    var $183 = HEAP32[__gm_ + 16 >> 2];
    var $184 = $182 >>> 0 < $183 >>> 0;
    if ($184) {
      __label__ = 46;
      break;
    } else {
      var $F1_0 = $181;
      var $_pre_phi = $180;
      __label__ = 47;
      break;
    }
   case 46:
    _abort();
   case 47:
    var $_pre_phi;
    var $F1_0;
    HEAP32[$_pre_phi >> 2] = $167;
    var $187 = $F1_0 + 12 | 0;
    HEAP32[$187 >> 2] = $167;
    var $188 = $167 + 8 | 0;
    HEAP32[$188 >> 2] = $F1_0;
    var $189 = $167 + 12 | 0;
    HEAP32[$189 >> 2] = $172;
    __label__ = 48;
    break;
   case 48:
    HEAP32[__gm_ + 8 >> 2] = $rsize_0_ph;
    HEAP32[__gm_ + 20 >> 2] = $51;
    __label__ = 49;
    break;
   case 49:
    var $192 = $v_0_ph + 8 | 0;
    var $193 = $192;
    return $193;
   case 50:
    _abort();
   default:
    assert(0, "bad label: " + __label__);
  }
}
_tmalloc_small["X"] = 1;
function _sys_alloc($nb) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_mparams >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _init_mparams();
    __label__ = 4;
    break;
   case 4:
    var $5 = HEAP32[__gm_ + 440 >> 2];
    var $6 = $5 & 4;
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 5;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 5:
    var $9 = HEAP32[__gm_ + 24 >> 2];
    var $10 = ($9 | 0) == 0;
    if ($10) {
      __label__ = 7;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $12 = $9;
    var $13 = _segment_holding($12);
    var $14 = ($13 | 0) == 0;
    if ($14) {
      __label__ = 7;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 7:
    var $15 = _sbrk(0);
    var $16 = ($15 | 0) == -1;
    if ($16) {
      __label__ = 15;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $18 = HEAP32[_mparams + 8 >> 2];
    var $19 = $nb + 47 | 0;
    var $20 = $19 + $18 | 0;
    var $21 = -$18 | 0;
    var $22 = $20 & $21;
    var $23 = $15;
    var $24 = HEAP32[_mparams + 4 >> 2];
    var $25 = $24 - 1 | 0;
    var $26 = $25 & $23;
    var $27 = ($26 | 0) == 0;
    if ($27) {
      var $asize_0 = $22;
      __label__ = 10;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $29 = $25 + $23 | 0;
    var $30 = -$24 | 0;
    var $31 = $29 & $30;
    var $32 = $22 - $23 | 0;
    var $33 = $32 + $31 | 0;
    var $asize_0 = $33;
    __label__ = 10;
    break;
   case 10:
    var $asize_0;
    var $35 = $asize_0 >>> 0 < 2147483647;
    if ($35) {
      __label__ = 11;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 11:
    var $37 = _sbrk($asize_0);
    var $38 = ($37 | 0) == ($15 | 0);
    if ($38) {
      var $tbase_0 = $15;
      var $asize_1 = $asize_0;
      var $br_0 = $37;
      __label__ = 14;
      break;
    } else {
      var $br_08 = $37;
      var $asize_19 = $asize_0;
      __label__ = 16;
      break;
    }
   case 12:
    var $40 = HEAP32[__gm_ + 12 >> 2];
    var $41 = HEAP32[_mparams + 8 >> 2];
    var $42 = $nb + 47 | 0;
    var $43 = $42 - $40 | 0;
    var $44 = $43 + $41 | 0;
    var $45 = -$41 | 0;
    var $46 = $44 & $45;
    var $47 = $46 >>> 0 < 2147483647;
    if ($47) {
      __label__ = 13;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 13:
    var $49 = _sbrk($46);
    var $50 = $13 | 0;
    var $51 = HEAP32[$50 >> 2];
    var $52 = $13 + 4 | 0;
    var $53 = HEAP32[$52 >> 2];
    var $54 = $51 + $53 | 0;
    var $55 = ($49 | 0) == ($54 | 0);
    if ($55) {
      var $tbase_0 = $49;
      var $asize_1 = $46;
      var $br_0 = $49;
      __label__ = 14;
      break;
    } else {
      var $br_08 = $49;
      var $asize_19 = $46;
      __label__ = 16;
      break;
    }
   case 14:
    var $br_0;
    var $asize_1;
    var $tbase_0;
    var $57 = ($tbase_0 | 0) == -1;
    if ($57) {
      var $br_08 = $br_0;
      var $asize_19 = $asize_1;
      __label__ = 16;
      break;
    } else {
      var $tsize_220 = $asize_1;
      var $tbase_221 = $tbase_0;
      __label__ = 27;
      break;
    }
   case 15:
    var $58 = HEAP32[__gm_ + 440 >> 2];
    var $59 = $58 | 4;
    HEAP32[__gm_ + 440 >> 2] = $59;
    __label__ = 24;
    break;
   case 16:
    var $asize_19;
    var $br_08;
    var $60 = -$asize_19 | 0;
    var $61 = ($br_08 | 0) != -1;
    var $62 = $asize_19 >>> 0 < 2147483647;
    var $or_cond = $61 & $62;
    if ($or_cond) {
      __label__ = 17;
      break;
    } else {
      var $asize_2 = $asize_19;
      __label__ = 22;
      break;
    }
   case 17:
    var $64 = $nb + 48 | 0;
    var $65 = $asize_19 >>> 0 < $64 >>> 0;
    if ($65) {
      __label__ = 18;
      break;
    } else {
      var $asize_2 = $asize_19;
      __label__ = 22;
      break;
    }
   case 18:
    var $67 = HEAP32[_mparams + 8 >> 2];
    var $68 = $nb + 47 | 0;
    var $69 = $68 - $asize_19 | 0;
    var $70 = $69 + $67 | 0;
    var $71 = -$67 | 0;
    var $72 = $70 & $71;
    var $73 = $72 >>> 0 < 2147483647;
    if ($73) {
      __label__ = 19;
      break;
    } else {
      var $asize_2 = $asize_19;
      __label__ = 22;
      break;
    }
   case 19:
    var $75 = _sbrk($72);
    var $76 = ($75 | 0) == -1;
    if ($76) {
      __label__ = 21;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 20:
    var $78 = $72 + $asize_19 | 0;
    var $asize_2 = $78;
    __label__ = 22;
    break;
   case 21:
    var $79 = _sbrk($60);
    __label__ = 23;
    break;
   case 22:
    var $asize_2;
    var $81 = ($br_08 | 0) == -1;
    if ($81) {
      __label__ = 23;
      break;
    } else {
      var $tsize_220 = $asize_2;
      var $tbase_221 = $br_08;
      __label__ = 27;
      break;
    }
   case 23:
    var $83 = HEAP32[__gm_ + 440 >> 2];
    var $84 = $83 | 4;
    HEAP32[__gm_ + 440 >> 2] = $84;
    __label__ = 24;
    break;
   case 24:
    var $85 = HEAP32[_mparams + 8 >> 2];
    var $86 = $nb + 47 | 0;
    var $87 = $86 + $85 | 0;
    var $88 = -$85 | 0;
    var $89 = $87 & $88;
    var $90 = $89 >>> 0 < 2147483647;
    if ($90) {
      __label__ = 25;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 25:
    var $92 = _sbrk($89);
    var $93 = _sbrk(0);
    var $notlhs = ($92 | 0) != -1;
    var $notrhs = ($93 | 0) != -1;
    var $or_cond1_not = $notrhs & $notlhs;
    var $94 = $92 >>> 0 < $93 >>> 0;
    var $or_cond2 = $or_cond1_not & $94;
    if ($or_cond2) {
      __label__ = 26;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 26:
    var $96 = $93;
    var $97 = $92;
    var $98 = $96 - $97 | 0;
    var $99 = $nb + 40 | 0;
    var $100 = $98 >>> 0 <= $99 >>> 0;
    var $101 = ($92 | 0) == -1;
    var $or_cond46 = $100 | $101;
    if ($or_cond46) {
      __label__ = 50;
      break;
    } else {
      var $tsize_220 = $98;
      var $tbase_221 = $92;
      __label__ = 27;
      break;
    }
   case 27:
    var $tbase_221;
    var $tsize_220;
    var $102 = HEAP32[__gm_ + 432 >> 2];
    var $103 = $102 + $tsize_220 | 0;
    HEAP32[__gm_ + 432 >> 2] = $103;
    var $104 = HEAP32[__gm_ + 436 >> 2];
    var $105 = $103 >>> 0 > $104 >>> 0;
    if ($105) {
      __label__ = 28;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 28:
    HEAP32[__gm_ + 436 >> 2] = $103;
    __label__ = 29;
    break;
   case 29:
    var $108 = HEAP32[__gm_ + 24 >> 2];
    var $109 = ($108 | 0) == 0;
    if ($109) {
      __label__ = 30;
      break;
    } else {
      var $sp_0 = __gm_ + 444 | 0;
      __label__ = 33;
      break;
    }
   case 30:
    var $111 = HEAP32[__gm_ + 16 >> 2];
    var $112 = ($111 | 0) == 0;
    var $113 = $tbase_221 >>> 0 < $111 >>> 0;
    var $or_cond3 = $112 | $113;
    if ($or_cond3) {
      __label__ = 31;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 31:
    HEAP32[__gm_ + 16 >> 2] = $tbase_221;
    __label__ = 32;
    break;
   case 32:
    HEAP32[__gm_ + 444 >> 2] = $tbase_221;
    HEAP32[__gm_ + 448 >> 2] = $tsize_220;
    HEAP32[__gm_ + 456 >> 2] = 0;
    var $116 = HEAP32[_mparams >> 2];
    HEAP32[__gm_ + 36 >> 2] = $116;
    HEAP32[__gm_ + 32 >> 2] = -1;
    _init_bins();
    var $117 = $tbase_221;
    var $118 = $tsize_220 - 40 | 0;
    _init_top($117, $118);
    __label__ = 48;
    break;
   case 33:
    var $sp_0;
    var $119 = ($sp_0 | 0) == 0;
    if ($119) {
      __label__ = 39;
      break;
    } else {
      __label__ = 34;
      break;
    }
   case 34:
    var $121 = $sp_0 | 0;
    var $122 = HEAP32[$121 >> 2];
    var $123 = $sp_0 + 4 | 0;
    var $124 = HEAP32[$123 >> 2];
    var $125 = $122 + $124 | 0;
    var $126 = ($tbase_221 | 0) == ($125 | 0);
    if ($126) {
      __label__ = 36;
      break;
    } else {
      __label__ = 35;
      break;
    }
   case 35:
    var $128 = $sp_0 + 8 | 0;
    var $129 = HEAP32[$128 >> 2];
    var $sp_0 = $129;
    __label__ = 33;
    break;
   case 36:
    var $130 = $sp_0 + 12 | 0;
    var $131 = HEAP32[$130 >> 2];
    var $132 = $131 & 8;
    var $133 = ($132 | 0) == 0;
    if ($133) {
      __label__ = 37;
      break;
    } else {
      __label__ = 39;
      break;
    }
   case 37:
    var $135 = $108;
    var $136 = $135 >>> 0 >= $122 >>> 0;
    var $137 = $135 >>> 0 < $125 >>> 0;
    var $or_cond29 = $136 & $137;
    if ($or_cond29) {
      __label__ = 38;
      break;
    } else {
      __label__ = 39;
      break;
    }
   case 38:
    var $139 = $124 + $tsize_220 | 0;
    HEAP32[$123 >> 2] = $139;
    var $140 = HEAP32[__gm_ + 24 >> 2];
    var $141 = HEAP32[__gm_ + 12 >> 2];
    var $142 = $141 + $tsize_220 | 0;
    _init_top($140, $142);
    __label__ = 48;
    break;
   case 39:
    var $143 = HEAP32[__gm_ + 16 >> 2];
    var $144 = $tbase_221 >>> 0 < $143 >>> 0;
    if ($144) {
      __label__ = 40;
      break;
    } else {
      __label__ = 41;
      break;
    }
   case 40:
    HEAP32[__gm_ + 16 >> 2] = $tbase_221;
    __label__ = 41;
    break;
   case 41:
    var $146 = $tbase_221 + $tsize_220 | 0;
    var $sp_1 = __gm_ + 444 | 0;
    __label__ = 42;
    break;
   case 42:
    var $sp_1;
    var $148 = ($sp_1 | 0) == 0;
    if ($148) {
      __label__ = 47;
      break;
    } else {
      __label__ = 43;
      break;
    }
   case 43:
    var $150 = $sp_1 | 0;
    var $151 = HEAP32[$150 >> 2];
    var $152 = ($151 | 0) == ($146 | 0);
    if ($152) {
      __label__ = 45;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 44:
    var $154 = $sp_1 + 8 | 0;
    var $155 = HEAP32[$154 >> 2];
    var $sp_1 = $155;
    __label__ = 42;
    break;
   case 45:
    var $156 = $sp_1 + 12 | 0;
    var $157 = HEAP32[$156 >> 2];
    var $158 = $157 & 8;
    var $159 = ($158 | 0) == 0;
    if ($159) {
      __label__ = 46;
      break;
    } else {
      __label__ = 47;
      break;
    }
   case 46:
    HEAP32[$150 >> 2] = $tbase_221;
    var $161 = $sp_1 + 4 | 0;
    var $162 = HEAP32[$161 >> 2];
    var $163 = $162 + $tsize_220 | 0;
    HEAP32[$161 >> 2] = $163;
    var $164 = _prepend_alloc($tbase_221, $151, $nb);
    var $_0 = $164;
    __label__ = 51;
    break;
   case 47:
    _add_segment($tbase_221, $tsize_220);
    __label__ = 48;
    break;
   case 48:
    var $166 = HEAP32[__gm_ + 12 >> 2];
    var $167 = $166 >>> 0 > $nb >>> 0;
    if ($167) {
      __label__ = 49;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 49:
    var $169 = $166 - $nb | 0;
    HEAP32[__gm_ + 12 >> 2] = $169;
    var $170 = HEAP32[__gm_ + 24 >> 2];
    var $171 = $170;
    var $172 = $171 + $nb | 0;
    var $173 = $172;
    HEAP32[__gm_ + 24 >> 2] = $173;
    var $174 = $169 | 1;
    var $_sum = $nb + 4 | 0;
    var $175 = $171 + $_sum | 0;
    var $176 = $175;
    HEAP32[$176 >> 2] = $174;
    var $177 = $nb | 3;
    var $178 = $170 + 4 | 0;
    HEAP32[$178 >> 2] = $177;
    var $179 = $170 + 8 | 0;
    var $180 = $179;
    var $_0 = $180;
    __label__ = 51;
    break;
   case 50:
    var $181 = ___errno();
    HEAP32[$181 >> 2] = 12;
    var $_0 = 0;
    __label__ = 51;
    break;
   case 51:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_sys_alloc["X"] = 1;
function _tmalloc_large($nb) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = -$nb | 0;
    var $2 = $nb >>> 8;
    var $3 = ($2 | 0) == 0;
    if ($3) {
      var $idx_0 = 0;
      __label__ = 5;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $5 = $nb >>> 0 > 16777215;
    if ($5) {
      var $idx_0 = 31;
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $7 = $2 + 1048320 | 0;
    var $8 = $7 >>> 16;
    var $9 = $8 & 8;
    var $10 = $2 << $9;
    var $11 = $10 + 520192 | 0;
    var $12 = $11 >>> 16;
    var $13 = $12 & 4;
    var $14 = $10 << $13;
    var $15 = $14 + 245760 | 0;
    var $16 = $15 >>> 16;
    var $17 = $16 & 2;
    var $18 = $13 | $9;
    var $19 = $18 | $17;
    var $20 = 14 - $19 | 0;
    var $21 = $14 << $17;
    var $22 = $21 >>> 15;
    var $23 = $20 + $22 | 0;
    var $24 = $23 << 1;
    var $25 = $23 + 7 | 0;
    var $26 = $nb >>> ($25 >>> 0);
    var $27 = $26 & 1;
    var $28 = $27 | $24;
    var $idx_0 = $28;
    __label__ = 5;
    break;
   case 5:
    var $idx_0;
    var $30 = __gm_ + 304 + ($idx_0 << 2) | 0;
    var $31 = HEAP32[$30 >> 2];
    var $32 = ($31 | 0) == 0;
    if ($32) {
      var $v_2 = 0;
      var $rsize_2 = $1;
      var $t_1 = 0;
      __label__ = 13;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $34 = ($idx_0 | 0) == 31;
    if ($34) {
      var $39 = 0;
      __label__ = 8;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $36 = $idx_0 >>> 1;
    var $37 = 25 - $36 | 0;
    var $39 = $37;
    __label__ = 8;
    break;
   case 8:
    var $39;
    var $40 = $nb << $39;
    var $v_0 = 0;
    var $rsize_0 = $1;
    var $t_0 = $31;
    var $sizebits_0 = $40;
    var $rst_0 = 0;
    __label__ = 9;
    break;
   case 9:
    var $rst_0;
    var $sizebits_0;
    var $t_0;
    var $rsize_0;
    var $v_0;
    var $42 = $t_0 + 4 | 0;
    var $43 = HEAP32[$42 >> 2];
    var $44 = $43 & -8;
    var $45 = $44 - $nb | 0;
    var $46 = $45 >>> 0 < $rsize_0 >>> 0;
    if ($46) {
      __label__ = 10;
      break;
    } else {
      var $v_1 = $v_0;
      var $rsize_1 = $rsize_0;
      __label__ = 11;
      break;
    }
   case 10:
    var $48 = ($44 | 0) == ($nb | 0);
    if ($48) {
      var $v_2 = $t_0;
      var $rsize_2 = $45;
      var $t_1 = $t_0;
      __label__ = 13;
      break;
    } else {
      var $v_1 = $t_0;
      var $rsize_1 = $45;
      __label__ = 11;
      break;
    }
   case 11:
    var $rsize_1;
    var $v_1;
    var $50 = $t_0 + 20 | 0;
    var $51 = HEAP32[$50 >> 2];
    var $52 = $sizebits_0 >>> 31;
    var $53 = $t_0 + 16 + ($52 << 2) | 0;
    var $54 = HEAP32[$53 >> 2];
    var $55 = ($51 | 0) == 0;
    var $56 = ($51 | 0) == ($54 | 0);
    var $or_cond = $55 | $56;
    var $rst_1 = $or_cond ? $rst_0 : $51;
    var $57 = ($54 | 0) == 0;
    if ($57) {
      var $v_2 = $v_1;
      var $rsize_2 = $rsize_1;
      var $t_1 = $rst_1;
      __label__ = 13;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $59 = $sizebits_0 << 1;
    var $v_0 = $v_1;
    var $rsize_0 = $rsize_1;
    var $t_0 = $54;
    var $sizebits_0 = $59;
    var $rst_0 = $rst_1;
    __label__ = 9;
    break;
   case 13:
    var $t_1;
    var $rsize_2;
    var $v_2;
    var $60 = ($t_1 | 0) == 0;
    var $61 = ($v_2 | 0) == 0;
    var $or_cond19 = $60 & $61;
    if ($or_cond19) {
      __label__ = 14;
      break;
    } else {
      var $t_2_ph = $t_1;
      __label__ = 16;
      break;
    }
   case 14:
    var $63 = 2 << $idx_0;
    var $64 = -$63 | 0;
    var $65 = $63 | $64;
    var $66 = HEAP32[__gm_ + 4 >> 2];
    var $67 = $66 & $65;
    var $68 = ($67 | 0) == 0;
    if ($68) {
      var $t_2_ph = $t_1;
      __label__ = 16;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $70 = -$67 | 0;
    var $71 = $67 & $70;
    var $72 = $71 - 1 | 0;
    var $73 = $72 >>> 12;
    var $74 = $73 & 16;
    var $75 = $72 >>> ($74 >>> 0);
    var $76 = $75 >>> 5;
    var $77 = $76 & 8;
    var $78 = $75 >>> ($77 >>> 0);
    var $79 = $78 >>> 2;
    var $80 = $79 & 4;
    var $81 = $78 >>> ($80 >>> 0);
    var $82 = $81 >>> 1;
    var $83 = $82 & 2;
    var $84 = $81 >>> ($83 >>> 0);
    var $85 = $84 >>> 1;
    var $86 = $85 & 1;
    var $87 = $77 | $74;
    var $88 = $87 | $80;
    var $89 = $88 | $83;
    var $90 = $89 | $86;
    var $91 = $84 >>> ($86 >>> 0);
    var $92 = $90 + $91 | 0;
    var $93 = __gm_ + 304 + ($92 << 2) | 0;
    var $94 = HEAP32[$93 >> 2];
    var $t_2_ph = $94;
    __label__ = 16;
    break;
   case 16:
    var $t_2_ph;
    var $95 = ($t_2_ph | 0) == 0;
    if ($95) {
      var $rsize_3_lcssa = $rsize_2;
      var $v_3_lcssa = $v_2;
      __label__ = 19;
      break;
    } else {
      var $t_224 = $t_2_ph;
      var $rsize_325 = $rsize_2;
      var $v_326 = $v_2;
      __label__ = 17;
      break;
    }
   case 17:
    var $v_326;
    var $rsize_325;
    var $t_224;
    var $96 = $t_224 + 4 | 0;
    var $97 = HEAP32[$96 >> 2];
    var $98 = $97 & -8;
    var $99 = $98 - $nb | 0;
    var $100 = $99 >>> 0 < $rsize_325 >>> 0;
    var $rsize_4 = $100 ? $99 : $rsize_325;
    var $v_4 = $100 ? $t_224 : $v_326;
    var $101 = $t_224 + 16 | 0;
    var $102 = HEAP32[$101 >> 2];
    var $103 = ($102 | 0) == 0;
    if ($103) {
      __label__ = 18;
      break;
    } else {
      var $t_224 = $102;
      var $rsize_325 = $rsize_4;
      var $v_326 = $v_4;
      __label__ = 17;
      break;
    }
   case 18:
    var $104 = $t_224 + 20 | 0;
    var $105 = HEAP32[$104 >> 2];
    var $106 = ($105 | 0) == 0;
    if ($106) {
      var $rsize_3_lcssa = $rsize_4;
      var $v_3_lcssa = $v_4;
      __label__ = 19;
      break;
    } else {
      var $t_224 = $105;
      var $rsize_325 = $rsize_4;
      var $v_326 = $v_4;
      __label__ = 17;
      break;
    }
   case 19:
    var $v_3_lcssa;
    var $rsize_3_lcssa;
    var $107 = ($v_3_lcssa | 0) == 0;
    if ($107) {
      var $_0 = 0;
      __label__ = 82;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 20:
    var $109 = HEAP32[__gm_ + 8 >> 2];
    var $110 = $109 - $nb | 0;
    var $111 = $rsize_3_lcssa >>> 0 < $110 >>> 0;
    if ($111) {
      __label__ = 21;
      break;
    } else {
      var $_0 = 0;
      __label__ = 82;
      break;
    }
   case 21:
    var $113 = $v_3_lcssa;
    var $114 = HEAP32[__gm_ + 16 >> 2];
    var $115 = $113 >>> 0 < $114 >>> 0;
    if ($115) {
      __label__ = 81;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    var $117 = $113 + $nb | 0;
    var $118 = $117;
    var $119 = $113 >>> 0 < $117 >>> 0;
    if ($119) {
      __label__ = 23;
      break;
    } else {
      __label__ = 81;
      break;
    }
   case 23:
    var $121 = $v_3_lcssa + 24 | 0;
    var $122 = HEAP32[$121 >> 2];
    var $123 = $v_3_lcssa + 12 | 0;
    var $124 = HEAP32[$123 >> 2];
    var $125 = ($124 | 0) == ($v_3_lcssa | 0);
    if ($125) {
      __label__ = 27;
      break;
    } else {
      __label__ = 24;
      break;
    }
   case 24:
    var $127 = $v_3_lcssa + 8 | 0;
    var $128 = HEAP32[$127 >> 2];
    var $129 = $128;
    var $130 = $129 >>> 0 < $114 >>> 0;
    if ($130) {
      __label__ = 26;
      break;
    } else {
      __label__ = 25;
      break;
    }
   case 25:
    var $132 = $128 + 12 | 0;
    HEAP32[$132 >> 2] = $124;
    var $133 = $124 + 8 | 0;
    HEAP32[$133 >> 2] = $128;
    var $R_1 = $124;
    __label__ = 34;
    break;
   case 26:
    _abort();
   case 27:
    var $136 = $v_3_lcssa + 20 | 0;
    var $137 = HEAP32[$136 >> 2];
    var $138 = ($137 | 0) == 0;
    if ($138) {
      __label__ = 28;
      break;
    } else {
      var $RP_0 = $136;
      var $R_0 = $137;
      __label__ = 29;
      break;
    }
   case 28:
    var $140 = $v_3_lcssa + 16 | 0;
    var $141 = HEAP32[$140 >> 2];
    var $142 = ($141 | 0) == 0;
    if ($142) {
      var $R_1 = 0;
      __label__ = 34;
      break;
    } else {
      var $RP_0 = $140;
      var $R_0 = $141;
      __label__ = 29;
      break;
    }
   case 29:
    var $R_0;
    var $RP_0;
    var $143 = $R_0 + 20 | 0;
    var $144 = HEAP32[$143 >> 2];
    var $145 = ($144 | 0) == 0;
    if ($145) {
      __label__ = 30;
      break;
    } else {
      var $RP_0 = $143;
      var $R_0 = $144;
      __label__ = 29;
      break;
    }
   case 30:
    var $147 = $R_0 + 16 | 0;
    var $148 = HEAP32[$147 >> 2];
    var $149 = ($148 | 0) == 0;
    if ($149) {
      __label__ = 31;
      break;
    } else {
      var $RP_0 = $147;
      var $R_0 = $148;
      __label__ = 29;
      break;
    }
   case 31:
    var $151 = $RP_0;
    var $152 = $151 >>> 0 < $114 >>> 0;
    if ($152) {
      __label__ = 33;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    HEAP32[$RP_0 >> 2] = 0;
    var $R_1 = $R_0;
    __label__ = 34;
    break;
   case 33:
    _abort();
   case 34:
    var $R_1;
    var $156 = ($122 | 0) == 0;
    if ($156) {
      __label__ = 54;
      break;
    } else {
      __label__ = 35;
      break;
    }
   case 35:
    var $158 = $v_3_lcssa + 28 | 0;
    var $159 = HEAP32[$158 >> 2];
    var $160 = __gm_ + 304 + ($159 << 2) | 0;
    var $161 = HEAP32[$160 >> 2];
    var $162 = ($v_3_lcssa | 0) == ($161 | 0);
    if ($162) {
      __label__ = 36;
      break;
    } else {
      __label__ = 38;
      break;
    }
   case 36:
    HEAP32[$160 >> 2] = $R_1;
    var $cond = ($R_1 | 0) == 0;
    if ($cond) {
      __label__ = 37;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 37:
    var $164 = HEAP32[$158 >> 2];
    var $165 = 1 << $164;
    var $166 = $165 ^ -1;
    var $167 = HEAP32[__gm_ + 4 >> 2];
    var $168 = $167 & $166;
    HEAP32[__gm_ + 4 >> 2] = $168;
    __label__ = 54;
    break;
   case 38:
    var $170 = $122;
    var $171 = HEAP32[__gm_ + 16 >> 2];
    var $172 = $170 >>> 0 < $171 >>> 0;
    if ($172) {
      __label__ = 42;
      break;
    } else {
      __label__ = 39;
      break;
    }
   case 39:
    var $174 = $122 + 16 | 0;
    var $175 = HEAP32[$174 >> 2];
    var $176 = ($175 | 0) == ($v_3_lcssa | 0);
    if ($176) {
      __label__ = 40;
      break;
    } else {
      __label__ = 41;
      break;
    }
   case 40:
    HEAP32[$174 >> 2] = $R_1;
    __label__ = 43;
    break;
   case 41:
    var $179 = $122 + 20 | 0;
    HEAP32[$179 >> 2] = $R_1;
    __label__ = 43;
    break;
   case 42:
    _abort();
   case 43:
    var $182 = ($R_1 | 0) == 0;
    if ($182) {
      __label__ = 54;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 44:
    var $184 = $R_1;
    var $185 = HEAP32[__gm_ + 16 >> 2];
    var $186 = $184 >>> 0 < $185 >>> 0;
    if ($186) {
      __label__ = 53;
      break;
    } else {
      __label__ = 45;
      break;
    }
   case 45:
    var $188 = $R_1 + 24 | 0;
    HEAP32[$188 >> 2] = $122;
    var $189 = $v_3_lcssa + 16 | 0;
    var $190 = HEAP32[$189 >> 2];
    var $191 = ($190 | 0) == 0;
    if ($191) {
      __label__ = 49;
      break;
    } else {
      __label__ = 46;
      break;
    }
   case 46:
    var $193 = $190;
    var $194 = HEAP32[__gm_ + 16 >> 2];
    var $195 = $193 >>> 0 < $194 >>> 0;
    if ($195) {
      __label__ = 48;
      break;
    } else {
      __label__ = 47;
      break;
    }
   case 47:
    var $197 = $R_1 + 16 | 0;
    HEAP32[$197 >> 2] = $190;
    var $198 = $190 + 24 | 0;
    HEAP32[$198 >> 2] = $R_1;
    __label__ = 49;
    break;
   case 48:
    _abort();
   case 49:
    var $201 = $v_3_lcssa + 20 | 0;
    var $202 = HEAP32[$201 >> 2];
    var $203 = ($202 | 0) == 0;
    if ($203) {
      __label__ = 54;
      break;
    } else {
      __label__ = 50;
      break;
    }
   case 50:
    var $205 = $202;
    var $206 = HEAP32[__gm_ + 16 >> 2];
    var $207 = $205 >>> 0 < $206 >>> 0;
    if ($207) {
      __label__ = 52;
      break;
    } else {
      __label__ = 51;
      break;
    }
   case 51:
    var $209 = $R_1 + 20 | 0;
    HEAP32[$209 >> 2] = $202;
    var $210 = $202 + 24 | 0;
    HEAP32[$210 >> 2] = $R_1;
    __label__ = 54;
    break;
   case 52:
    _abort();
   case 53:
    _abort();
   case 54:
    var $214 = $rsize_3_lcssa >>> 0 < 16;
    if ($214) {
      __label__ = 55;
      break;
    } else {
      __label__ = 56;
      break;
    }
   case 55:
    var $216 = $rsize_3_lcssa + $nb | 0;
    var $217 = $216 | 3;
    var $218 = $v_3_lcssa + 4 | 0;
    HEAP32[$218 >> 2] = $217;
    var $_sum18 = $216 + 4 | 0;
    var $219 = $113 + $_sum18 | 0;
    var $220 = $219;
    var $221 = HEAP32[$220 >> 2];
    var $222 = $221 | 1;
    HEAP32[$220 >> 2] = $222;
    __label__ = 80;
    break;
   case 56:
    var $224 = $nb | 3;
    var $225 = $v_3_lcssa + 4 | 0;
    HEAP32[$225 >> 2] = $224;
    var $226 = $rsize_3_lcssa | 1;
    var $_sum = $nb + 4 | 0;
    var $227 = $113 + $_sum | 0;
    var $228 = $227;
    HEAP32[$228 >> 2] = $226;
    var $_sum1 = $rsize_3_lcssa + $nb | 0;
    var $229 = $113 + $_sum1 | 0;
    var $230 = $229;
    HEAP32[$230 >> 2] = $rsize_3_lcssa;
    var $231 = $rsize_3_lcssa >>> 0 < 256;
    if ($231) {
      __label__ = 57;
      break;
    } else {
      __label__ = 62;
      break;
    }
   case 57:
    var $233 = $rsize_3_lcssa >>> 3;
    var $234 = $rsize_3_lcssa >>> 2;
    var $235 = $234 & 1073741822;
    var $236 = __gm_ + 40 + ($235 << 2) | 0;
    var $237 = $236;
    var $238 = HEAP32[__gm_ >> 2];
    var $239 = 1 << $233;
    var $240 = $238 & $239;
    var $241 = ($240 | 0) == 0;
    if ($241) {
      __label__ = 58;
      break;
    } else {
      __label__ = 59;
      break;
    }
   case 58:
    var $243 = $238 | $239;
    HEAP32[__gm_ >> 2] = $243;
    var $_sum14_pre = $235 + 2 | 0;
    var $_pre = __gm_ + 40 + ($_sum14_pre << 2) | 0;
    var $F5_0 = $237;
    var $_pre_phi = $_pre;
    __label__ = 61;
    break;
   case 59:
    var $_sum17 = $235 + 2 | 0;
    var $245 = __gm_ + 40 + ($_sum17 << 2) | 0;
    var $246 = HEAP32[$245 >> 2];
    var $247 = $246;
    var $248 = HEAP32[__gm_ + 16 >> 2];
    var $249 = $247 >>> 0 < $248 >>> 0;
    if ($249) {
      __label__ = 60;
      break;
    } else {
      var $F5_0 = $246;
      var $_pre_phi = $245;
      __label__ = 61;
      break;
    }
   case 60:
    _abort();
   case 61:
    var $_pre_phi;
    var $F5_0;
    HEAP32[$_pre_phi >> 2] = $118;
    var $252 = $F5_0 + 12 | 0;
    HEAP32[$252 >> 2] = $118;
    var $_sum15 = $nb + 8 | 0;
    var $253 = $113 + $_sum15 | 0;
    var $254 = $253;
    HEAP32[$254 >> 2] = $F5_0;
    var $_sum16 = $nb + 12 | 0;
    var $255 = $113 + $_sum16 | 0;
    var $256 = $255;
    HEAP32[$256 >> 2] = $237;
    __label__ = 80;
    break;
   case 62:
    var $258 = $117;
    var $259 = $rsize_3_lcssa >>> 8;
    var $260 = ($259 | 0) == 0;
    if ($260) {
      var $I7_0 = 0;
      __label__ = 65;
      break;
    } else {
      __label__ = 63;
      break;
    }
   case 63:
    var $262 = $rsize_3_lcssa >>> 0 > 16777215;
    if ($262) {
      var $I7_0 = 31;
      __label__ = 65;
      break;
    } else {
      __label__ = 64;
      break;
    }
   case 64:
    var $264 = $259 + 1048320 | 0;
    var $265 = $264 >>> 16;
    var $266 = $265 & 8;
    var $267 = $259 << $266;
    var $268 = $267 + 520192 | 0;
    var $269 = $268 >>> 16;
    var $270 = $269 & 4;
    var $271 = $267 << $270;
    var $272 = $271 + 245760 | 0;
    var $273 = $272 >>> 16;
    var $274 = $273 & 2;
    var $275 = $270 | $266;
    var $276 = $275 | $274;
    var $277 = 14 - $276 | 0;
    var $278 = $271 << $274;
    var $279 = $278 >>> 15;
    var $280 = $277 + $279 | 0;
    var $281 = $280 << 1;
    var $282 = $280 + 7 | 0;
    var $283 = $rsize_3_lcssa >>> ($282 >>> 0);
    var $284 = $283 & 1;
    var $285 = $284 | $281;
    var $I7_0 = $285;
    __label__ = 65;
    break;
   case 65:
    var $I7_0;
    var $287 = __gm_ + 304 + ($I7_0 << 2) | 0;
    var $_sum2 = $nb + 28 | 0;
    var $288 = $113 + $_sum2 | 0;
    var $289 = $288;
    HEAP32[$289 >> 2] = $I7_0;
    var $_sum3 = $nb + 16 | 0;
    var $290 = $113 + $_sum3 | 0;
    var $_sum4 = $nb + 20 | 0;
    var $291 = $113 + $_sum4 | 0;
    var $292 = $291;
    HEAP32[$292 >> 2] = 0;
    var $293 = $290;
    HEAP32[$293 >> 2] = 0;
    var $294 = HEAP32[__gm_ + 4 >> 2];
    var $295 = 1 << $I7_0;
    var $296 = $294 & $295;
    var $297 = ($296 | 0) == 0;
    if ($297) {
      __label__ = 66;
      break;
    } else {
      __label__ = 67;
      break;
    }
   case 66:
    var $299 = $294 | $295;
    HEAP32[__gm_ + 4 >> 2] = $299;
    HEAP32[$287 >> 2] = $258;
    var $300 = $287;
    var $_sum5 = $nb + 24 | 0;
    var $301 = $113 + $_sum5 | 0;
    var $302 = $301;
    HEAP32[$302 >> 2] = $300;
    var $_sum6 = $nb + 12 | 0;
    var $303 = $113 + $_sum6 | 0;
    var $304 = $303;
    HEAP32[$304 >> 2] = $258;
    var $_sum7 = $nb + 8 | 0;
    var $305 = $113 + $_sum7 | 0;
    var $306 = $305;
    HEAP32[$306 >> 2] = $258;
    __label__ = 80;
    break;
   case 67:
    var $308 = HEAP32[$287 >> 2];
    var $309 = ($I7_0 | 0) == 31;
    if ($309) {
      var $314 = 0;
      __label__ = 69;
      break;
    } else {
      __label__ = 68;
      break;
    }
   case 68:
    var $311 = $I7_0 >>> 1;
    var $312 = 25 - $311 | 0;
    var $314 = $312;
    __label__ = 69;
    break;
   case 69:
    var $314;
    var $315 = $rsize_3_lcssa << $314;
    var $K12_0 = $315;
    var $T_0 = $308;
    __label__ = 70;
    break;
   case 70:
    var $T_0;
    var $K12_0;
    var $317 = $T_0 + 4 | 0;
    var $318 = HEAP32[$317 >> 2];
    var $319 = $318 & -8;
    var $320 = ($319 | 0) == ($rsize_3_lcssa | 0);
    if ($320) {
      __label__ = 76;
      break;
    } else {
      __label__ = 71;
      break;
    }
   case 71:
    var $322 = $K12_0 >>> 31;
    var $323 = $T_0 + 16 + ($322 << 2) | 0;
    var $324 = HEAP32[$323 >> 2];
    var $325 = ($324 | 0) == 0;
    if ($325) {
      __label__ = 73;
      break;
    } else {
      __label__ = 72;
      break;
    }
   case 72:
    var $327 = $K12_0 << 1;
    var $K12_0 = $327;
    var $T_0 = $324;
    __label__ = 70;
    break;
   case 73:
    var $329 = $323;
    var $330 = HEAP32[__gm_ + 16 >> 2];
    var $331 = $329 >>> 0 < $330 >>> 0;
    if ($331) {
      __label__ = 75;
      break;
    } else {
      __label__ = 74;
      break;
    }
   case 74:
    HEAP32[$323 >> 2] = $258;
    var $_sum11 = $nb + 24 | 0;
    var $333 = $113 + $_sum11 | 0;
    var $334 = $333;
    HEAP32[$334 >> 2] = $T_0;
    var $_sum12 = $nb + 12 | 0;
    var $335 = $113 + $_sum12 | 0;
    var $336 = $335;
    HEAP32[$336 >> 2] = $258;
    var $_sum13 = $nb + 8 | 0;
    var $337 = $113 + $_sum13 | 0;
    var $338 = $337;
    HEAP32[$338 >> 2] = $258;
    __label__ = 80;
    break;
   case 75:
    _abort();
   case 76:
    var $341 = $T_0 + 8 | 0;
    var $342 = HEAP32[$341 >> 2];
    var $343 = $T_0;
    var $344 = HEAP32[__gm_ + 16 >> 2];
    var $345 = $343 >>> 0 < $344 >>> 0;
    if ($345) {
      __label__ = 79;
      break;
    } else {
      __label__ = 77;
      break;
    }
   case 77:
    var $347 = $342;
    var $348 = $347 >>> 0 < $344 >>> 0;
    if ($348) {
      __label__ = 79;
      break;
    } else {
      __label__ = 78;
      break;
    }
   case 78:
    var $350 = $342 + 12 | 0;
    HEAP32[$350 >> 2] = $258;
    HEAP32[$341 >> 2] = $258;
    var $_sum8 = $nb + 8 | 0;
    var $351 = $113 + $_sum8 | 0;
    var $352 = $351;
    HEAP32[$352 >> 2] = $342;
    var $_sum9 = $nb + 12 | 0;
    var $353 = $113 + $_sum9 | 0;
    var $354 = $353;
    HEAP32[$354 >> 2] = $T_0;
    var $_sum10 = $nb + 24 | 0;
    var $355 = $113 + $_sum10 | 0;
    var $356 = $355;
    HEAP32[$356 >> 2] = 0;
    __label__ = 80;
    break;
   case 79:
    _abort();
   case 80:
    var $358 = $v_3_lcssa + 8 | 0;
    var $359 = $358;
    var $_0 = $359;
    __label__ = 82;
    break;
   case 81:
    _abort();
   case 82:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_tmalloc_large["X"] = 1;
function _release_unused_segments() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $sp_01 = HEAP32[__gm_ + 452 >> 2];
    var $1 = ($sp_01 | 0) == 0;
    if ($1) {
      __label__ = 4;
      break;
    } else {
      var $sp_02 = $sp_01;
      __label__ = 3;
      break;
    }
   case 3:
    var $sp_02;
    var $2 = $sp_02 + 8 | 0;
    var $sp_0 = HEAP32[$2 >> 2];
    var $3 = ($sp_0 | 0) == 0;
    if ($3) {
      __label__ = 4;
      break;
    } else {
      var $sp_02 = $sp_0;
      __label__ = 3;
      break;
    }
   case 4:
    HEAP32[__gm_ + 32 >> 2] = -1;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _sys_trim() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_mparams >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    _init_mparams();
    __label__ = 4;
    break;
   case 4:
    var $5 = HEAP32[__gm_ + 24 >> 2];
    var $6 = ($5 | 0) == 0;
    if ($6) {
      __label__ = 13;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $8 = HEAP32[__gm_ + 12 >> 2];
    var $9 = $8 >>> 0 > 40;
    if ($9) {
      __label__ = 6;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 6:
    var $11 = HEAP32[_mparams + 8 >> 2];
    var $12 = $8 - 41 | 0;
    var $13 = $12 + $11 | 0;
    var $14 = Math.floor(($13 >>> 0) / ($11 >>> 0));
    var $15 = $14 - 1 | 0;
    var $16 = $15 * $11 | 0;
    var $17 = $5;
    var $18 = _segment_holding($17);
    var $19 = $18 + 12 | 0;
    var $20 = HEAP32[$19 >> 2];
    var $21 = $20 & 8;
    var $22 = ($21 | 0) == 0;
    if ($22) {
      __label__ = 7;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 7:
    var $24 = _sbrk(0);
    var $25 = $18 | 0;
    var $26 = HEAP32[$25 >> 2];
    var $27 = $18 + 4 | 0;
    var $28 = HEAP32[$27 >> 2];
    var $29 = $26 + $28 | 0;
    var $30 = ($24 | 0) == ($29 | 0);
    if ($30) {
      __label__ = 8;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 8:
    var $32 = $16 >>> 0 > 2147483646;
    var $33 = -2147483648 - $11 | 0;
    var $_ = $32 ? $33 : $16;
    var $34 = -$_ | 0;
    var $35 = _sbrk($34);
    var $36 = _sbrk(0);
    var $37 = ($35 | 0) != -1;
    var $38 = $36 >>> 0 < $24 >>> 0;
    var $or_cond = $37 & $38;
    if ($or_cond) {
      __label__ = 9;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 9:
    var $40 = $24;
    var $41 = $36;
    var $42 = $40 - $41 | 0;
    var $43 = ($24 | 0) == ($36 | 0);
    if ($43) {
      __label__ = 11;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 10:
    var $45 = HEAP32[$27 >> 2];
    var $46 = $45 - $42 | 0;
    HEAP32[$27 >> 2] = $46;
    var $47 = HEAP32[__gm_ + 432 >> 2];
    var $48 = $47 - $42 | 0;
    HEAP32[__gm_ + 432 >> 2] = $48;
    var $49 = HEAP32[__gm_ + 24 >> 2];
    var $50 = HEAP32[__gm_ + 12 >> 2];
    var $51 = $50 - $42 | 0;
    _init_top($49, $51);
    __label__ = 13;
    break;
   case 11:
    var $52 = HEAP32[__gm_ + 12 >> 2];
    var $53 = HEAP32[__gm_ + 28 >> 2];
    var $54 = $52 >>> 0 > $53 >>> 0;
    if ($54) {
      __label__ = 12;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 12:
    HEAP32[__gm_ + 28 >> 2] = -1;
    __label__ = 13;
    break;
   case 13:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_sys_trim["X"] = 1;
function _free($mem) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($mem | 0) == 0;
    if ($1) {
      __label__ = 129;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $3 = $mem - 8 | 0;
    var $4 = $3;
    var $5 = HEAP32[__gm_ + 16 >> 2];
    var $6 = $3 >>> 0 < $5 >>> 0;
    if ($6) {
      __label__ = 128;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $8 = $mem - 4 | 0;
    var $9 = $8;
    var $10 = HEAP32[$9 >> 2];
    var $11 = $10 & 3;
    var $12 = ($11 | 0) == 1;
    if ($12) {
      __label__ = 128;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $14 = $10 & -8;
    var $_sum = $14 - 8 | 0;
    var $15 = $mem + $_sum | 0;
    var $16 = $15;
    var $17 = $10 & 1;
    var $18 = ($17 | 0) == 0;
    if ($18) {
      __label__ = 6;
      break;
    } else {
      var $p_0 = $4;
      var $psize_0 = $14;
      __label__ = 49;
      break;
    }
   case 6:
    var $20 = $3;
    var $21 = HEAP32[$20 >> 2];
    var $22 = ($11 | 0) == 0;
    if ($22) {
      __label__ = 129;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $_sum2 = -8 - $21 | 0;
    var $24 = $mem + $_sum2 | 0;
    var $25 = $24;
    var $26 = $21 + $14 | 0;
    var $27 = $24 >>> 0 < $5 >>> 0;
    if ($27) {
      __label__ = 128;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $29 = HEAP32[__gm_ + 20 >> 2];
    var $30 = ($25 | 0) == ($29 | 0);
    if ($30) {
      __label__ = 47;
      break;
    } else {
      __label__ = 9;
      break;
    }
   case 9:
    var $32 = $21 >>> 3;
    var $33 = $21 >>> 0 < 256;
    if ($33) {
      __label__ = 10;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 10:
    var $_sum36 = $_sum2 + 8 | 0;
    var $35 = $mem + $_sum36 | 0;
    var $36 = $35;
    var $37 = HEAP32[$36 >> 2];
    var $_sum37 = $_sum2 + 12 | 0;
    var $38 = $mem + $_sum37 | 0;
    var $39 = $38;
    var $40 = HEAP32[$39 >> 2];
    var $41 = ($37 | 0) == ($40 | 0);
    if ($41) {
      __label__ = 11;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 11:
    var $43 = 1 << $32;
    var $44 = $43 ^ -1;
    var $45 = HEAP32[__gm_ >> 2];
    var $46 = $45 & $44;
    HEAP32[__gm_ >> 2] = $46;
    var $p_0 = $25;
    var $psize_0 = $26;
    __label__ = 49;
    break;
   case 12:
    var $48 = $21 >>> 2;
    var $49 = $48 & 1073741822;
    var $50 = __gm_ + 40 + ($49 << 2) | 0;
    var $51 = $50;
    var $52 = ($37 | 0) != ($51 | 0);
    var $53 = $37;
    var $54 = $53 >>> 0 < $5 >>> 0;
    var $or_cond = $52 & $54;
    if ($or_cond) {
      __label__ = 15;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 13:
    var $56 = ($40 | 0) == ($51 | 0);
    var $57 = $40;
    var $58 = $57 >>> 0 >= $5 >>> 0;
    var $or_cond49 = $56 | $58;
    if ($or_cond49) {
      __label__ = 14;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 14:
    var $59 = $37 + 12 | 0;
    HEAP32[$59 >> 2] = $40;
    var $60 = $40 + 8 | 0;
    HEAP32[$60 >> 2] = $37;
    var $p_0 = $25;
    var $psize_0 = $26;
    __label__ = 49;
    break;
   case 15:
    _abort();
   case 16:
    var $62 = $24;
    var $_sum28 = $_sum2 + 24 | 0;
    var $63 = $mem + $_sum28 | 0;
    var $64 = $63;
    var $65 = HEAP32[$64 >> 2];
    var $_sum29 = $_sum2 + 12 | 0;
    var $66 = $mem + $_sum29 | 0;
    var $67 = $66;
    var $68 = HEAP32[$67 >> 2];
    var $69 = ($68 | 0) == ($62 | 0);
    if ($69) {
      __label__ = 20;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    var $_sum35 = $_sum2 + 8 | 0;
    var $71 = $mem + $_sum35 | 0;
    var $72 = $71;
    var $73 = HEAP32[$72 >> 2];
    var $74 = $73;
    var $75 = $74 >>> 0 < $5 >>> 0;
    if ($75) {
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $77 = $73 + 12 | 0;
    HEAP32[$77 >> 2] = $68;
    var $78 = $68 + 8 | 0;
    HEAP32[$78 >> 2] = $73;
    var $R_1 = $68;
    __label__ = 27;
    break;
   case 19:
    _abort();
   case 20:
    var $_sum31 = $_sum2 + 20 | 0;
    var $81 = $mem + $_sum31 | 0;
    var $82 = $81;
    var $83 = HEAP32[$82 >> 2];
    var $84 = ($83 | 0) == 0;
    if ($84) {
      __label__ = 21;
      break;
    } else {
      var $RP_0 = $82;
      var $R_0 = $83;
      __label__ = 22;
      break;
    }
   case 21:
    var $_sum30 = $_sum2 + 16 | 0;
    var $86 = $mem + $_sum30 | 0;
    var $87 = $86;
    var $88 = HEAP32[$87 >> 2];
    var $89 = ($88 | 0) == 0;
    if ($89) {
      var $R_1 = 0;
      __label__ = 27;
      break;
    } else {
      var $RP_0 = $87;
      var $R_0 = $88;
      __label__ = 22;
      break;
    }
   case 22:
    var $R_0;
    var $RP_0;
    var $90 = $R_0 + 20 | 0;
    var $91 = HEAP32[$90 >> 2];
    var $92 = ($91 | 0) == 0;
    if ($92) {
      __label__ = 23;
      break;
    } else {
      var $RP_0 = $90;
      var $R_0 = $91;
      __label__ = 22;
      break;
    }
   case 23:
    var $94 = $R_0 + 16 | 0;
    var $95 = HEAP32[$94 >> 2];
    var $96 = ($95 | 0) == 0;
    if ($96) {
      __label__ = 24;
      break;
    } else {
      var $RP_0 = $94;
      var $R_0 = $95;
      __label__ = 22;
      break;
    }
   case 24:
    var $98 = $RP_0;
    var $99 = $98 >>> 0 < $5 >>> 0;
    if ($99) {
      __label__ = 26;
      break;
    } else {
      __label__ = 25;
      break;
    }
   case 25:
    HEAP32[$RP_0 >> 2] = 0;
    var $R_1 = $R_0;
    __label__ = 27;
    break;
   case 26:
    _abort();
   case 27:
    var $R_1;
    var $103 = ($65 | 0) == 0;
    if ($103) {
      var $p_0 = $25;
      var $psize_0 = $26;
      __label__ = 49;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 28:
    var $_sum32 = $_sum2 + 28 | 0;
    var $105 = $mem + $_sum32 | 0;
    var $106 = $105;
    var $107 = HEAP32[$106 >> 2];
    var $108 = __gm_ + 304 + ($107 << 2) | 0;
    var $109 = HEAP32[$108 >> 2];
    var $110 = ($62 | 0) == ($109 | 0);
    if ($110) {
      __label__ = 29;
      break;
    } else {
      __label__ = 31;
      break;
    }
   case 29:
    HEAP32[$108 >> 2] = $R_1;
    var $cond = ($R_1 | 0) == 0;
    if ($cond) {
      __label__ = 30;
      break;
    } else {
      __label__ = 37;
      break;
    }
   case 30:
    var $112 = HEAP32[$106 >> 2];
    var $113 = 1 << $112;
    var $114 = $113 ^ -1;
    var $115 = HEAP32[__gm_ + 4 >> 2];
    var $116 = $115 & $114;
    HEAP32[__gm_ + 4 >> 2] = $116;
    var $p_0 = $25;
    var $psize_0 = $26;
    __label__ = 49;
    break;
   case 31:
    var $118 = $65;
    var $119 = HEAP32[__gm_ + 16 >> 2];
    var $120 = $118 >>> 0 < $119 >>> 0;
    if ($120) {
      __label__ = 35;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    var $122 = $65 + 16 | 0;
    var $123 = HEAP32[$122 >> 2];
    var $124 = ($123 | 0) == ($62 | 0);
    if ($124) {
      __label__ = 33;
      break;
    } else {
      __label__ = 34;
      break;
    }
   case 33:
    HEAP32[$122 >> 2] = $R_1;
    __label__ = 36;
    break;
   case 34:
    var $127 = $65 + 20 | 0;
    HEAP32[$127 >> 2] = $R_1;
    __label__ = 36;
    break;
   case 35:
    _abort();
   case 36:
    var $130 = ($R_1 | 0) == 0;
    if ($130) {
      var $p_0 = $25;
      var $psize_0 = $26;
      __label__ = 49;
      break;
    } else {
      __label__ = 37;
      break;
    }
   case 37:
    var $132 = $R_1;
    var $133 = HEAP32[__gm_ + 16 >> 2];
    var $134 = $132 >>> 0 < $133 >>> 0;
    if ($134) {
      __label__ = 46;
      break;
    } else {
      __label__ = 38;
      break;
    }
   case 38:
    var $136 = $R_1 + 24 | 0;
    HEAP32[$136 >> 2] = $65;
    var $_sum33 = $_sum2 + 16 | 0;
    var $137 = $mem + $_sum33 | 0;
    var $138 = $137;
    var $139 = HEAP32[$138 >> 2];
    var $140 = ($139 | 0) == 0;
    if ($140) {
      __label__ = 42;
      break;
    } else {
      __label__ = 39;
      break;
    }
   case 39:
    var $142 = $139;
    var $143 = HEAP32[__gm_ + 16 >> 2];
    var $144 = $142 >>> 0 < $143 >>> 0;
    if ($144) {
      __label__ = 41;
      break;
    } else {
      __label__ = 40;
      break;
    }
   case 40:
    var $146 = $R_1 + 16 | 0;
    HEAP32[$146 >> 2] = $139;
    var $147 = $139 + 24 | 0;
    HEAP32[$147 >> 2] = $R_1;
    __label__ = 42;
    break;
   case 41:
    _abort();
   case 42:
    var $_sum34 = $_sum2 + 20 | 0;
    var $150 = $mem + $_sum34 | 0;
    var $151 = $150;
    var $152 = HEAP32[$151 >> 2];
    var $153 = ($152 | 0) == 0;
    if ($153) {
      var $p_0 = $25;
      var $psize_0 = $26;
      __label__ = 49;
      break;
    } else {
      __label__ = 43;
      break;
    }
   case 43:
    var $155 = $152;
    var $156 = HEAP32[__gm_ + 16 >> 2];
    var $157 = $155 >>> 0 < $156 >>> 0;
    if ($157) {
      __label__ = 45;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 44:
    var $159 = $R_1 + 20 | 0;
    HEAP32[$159 >> 2] = $152;
    var $160 = $152 + 24 | 0;
    HEAP32[$160 >> 2] = $R_1;
    var $p_0 = $25;
    var $psize_0 = $26;
    __label__ = 49;
    break;
   case 45:
    _abort();
   case 46:
    _abort();
   case 47:
    var $_sum3 = $14 - 4 | 0;
    var $164 = $mem + $_sum3 | 0;
    var $165 = $164;
    var $166 = HEAP32[$165 >> 2];
    var $167 = $166 & 3;
    var $168 = ($167 | 0) == 3;
    if ($168) {
      __label__ = 48;
      break;
    } else {
      var $p_0 = $25;
      var $psize_0 = $26;
      __label__ = 49;
      break;
    }
   case 48:
    HEAP32[__gm_ + 8 >> 2] = $26;
    var $170 = HEAP32[$165 >> 2];
    var $171 = $170 & -2;
    HEAP32[$165 >> 2] = $171;
    var $172 = $26 | 1;
    var $_sum26 = $_sum2 + 4 | 0;
    var $173 = $mem + $_sum26 | 0;
    var $174 = $173;
    HEAP32[$174 >> 2] = $172;
    var $175 = $15;
    HEAP32[$175 >> 2] = $26;
    __label__ = 129;
    break;
   case 49:
    var $psize_0;
    var $p_0;
    var $177 = $p_0;
    var $178 = $177 >>> 0 < $15 >>> 0;
    if ($178) {
      __label__ = 50;
      break;
    } else {
      __label__ = 128;
      break;
    }
   case 50:
    var $_sum25 = $14 - 4 | 0;
    var $180 = $mem + $_sum25 | 0;
    var $181 = $180;
    var $182 = HEAP32[$181 >> 2];
    var $183 = $182 & 1;
    var $184 = ($183 | 0) == 0;
    if ($184) {
      __label__ = 128;
      break;
    } else {
      __label__ = 51;
      break;
    }
   case 51:
    var $186 = $182 & 2;
    var $187 = ($186 | 0) == 0;
    if ($187) {
      __label__ = 52;
      break;
    } else {
      __label__ = 101;
      break;
    }
   case 52:
    var $189 = HEAP32[__gm_ + 24 >> 2];
    var $190 = ($16 | 0) == ($189 | 0);
    if ($190) {
      __label__ = 53;
      break;
    } else {
      __label__ = 57;
      break;
    }
   case 53:
    var $192 = HEAP32[__gm_ + 12 >> 2];
    var $193 = $192 + $psize_0 | 0;
    HEAP32[__gm_ + 12 >> 2] = $193;
    HEAP32[__gm_ + 24 >> 2] = $p_0;
    var $194 = $193 | 1;
    var $195 = $p_0 + 4 | 0;
    HEAP32[$195 >> 2] = $194;
    var $196 = HEAP32[__gm_ + 20 >> 2];
    var $197 = ($p_0 | 0) == ($196 | 0);
    if ($197) {
      __label__ = 54;
      break;
    } else {
      __label__ = 55;
      break;
    }
   case 54:
    HEAP32[__gm_ + 20 >> 2] = 0;
    HEAP32[__gm_ + 8 >> 2] = 0;
    __label__ = 55;
    break;
   case 55:
    var $200 = HEAP32[__gm_ + 28 >> 2];
    var $201 = $193 >>> 0 > $200 >>> 0;
    if ($201) {
      __label__ = 56;
      break;
    } else {
      __label__ = 129;
      break;
    }
   case 56:
    _sys_trim();
    __label__ = 129;
    break;
   case 57:
    var $204 = HEAP32[__gm_ + 20 >> 2];
    var $205 = ($16 | 0) == ($204 | 0);
    if ($205) {
      __label__ = 58;
      break;
    } else {
      __label__ = 59;
      break;
    }
   case 58:
    var $207 = HEAP32[__gm_ + 8 >> 2];
    var $208 = $207 + $psize_0 | 0;
    HEAP32[__gm_ + 8 >> 2] = $208;
    HEAP32[__gm_ + 20 >> 2] = $p_0;
    var $209 = $208 | 1;
    var $210 = $p_0 + 4 | 0;
    HEAP32[$210 >> 2] = $209;
    var $211 = $177 + $208 | 0;
    var $212 = $211;
    HEAP32[$212 >> 2] = $208;
    __label__ = 129;
    break;
   case 59:
    var $214 = $182 & -8;
    var $215 = $214 + $psize_0 | 0;
    var $216 = $182 >>> 3;
    var $217 = $182 >>> 0 < 256;
    if ($217) {
      __label__ = 60;
      break;
    } else {
      __label__ = 68;
      break;
    }
   case 60:
    var $219 = $mem + $14 | 0;
    var $220 = $219;
    var $221 = HEAP32[$220 >> 2];
    var $_sum2324 = $14 | 4;
    var $222 = $mem + $_sum2324 | 0;
    var $223 = $222;
    var $224 = HEAP32[$223 >> 2];
    var $225 = ($221 | 0) == ($224 | 0);
    if ($225) {
      __label__ = 61;
      break;
    } else {
      __label__ = 62;
      break;
    }
   case 61:
    var $227 = 1 << $216;
    var $228 = $227 ^ -1;
    var $229 = HEAP32[__gm_ >> 2];
    var $230 = $229 & $228;
    HEAP32[__gm_ >> 2] = $230;
    __label__ = 99;
    break;
   case 62:
    var $232 = $182 >>> 2;
    var $233 = $232 & 1073741822;
    var $234 = __gm_ + 40 + ($233 << 2) | 0;
    var $235 = $234;
    var $236 = ($221 | 0) == ($235 | 0);
    if ($236) {
      __label__ = 64;
      break;
    } else {
      __label__ = 63;
      break;
    }
   case 63:
    var $238 = $221;
    var $239 = HEAP32[__gm_ + 16 >> 2];
    var $240 = $238 >>> 0 < $239 >>> 0;
    if ($240) {
      __label__ = 67;
      break;
    } else {
      __label__ = 64;
      break;
    }
   case 64:
    var $242 = ($224 | 0) == ($235 | 0);
    if ($242) {
      __label__ = 66;
      break;
    } else {
      __label__ = 65;
      break;
    }
   case 65:
    var $244 = $224;
    var $245 = HEAP32[__gm_ + 16 >> 2];
    var $246 = $244 >>> 0 < $245 >>> 0;
    if ($246) {
      __label__ = 67;
      break;
    } else {
      __label__ = 66;
      break;
    }
   case 66:
    var $247 = $221 + 12 | 0;
    HEAP32[$247 >> 2] = $224;
    var $248 = $224 + 8 | 0;
    HEAP32[$248 >> 2] = $221;
    __label__ = 99;
    break;
   case 67:
    _abort();
   case 68:
    var $250 = $15;
    var $_sum5 = $14 + 16 | 0;
    var $251 = $mem + $_sum5 | 0;
    var $252 = $251;
    var $253 = HEAP32[$252 >> 2];
    var $_sum67 = $14 | 4;
    var $254 = $mem + $_sum67 | 0;
    var $255 = $254;
    var $256 = HEAP32[$255 >> 2];
    var $257 = ($256 | 0) == ($250 | 0);
    if ($257) {
      __label__ = 72;
      break;
    } else {
      __label__ = 69;
      break;
    }
   case 69:
    var $259 = $mem + $14 | 0;
    var $260 = $259;
    var $261 = HEAP32[$260 >> 2];
    var $262 = $261;
    var $263 = HEAP32[__gm_ + 16 >> 2];
    var $264 = $262 >>> 0 < $263 >>> 0;
    if ($264) {
      __label__ = 71;
      break;
    } else {
      __label__ = 70;
      break;
    }
   case 70:
    var $266 = $261 + 12 | 0;
    HEAP32[$266 >> 2] = $256;
    var $267 = $256 + 8 | 0;
    HEAP32[$267 >> 2] = $261;
    var $R7_1 = $256;
    __label__ = 79;
    break;
   case 71:
    _abort();
   case 72:
    var $_sum9 = $14 + 12 | 0;
    var $270 = $mem + $_sum9 | 0;
    var $271 = $270;
    var $272 = HEAP32[$271 >> 2];
    var $273 = ($272 | 0) == 0;
    if ($273) {
      __label__ = 73;
      break;
    } else {
      var $RP9_0 = $271;
      var $R7_0 = $272;
      __label__ = 74;
      break;
    }
   case 73:
    var $_sum8 = $14 + 8 | 0;
    var $275 = $mem + $_sum8 | 0;
    var $276 = $275;
    var $277 = HEAP32[$276 >> 2];
    var $278 = ($277 | 0) == 0;
    if ($278) {
      var $R7_1 = 0;
      __label__ = 79;
      break;
    } else {
      var $RP9_0 = $276;
      var $R7_0 = $277;
      __label__ = 74;
      break;
    }
   case 74:
    var $R7_0;
    var $RP9_0;
    var $279 = $R7_0 + 20 | 0;
    var $280 = HEAP32[$279 >> 2];
    var $281 = ($280 | 0) == 0;
    if ($281) {
      __label__ = 75;
      break;
    } else {
      var $RP9_0 = $279;
      var $R7_0 = $280;
      __label__ = 74;
      break;
    }
   case 75:
    var $283 = $R7_0 + 16 | 0;
    var $284 = HEAP32[$283 >> 2];
    var $285 = ($284 | 0) == 0;
    if ($285) {
      __label__ = 76;
      break;
    } else {
      var $RP9_0 = $283;
      var $R7_0 = $284;
      __label__ = 74;
      break;
    }
   case 76:
    var $287 = $RP9_0;
    var $288 = HEAP32[__gm_ + 16 >> 2];
    var $289 = $287 >>> 0 < $288 >>> 0;
    if ($289) {
      __label__ = 78;
      break;
    } else {
      __label__ = 77;
      break;
    }
   case 77:
    HEAP32[$RP9_0 >> 2] = 0;
    var $R7_1 = $R7_0;
    __label__ = 79;
    break;
   case 78:
    _abort();
   case 79:
    var $R7_1;
    var $293 = ($253 | 0) == 0;
    if ($293) {
      __label__ = 99;
      break;
    } else {
      __label__ = 80;
      break;
    }
   case 80:
    var $_sum18 = $14 + 20 | 0;
    var $295 = $mem + $_sum18 | 0;
    var $296 = $295;
    var $297 = HEAP32[$296 >> 2];
    var $298 = __gm_ + 304 + ($297 << 2) | 0;
    var $299 = HEAP32[$298 >> 2];
    var $300 = ($250 | 0) == ($299 | 0);
    if ($300) {
      __label__ = 81;
      break;
    } else {
      __label__ = 83;
      break;
    }
   case 81:
    HEAP32[$298 >> 2] = $R7_1;
    var $cond47 = ($R7_1 | 0) == 0;
    if ($cond47) {
      __label__ = 82;
      break;
    } else {
      __label__ = 89;
      break;
    }
   case 82:
    var $302 = HEAP32[$296 >> 2];
    var $303 = 1 << $302;
    var $304 = $303 ^ -1;
    var $305 = HEAP32[__gm_ + 4 >> 2];
    var $306 = $305 & $304;
    HEAP32[__gm_ + 4 >> 2] = $306;
    __label__ = 99;
    break;
   case 83:
    var $308 = $253;
    var $309 = HEAP32[__gm_ + 16 >> 2];
    var $310 = $308 >>> 0 < $309 >>> 0;
    if ($310) {
      __label__ = 87;
      break;
    } else {
      __label__ = 84;
      break;
    }
   case 84:
    var $312 = $253 + 16 | 0;
    var $313 = HEAP32[$312 >> 2];
    var $314 = ($313 | 0) == ($250 | 0);
    if ($314) {
      __label__ = 85;
      break;
    } else {
      __label__ = 86;
      break;
    }
   case 85:
    HEAP32[$312 >> 2] = $R7_1;
    __label__ = 88;
    break;
   case 86:
    var $317 = $253 + 20 | 0;
    HEAP32[$317 >> 2] = $R7_1;
    __label__ = 88;
    break;
   case 87:
    _abort();
   case 88:
    var $320 = ($R7_1 | 0) == 0;
    if ($320) {
      __label__ = 99;
      break;
    } else {
      __label__ = 89;
      break;
    }
   case 89:
    var $322 = $R7_1;
    var $323 = HEAP32[__gm_ + 16 >> 2];
    var $324 = $322 >>> 0 < $323 >>> 0;
    if ($324) {
      __label__ = 98;
      break;
    } else {
      __label__ = 90;
      break;
    }
   case 90:
    var $326 = $R7_1 + 24 | 0;
    HEAP32[$326 >> 2] = $253;
    var $_sum19 = $14 + 8 | 0;
    var $327 = $mem + $_sum19 | 0;
    var $328 = $327;
    var $329 = HEAP32[$328 >> 2];
    var $330 = ($329 | 0) == 0;
    if ($330) {
      __label__ = 94;
      break;
    } else {
      __label__ = 91;
      break;
    }
   case 91:
    var $332 = $329;
    var $333 = HEAP32[__gm_ + 16 >> 2];
    var $334 = $332 >>> 0 < $333 >>> 0;
    if ($334) {
      __label__ = 93;
      break;
    } else {
      __label__ = 92;
      break;
    }
   case 92:
    var $336 = $R7_1 + 16 | 0;
    HEAP32[$336 >> 2] = $329;
    var $337 = $329 + 24 | 0;
    HEAP32[$337 >> 2] = $R7_1;
    __label__ = 94;
    break;
   case 93:
    _abort();
   case 94:
    var $_sum20 = $14 + 12 | 0;
    var $340 = $mem + $_sum20 | 0;
    var $341 = $340;
    var $342 = HEAP32[$341 >> 2];
    var $343 = ($342 | 0) == 0;
    if ($343) {
      __label__ = 99;
      break;
    } else {
      __label__ = 95;
      break;
    }
   case 95:
    var $345 = $342;
    var $346 = HEAP32[__gm_ + 16 >> 2];
    var $347 = $345 >>> 0 < $346 >>> 0;
    if ($347) {
      __label__ = 97;
      break;
    } else {
      __label__ = 96;
      break;
    }
   case 96:
    var $349 = $R7_1 + 20 | 0;
    HEAP32[$349 >> 2] = $342;
    var $350 = $342 + 24 | 0;
    HEAP32[$350 >> 2] = $R7_1;
    __label__ = 99;
    break;
   case 97:
    _abort();
   case 98:
    _abort();
   case 99:
    var $354 = $215 | 1;
    var $355 = $p_0 + 4 | 0;
    HEAP32[$355 >> 2] = $354;
    var $356 = $177 + $215 | 0;
    var $357 = $356;
    HEAP32[$357 >> 2] = $215;
    var $358 = HEAP32[__gm_ + 20 >> 2];
    var $359 = ($p_0 | 0) == ($358 | 0);
    if ($359) {
      __label__ = 100;
      break;
    } else {
      var $psize_1 = $215;
      __label__ = 102;
      break;
    }
   case 100:
    HEAP32[__gm_ + 8 >> 2] = $215;
    __label__ = 129;
    break;
   case 101:
    var $362 = $182 & -2;
    HEAP32[$181 >> 2] = $362;
    var $363 = $psize_0 | 1;
    var $364 = $p_0 + 4 | 0;
    HEAP32[$364 >> 2] = $363;
    var $365 = $177 + $psize_0 | 0;
    var $366 = $365;
    HEAP32[$366 >> 2] = $psize_0;
    var $psize_1 = $psize_0;
    __label__ = 102;
    break;
   case 102:
    var $psize_1;
    var $368 = $psize_1 >>> 0 < 256;
    if ($368) {
      __label__ = 103;
      break;
    } else {
      __label__ = 108;
      break;
    }
   case 103:
    var $370 = $psize_1 >>> 3;
    var $371 = $psize_1 >>> 2;
    var $372 = $371 & 1073741822;
    var $373 = __gm_ + 40 + ($372 << 2) | 0;
    var $374 = $373;
    var $375 = HEAP32[__gm_ >> 2];
    var $376 = 1 << $370;
    var $377 = $375 & $376;
    var $378 = ($377 | 0) == 0;
    if ($378) {
      __label__ = 104;
      break;
    } else {
      __label__ = 105;
      break;
    }
   case 104:
    var $380 = $375 | $376;
    HEAP32[__gm_ >> 2] = $380;
    var $_sum16_pre = $372 + 2 | 0;
    var $_pre = __gm_ + 40 + ($_sum16_pre << 2) | 0;
    var $F16_0 = $374;
    var $_pre_phi = $_pre;
    __label__ = 107;
    break;
   case 105:
    var $_sum17 = $372 + 2 | 0;
    var $382 = __gm_ + 40 + ($_sum17 << 2) | 0;
    var $383 = HEAP32[$382 >> 2];
    var $384 = $383;
    var $385 = HEAP32[__gm_ + 16 >> 2];
    var $386 = $384 >>> 0 < $385 >>> 0;
    if ($386) {
      __label__ = 106;
      break;
    } else {
      var $F16_0 = $383;
      var $_pre_phi = $382;
      __label__ = 107;
      break;
    }
   case 106:
    _abort();
   case 107:
    var $_pre_phi;
    var $F16_0;
    HEAP32[$_pre_phi >> 2] = $p_0;
    var $389 = $F16_0 + 12 | 0;
    HEAP32[$389 >> 2] = $p_0;
    var $390 = $p_0 + 8 | 0;
    HEAP32[$390 >> 2] = $F16_0;
    var $391 = $p_0 + 12 | 0;
    HEAP32[$391 >> 2] = $374;
    __label__ = 129;
    break;
   case 108:
    var $393 = $p_0;
    var $394 = $psize_1 >>> 8;
    var $395 = ($394 | 0) == 0;
    if ($395) {
      var $I18_0 = 0;
      __label__ = 111;
      break;
    } else {
      __label__ = 109;
      break;
    }
   case 109:
    var $397 = $psize_1 >>> 0 > 16777215;
    if ($397) {
      var $I18_0 = 31;
      __label__ = 111;
      break;
    } else {
      __label__ = 110;
      break;
    }
   case 110:
    var $399 = $394 + 1048320 | 0;
    var $400 = $399 >>> 16;
    var $401 = $400 & 8;
    var $402 = $394 << $401;
    var $403 = $402 + 520192 | 0;
    var $404 = $403 >>> 16;
    var $405 = $404 & 4;
    var $406 = $402 << $405;
    var $407 = $406 + 245760 | 0;
    var $408 = $407 >>> 16;
    var $409 = $408 & 2;
    var $410 = $405 | $401;
    var $411 = $410 | $409;
    var $412 = 14 - $411 | 0;
    var $413 = $406 << $409;
    var $414 = $413 >>> 15;
    var $415 = $412 + $414 | 0;
    var $416 = $415 << 1;
    var $417 = $415 + 7 | 0;
    var $418 = $psize_1 >>> ($417 >>> 0);
    var $419 = $418 & 1;
    var $420 = $419 | $416;
    var $I18_0 = $420;
    __label__ = 111;
    break;
   case 111:
    var $I18_0;
    var $422 = __gm_ + 304 + ($I18_0 << 2) | 0;
    var $423 = $p_0 + 28 | 0;
    var $I18_0_c = $I18_0;
    HEAP32[$423 >> 2] = $I18_0_c;
    var $424 = $p_0 + 20 | 0;
    HEAP32[$424 >> 2] = 0;
    var $425 = $p_0 + 16 | 0;
    HEAP32[$425 >> 2] = 0;
    var $426 = HEAP32[__gm_ + 4 >> 2];
    var $427 = 1 << $I18_0;
    var $428 = $426 & $427;
    var $429 = ($428 | 0) == 0;
    if ($429) {
      __label__ = 112;
      break;
    } else {
      __label__ = 113;
      break;
    }
   case 112:
    var $431 = $426 | $427;
    HEAP32[__gm_ + 4 >> 2] = $431;
    HEAP32[$422 >> 2] = $393;
    var $432 = $p_0 + 24 | 0;
    var $_c = $422;
    HEAP32[$432 >> 2] = $_c;
    var $433 = $p_0 + 12 | 0;
    HEAP32[$433 >> 2] = $p_0;
    var $434 = $p_0 + 8 | 0;
    HEAP32[$434 >> 2] = $p_0;
    __label__ = 126;
    break;
   case 113:
    var $436 = HEAP32[$422 >> 2];
    var $437 = ($I18_0 | 0) == 31;
    if ($437) {
      var $442 = 0;
      __label__ = 115;
      break;
    } else {
      __label__ = 114;
      break;
    }
   case 114:
    var $439 = $I18_0 >>> 1;
    var $440 = 25 - $439 | 0;
    var $442 = $440;
    __label__ = 115;
    break;
   case 115:
    var $442;
    var $443 = $psize_1 << $442;
    var $K19_0 = $443;
    var $T_0 = $436;
    __label__ = 116;
    break;
   case 116:
    var $T_0;
    var $K19_0;
    var $445 = $T_0 + 4 | 0;
    var $446 = HEAP32[$445 >> 2];
    var $447 = $446 & -8;
    var $448 = ($447 | 0) == ($psize_1 | 0);
    if ($448) {
      __label__ = 122;
      break;
    } else {
      __label__ = 117;
      break;
    }
   case 117:
    var $450 = $K19_0 >>> 31;
    var $451 = $T_0 + 16 + ($450 << 2) | 0;
    var $452 = HEAP32[$451 >> 2];
    var $453 = ($452 | 0) == 0;
    if ($453) {
      __label__ = 119;
      break;
    } else {
      __label__ = 118;
      break;
    }
   case 118:
    var $455 = $K19_0 << 1;
    var $K19_0 = $455;
    var $T_0 = $452;
    __label__ = 116;
    break;
   case 119:
    var $457 = $451;
    var $458 = HEAP32[__gm_ + 16 >> 2];
    var $459 = $457 >>> 0 < $458 >>> 0;
    if ($459) {
      __label__ = 121;
      break;
    } else {
      __label__ = 120;
      break;
    }
   case 120:
    HEAP32[$451 >> 2] = $393;
    var $461 = $p_0 + 24 | 0;
    var $T_0_c13 = $T_0;
    HEAP32[$461 >> 2] = $T_0_c13;
    var $462 = $p_0 + 12 | 0;
    HEAP32[$462 >> 2] = $p_0;
    var $463 = $p_0 + 8 | 0;
    HEAP32[$463 >> 2] = $p_0;
    __label__ = 126;
    break;
   case 121:
    _abort();
   case 122:
    var $466 = $T_0 + 8 | 0;
    var $467 = HEAP32[$466 >> 2];
    var $468 = $T_0;
    var $469 = HEAP32[__gm_ + 16 >> 2];
    var $470 = $468 >>> 0 < $469 >>> 0;
    if ($470) {
      __label__ = 125;
      break;
    } else {
      __label__ = 123;
      break;
    }
   case 123:
    var $472 = $467;
    var $473 = $472 >>> 0 < $469 >>> 0;
    if ($473) {
      __label__ = 125;
      break;
    } else {
      __label__ = 124;
      break;
    }
   case 124:
    var $475 = $467 + 12 | 0;
    HEAP32[$475 >> 2] = $393;
    HEAP32[$466 >> 2] = $393;
    var $476 = $p_0 + 8 | 0;
    var $_c12 = $467;
    HEAP32[$476 >> 2] = $_c12;
    var $477 = $p_0 + 12 | 0;
    var $T_0_c = $T_0;
    HEAP32[$477 >> 2] = $T_0_c;
    var $478 = $p_0 + 24 | 0;
    HEAP32[$478 >> 2] = 0;
    __label__ = 126;
    break;
   case 125:
    _abort();
   case 126:
    var $480 = HEAP32[__gm_ + 32 >> 2];
    var $481 = $480 - 1 | 0;
    HEAP32[__gm_ + 32 >> 2] = $481;
    var $482 = ($481 | 0) == 0;
    if ($482) {
      __label__ = 127;
      break;
    } else {
      __label__ = 129;
      break;
    }
   case 127:
    _release_unused_segments();
    __label__ = 129;
    break;
   case 128:
    _abort();
   case 129:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
Module["_free"] = _free;
_free["X"] = 1;
function _mmap_resize($oldp, $nb) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $oldp + 4 | 0;
    var $2 = HEAP32[$1 >> 2];
    var $3 = $2 & -8;
    var $4 = $nb >>> 0 < 256;
    if ($4) {
      var $_0 = 0;
      __label__ = 6;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $6 = $nb + 4 | 0;
    var $7 = $3 >>> 0 < $6 >>> 0;
    if ($7) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $9 = $3 - $nb | 0;
    var $10 = HEAP32[_mparams + 8 >> 2];
    var $11 = $10 << 1;
    var $12 = $9 >>> 0 > $11 >>> 0;
    if ($12) {
      __label__ = 5;
      break;
    } else {
      var $_0 = $oldp;
      __label__ = 6;
      break;
    }
   case 5:
    var $_0 = 0;
    __label__ = 6;
    break;
   case 6:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _segment_holding($addr) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $sp_0 = __gm_ + 444 | 0;
    __label__ = 3;
    break;
   case 3:
    var $sp_0;
    var $2 = $sp_0 | 0;
    var $3 = HEAP32[$2 >> 2];
    var $4 = $3 >>> 0 > $addr >>> 0;
    if ($4) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    var $6 = $sp_0 + 4 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = $3 + $7 | 0;
    var $9 = $8 >>> 0 > $addr >>> 0;
    if ($9) {
      var $_0 = $sp_0;
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $11 = $sp_0 + 8 | 0;
    var $12 = HEAP32[$11 >> 2];
    var $13 = ($12 | 0) == 0;
    if ($13) {
      var $_0 = 0;
      __label__ = 6;
      break;
    } else {
      var $sp_0 = $12;
      __label__ = 3;
      break;
    }
   case 6:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _init_top($p, $psize) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $p;
    var $2 = $p + 8 | 0;
    var $3 = $2;
    var $4 = $3 & 7;
    var $5 = ($4 | 0) == 0;
    if ($5) {
      var $10 = 0;
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $7 = -$3 | 0;
    var $8 = $7 & 7;
    var $10 = $8;
    __label__ = 4;
    break;
   case 4:
    var $10;
    var $11 = $1 + $10 | 0;
    var $12 = $11;
    var $13 = $psize - $10 | 0;
    HEAP32[__gm_ + 24 >> 2] = $12;
    HEAP32[__gm_ + 12 >> 2] = $13;
    var $14 = $13 | 1;
    var $_sum = $10 + 4 | 0;
    var $15 = $1 + $_sum | 0;
    var $16 = $15;
    HEAP32[$16 >> 2] = $14;
    var $_sum2 = $psize + 4 | 0;
    var $17 = $1 + $_sum2 | 0;
    var $18 = $17;
    HEAP32[$18 >> 2] = 40;
    var $19 = HEAP32[_mparams + 16 >> 2];
    HEAP32[__gm_ + 28 >> 2] = $19;
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _init_bins() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $i_02 = 0;
    __label__ = 3;
    break;
   case 3:
    var $i_02;
    var $2 = $i_02 << 1;
    var $3 = __gm_ + 40 + ($2 << 2) | 0;
    var $4 = $3;
    var $_sum = $2 + 3 | 0;
    var $5 = __gm_ + 40 + ($_sum << 2) | 0;
    HEAP32[$5 >> 2] = $4;
    var $_sum1 = $2 + 2 | 0;
    var $6 = __gm_ + 40 + ($_sum1 << 2) | 0;
    HEAP32[$6 >> 2] = $4;
    var $7 = $i_02 + 1 | 0;
    var $exitcond = ($7 | 0) == 32;
    if ($exitcond) {
      __label__ = 4;
      break;
    } else {
      var $i_02 = $7;
      __label__ = 3;
      break;
    }
   case 4:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _calloc() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = _malloc(8524);
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 5;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $4 = $1 - 4 | 0;
    var $5 = $4;
    var $6 = HEAP32[$5 >> 2];
    var $7 = $6 & 3;
    var $8 = ($7 | 0) == 0;
    if ($8) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    _memset($1, 0, 8524, 1);
    __label__ = 5;
    break;
   case 5:
    return $1;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _realloc($oldmem, $bytes) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = ($oldmem | 0) == 0;
    if ($1) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $3 = _malloc($bytes);
    var $_0 = $3;
    __label__ = 5;
    break;
   case 4:
    var $5 = _internal_realloc($oldmem, $bytes);
    var $_0 = $5;
    __label__ = 5;
    break;
   case 5:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _internal_realloc($oldmem, $bytes) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $bytes >>> 0 > 4294967231;
    if ($1) {
      __label__ = 3;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 3:
    var $3 = ___errno();
    HEAP32[$3 >> 2] = 12;
    var $_0 = 0;
    __label__ = 24;
    break;
   case 4:
    var $5 = $oldmem - 8 | 0;
    var $6 = $5;
    var $7 = $oldmem - 4 | 0;
    var $8 = $7;
    var $9 = HEAP32[$8 >> 2];
    var $10 = $9 & -8;
    var $_sum = $10 - 8 | 0;
    var $11 = $oldmem + $_sum | 0;
    var $12 = $11;
    var $13 = HEAP32[__gm_ + 16 >> 2];
    var $14 = $5 >>> 0 < $13 >>> 0;
    if ($14) {
      __label__ = 17;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $16 = $9 & 3;
    var $17 = ($16 | 0) != 1;
    var $18 = ($_sum | 0) > -8;
    var $or_cond = $17 & $18;
    if ($or_cond) {
      __label__ = 6;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 6:
    var $_sum8 = $10 - 4 | 0;
    var $20 = $oldmem + $_sum8 | 0;
    var $21 = $20;
    var $22 = HEAP32[$21 >> 2];
    var $23 = $22 & 1;
    var $24 = ($23 | 0) == 0;
    if ($24) {
      __label__ = 17;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $26 = $bytes >>> 0 < 11;
    if ($26) {
      var $31 = 16;
      __label__ = 9;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 8:
    var $28 = $bytes + 11 | 0;
    var $29 = $28 & -8;
    var $31 = $29;
    __label__ = 9;
    break;
   case 9:
    var $31;
    var $32 = ($16 | 0) == 0;
    if ($32) {
      __label__ = 10;
      break;
    } else {
      __label__ = 11;
      break;
    }
   case 10:
    var $34 = _mmap_resize($6, $31);
    var $extra_0 = 0;
    var $newp_0 = $34;
    __label__ = 18;
    break;
   case 11:
    var $36 = $10 >>> 0 < $31 >>> 0;
    if ($36) {
      __label__ = 14;
      break;
    } else {
      __label__ = 12;
      break;
    }
   case 12:
    var $38 = $10 - $31 | 0;
    var $39 = $38 >>> 0 > 15;
    if ($39) {
      __label__ = 13;
      break;
    } else {
      var $extra_0 = 0;
      var $newp_0 = $6;
      __label__ = 18;
      break;
    }
   case 13:
    var $41 = $9 & 1;
    var $42 = $31 | $41;
    var $43 = $42 | 2;
    HEAP32[$8 >> 2] = $43;
    var $_sum4 = $31 - 4 | 0;
    var $44 = $oldmem + $_sum4 | 0;
    var $45 = $44;
    var $46 = $38 | 3;
    HEAP32[$45 >> 2] = $46;
    var $47 = HEAP32[$21 >> 2];
    var $48 = $47 | 1;
    HEAP32[$21 >> 2] = $48;
    var $49 = $oldmem + $31 | 0;
    var $extra_0 = $49;
    var $newp_0 = $6;
    __label__ = 18;
    break;
   case 14:
    var $51 = HEAP32[__gm_ + 24 >> 2];
    var $52 = ($12 | 0) == ($51 | 0);
    if ($52) {
      __label__ = 15;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 15:
    var $54 = HEAP32[__gm_ + 12 >> 2];
    var $55 = $54 + $10 | 0;
    var $56 = $55 >>> 0 > $31 >>> 0;
    if ($56) {
      __label__ = 16;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 16:
    var $58 = $55 - $31 | 0;
    var $_sum1 = $31 - 8 | 0;
    var $59 = $oldmem + $_sum1 | 0;
    var $60 = $59;
    var $61 = $9 & 1;
    var $62 = $31 | $61;
    var $63 = $62 | 2;
    HEAP32[$8 >> 2] = $63;
    var $_sum2 = $31 - 4 | 0;
    var $64 = $oldmem + $_sum2 | 0;
    var $65 = $64;
    var $66 = $58 | 1;
    HEAP32[$65 >> 2] = $66;
    HEAP32[__gm_ + 24 >> 2] = $60;
    HEAP32[__gm_ + 12 >> 2] = $58;
    var $extra_0 = 0;
    var $newp_0 = $6;
    __label__ = 18;
    break;
   case 17:
    _abort();
   case 18:
    var $newp_0;
    var $extra_0;
    var $68 = ($newp_0 | 0) == 0;
    if ($68) {
      __label__ = 22;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 19:
    var $70 = ($extra_0 | 0) == 0;
    if ($70) {
      __label__ = 21;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 20:
    _free($extra_0);
    __label__ = 21;
    break;
   case 21:
    var $73 = $newp_0 + 8 | 0;
    var $74 = $73;
    var $_0 = $74;
    __label__ = 24;
    break;
   case 22:
    var $75 = _malloc($bytes);
    var $76 = ($75 | 0) == 0;
    if ($76) {
      var $_0 = 0;
      __label__ = 24;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $78 = HEAP32[$8 >> 2];
    var $79 = $78 & 3;
    var $80 = ($79 | 0) == 0;
    var $81 = $80 ? 8 : 4;
    var $82 = $10 - $81 | 0;
    var $83 = $82 >>> 0 < $bytes >>> 0;
    var $84 = $83 ? $82 : $bytes;
    _memcpy($75, $oldmem, $84, 1);
    _free($oldmem);
    var $_0 = $75;
    __label__ = 24;
    break;
   case 24:
    var $_0;
    return $_0;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_internal_realloc["X"] = 1;
function _init_mparams() {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[_mparams >> 2];
    var $2 = ($1 | 0) == 0;
    if ($2) {
      __label__ = 3;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 3:
    var $4 = _sysconf(8);
    var $5 = $4 - 1 | 0;
    var $6 = $5 & $4;
    var $7 = ($6 | 0) == 0;
    if ($7) {
      __label__ = 5;
      break;
    } else {
      __label__ = 4;
      break;
    }
   case 4:
    _abort();
   case 5:
    HEAP32[_mparams + 8 >> 2] = $4;
    HEAP32[_mparams + 4 >> 2] = $4;
    HEAP32[_mparams + 12 >> 2] = -1;
    HEAP32[_mparams + 16 >> 2] = 2097152;
    HEAP32[_mparams + 20 >> 2] = 0;
    HEAP32[__gm_ + 440 >> 2] = 0;
    var $10 = _time(0);
    var $11 = $10 & -16;
    var $12 = $11 ^ 1431655768;
    HEAP32[_mparams >> 2] = $12;
    __label__ = 6;
    break;
   case 6:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
function _prepend_alloc($newbase, $oldbase, $nb) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = $newbase + 8 | 0;
    var $2 = $1;
    var $3 = $2 & 7;
    var $4 = ($3 | 0) == 0;
    if ($4) {
      var $9 = 0;
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $6 = -$2 | 0;
    var $7 = $6 & 7;
    var $9 = $7;
    __label__ = 4;
    break;
   case 4:
    var $9;
    var $10 = $newbase + $9 | 0;
    var $11 = $oldbase + 8 | 0;
    var $12 = $11;
    var $13 = $12 & 7;
    var $14 = ($13 | 0) == 0;
    if ($14) {
      var $19 = 0;
      __label__ = 6;
      break;
    } else {
      __label__ = 5;
      break;
    }
   case 5:
    var $16 = -$12 | 0;
    var $17 = $16 & 7;
    var $19 = $17;
    __label__ = 6;
    break;
   case 6:
    var $19;
    var $20 = $oldbase + $19 | 0;
    var $21 = $20;
    var $22 = $20;
    var $23 = $10;
    var $24 = $22 - $23 | 0;
    var $_sum = $9 + $nb | 0;
    var $25 = $newbase + $_sum | 0;
    var $26 = $25;
    var $27 = $24 - $nb | 0;
    var $28 = $nb | 3;
    var $_sum1 = $9 + 4 | 0;
    var $29 = $newbase + $_sum1 | 0;
    var $30 = $29;
    HEAP32[$30 >> 2] = $28;
    var $31 = HEAP32[__gm_ + 24 >> 2];
    var $32 = ($21 | 0) == ($31 | 0);
    if ($32) {
      __label__ = 7;
      break;
    } else {
      __label__ = 8;
      break;
    }
   case 7:
    var $34 = HEAP32[__gm_ + 12 >> 2];
    var $35 = $34 + $27 | 0;
    HEAP32[__gm_ + 12 >> 2] = $35;
    HEAP32[__gm_ + 24 >> 2] = $26;
    var $36 = $35 | 1;
    var $_sum42 = $_sum + 4 | 0;
    var $37 = $newbase + $_sum42 | 0;
    var $38 = $37;
    HEAP32[$38 >> 2] = $36;
    __label__ = 76;
    break;
   case 8:
    var $40 = HEAP32[__gm_ + 20 >> 2];
    var $41 = ($21 | 0) == ($40 | 0);
    if ($41) {
      __label__ = 9;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 9:
    var $43 = HEAP32[__gm_ + 8 >> 2];
    var $44 = $43 + $27 | 0;
    HEAP32[__gm_ + 8 >> 2] = $44;
    HEAP32[__gm_ + 20 >> 2] = $26;
    var $45 = $44 | 1;
    var $_sum40 = $_sum + 4 | 0;
    var $46 = $newbase + $_sum40 | 0;
    var $47 = $46;
    HEAP32[$47 >> 2] = $45;
    var $_sum41 = $44 + $_sum | 0;
    var $48 = $newbase + $_sum41 | 0;
    var $49 = $48;
    HEAP32[$49 >> 2] = $44;
    __label__ = 76;
    break;
   case 10:
    var $_sum2 = $19 + 4 | 0;
    var $51 = $oldbase + $_sum2 | 0;
    var $52 = $51;
    var $53 = HEAP32[$52 >> 2];
    var $54 = $53 & 3;
    var $55 = ($54 | 0) == 1;
    if ($55) {
      __label__ = 11;
      break;
    } else {
      var $oldfirst_0 = $21;
      var $qsize_0 = $27;
      __label__ = 52;
      break;
    }
   case 11:
    var $57 = $53 & -8;
    var $58 = $53 >>> 3;
    var $59 = $53 >>> 0 < 256;
    if ($59) {
      __label__ = 12;
      break;
    } else {
      __label__ = 20;
      break;
    }
   case 12:
    var $_sum3738 = $19 | 8;
    var $61 = $oldbase + $_sum3738 | 0;
    var $62 = $61;
    var $63 = HEAP32[$62 >> 2];
    var $_sum39 = $19 + 12 | 0;
    var $64 = $oldbase + $_sum39 | 0;
    var $65 = $64;
    var $66 = HEAP32[$65 >> 2];
    var $67 = ($63 | 0) == ($66 | 0);
    if ($67) {
      __label__ = 13;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 13:
    var $69 = 1 << $58;
    var $70 = $69 ^ -1;
    var $71 = HEAP32[__gm_ >> 2];
    var $72 = $71 & $70;
    HEAP32[__gm_ >> 2] = $72;
    __label__ = 51;
    break;
   case 14:
    var $74 = $53 >>> 2;
    var $75 = $74 & 1073741822;
    var $76 = __gm_ + 40 + ($75 << 2) | 0;
    var $77 = $76;
    var $78 = ($63 | 0) == ($77 | 0);
    if ($78) {
      __label__ = 16;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $80 = $63;
    var $81 = HEAP32[__gm_ + 16 >> 2];
    var $82 = $80 >>> 0 < $81 >>> 0;
    if ($82) {
      __label__ = 19;
      break;
    } else {
      __label__ = 16;
      break;
    }
   case 16:
    var $84 = ($66 | 0) == ($77 | 0);
    if ($84) {
      __label__ = 18;
      break;
    } else {
      __label__ = 17;
      break;
    }
   case 17:
    var $86 = $66;
    var $87 = HEAP32[__gm_ + 16 >> 2];
    var $88 = $86 >>> 0 < $87 >>> 0;
    if ($88) {
      __label__ = 19;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 18:
    var $89 = $63 + 12 | 0;
    HEAP32[$89 >> 2] = $66;
    var $90 = $66 + 8 | 0;
    HEAP32[$90 >> 2] = $63;
    __label__ = 51;
    break;
   case 19:
    _abort();
   case 20:
    var $92 = $20;
    var $_sum34 = $19 | 24;
    var $93 = $oldbase + $_sum34 | 0;
    var $94 = $93;
    var $95 = HEAP32[$94 >> 2];
    var $_sum5 = $19 + 12 | 0;
    var $96 = $oldbase + $_sum5 | 0;
    var $97 = $96;
    var $98 = HEAP32[$97 >> 2];
    var $99 = ($98 | 0) == ($92 | 0);
    if ($99) {
      __label__ = 24;
      break;
    } else {
      __label__ = 21;
      break;
    }
   case 21:
    var $_sum3536 = $19 | 8;
    var $101 = $oldbase + $_sum3536 | 0;
    var $102 = $101;
    var $103 = HEAP32[$102 >> 2];
    var $104 = $103;
    var $105 = HEAP32[__gm_ + 16 >> 2];
    var $106 = $104 >>> 0 < $105 >>> 0;
    if ($106) {
      __label__ = 23;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    var $108 = $103 + 12 | 0;
    HEAP32[$108 >> 2] = $98;
    var $109 = $98 + 8 | 0;
    HEAP32[$109 >> 2] = $103;
    var $R_1 = $98;
    __label__ = 31;
    break;
   case 23:
    _abort();
   case 24:
    var $_sum67 = $19 | 16;
    var $_sum8 = $_sum67 + 4 | 0;
    var $112 = $oldbase + $_sum8 | 0;
    var $113 = $112;
    var $114 = HEAP32[$113 >> 2];
    var $115 = ($114 | 0) == 0;
    if ($115) {
      __label__ = 25;
      break;
    } else {
      var $RP_0 = $113;
      var $R_0 = $114;
      __label__ = 26;
      break;
    }
   case 25:
    var $117 = $oldbase + $_sum67 | 0;
    var $118 = $117;
    var $119 = HEAP32[$118 >> 2];
    var $120 = ($119 | 0) == 0;
    if ($120) {
      var $R_1 = 0;
      __label__ = 31;
      break;
    } else {
      var $RP_0 = $118;
      var $R_0 = $119;
      __label__ = 26;
      break;
    }
   case 26:
    var $R_0;
    var $RP_0;
    var $121 = $R_0 + 20 | 0;
    var $122 = HEAP32[$121 >> 2];
    var $123 = ($122 | 0) == 0;
    if ($123) {
      __label__ = 27;
      break;
    } else {
      var $RP_0 = $121;
      var $R_0 = $122;
      __label__ = 26;
      break;
    }
   case 27:
    var $125 = $R_0 + 16 | 0;
    var $126 = HEAP32[$125 >> 2];
    var $127 = ($126 | 0) == 0;
    if ($127) {
      __label__ = 28;
      break;
    } else {
      var $RP_0 = $125;
      var $R_0 = $126;
      __label__ = 26;
      break;
    }
   case 28:
    var $129 = $RP_0;
    var $130 = HEAP32[__gm_ + 16 >> 2];
    var $131 = $129 >>> 0 < $130 >>> 0;
    if ($131) {
      __label__ = 30;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    HEAP32[$RP_0 >> 2] = 0;
    var $R_1 = $R_0;
    __label__ = 31;
    break;
   case 30:
    _abort();
   case 31:
    var $R_1;
    var $135 = ($95 | 0) == 0;
    if ($135) {
      __label__ = 51;
      break;
    } else {
      __label__ = 32;
      break;
    }
   case 32:
    var $_sum30 = $19 + 28 | 0;
    var $137 = $oldbase + $_sum30 | 0;
    var $138 = $137;
    var $139 = HEAP32[$138 >> 2];
    var $140 = __gm_ + 304 + ($139 << 2) | 0;
    var $141 = HEAP32[$140 >> 2];
    var $142 = ($92 | 0) == ($141 | 0);
    if ($142) {
      __label__ = 33;
      break;
    } else {
      __label__ = 35;
      break;
    }
   case 33:
    HEAP32[$140 >> 2] = $R_1;
    var $cond = ($R_1 | 0) == 0;
    if ($cond) {
      __label__ = 34;
      break;
    } else {
      __label__ = 41;
      break;
    }
   case 34:
    var $144 = HEAP32[$138 >> 2];
    var $145 = 1 << $144;
    var $146 = $145 ^ -1;
    var $147 = HEAP32[__gm_ + 4 >> 2];
    var $148 = $147 & $146;
    HEAP32[__gm_ + 4 >> 2] = $148;
    __label__ = 51;
    break;
   case 35:
    var $150 = $95;
    var $151 = HEAP32[__gm_ + 16 >> 2];
    var $152 = $150 >>> 0 < $151 >>> 0;
    if ($152) {
      __label__ = 39;
      break;
    } else {
      __label__ = 36;
      break;
    }
   case 36:
    var $154 = $95 + 16 | 0;
    var $155 = HEAP32[$154 >> 2];
    var $156 = ($155 | 0) == ($92 | 0);
    if ($156) {
      __label__ = 37;
      break;
    } else {
      __label__ = 38;
      break;
    }
   case 37:
    HEAP32[$154 >> 2] = $R_1;
    __label__ = 40;
    break;
   case 38:
    var $159 = $95 + 20 | 0;
    HEAP32[$159 >> 2] = $R_1;
    __label__ = 40;
    break;
   case 39:
    _abort();
   case 40:
    var $162 = ($R_1 | 0) == 0;
    if ($162) {
      __label__ = 51;
      break;
    } else {
      __label__ = 41;
      break;
    }
   case 41:
    var $164 = $R_1;
    var $165 = HEAP32[__gm_ + 16 >> 2];
    var $166 = $164 >>> 0 < $165 >>> 0;
    if ($166) {
      __label__ = 50;
      break;
    } else {
      __label__ = 42;
      break;
    }
   case 42:
    var $168 = $R_1 + 24 | 0;
    HEAP32[$168 >> 2] = $95;
    var $_sum3132 = $19 | 16;
    var $169 = $oldbase + $_sum3132 | 0;
    var $170 = $169;
    var $171 = HEAP32[$170 >> 2];
    var $172 = ($171 | 0) == 0;
    if ($172) {
      __label__ = 46;
      break;
    } else {
      __label__ = 43;
      break;
    }
   case 43:
    var $174 = $171;
    var $175 = HEAP32[__gm_ + 16 >> 2];
    var $176 = $174 >>> 0 < $175 >>> 0;
    if ($176) {
      __label__ = 45;
      break;
    } else {
      __label__ = 44;
      break;
    }
   case 44:
    var $178 = $R_1 + 16 | 0;
    HEAP32[$178 >> 2] = $171;
    var $179 = $171 + 24 | 0;
    HEAP32[$179 >> 2] = $R_1;
    __label__ = 46;
    break;
   case 45:
    _abort();
   case 46:
    var $_sum33 = $_sum3132 + 4 | 0;
    var $182 = $oldbase + $_sum33 | 0;
    var $183 = $182;
    var $184 = HEAP32[$183 >> 2];
    var $185 = ($184 | 0) == 0;
    if ($185) {
      __label__ = 51;
      break;
    } else {
      __label__ = 47;
      break;
    }
   case 47:
    var $187 = $184;
    var $188 = HEAP32[__gm_ + 16 >> 2];
    var $189 = $187 >>> 0 < $188 >>> 0;
    if ($189) {
      __label__ = 49;
      break;
    } else {
      __label__ = 48;
      break;
    }
   case 48:
    var $191 = $R_1 + 20 | 0;
    HEAP32[$191 >> 2] = $184;
    var $192 = $184 + 24 | 0;
    HEAP32[$192 >> 2] = $R_1;
    __label__ = 51;
    break;
   case 49:
    _abort();
   case 50:
    _abort();
   case 51:
    var $_sum9 = $57 | $19;
    var $196 = $oldbase + $_sum9 | 0;
    var $197 = $196;
    var $198 = $57 + $27 | 0;
    var $oldfirst_0 = $197;
    var $qsize_0 = $198;
    __label__ = 52;
    break;
   case 52:
    var $qsize_0;
    var $oldfirst_0;
    var $200 = $oldfirst_0 + 4 | 0;
    var $201 = HEAP32[$200 >> 2];
    var $202 = $201 & -2;
    HEAP32[$200 >> 2] = $202;
    var $203 = $qsize_0 | 1;
    var $_sum10 = $_sum + 4 | 0;
    var $204 = $newbase + $_sum10 | 0;
    var $205 = $204;
    HEAP32[$205 >> 2] = $203;
    var $_sum11 = $qsize_0 + $_sum | 0;
    var $206 = $newbase + $_sum11 | 0;
    var $207 = $206;
    HEAP32[$207 >> 2] = $qsize_0;
    var $208 = $qsize_0 >>> 0 < 256;
    if ($208) {
      __label__ = 53;
      break;
    } else {
      __label__ = 58;
      break;
    }
   case 53:
    var $210 = $qsize_0 >>> 3;
    var $211 = $qsize_0 >>> 2;
    var $212 = $211 & 1073741822;
    var $213 = __gm_ + 40 + ($212 << 2) | 0;
    var $214 = $213;
    var $215 = HEAP32[__gm_ >> 2];
    var $216 = 1 << $210;
    var $217 = $215 & $216;
    var $218 = ($217 | 0) == 0;
    if ($218) {
      __label__ = 54;
      break;
    } else {
      __label__ = 55;
      break;
    }
   case 54:
    var $220 = $215 | $216;
    HEAP32[__gm_ >> 2] = $220;
    var $_sum26_pre = $212 + 2 | 0;
    var $_pre = __gm_ + 40 + ($_sum26_pre << 2) | 0;
    var $F4_0 = $214;
    var $_pre_phi = $_pre;
    __label__ = 57;
    break;
   case 55:
    var $_sum29 = $212 + 2 | 0;
    var $222 = __gm_ + 40 + ($_sum29 << 2) | 0;
    var $223 = HEAP32[$222 >> 2];
    var $224 = $223;
    var $225 = HEAP32[__gm_ + 16 >> 2];
    var $226 = $224 >>> 0 < $225 >>> 0;
    if ($226) {
      __label__ = 56;
      break;
    } else {
      var $F4_0 = $223;
      var $_pre_phi = $222;
      __label__ = 57;
      break;
    }
   case 56:
    _abort();
   case 57:
    var $_pre_phi;
    var $F4_0;
    HEAP32[$_pre_phi >> 2] = $26;
    var $229 = $F4_0 + 12 | 0;
    HEAP32[$229 >> 2] = $26;
    var $_sum27 = $_sum + 8 | 0;
    var $230 = $newbase + $_sum27 | 0;
    var $231 = $230;
    HEAP32[$231 >> 2] = $F4_0;
    var $_sum28 = $_sum + 12 | 0;
    var $232 = $newbase + $_sum28 | 0;
    var $233 = $232;
    HEAP32[$233 >> 2] = $214;
    __label__ = 76;
    break;
   case 58:
    var $235 = $25;
    var $236 = $qsize_0 >>> 8;
    var $237 = ($236 | 0) == 0;
    if ($237) {
      var $I7_0 = 0;
      __label__ = 61;
      break;
    } else {
      __label__ = 59;
      break;
    }
   case 59:
    var $239 = $qsize_0 >>> 0 > 16777215;
    if ($239) {
      var $I7_0 = 31;
      __label__ = 61;
      break;
    } else {
      __label__ = 60;
      break;
    }
   case 60:
    var $241 = $236 + 1048320 | 0;
    var $242 = $241 >>> 16;
    var $243 = $242 & 8;
    var $244 = $236 << $243;
    var $245 = $244 + 520192 | 0;
    var $246 = $245 >>> 16;
    var $247 = $246 & 4;
    var $248 = $244 << $247;
    var $249 = $248 + 245760 | 0;
    var $250 = $249 >>> 16;
    var $251 = $250 & 2;
    var $252 = $247 | $243;
    var $253 = $252 | $251;
    var $254 = 14 - $253 | 0;
    var $255 = $248 << $251;
    var $256 = $255 >>> 15;
    var $257 = $254 + $256 | 0;
    var $258 = $257 << 1;
    var $259 = $257 + 7 | 0;
    var $260 = $qsize_0 >>> ($259 >>> 0);
    var $261 = $260 & 1;
    var $262 = $261 | $258;
    var $I7_0 = $262;
    __label__ = 61;
    break;
   case 61:
    var $I7_0;
    var $264 = __gm_ + 304 + ($I7_0 << 2) | 0;
    var $_sum12 = $_sum + 28 | 0;
    var $265 = $newbase + $_sum12 | 0;
    var $266 = $265;
    HEAP32[$266 >> 2] = $I7_0;
    var $_sum13 = $_sum + 16 | 0;
    var $267 = $newbase + $_sum13 | 0;
    var $_sum14 = $_sum + 20 | 0;
    var $268 = $newbase + $_sum14 | 0;
    var $269 = $268;
    HEAP32[$269 >> 2] = 0;
    var $270 = $267;
    HEAP32[$270 >> 2] = 0;
    var $271 = HEAP32[__gm_ + 4 >> 2];
    var $272 = 1 << $I7_0;
    var $273 = $271 & $272;
    var $274 = ($273 | 0) == 0;
    if ($274) {
      __label__ = 62;
      break;
    } else {
      __label__ = 63;
      break;
    }
   case 62:
    var $276 = $271 | $272;
    HEAP32[__gm_ + 4 >> 2] = $276;
    HEAP32[$264 >> 2] = $235;
    var $277 = $264;
    var $_sum15 = $_sum + 24 | 0;
    var $278 = $newbase + $_sum15 | 0;
    var $279 = $278;
    HEAP32[$279 >> 2] = $277;
    var $_sum16 = $_sum + 12 | 0;
    var $280 = $newbase + $_sum16 | 0;
    var $281 = $280;
    HEAP32[$281 >> 2] = $235;
    var $_sum17 = $_sum + 8 | 0;
    var $282 = $newbase + $_sum17 | 0;
    var $283 = $282;
    HEAP32[$283 >> 2] = $235;
    __label__ = 76;
    break;
   case 63:
    var $285 = HEAP32[$264 >> 2];
    var $286 = ($I7_0 | 0) == 31;
    if ($286) {
      var $291 = 0;
      __label__ = 65;
      break;
    } else {
      __label__ = 64;
      break;
    }
   case 64:
    var $288 = $I7_0 >>> 1;
    var $289 = 25 - $288 | 0;
    var $291 = $289;
    __label__ = 65;
    break;
   case 65:
    var $291;
    var $292 = $qsize_0 << $291;
    var $K8_0 = $292;
    var $T_0 = $285;
    __label__ = 66;
    break;
   case 66:
    var $T_0;
    var $K8_0;
    var $294 = $T_0 + 4 | 0;
    var $295 = HEAP32[$294 >> 2];
    var $296 = $295 & -8;
    var $297 = ($296 | 0) == ($qsize_0 | 0);
    if ($297) {
      __label__ = 72;
      break;
    } else {
      __label__ = 67;
      break;
    }
   case 67:
    var $299 = $K8_0 >>> 31;
    var $300 = $T_0 + 16 + ($299 << 2) | 0;
    var $301 = HEAP32[$300 >> 2];
    var $302 = ($301 | 0) == 0;
    if ($302) {
      __label__ = 69;
      break;
    } else {
      __label__ = 68;
      break;
    }
   case 68:
    var $304 = $K8_0 << 1;
    var $K8_0 = $304;
    var $T_0 = $301;
    __label__ = 66;
    break;
   case 69:
    var $306 = $300;
    var $307 = HEAP32[__gm_ + 16 >> 2];
    var $308 = $306 >>> 0 < $307 >>> 0;
    if ($308) {
      __label__ = 71;
      break;
    } else {
      __label__ = 70;
      break;
    }
   case 70:
    HEAP32[$300 >> 2] = $235;
    var $_sum23 = $_sum + 24 | 0;
    var $310 = $newbase + $_sum23 | 0;
    var $311 = $310;
    HEAP32[$311 >> 2] = $T_0;
    var $_sum24 = $_sum + 12 | 0;
    var $312 = $newbase + $_sum24 | 0;
    var $313 = $312;
    HEAP32[$313 >> 2] = $235;
    var $_sum25 = $_sum + 8 | 0;
    var $314 = $newbase + $_sum25 | 0;
    var $315 = $314;
    HEAP32[$315 >> 2] = $235;
    __label__ = 76;
    break;
   case 71:
    _abort();
   case 72:
    var $318 = $T_0 + 8 | 0;
    var $319 = HEAP32[$318 >> 2];
    var $320 = $T_0;
    var $321 = HEAP32[__gm_ + 16 >> 2];
    var $322 = $320 >>> 0 < $321 >>> 0;
    if ($322) {
      __label__ = 75;
      break;
    } else {
      __label__ = 73;
      break;
    }
   case 73:
    var $324 = $319;
    var $325 = $324 >>> 0 < $321 >>> 0;
    if ($325) {
      __label__ = 75;
      break;
    } else {
      __label__ = 74;
      break;
    }
   case 74:
    var $327 = $319 + 12 | 0;
    HEAP32[$327 >> 2] = $235;
    HEAP32[$318 >> 2] = $235;
    var $_sum20 = $_sum + 8 | 0;
    var $328 = $newbase + $_sum20 | 0;
    var $329 = $328;
    HEAP32[$329 >> 2] = $319;
    var $_sum21 = $_sum + 12 | 0;
    var $330 = $newbase + $_sum21 | 0;
    var $331 = $330;
    HEAP32[$331 >> 2] = $T_0;
    var $_sum22 = $_sum + 24 | 0;
    var $332 = $newbase + $_sum22 | 0;
    var $333 = $332;
    HEAP32[$333 >> 2] = 0;
    __label__ = 76;
    break;
   case 75:
    _abort();
   case 76:
    var $_sum1819 = $9 | 8;
    var $335 = $newbase + $_sum1819 | 0;
    return $335;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_prepend_alloc["X"] = 1;
function _add_segment($tbase, $tsize) {
  var __label__;
  __label__ = 2;
  while (1) switch (__label__) {
   case 2:
    var $1 = HEAP32[__gm_ + 24 >> 2];
    var $2 = $1;
    var $3 = _segment_holding($2);
    var $4 = $3 | 0;
    var $5 = HEAP32[$4 >> 2];
    var $6 = $3 + 4 | 0;
    var $7 = HEAP32[$6 >> 2];
    var $8 = $5 + $7 | 0;
    var $_sum1 = $7 - 39 | 0;
    var $9 = $5 + $_sum1 | 0;
    var $10 = $9;
    var $11 = $10 & 7;
    var $12 = ($11 | 0) == 0;
    if ($12) {
      var $17 = 0;
      __label__ = 4;
      break;
    } else {
      __label__ = 3;
      break;
    }
   case 3:
    var $14 = -$10 | 0;
    var $15 = $14 & 7;
    var $17 = $15;
    __label__ = 4;
    break;
   case 4:
    var $17;
    var $_sum = $7 - 47 | 0;
    var $_sum2 = $_sum + $17 | 0;
    var $18 = $5 + $_sum2 | 0;
    var $19 = $1 + 16 | 0;
    var $20 = $19;
    var $21 = $18 >>> 0 < $20 >>> 0;
    var $22 = $21 ? $2 : $18;
    var $23 = $22 + 8 | 0;
    var $24 = $23;
    var $25 = $tbase;
    var $26 = $tsize - 40 | 0;
    _init_top($25, $26);
    var $27 = $22 + 4 | 0;
    var $28 = $27;
    HEAP32[$28 >> 2] = 27;
    HEAP32[$23 >> 2] = HEAP32[__gm_ + 444 >> 2];
    HEAP32[$23 + 4 >> 2] = HEAP32[__gm_ + 448 >> 2];
    HEAP32[$23 + 8 >> 2] = HEAP32[__gm_ + 452 >> 2];
    HEAP32[$23 + 12 >> 2] = HEAP32[__gm_ + 456 >> 2];
    HEAP32[__gm_ + 444 >> 2] = $tbase;
    HEAP32[__gm_ + 448 >> 2] = $tsize;
    HEAP32[__gm_ + 456 >> 2] = 0;
    HEAP32[__gm_ + 452 >> 2] = $24;
    var $29 = $22 + 28 | 0;
    var $30 = $29;
    HEAP32[$30 >> 2] = 7;
    var $31 = $22 + 32 | 0;
    var $32 = $31 >>> 0 < $8 >>> 0;
    if ($32) {
      var $33 = $30;
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 5:
    var $33;
    var $34 = $33 + 4 | 0;
    HEAP32[$34 >> 2] = 7;
    var $35 = $33 + 8 | 0;
    var $36 = $35;
    var $37 = $36 >>> 0 < $8 >>> 0;
    if ($37) {
      var $33 = $34;
      __label__ = 5;
      break;
    } else {
      __label__ = 6;
      break;
    }
   case 6:
    var $38 = ($22 | 0) == ($2 | 0);
    if ($38) {
      __label__ = 31;
      break;
    } else {
      __label__ = 7;
      break;
    }
   case 7:
    var $40 = $22;
    var $41 = $1;
    var $42 = $40 - $41 | 0;
    var $43 = $2 + $42 | 0;
    var $_sum3 = $42 + 4 | 0;
    var $44 = $2 + $_sum3 | 0;
    var $45 = $44;
    var $46 = HEAP32[$45 >> 2];
    var $47 = $46 & -2;
    HEAP32[$45 >> 2] = $47;
    var $48 = $42 | 1;
    var $49 = $1 + 4 | 0;
    HEAP32[$49 >> 2] = $48;
    var $50 = $43;
    HEAP32[$50 >> 2] = $42;
    var $51 = $42 >>> 0 < 256;
    if ($51) {
      __label__ = 8;
      break;
    } else {
      __label__ = 13;
      break;
    }
   case 8:
    var $53 = $42 >>> 3;
    var $54 = $42 >>> 2;
    var $55 = $54 & 1073741822;
    var $56 = __gm_ + 40 + ($55 << 2) | 0;
    var $57 = $56;
    var $58 = HEAP32[__gm_ >> 2];
    var $59 = 1 << $53;
    var $60 = $58 & $59;
    var $61 = ($60 | 0) == 0;
    if ($61) {
      __label__ = 9;
      break;
    } else {
      __label__ = 10;
      break;
    }
   case 9:
    var $63 = $58 | $59;
    HEAP32[__gm_ >> 2] = $63;
    var $_sum10_pre = $55 + 2 | 0;
    var $_pre = __gm_ + 40 + ($_sum10_pre << 2) | 0;
    var $F_0 = $57;
    var $_pre_phi = $_pre;
    __label__ = 12;
    break;
   case 10:
    var $_sum11 = $55 + 2 | 0;
    var $65 = __gm_ + 40 + ($_sum11 << 2) | 0;
    var $66 = HEAP32[$65 >> 2];
    var $67 = $66;
    var $68 = HEAP32[__gm_ + 16 >> 2];
    var $69 = $67 >>> 0 < $68 >>> 0;
    if ($69) {
      __label__ = 11;
      break;
    } else {
      var $F_0 = $66;
      var $_pre_phi = $65;
      __label__ = 12;
      break;
    }
   case 11:
    _abort();
   case 12:
    var $_pre_phi;
    var $F_0;
    HEAP32[$_pre_phi >> 2] = $1;
    var $72 = $F_0 + 12 | 0;
    HEAP32[$72 >> 2] = $1;
    var $73 = $1 + 8 | 0;
    HEAP32[$73 >> 2] = $F_0;
    var $74 = $1 + 12 | 0;
    HEAP32[$74 >> 2] = $57;
    __label__ = 31;
    break;
   case 13:
    var $76 = $1;
    var $77 = $42 >>> 8;
    var $78 = ($77 | 0) == 0;
    if ($78) {
      var $I1_0 = 0;
      __label__ = 16;
      break;
    } else {
      __label__ = 14;
      break;
    }
   case 14:
    var $80 = $42 >>> 0 > 16777215;
    if ($80) {
      var $I1_0 = 31;
      __label__ = 16;
      break;
    } else {
      __label__ = 15;
      break;
    }
   case 15:
    var $82 = $77 + 1048320 | 0;
    var $83 = $82 >>> 16;
    var $84 = $83 & 8;
    var $85 = $77 << $84;
    var $86 = $85 + 520192 | 0;
    var $87 = $86 >>> 16;
    var $88 = $87 & 4;
    var $89 = $85 << $88;
    var $90 = $89 + 245760 | 0;
    var $91 = $90 >>> 16;
    var $92 = $91 & 2;
    var $93 = $88 | $84;
    var $94 = $93 | $92;
    var $95 = 14 - $94 | 0;
    var $96 = $89 << $92;
    var $97 = $96 >>> 15;
    var $98 = $95 + $97 | 0;
    var $99 = $98 << 1;
    var $100 = $98 + 7 | 0;
    var $101 = $42 >>> ($100 >>> 0);
    var $102 = $101 & 1;
    var $103 = $102 | $99;
    var $I1_0 = $103;
    __label__ = 16;
    break;
   case 16:
    var $I1_0;
    var $105 = __gm_ + 304 + ($I1_0 << 2) | 0;
    var $106 = $1 + 28 | 0;
    var $I1_0_c = $I1_0;
    HEAP32[$106 >> 2] = $I1_0_c;
    var $107 = $1 + 20 | 0;
    HEAP32[$107 >> 2] = 0;
    var $108 = $1 + 16 | 0;
    HEAP32[$108 >> 2] = 0;
    var $109 = HEAP32[__gm_ + 4 >> 2];
    var $110 = 1 << $I1_0;
    var $111 = $109 & $110;
    var $112 = ($111 | 0) == 0;
    if ($112) {
      __label__ = 17;
      break;
    } else {
      __label__ = 18;
      break;
    }
   case 17:
    var $114 = $109 | $110;
    HEAP32[__gm_ + 4 >> 2] = $114;
    HEAP32[$105 >> 2] = $76;
    var $115 = $1 + 24 | 0;
    var $_c = $105;
    HEAP32[$115 >> 2] = $_c;
    var $116 = $1 + 12 | 0;
    HEAP32[$116 >> 2] = $1;
    var $117 = $1 + 8 | 0;
    HEAP32[$117 >> 2] = $1;
    __label__ = 31;
    break;
   case 18:
    var $119 = HEAP32[$105 >> 2];
    var $120 = ($I1_0 | 0) == 31;
    if ($120) {
      var $125 = 0;
      __label__ = 20;
      break;
    } else {
      __label__ = 19;
      break;
    }
   case 19:
    var $122 = $I1_0 >>> 1;
    var $123 = 25 - $122 | 0;
    var $125 = $123;
    __label__ = 20;
    break;
   case 20:
    var $125;
    var $126 = $42 << $125;
    var $K2_0 = $126;
    var $T_0 = $119;
    __label__ = 21;
    break;
   case 21:
    var $T_0;
    var $K2_0;
    var $128 = $T_0 + 4 | 0;
    var $129 = HEAP32[$128 >> 2];
    var $130 = $129 & -8;
    var $131 = ($130 | 0) == ($42 | 0);
    if ($131) {
      __label__ = 27;
      break;
    } else {
      __label__ = 22;
      break;
    }
   case 22:
    var $133 = $K2_0 >>> 31;
    var $134 = $T_0 + 16 + ($133 << 2) | 0;
    var $135 = HEAP32[$134 >> 2];
    var $136 = ($135 | 0) == 0;
    if ($136) {
      __label__ = 24;
      break;
    } else {
      __label__ = 23;
      break;
    }
   case 23:
    var $138 = $K2_0 << 1;
    var $K2_0 = $138;
    var $T_0 = $135;
    __label__ = 21;
    break;
   case 24:
    var $140 = $134;
    var $141 = HEAP32[__gm_ + 16 >> 2];
    var $142 = $140 >>> 0 < $141 >>> 0;
    if ($142) {
      __label__ = 26;
      break;
    } else {
      __label__ = 25;
      break;
    }
   case 25:
    HEAP32[$134 >> 2] = $76;
    var $144 = $1 + 24 | 0;
    var $T_0_c7 = $T_0;
    HEAP32[$144 >> 2] = $T_0_c7;
    var $145 = $1 + 12 | 0;
    HEAP32[$145 >> 2] = $1;
    var $146 = $1 + 8 | 0;
    HEAP32[$146 >> 2] = $1;
    __label__ = 31;
    break;
   case 26:
    _abort();
   case 27:
    var $149 = $T_0 + 8 | 0;
    var $150 = HEAP32[$149 >> 2];
    var $151 = $T_0;
    var $152 = HEAP32[__gm_ + 16 >> 2];
    var $153 = $151 >>> 0 < $152 >>> 0;
    if ($153) {
      __label__ = 30;
      break;
    } else {
      __label__ = 28;
      break;
    }
   case 28:
    var $155 = $150;
    var $156 = $155 >>> 0 < $152 >>> 0;
    if ($156) {
      __label__ = 30;
      break;
    } else {
      __label__ = 29;
      break;
    }
   case 29:
    var $158 = $150 + 12 | 0;
    HEAP32[$158 >> 2] = $76;
    HEAP32[$149 >> 2] = $76;
    var $159 = $1 + 8 | 0;
    var $_c6 = $150;
    HEAP32[$159 >> 2] = $_c6;
    var $160 = $1 + 12 | 0;
    var $T_0_c = $T_0;
    HEAP32[$160 >> 2] = $T_0_c;
    var $161 = $1 + 24 | 0;
    HEAP32[$161 >> 2] = 0;
    __label__ = 31;
    break;
   case 30:
    _abort();
   case 31:
    return;
   default:
    assert(0, "bad label: " + __label__);
  }
}
_add_segment["X"] = 1;
var i64Math = (function() {
  var goog = {
    math: {}
  };
  goog.math.Long = (function(low, high) {
    this.low_ = low | 0;
    this.high_ = high | 0;
  });
  goog.math.Long.IntCache_ = {};
  goog.math.Long.fromInt = (function(value) {
    if (-128 <= value && value < 128) {
      var cachedObj = goog.math.Long.IntCache_[value];
      if (cachedObj) {
        return cachedObj;
      }
    }
    var obj = new goog.math.Long(value | 0, value < 0 ? -1 : 0);
    if (-128 <= value && value < 128) {
      goog.math.Long.IntCache_[value] = obj;
    }
    return obj;
  });
  goog.math.Long.fromNumber = (function(value) {
    if (isNaN(value) || !isFinite(value)) {
      return goog.math.Long.ZERO;
    } else if (value <= -goog.math.Long.TWO_PWR_63_DBL_) {
      return goog.math.Long.MIN_VALUE;
    } else if (value + 1 >= goog.math.Long.TWO_PWR_63_DBL_) {
      return goog.math.Long.MAX_VALUE;
    } else if (value < 0) {
      return goog.math.Long.fromNumber(-value).negate();
    } else {
      return new goog.math.Long(value % goog.math.Long.TWO_PWR_32_DBL_ | 0, value / goog.math.Long.TWO_PWR_32_DBL_ | 0);
    }
  });
  goog.math.Long.fromBits = (function(lowBits, highBits) {
    return new goog.math.Long(lowBits, highBits);
  });
  goog.math.Long.fromString = (function(str, opt_radix) {
    if (str.length == 0) {
      throw Error("number format error: empty string");
    }
    var radix = opt_radix || 10;
    if (radix < 2 || 36 < radix) {
      throw Error("radix out of range: " + radix);
    }
    if (str.charAt(0) == "-") {
      return goog.math.Long.fromString(str.substring(1), radix).negate();
    } else if (str.indexOf("-") >= 0) {
      throw Error('number format error: interior "-" character: ' + str);
    }
    var radixToPower = goog.math.Long.fromNumber(Math.pow(radix, 8));
    var result = goog.math.Long.ZERO;
    for (var i = 0; i < str.length; i += 8) {
      var size = Math.min(8, str.length - i);
      var value = parseInt(str.substring(i, i + size), radix);
      if (size < 8) {
        var power = goog.math.Long.fromNumber(Math.pow(radix, size));
        result = result.multiply(power).add(goog.math.Long.fromNumber(value));
      } else {
        result = result.multiply(radixToPower);
        result = result.add(goog.math.Long.fromNumber(value));
      }
    }
    return result;
  });
  goog.math.Long.TWO_PWR_16_DBL_ = 1 << 16;
  goog.math.Long.TWO_PWR_24_DBL_ = 1 << 24;
  goog.math.Long.TWO_PWR_32_DBL_ = goog.math.Long.TWO_PWR_16_DBL_ * goog.math.Long.TWO_PWR_16_DBL_;
  goog.math.Long.TWO_PWR_31_DBL_ = goog.math.Long.TWO_PWR_32_DBL_ / 2;
  goog.math.Long.TWO_PWR_48_DBL_ = goog.math.Long.TWO_PWR_32_DBL_ * goog.math.Long.TWO_PWR_16_DBL_;
  goog.math.Long.TWO_PWR_64_DBL_ = goog.math.Long.TWO_PWR_32_DBL_ * goog.math.Long.TWO_PWR_32_DBL_;
  goog.math.Long.TWO_PWR_63_DBL_ = goog.math.Long.TWO_PWR_64_DBL_ / 2;
  goog.math.Long.ZERO = goog.math.Long.fromInt(0);
  goog.math.Long.ONE = goog.math.Long.fromInt(1);
  goog.math.Long.NEG_ONE = goog.math.Long.fromInt(-1);
  goog.math.Long.MAX_VALUE = goog.math.Long.fromBits(4294967295 | 0, 2147483647 | 0);
  goog.math.Long.MIN_VALUE = goog.math.Long.fromBits(0, 2147483648 | 0);
  goog.math.Long.TWO_PWR_24_ = goog.math.Long.fromInt(1 << 24);
  goog.math.Long.prototype.toInt = (function() {
    return this.low_;
  });
  goog.math.Long.prototype.toNumber = (function() {
    return this.high_ * goog.math.Long.TWO_PWR_32_DBL_ + this.getLowBitsUnsigned();
  });
  goog.math.Long.prototype.toString = (function(opt_radix) {
    var radix = opt_radix || 10;
    if (radix < 2 || 36 < radix) {
      throw Error("radix out of range: " + radix);
    }
    if (this.isZero()) {
      return "0";
    }
    if (this.isNegative()) {
      if (this.equals(goog.math.Long.MIN_VALUE)) {
        var radixLong = goog.math.Long.fromNumber(radix);
        var div = this.div(radixLong);
        var rem = div.multiply(radixLong).subtract(this);
        return div.toString(radix) + rem.toInt().toString(radix);
      } else {
        return "-" + this.negate().toString(radix);
      }
    }
    var radixToPower = goog.math.Long.fromNumber(Math.pow(radix, 6));
    var rem = this;
    var result = "";
    while (true) {
      var remDiv = rem.div(radixToPower);
      var intval = rem.subtract(remDiv.multiply(radixToPower)).toInt();
      var digits = intval.toString(radix);
      rem = remDiv;
      if (rem.isZero()) {
        return digits + result;
      } else {
        while (digits.length < 6) {
          digits = "0" + digits;
        }
        result = "" + digits + result;
      }
    }
  });
  goog.math.Long.prototype.getHighBits = (function() {
    return this.high_;
  });
  goog.math.Long.prototype.getLowBits = (function() {
    return this.low_;
  });
  goog.math.Long.prototype.getLowBitsUnsigned = (function() {
    return this.low_ >= 0 ? this.low_ : goog.math.Long.TWO_PWR_32_DBL_ + this.low_;
  });
  goog.math.Long.prototype.getNumBitsAbs = (function() {
    if (this.isNegative()) {
      if (this.equals(goog.math.Long.MIN_VALUE)) {
        return 64;
      } else {
        return this.negate().getNumBitsAbs();
      }
    } else {
      var val = this.high_ != 0 ? this.high_ : this.low_;
      for (var bit = 31; bit > 0; bit--) {
        if ((val & 1 << bit) != 0) {
          break;
        }
      }
      return this.high_ != 0 ? bit + 33 : bit + 1;
    }
  });
  goog.math.Long.prototype.isZero = (function() {
    return this.high_ == 0 && this.low_ == 0;
  });
  goog.math.Long.prototype.isNegative = (function() {
    return this.high_ < 0;
  });
  goog.math.Long.prototype.isOdd = (function() {
    return (this.low_ & 1) == 1;
  });
  goog.math.Long.prototype.equals = (function(other) {
    return this.high_ == other.high_ && this.low_ == other.low_;
  });
  goog.math.Long.prototype.notEquals = (function(other) {
    return this.high_ != other.high_ || this.low_ != other.low_;
  });
  goog.math.Long.prototype.lessThan = (function(other) {
    return this.compare(other) < 0;
  });
  goog.math.Long.prototype.lessThanOrEqual = (function(other) {
    return this.compare(other) <= 0;
  });
  goog.math.Long.prototype.greaterThan = (function(other) {
    return this.compare(other) > 0;
  });
  goog.math.Long.prototype.greaterThanOrEqual = (function(other) {
    return this.compare(other) >= 0;
  });
  goog.math.Long.prototype.compare = (function(other) {
    if (this.equals(other)) {
      return 0;
    }
    var thisNeg = this.isNegative();
    var otherNeg = other.isNegative();
    if (thisNeg && !otherNeg) {
      return -1;
    }
    if (!thisNeg && otherNeg) {
      return 1;
    }
    if (this.subtract(other).isNegative()) {
      return -1;
    } else {
      return 1;
    }
  });
  goog.math.Long.prototype.negate = (function() {
    if (this.equals(goog.math.Long.MIN_VALUE)) {
      return goog.math.Long.MIN_VALUE;
    } else {
      return this.not().add(goog.math.Long.ONE);
    }
  });
  goog.math.Long.prototype.add = (function(other) {
    var a48 = this.high_ >>> 16;
    var a32 = this.high_ & 65535;
    var a16 = this.low_ >>> 16;
    var a00 = this.low_ & 65535;
    var b48 = other.high_ >>> 16;
    var b32 = other.high_ & 65535;
    var b16 = other.low_ >>> 16;
    var b00 = other.low_ & 65535;
    var c48 = 0, c32 = 0, c16 = 0, c00 = 0;
    c00 += a00 + b00;
    c16 += c00 >>> 16;
    c00 &= 65535;
    c16 += a16 + b16;
    c32 += c16 >>> 16;
    c16 &= 65535;
    c32 += a32 + b32;
    c48 += c32 >>> 16;
    c32 &= 65535;
    c48 += a48 + b48;
    c48 &= 65535;
    return goog.math.Long.fromBits(c16 << 16 | c00, c48 << 16 | c32);
  });
  goog.math.Long.prototype.subtract = (function(other) {
    return this.add(other.negate());
  });
  goog.math.Long.prototype.multiply = (function(other) {
    if (this.isZero()) {
      return goog.math.Long.ZERO;
    } else if (other.isZero()) {
      return goog.math.Long.ZERO;
    }
    if (this.equals(goog.math.Long.MIN_VALUE)) {
      return other.isOdd() ? goog.math.Long.MIN_VALUE : goog.math.Long.ZERO;
    } else if (other.equals(goog.math.Long.MIN_VALUE)) {
      return this.isOdd() ? goog.math.Long.MIN_VALUE : goog.math.Long.ZERO;
    }
    if (this.isNegative()) {
      if (other.isNegative()) {
        return this.negate().multiply(other.negate());
      } else {
        return this.negate().multiply(other).negate();
      }
    } else if (other.isNegative()) {
      return this.multiply(other.negate()).negate();
    }
    if (this.lessThan(goog.math.Long.TWO_PWR_24_) && other.lessThan(goog.math.Long.TWO_PWR_24_)) {
      return goog.math.Long.fromNumber(this.toNumber() * other.toNumber());
    }
    var a48 = this.high_ >>> 16;
    var a32 = this.high_ & 65535;
    var a16 = this.low_ >>> 16;
    var a00 = this.low_ & 65535;
    var b48 = other.high_ >>> 16;
    var b32 = other.high_ & 65535;
    var b16 = other.low_ >>> 16;
    var b00 = other.low_ & 65535;
    var c48 = 0, c32 = 0, c16 = 0, c00 = 0;
    c00 += a00 * b00;
    c16 += c00 >>> 16;
    c00 &= 65535;
    c16 += a16 * b00;
    c32 += c16 >>> 16;
    c16 &= 65535;
    c16 += a00 * b16;
    c32 += c16 >>> 16;
    c16 &= 65535;
    c32 += a32 * b00;
    c48 += c32 >>> 16;
    c32 &= 65535;
    c32 += a16 * b16;
    c48 += c32 >>> 16;
    c32 &= 65535;
    c32 += a00 * b32;
    c48 += c32 >>> 16;
    c32 &= 65535;
    c48 += a48 * b00 + a32 * b16 + a16 * b32 + a00 * b48;
    c48 &= 65535;
    return goog.math.Long.fromBits(c16 << 16 | c00, c48 << 16 | c32);
  });
  goog.math.Long.prototype.div = (function(other) {
    if (other.isZero()) {
      throw Error("division by zero");
    } else if (this.isZero()) {
      return goog.math.Long.ZERO;
    }
    if (this.equals(goog.math.Long.MIN_VALUE)) {
      if (other.equals(goog.math.Long.ONE) || other.equals(goog.math.Long.NEG_ONE)) {
        return goog.math.Long.MIN_VALUE;
      } else if (other.equals(goog.math.Long.MIN_VALUE)) {
        return goog.math.Long.ONE;
      } else {
        var halfThis = this.shiftRight(1);
        var approx = halfThis.div(other).shiftLeft(1);
        if (approx.equals(goog.math.Long.ZERO)) {
          return other.isNegative() ? goog.math.Long.ONE : goog.math.Long.NEG_ONE;
        } else {
          var rem = this.subtract(other.multiply(approx));
          var result = approx.add(rem.div(other));
          return result;
        }
      }
    } else if (other.equals(goog.math.Long.MIN_VALUE)) {
      return goog.math.Long.ZERO;
    }
    if (this.isNegative()) {
      if (other.isNegative()) {
        return this.negate().div(other.negate());
      } else {
        return this.negate().div(other).negate();
      }
    } else if (other.isNegative()) {
      return this.div(other.negate()).negate();
    }
    var res = goog.math.Long.ZERO;
    var rem = this;
    while (rem.greaterThanOrEqual(other)) {
      var approx = Math.max(1, Math.floor(rem.toNumber() / other.toNumber()));
      var log2 = Math.ceil(Math.log(approx) / Math.LN2);
      var delta = log2 <= 48 ? 1 : Math.pow(2, log2 - 48);
      var approxRes = goog.math.Long.fromNumber(approx);
      var approxRem = approxRes.multiply(other);
      while (approxRem.isNegative() || approxRem.greaterThan(rem)) {
        approx -= delta;
        approxRes = goog.math.Long.fromNumber(approx);
        approxRem = approxRes.multiply(other);
      }
      if (approxRes.isZero()) {
        approxRes = goog.math.Long.ONE;
      }
      res = res.add(approxRes);
      rem = rem.subtract(approxRem);
    }
    return res;
  });
  goog.math.Long.prototype.modulo = (function(other) {
    return this.subtract(this.div(other).multiply(other));
  });
  goog.math.Long.prototype.not = (function() {
    return goog.math.Long.fromBits(~this.low_, ~this.high_);
  });
  goog.math.Long.prototype.and = (function(other) {
    return goog.math.Long.fromBits(this.low_ & other.low_, this.high_ & other.high_);
  });
  goog.math.Long.prototype.or = (function(other) {
    return goog.math.Long.fromBits(this.low_ | other.low_, this.high_ | other.high_);
  });
  goog.math.Long.prototype.xor = (function(other) {
    return goog.math.Long.fromBits(this.low_ ^ other.low_, this.high_ ^ other.high_);
  });
  goog.math.Long.prototype.shiftLeft = (function(numBits) {
    numBits &= 63;
    if (numBits == 0) {
      return this;
    } else {
      var low = this.low_;
      if (numBits < 32) {
        var high = this.high_;
        return goog.math.Long.fromBits(low << numBits, high << numBits | low >>> 32 - numBits);
      } else {
        return goog.math.Long.fromBits(0, low << numBits - 32);
      }
    }
  });
  goog.math.Long.prototype.shiftRight = (function(numBits) {
    numBits &= 63;
    if (numBits == 0) {
      return this;
    } else {
      var high = this.high_;
      if (numBits < 32) {
        var low = this.low_;
        return goog.math.Long.fromBits(low >>> numBits | high << 32 - numBits, high >> numBits);
      } else {
        return goog.math.Long.fromBits(high >> numBits - 32, high >= 0 ? 0 : -1);
      }
    }
  });
  goog.math.Long.prototype.shiftRightUnsigned = (function(numBits) {
    numBits &= 63;
    if (numBits == 0) {
      return this;
    } else {
      var high = this.high_;
      if (numBits < 32) {
        var low = this.low_;
        return goog.math.Long.fromBits(low >>> numBits | high << 32 - numBits, high >>> numBits);
      } else if (numBits == 32) {
        return goog.math.Long.fromBits(high, 0);
      } else {
        return goog.math.Long.fromBits(high >>> numBits - 32, 0);
      }
    }
  });
  var navigator = {
    appName: "Modern Browser"
  };
  var dbits;
  var canary = 0xdeadbeefcafe;
  var j_lm = (canary & 16777215) == 15715070;
  function BigInteger(a, b, c) {
    if (a != null) if ("number" == typeof a) this.fromNumber(a, b, c); else if (b == null && "string" != typeof a) this.fromString(a, 256); else this.fromString(a, b);
  }
  function nbi() {
    return new BigInteger(null);
  }
  function am1(i, x, w, j, c, n) {
    while (--n >= 0) {
      var v = x * this[i++] + w[j] + c;
      c = Math.floor(v / 67108864);
      w[j++] = v & 67108863;
    }
    return c;
  }
  function am2(i, x, w, j, c, n) {
    var xl = x & 32767, xh = x >> 15;
    while (--n >= 0) {
      var l = this[i] & 32767;
      var h = this[i++] >> 15;
      var m = xh * l + h * xl;
      l = xl * l + ((m & 32767) << 15) + w[j] + (c & 1073741823);
      c = (l >>> 30) + (m >>> 15) + xh * h + (c >>> 30);
      w[j++] = l & 1073741823;
    }
    return c;
  }
  function am3(i, x, w, j, c, n) {
    var xl = x & 16383, xh = x >> 14;
    while (--n >= 0) {
      var l = this[i] & 16383;
      var h = this[i++] >> 14;
      var m = xh * l + h * xl;
      l = xl * l + ((m & 16383) << 14) + w[j] + c;
      c = (l >> 28) + (m >> 14) + xh * h;
      w[j++] = l & 268435455;
    }
    return c;
  }
  if (j_lm && navigator.appName == "Microsoft Internet Explorer") {
    BigInteger.prototype.am = am2;
    dbits = 30;
  } else if (j_lm && navigator.appName != "Netscape") {
    BigInteger.prototype.am = am1;
    dbits = 26;
  } else {
    BigInteger.prototype.am = am3;
    dbits = 28;
  }
  BigInteger.prototype.DB = dbits;
  BigInteger.prototype.DM = (1 << dbits) - 1;
  BigInteger.prototype.DV = 1 << dbits;
  var BI_FP = 52;
  BigInteger.prototype.FV = Math.pow(2, BI_FP);
  BigInteger.prototype.F1 = BI_FP - dbits;
  BigInteger.prototype.F2 = 2 * dbits - BI_FP;
  var BI_RM = "0123456789abcdefghijklmnopqrstuvwxyz";
  var BI_RC = new Array;
  var rr, vv;
  rr = "0".charCodeAt(0);
  for (vv = 0; vv <= 9; ++vv) BI_RC[rr++] = vv;
  rr = "a".charCodeAt(0);
  for (vv = 10; vv < 36; ++vv) BI_RC[rr++] = vv;
  rr = "A".charCodeAt(0);
  for (vv = 10; vv < 36; ++vv) BI_RC[rr++] = vv;
  function int2char(n) {
    return BI_RM.charAt(n);
  }
  function intAt(s, i) {
    var c = BI_RC[s.charCodeAt(i)];
    return c == null ? -1 : c;
  }
  function bnpCopyTo(r) {
    for (var i = this.t - 1; i >= 0; --i) r[i] = this[i];
    r.t = this.t;
    r.s = this.s;
  }
  function bnpFromInt(x) {
    this.t = 1;
    this.s = x < 0 ? -1 : 0;
    if (x > 0) this[0] = x; else if (x < -1) this[0] = x + DV; else this.t = 0;
  }
  function nbv(i) {
    var r = nbi();
    r.fromInt(i);
    return r;
  }
  function bnpFromString(s, b) {
    var k;
    if (b == 16) k = 4; else if (b == 8) k = 3; else if (b == 256) k = 8; else if (b == 2) k = 1; else if (b == 32) k = 5; else if (b == 4) k = 2; else {
      this.fromRadix(s, b);
      return;
    }
    this.t = 0;
    this.s = 0;
    var i = s.length, mi = false, sh = 0;
    while (--i >= 0) {
      var x = k == 8 ? s[i] & 255 : intAt(s, i);
      if (x < 0) {
        if (s.charAt(i) == "-") mi = true;
        continue;
      }
      mi = false;
      if (sh == 0) this[this.t++] = x; else if (sh + k > this.DB) {
        this[this.t - 1] |= (x & (1 << this.DB - sh) - 1) << sh;
        this[this.t++] = x >> this.DB - sh;
      } else this[this.t - 1] |= x << sh;
      sh += k;
      if (sh >= this.DB) sh -= this.DB;
    }
    if (k == 8 && (s[0] & 128) != 0) {
      this.s = -1;
      if (sh > 0) this[this.t - 1] |= (1 << this.DB - sh) - 1 << sh;
    }
    this.clamp();
    if (mi) BigInteger.ZERO.subTo(this, this);
  }
  function bnpClamp() {
    var c = this.s & this.DM;
    while (this.t > 0 && this[this.t - 1] == c) --this.t;
  }
  function bnToString(b) {
    if (this.s < 0) return "-" + this.negate().toString(b);
    var k;
    if (b == 16) k = 4; else if (b == 8) k = 3; else if (b == 2) k = 1; else if (b == 32) k = 5; else if (b == 4) k = 2; else return this.toRadix(b);
    var km = (1 << k) - 1, d, m = false, r = "", i = this.t;
    var p = this.DB - i * this.DB % k;
    if (i-- > 0) {
      if (p < this.DB && (d = this[i] >> p) > 0) {
        m = true;
        r = int2char(d);
      }
      while (i >= 0) {
        if (p < k) {
          d = (this[i] & (1 << p) - 1) << k - p;
          d |= this[--i] >> (p += this.DB - k);
        } else {
          d = this[i] >> (p -= k) & km;
          if (p <= 0) {
            p += this.DB;
            --i;
          }
        }
        if (d > 0) m = true;
        if (m) r += int2char(d);
      }
    }
    return m ? r : "0";
  }
  function bnNegate() {
    var r = nbi();
    BigInteger.ZERO.subTo(this, r);
    return r;
  }
  function bnAbs() {
    return this.s < 0 ? this.negate() : this;
  }
  function bnCompareTo(a) {
    var r = this.s - a.s;
    if (r != 0) return r;
    var i = this.t;
    r = i - a.t;
    if (r != 0) return r;
    while (--i >= 0) if ((r = this[i] - a[i]) != 0) return r;
    return 0;
  }
  function nbits(x) {
    var r = 1, t;
    if ((t = x >>> 16) != 0) {
      x = t;
      r += 16;
    }
    if ((t = x >> 8) != 0) {
      x = t;
      r += 8;
    }
    if ((t = x >> 4) != 0) {
      x = t;
      r += 4;
    }
    if ((t = x >> 2) != 0) {
      x = t;
      r += 2;
    }
    if ((t = x >> 1) != 0) {
      x = t;
      r += 1;
    }
    return r;
  }
  function bnBitLength() {
    if (this.t <= 0) return 0;
    return this.DB * (this.t - 1) + nbits(this[this.t - 1] ^ this.s & this.DM);
  }
  function bnpDLShiftTo(n, r) {
    var i;
    for (i = this.t - 1; i >= 0; --i) r[i + n] = this[i];
    for (i = n - 1; i >= 0; --i) r[i] = 0;
    r.t = this.t + n;
    r.s = this.s;
  }
  function bnpDRShiftTo(n, r) {
    for (var i = n; i < this.t; ++i) r[i - n] = this[i];
    r.t = Math.max(this.t - n, 0);
    r.s = this.s;
  }
  function bnpLShiftTo(n, r) {
    var bs = n % this.DB;
    var cbs = this.DB - bs;
    var bm = (1 << cbs) - 1;
    var ds = Math.floor(n / this.DB), c = this.s << bs & this.DM, i;
    for (i = this.t - 1; i >= 0; --i) {
      r[ds + (i + 1)] = this[i] >> cbs | c;
      c = (this[i] & bm) << bs;
    }
    for (i = ds - 1; i >= 0; --i) r[i] = 0;
    r[ds] = c;
    r.t = this.t + ds + 1;
    r.s = this.s;
    r.clamp();
  }
  function bnpRShiftTo(n, r) {
    r.s = this.s;
    var ds = Math.floor(n / this.DB);
    if (ds >= this.t) {
      r.t = 0;
      return;
    }
    var bs = n % this.DB;
    var cbs = this.DB - bs;
    var bm = (1 << bs) - 1;
    r[0] = this[ds] >> bs;
    for (var i = ds + 1; i < this.t; ++i) {
      r[i - ds - 1] |= (this[i] & bm) << cbs;
      r[i - ds] = this[i] >> bs;
    }
    if (bs > 0) r[this.t - ds - 1] |= (this.s & bm) << cbs;
    r.t = this.t - ds;
    r.clamp();
  }
  function bnpSubTo(a, r) {
    var i = 0, c = 0, m = Math.min(a.t, this.t);
    while (i < m) {
      c += this[i] - a[i];
      r[i++] = c & this.DM;
      c >>= this.DB;
    }
    if (a.t < this.t) {
      c -= a.s;
      while (i < this.t) {
        c += this[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
      }
      c += this.s;
    } else {
      c += this.s;
      while (i < a.t) {
        c -= a[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
      }
      c -= a.s;
    }
    r.s = c < 0 ? -1 : 0;
    if (c < -1) r[i++] = this.DV + c; else if (c > 0) r[i++] = c;
    r.t = i;
    r.clamp();
  }
  function bnpMultiplyTo(a, r) {
    var x = this.abs(), y = a.abs();
    var i = x.t;
    r.t = i + y.t;
    while (--i >= 0) r[i] = 0;
    for (i = 0; i < y.t; ++i) r[i + x.t] = x.am(0, y[i], r, i, 0, x.t);
    r.s = 0;
    r.clamp();
    if (this.s != a.s) BigInteger.ZERO.subTo(r, r);
  }
  function bnpSquareTo(r) {
    var x = this.abs();
    var i = r.t = 2 * x.t;
    while (--i >= 0) r[i] = 0;
    for (i = 0; i < x.t - 1; ++i) {
      var c = x.am(i, x[i], r, 2 * i, 0, 1);
      if ((r[i + x.t] += x.am(i + 1, 2 * x[i], r, 2 * i + 1, c, x.t - i - 1)) >= x.DV) {
        r[i + x.t] -= x.DV;
        r[i + x.t + 1] = 1;
      }
    }
    if (r.t > 0) r[r.t - 1] += x.am(i, x[i], r, 2 * i, 0, 1);
    r.s = 0;
    r.clamp();
  }
  function bnpDivRemTo(m, q, r) {
    var pm = m.abs();
    if (pm.t <= 0) return;
    var pt = this.abs();
    if (pt.t < pm.t) {
      if (q != null) q.fromInt(0);
      if (r != null) this.copyTo(r);
      return;
    }
    if (r == null) r = nbi();
    var y = nbi(), ts = this.s, ms = m.s;
    var nsh = this.DB - nbits(pm[pm.t - 1]);
    if (nsh > 0) {
      pm.lShiftTo(nsh, y);
      pt.lShiftTo(nsh, r);
    } else {
      pm.copyTo(y);
      pt.copyTo(r);
    }
    var ys = y.t;
    var y0 = y[ys - 1];
    if (y0 == 0) return;
    var yt = y0 * (1 << this.F1) + (ys > 1 ? y[ys - 2] >> this.F2 : 0);
    var d1 = this.FV / yt, d2 = (1 << this.F1) / yt, e = 1 << this.F2;
    var i = r.t, j = i - ys, t = q == null ? nbi() : q;
    y.dlShiftTo(j, t);
    if (r.compareTo(t) >= 0) {
      r[r.t++] = 1;
      r.subTo(t, r);
    }
    BigInteger.ONE.dlShiftTo(ys, t);
    t.subTo(y, y);
    while (y.t < ys) y[y.t++] = 0;
    while (--j >= 0) {
      var qd = r[--i] == y0 ? this.DM : Math.floor(r[i] * d1 + (r[i - 1] + e) * d2);
      if ((r[i] += y.am(0, qd, r, j, 0, ys)) < qd) {
        y.dlShiftTo(j, t);
        r.subTo(t, r);
        while (r[i] < --qd) r.subTo(t, r);
      }
    }
    if (q != null) {
      r.drShiftTo(ys, q);
      if (ts != ms) BigInteger.ZERO.subTo(q, q);
    }
    r.t = ys;
    r.clamp();
    if (nsh > 0) r.rShiftTo(nsh, r);
    if (ts < 0) BigInteger.ZERO.subTo(r, r);
  }
  function bnMod(a) {
    var r = nbi();
    this.abs().divRemTo(a, null, r);
    if (this.s < 0 && r.compareTo(BigInteger.ZERO) > 0) a.subTo(r, r);
    return r;
  }
  function Classic(m) {
    this.m = m;
  }
  function cConvert(x) {
    if (x.s < 0 || x.compareTo(this.m) >= 0) return x.mod(this.m); else return x;
  }
  function cRevert(x) {
    return x;
  }
  function cReduce(x) {
    x.divRemTo(this.m, null, x);
  }
  function cMulTo(x, y, r) {
    x.multiplyTo(y, r);
    this.reduce(r);
  }
  function cSqrTo(x, r) {
    x.squareTo(r);
    this.reduce(r);
  }
  Classic.prototype.convert = cConvert;
  Classic.prototype.revert = cRevert;
  Classic.prototype.reduce = cReduce;
  Classic.prototype.mulTo = cMulTo;
  Classic.prototype.sqrTo = cSqrTo;
  function bnpInvDigit() {
    if (this.t < 1) return 0;
    var x = this[0];
    if ((x & 1) == 0) return 0;
    var y = x & 3;
    y = y * (2 - (x & 15) * y) & 15;
    y = y * (2 - (x & 255) * y) & 255;
    y = y * (2 - ((x & 65535) * y & 65535)) & 65535;
    y = y * (2 - x * y % this.DV) % this.DV;
    return y > 0 ? this.DV - y : -y;
  }
  function Montgomery(m) {
    this.m = m;
    this.mp = m.invDigit();
    this.mpl = this.mp & 32767;
    this.mph = this.mp >> 15;
    this.um = (1 << m.DB - 15) - 1;
    this.mt2 = 2 * m.t;
  }
  function montConvert(x) {
    var r = nbi();
    x.abs().dlShiftTo(this.m.t, r);
    r.divRemTo(this.m, null, r);
    if (x.s < 0 && r.compareTo(BigInteger.ZERO) > 0) this.m.subTo(r, r);
    return r;
  }
  function montRevert(x) {
    var r = nbi();
    x.copyTo(r);
    this.reduce(r);
    return r;
  }
  function montReduce(x) {
    while (x.t <= this.mt2) x[x.t++] = 0;
    for (var i = 0; i < this.m.t; ++i) {
      var j = x[i] & 32767;
      var u0 = j * this.mpl + ((j * this.mph + (x[i] >> 15) * this.mpl & this.um) << 15) & x.DM;
      j = i + this.m.t;
      x[j] += this.m.am(0, u0, x, i, 0, this.m.t);
      while (x[j] >= x.DV) {
        x[j] -= x.DV;
        x[++j]++;
      }
    }
    x.clamp();
    x.drShiftTo(this.m.t, x);
    if (x.compareTo(this.m) >= 0) x.subTo(this.m, x);
  }
  function montSqrTo(x, r) {
    x.squareTo(r);
    this.reduce(r);
  }
  function montMulTo(x, y, r) {
    x.multiplyTo(y, r);
    this.reduce(r);
  }
  Montgomery.prototype.convert = montConvert;
  Montgomery.prototype.revert = montRevert;
  Montgomery.prototype.reduce = montReduce;
  Montgomery.prototype.mulTo = montMulTo;
  Montgomery.prototype.sqrTo = montSqrTo;
  function bnpIsEven() {
    return (this.t > 0 ? this[0] & 1 : this.s) == 0;
  }
  function bnpExp(e, z) {
    if (e > 4294967295 || e < 1) return BigInteger.ONE;
    var r = nbi(), r2 = nbi(), g = z.convert(this), i = nbits(e) - 1;
    g.copyTo(r);
    while (--i >= 0) {
      z.sqrTo(r, r2);
      if ((e & 1 << i) > 0) z.mulTo(r2, g, r); else {
        var t = r;
        r = r2;
        r2 = t;
      }
    }
    return z.revert(r);
  }
  function bnModPowInt(e, m) {
    var z;
    if (e < 256 || m.isEven()) z = new Classic(m); else z = new Montgomery(m);
    return this.exp(e, z);
  }
  BigInteger.prototype.copyTo = bnpCopyTo;
  BigInteger.prototype.fromInt = bnpFromInt;
  BigInteger.prototype.fromString = bnpFromString;
  BigInteger.prototype.clamp = bnpClamp;
  BigInteger.prototype.dlShiftTo = bnpDLShiftTo;
  BigInteger.prototype.drShiftTo = bnpDRShiftTo;
  BigInteger.prototype.lShiftTo = bnpLShiftTo;
  BigInteger.prototype.rShiftTo = bnpRShiftTo;
  BigInteger.prototype.subTo = bnpSubTo;
  BigInteger.prototype.multiplyTo = bnpMultiplyTo;
  BigInteger.prototype.squareTo = bnpSquareTo;
  BigInteger.prototype.divRemTo = bnpDivRemTo;
  BigInteger.prototype.invDigit = bnpInvDigit;
  BigInteger.prototype.isEven = bnpIsEven;
  BigInteger.prototype.exp = bnpExp;
  BigInteger.prototype.toString = bnToString;
  BigInteger.prototype.negate = bnNegate;
  BigInteger.prototype.abs = bnAbs;
  BigInteger.prototype.compareTo = bnCompareTo;
  BigInteger.prototype.bitLength = bnBitLength;
  BigInteger.prototype.mod = bnMod;
  BigInteger.prototype.modPowInt = bnModPowInt;
  BigInteger.ZERO = nbv(0);
  BigInteger.ONE = nbv(1);
  function bnpFromRadix(s, b) {
    this.fromInt(0);
    if (b == null) b = 10;
    var cs = this.chunkSize(b);
    var d = Math.pow(b, cs), mi = false, j = 0, w = 0;
    for (var i = 0; i < s.length; ++i) {
      var x = intAt(s, i);
      if (x < 0) {
        if (s.charAt(i) == "-" && this.signum() == 0) mi = true;
        continue;
      }
      w = b * w + x;
      if (++j >= cs) {
        this.dMultiply(d);
        this.dAddOffset(w, 0);
        j = 0;
        w = 0;
      }
    }
    if (j > 0) {
      this.dMultiply(Math.pow(b, j));
      this.dAddOffset(w, 0);
    }
    if (mi) BigInteger.ZERO.subTo(this, this);
  }
  function bnpChunkSize(r) {
    return Math.floor(Math.LN2 * this.DB / Math.log(r));
  }
  function bnSigNum() {
    if (this.s < 0) return -1; else if (this.t <= 0 || this.t == 1 && this[0] <= 0) return 0; else return 1;
  }
  function bnpDMultiply(n) {
    this[this.t] = this.am(0, n - 1, this, 0, 0, this.t);
    ++this.t;
    this.clamp();
  }
  function bnpDAddOffset(n, w) {
    if (n == 0) return;
    while (this.t <= w) this[this.t++] = 0;
    this[w] += n;
    while (this[w] >= this.DV) {
      this[w] -= this.DV;
      if (++w >= this.t) this[this.t++] = 0;
      ++this[w];
    }
  }
  function bnpToRadix(b) {
    if (b == null) b = 10;
    if (this.signum() == 0 || b < 2 || b > 36) return "0";
    var cs = this.chunkSize(b);
    var a = Math.pow(b, cs);
    var d = nbv(a), y = nbi(), z = nbi(), r = "";
    this.divRemTo(d, y, z);
    while (y.signum() > 0) {
      r = (a + z.intValue()).toString(b).substr(1) + r;
      y.divRemTo(d, y, z);
    }
    return z.intValue().toString(b) + r;
  }
  function bnIntValue() {
    if (this.s < 0) {
      if (this.t == 1) return this[0] - this.DV; else if (this.t == 0) return -1;
    } else if (this.t == 1) return this[0]; else if (this.t == 0) return 0;
    return (this[1] & (1 << 32 - this.DB) - 1) << this.DB | this[0];
  }
  function bnpAddTo(a, r) {
    var i = 0, c = 0, m = Math.min(a.t, this.t);
    while (i < m) {
      c += this[i] + a[i];
      r[i++] = c & this.DM;
      c >>= this.DB;
    }
    if (a.t < this.t) {
      c += a.s;
      while (i < this.t) {
        c += this[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
      }
      c += this.s;
    } else {
      c += this.s;
      while (i < a.t) {
        c += a[i];
        r[i++] = c & this.DM;
        c >>= this.DB;
      }
      c += a.s;
    }
    r.s = c < 0 ? -1 : 0;
    if (c > 0) r[i++] = c; else if (c < -1) r[i++] = this.DV + c;
    r.t = i;
    r.clamp();
  }
  BigInteger.prototype.fromRadix = bnpFromRadix;
  BigInteger.prototype.chunkSize = bnpChunkSize;
  BigInteger.prototype.signum = bnSigNum;
  BigInteger.prototype.dMultiply = bnpDMultiply;
  BigInteger.prototype.dAddOffset = bnpDAddOffset;
  BigInteger.prototype.toRadix = bnpToRadix;
  BigInteger.prototype.intValue = bnIntValue;
  BigInteger.prototype.addTo = bnpAddTo;
  var Wrapper = {
    result: [ 0, 0 ],
    add: (function(xl, xh, yl, yh) {
      var x = new goog.math.Long(xl, xh);
      var y = new goog.math.Long(yl, yh);
      var ret = x.add(y);
      Wrapper.result[0] = ret.low_;
      Wrapper.result[1] = ret.high_;
    }),
    subtract: (function(xl, xh, yl, yh) {
      var x = new goog.math.Long(xl, xh);
      var y = new goog.math.Long(yl, yh);
      var ret = x.subtract(y);
      Wrapper.result[0] = ret.low_;
      Wrapper.result[1] = ret.high_;
    }),
    multiply: (function(xl, xh, yl, yh) {
      var x = new goog.math.Long(xl, xh);
      var y = new goog.math.Long(yl, yh);
      var ret = x.multiply(y);
      Wrapper.result[0] = ret.low_;
      Wrapper.result[1] = ret.high_;
    }),
    makeTwo32: (function() {
      Wrapper.two32 = new BigInteger;
      Wrapper.two32.fromString("4294967296", 10);
    }),
    lh2bignum: (function(l, h) {
      var a = new BigInteger;
      a.fromString(h.toString(), 10);
      var b = new BigInteger;
      a.multiplyTo(Wrapper.two32, b);
      var c = new BigInteger;
      c.fromString(l.toString(), 10);
      var d = new BigInteger;
      c.addTo(b, d);
      return d;
    }),
    divide: (function(xl, xh, yl, yh, unsigned) {
      if (!Wrapper.two32) Wrapper.makeTwo32();
      if (!unsigned) {
        var x = new goog.math.Long(xl, xh);
        var y = new goog.math.Long(yl, yh);
        var ret = x.div(y);
        Wrapper.result[0] = ret.low_;
        Wrapper.result[1] = ret.high_;
      } else {
        var x = Wrapper.lh2bignum(xl >>> 0, xh >>> 0);
        var y = Wrapper.lh2bignum(yl >>> 0, yh >>> 0);
        var z = new BigInteger;
        x.divRemTo(y, z, null);
        var l = new BigInteger;
        var h = new BigInteger;
        z.divRemTo(Wrapper.two32, h, l);
        Wrapper.result[0] = parseInt(l.toString()) | 0;
        Wrapper.result[1] = parseInt(h.toString()) | 0;
      }
    }),
    modulo: (function(xl, xh, yl, yh, unsigned) {
      if (!Wrapper.two32) Wrapper.makeTwo32();
      if (!unsigned) {
        var x = new goog.math.Long(xl, xh);
        var y = new goog.math.Long(yl, yh);
        var ret = x.modulo(y);
        Wrapper.result[0] = ret.low_;
        Wrapper.result[1] = ret.high_;
      } else {
        var x = Wrapper.lh2bignum(xl >>> 0, xh >>> 0);
        var y = Wrapper.lh2bignum(yl >>> 0, yh >>> 0);
        var z = new BigInteger;
        x.divRemTo(y, null, z);
        var l = new BigInteger;
        var h = new BigInteger;
        z.divRemTo(Wrapper.two32, h, l);
        Wrapper.result[0] = parseInt(l.toString()) | 0;
        Wrapper.result[1] = parseInt(h.toString()) | 0;
      }
    }),
    stringify: (function(l, h, unsigned) {
      var ret = (new goog.math.Long(l, h)).toString();
      if (unsigned && ret[0] == "-") {
        if (!Wrapper.two64) {
          Wrapper.two64 = new BigInteger;
          Wrapper.two64.fromString("18446744073709551616", 10);
        }
        var bignum = new BigInteger;
        bignum.fromString(ret, 10);
        ret = new BigInteger;
        Wrapper.two64.addTo(bignum, ret);
        ret = ret.toString(10);
      }
      return ret;
    })
  };
  return Wrapper;
})();
function _memcpy(dest, src, num, align) {
  if (num >= 20 && src % 2 == dest % 2) {
    if (src % 4 == dest % 4) {
      var stop = src + num;
      while (src % 4) {
        HEAP8[dest++] = HEAP8[src++];
      }
      var src4 = src >> 2, dest4 = dest >> 2, stop4 = stop >> 2;
      while (src4 < stop4) {
        HEAP32[dest4++] = HEAP32[src4++];
      }
      src = src4 << 2;
      dest = dest4 << 2;
      while (src < stop) {
        HEAP8[dest++] = HEAP8[src++];
      }
    } else {
      var stop = src + num;
      if (src % 2) {
        HEAP8[dest++] = HEAP8[src++];
      }
      var src2 = src >> 1, dest2 = dest >> 1, stop2 = stop >> 1;
      while (src2 < stop2) {
        HEAP16[dest2++] = HEAP16[src2++];
      }
      src = src2 << 1;
      dest = dest2 << 1;
      if (src < stop) {
        HEAP8[dest++] = HEAP8[src++];
      }
    }
  } else {
    while (num--) {
      HEAP8[dest++] = HEAP8[src++];
    }
  }
}
var _llvm_memcpy_p0i8_p0i8_i32 = _memcpy;
var ERRNO_CODES = {
  E2BIG: 7,
  EACCES: 13,
  EADDRINUSE: 98,
  EADDRNOTAVAIL: 99,
  EAFNOSUPPORT: 97,
  EAGAIN: 11,
  EALREADY: 114,
  EBADF: 9,
  EBADMSG: 74,
  EBUSY: 16,
  ECANCELED: 125,
  ECHILD: 10,
  ECONNABORTED: 103,
  ECONNREFUSED: 111,
  ECONNRESET: 104,
  EDEADLK: 35,
  EDESTADDRREQ: 89,
  EDOM: 33,
  EDQUOT: 122,
  EEXIST: 17,
  EFAULT: 14,
  EFBIG: 27,
  EHOSTUNREACH: 113,
  EIDRM: 43,
  EILSEQ: 84,
  EINPROGRESS: 115,
  EINTR: 4,
  EINVAL: 22,
  EIO: 5,
  EISCONN: 106,
  EISDIR: 21,
  ELOOP: 40,
  EMFILE: 24,
  EMLINK: 31,
  EMSGSIZE: 90,
  EMULTIHOP: 72,
  ENAMETOOLONG: 36,
  ENETDOWN: 100,
  ENETRESET: 102,
  ENETUNREACH: 101,
  ENFILE: 23,
  ENOBUFS: 105,
  ENODATA: 61,
  ENODEV: 19,
  ENOENT: 2,
  ENOEXEC: 8,
  ENOLCK: 37,
  ENOLINK: 67,
  ENOMEM: 12,
  ENOMSG: 42,
  ENOPROTOOPT: 92,
  ENOSPC: 28,
  ENOSR: 63,
  ENOSTR: 60,
  ENOSYS: 38,
  ENOTCONN: 107,
  ENOTDIR: 20,
  ENOTEMPTY: 39,
  ENOTRECOVERABLE: 131,
  ENOTSOCK: 88,
  ENOTSUP: 95,
  ENOTTY: 25,
  ENXIO: 6,
  EOVERFLOW: 75,
  EOWNERDEAD: 130,
  EPERM: 1,
  EPIPE: 32,
  EPROTO: 71,
  EPROTONOSUPPORT: 93,
  EPROTOTYPE: 91,
  ERANGE: 34,
  EROFS: 30,
  ESPIPE: 29,
  ESRCH: 3,
  ESTALE: 116,
  ETIME: 62,
  ETIMEDOUT: 110,
  ETXTBSY: 26,
  EWOULDBLOCK: 11,
  EXDEV: 18
};
function ___setErrNo(value) {
  if (!___setErrNo.ret) ___setErrNo.ret = allocate([ 0 ], "i32", ALLOC_STATIC);
  HEAP32[___setErrNo.ret >> 2] = value;
  return value;
}
var _stdin = 0;
var _stdout = 0;
var _stderr = 0;
var __impure_ptr = 0;
var FS = {
  currentPath: "/",
  nextInode: 2,
  streams: [ null ],
  ignorePermissions: true,
  joinPath: (function(parts, forceRelative) {
    var ret = parts[0];
    for (var i = 1; i < parts.length; i++) {
      if (ret[ret.length - 1] != "/") ret += "/";
      ret += parts[i];
    }
    if (forceRelative && ret[0] == "/") ret = ret.substr(1);
    return ret;
  }),
  absolutePath: (function(relative, base) {
    if (typeof relative !== "string") return null;
    if (base === undefined) base = FS.currentPath;
    if (relative && relative[0] == "/") base = "";
    var full = base + "/" + relative;
    var parts = full.split("/").reverse();
    var absolute = [ "" ];
    while (parts.length) {
      var part = parts.pop();
      if (part == "" || part == ".") {} else if (part == "..") {
        if (absolute.length > 1) absolute.pop();
      } else {
        absolute.push(part);
      }
    }
    return absolute.length == 1 ? "/" : absolute.join("/");
  }),
  analyzePath: (function(path, dontResolveLastLink, linksVisited) {
    var ret = {
      isRoot: false,
      exists: false,
      error: 0,
      name: null,
      path: null,
      object: null,
      parentExists: false,
      parentPath: null,
      parentObject: null
    };
    path = FS.absolutePath(path);
    if (path == "/") {
      ret.isRoot = true;
      ret.exists = ret.parentExists = true;
      ret.name = "/";
      ret.path = ret.parentPath = "/";
      ret.object = ret.parentObject = FS.root;
    } else if (path !== null) {
      linksVisited = linksVisited || 0;
      path = path.slice(1).split("/");
      var current = FS.root;
      var traversed = [ "" ];
      while (path.length) {
        if (path.length == 1 && current.isFolder) {
          ret.parentExists = true;
          ret.parentPath = traversed.length == 1 ? "/" : traversed.join("/");
          ret.parentObject = current;
          ret.name = path[0];
        }
        var target = path.shift();
        if (!current.isFolder) {
          ret.error = ERRNO_CODES.ENOTDIR;
          break;
        } else if (!current.read) {
          ret.error = ERRNO_CODES.EACCES;
          break;
        } else if (!current.contents.hasOwnProperty(target)) {
          ret.error = ERRNO_CODES.ENOENT;
          break;
        }
        current = current.contents[target];
        if (current.link && !(dontResolveLastLink && path.length == 0)) {
          if (linksVisited > 40) {
            ret.error = ERRNO_CODES.ELOOP;
            break;
          }
          var link = FS.absolutePath(current.link, traversed.join("/"));
          ret = FS.analyzePath([ link ].concat(path).join("/"), dontResolveLastLink, linksVisited + 1);
          return ret;
        }
        traversed.push(target);
        if (path.length == 0) {
          ret.exists = true;
          ret.path = traversed.join("/");
          ret.object = current;
        }
      }
    }
    return ret;
  }),
  findObject: (function(path, dontResolveLastLink) {
    FS.ensureRoot();
    var ret = FS.analyzePath(path, dontResolveLastLink);
    if (ret.exists) {
      return ret.object;
    } else {
      ___setErrNo(ret.error);
      return null;
    }
  }),
  createObject: (function(parent, name, properties, canRead, canWrite) {
    if (!parent) parent = "/";
    if (typeof parent === "string") parent = FS.findObject(parent);
    if (!parent) {
      ___setErrNo(ERRNO_CODES.EACCES);
      throw new Error("Parent path must exist.");
    }
    if (!parent.isFolder) {
      ___setErrNo(ERRNO_CODES.ENOTDIR);
      throw new Error("Parent must be a folder.");
    }
    if (!parent.write && !FS.ignorePermissions) {
      ___setErrNo(ERRNO_CODES.EACCES);
      throw new Error("Parent folder must be writeable.");
    }
    if (!name || name == "." || name == "..") {
      ___setErrNo(ERRNO_CODES.ENOENT);
      throw new Error("Name must not be empty.");
    }
    if (parent.contents.hasOwnProperty(name)) {
      ___setErrNo(ERRNO_CODES.EEXIST);
      throw new Error("Can't overwrite object.");
    }
    parent.contents[name] = {
      read: canRead === undefined ? true : canRead,
      write: canWrite === undefined ? false : canWrite,
      timestamp: Date.now(),
      inodeNumber: FS.nextInode++
    };
    for (var key in properties) {
      if (properties.hasOwnProperty(key)) {
        parent.contents[name][key] = properties[key];
      }
    }
    return parent.contents[name];
  }),
  createFolder: (function(parent, name, canRead, canWrite) {
    var properties = {
      isFolder: true,
      isDevice: false,
      contents: {}
    };
    return FS.createObject(parent, name, properties, canRead, canWrite);
  }),
  createPath: (function(parent, path, canRead, canWrite) {
    var current = FS.findObject(parent);
    if (current === null) throw new Error("Invalid parent.");
    path = path.split("/").reverse();
    while (path.length) {
      var part = path.pop();
      if (!part) continue;
      if (!current.contents.hasOwnProperty(part)) {
        FS.createFolder(current, part, canRead, canWrite);
      }
      current = current.contents[part];
    }
    return current;
  }),
  createFile: (function(parent, name, properties, canRead, canWrite) {
    properties.isFolder = false;
    return FS.createObject(parent, name, properties, canRead, canWrite);
  }),
  createDataFile: (function(parent, name, data, canRead, canWrite) {
    if (typeof data === "string") {
      var dataArray = new Array(data.length);
      for (var i = 0, len = data.length; i < len; ++i) dataArray[i] = data.charCodeAt(i);
      data = dataArray;
    }
    var properties = {
      isDevice: false,
      contents: data.subarray ? data.subarray(0) : data
    };
    return FS.createFile(parent, name, properties, canRead, canWrite);
  }),
  createLazyFile: (function(parent, name, url, canRead, canWrite) {
    if (typeof XMLHttpRequest !== "undefined") {
      if (!ENVIRONMENT_IS_WORKER) throw "Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc";
      var LazyUint8Array = (function(chunkSize, length) {
        this.length = length;
        this.chunkSize = chunkSize;
        this.chunks = [];
      });
      LazyUint8Array.prototype.get = (function(idx) {
        if (idx > this.length - 1 || idx < 0) {
          return undefined;
        }
        var chunkOffset = idx % chunkSize;
        var chunkNum = Math.floor(idx / chunkSize);
        return this.getter(chunkNum)[chunkOffset];
      });
      LazyUint8Array.prototype.setDataGetter = (function(getter) {
        this.getter = getter;
      });
      var xhr = new XMLHttpRequest;
      xhr.open("HEAD", url, false);
      xhr.send(null);
      if (!(xhr.status >= 200 && xhr.status < 300 || xhr.status === 304)) throw new Error("Couldn't load " + url + ". Status: " + xhr.status);
      var datalength = Number(xhr.getResponseHeader("Content-length"));
      var header;
      var hasByteServing = (header = xhr.getResponseHeader("Accept-Ranges")) && header === "bytes";
      var chunkSize = 1024 * 1024;
      if (!hasByteServing) chunkSize = datalength;
      var doXHR = (function(from, to) {
        if (from > to) throw new Error("invalid range (" + from + ", " + to + ") or no bytes requested!");
        if (to > datalength - 1) throw new Error("only " + datalength + " bytes available! programmer error!");
        var xhr = new XMLHttpRequest;
        xhr.open("GET", url, false);
        if (datalength !== chunkSize) xhr.setRequestHeader("Range", "bytes=" + from + "-" + to);
        if (typeof Uint8Array != "undefined") xhr.responseType = "arraybuffer";
        if (xhr.overrideMimeType) {
          xhr.overrideMimeType("text/plain; charset=x-user-defined");
        }
        xhr.send(null);
        if (!(xhr.status >= 200 && xhr.status < 300 || xhr.status === 304)) throw new Error("Couldn't load " + url + ". Status: " + xhr.status);
        if (xhr.response !== undefined) {
          return new Uint8Array(xhr.response || []);
        } else {
          return intArrayFromString(xhr.responseText || "", true);
        }
      });
      var lazyArray = new LazyUint8Array(chunkSize, datalength);
      lazyArray.setDataGetter((function(chunkNum) {
        var start = chunkNum * lazyArray.chunkSize;
        var end = (chunkNum + 1) * lazyArray.chunkSize - 1;
        end = Math.min(end, datalength - 1);
        if (typeof lazyArray.chunks[chunkNum] === "undefined") {
          lazyArray.chunks[chunkNum] = doXHR(start, end);
        }
        if (typeof lazyArray.chunks[chunkNum] === "undefined") throw new Error("doXHR failed!");
        return lazyArray.chunks[chunkNum];
      }));
      var properties = {
        isDevice: false,
        contents: lazyArray
      };
    } else {
      var properties = {
        isDevice: false,
        url: url
      };
    }
    return FS.createFile(parent, name, properties, canRead, canWrite);
  }),
  createPreloadedFile: (function(parent, name, url, canRead, canWrite, onload, onerror, dontCreateFile) {
    Browser.ensureObjects();
    var fullname = FS.joinPath([ parent, name ], true);
    function processData(byteArray) {
      function finish(byteArray) {
        if (!dontCreateFile) {
          FS.createDataFile(parent, name, byteArray, canRead, canWrite);
        }
        if (onload) onload();
        removeRunDependency("cp " + fullname);
      }
      var handled = false;
      Module["preloadPlugins"].forEach((function(plugin) {
        if (handled) return;
        if (plugin["canHandle"](fullname)) {
          plugin["handle"](byteArray, fullname, finish, (function() {
            if (onerror) onerror();
            removeRunDependency("cp " + fullname);
          }));
          handled = true;
        }
      }));
      if (!handled) finish(byteArray);
    }
    addRunDependency("cp " + fullname);
    if (typeof url == "string") {
      Browser.asyncLoad(url, (function(byteArray) {
        processData(byteArray);
      }), onerror);
    } else {
      processData(url);
    }
  }),
  createLink: (function(parent, name, target, canRead, canWrite) {
    var properties = {
      isDevice: false,
      link: target
    };
    return FS.createFile(parent, name, properties, canRead, canWrite);
  }),
  createDevice: (function(parent, name, input, output) {
    if (!(input || output)) {
      throw new Error("A device must have at least one callback defined.");
    }
    var ops = {
      isDevice: true,
      input: input,
      output: output
    };
    return FS.createFile(parent, name, ops, Boolean(input), Boolean(output));
  }),
  forceLoadFile: (function(obj) {
    if (obj.isDevice || obj.isFolder || obj.link || obj.contents) return true;
    var success = true;
    if (typeof XMLHttpRequest !== "undefined") {
      throw new Error("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");
    } else if (Module["read"]) {
      try {
        obj.contents = intArrayFromString(Module["read"](obj.url), true);
      } catch (e) {
        success = false;
      }
    } else {
      throw new Error("Cannot load without read() or XMLHttpRequest.");
    }
    if (!success) ___setErrNo(ERRNO_CODES.EIO);
    return success;
  }),
  ensureRoot: (function() {
    if (FS.root) return;
    FS.root = {
      read: true,
      write: true,
      isFolder: true,
      isDevice: false,
      timestamp: Date.now(),
      inodeNumber: 1,
      contents: {}
    };
  }),
  init: (function(input, output, error) {
    assert(!FS.init.initialized, "FS.init was previously called. If you want to initialize later with custom parameters, remove any earlier calls (note that one is automatically added to the generated code)");
    FS.init.initialized = true;
    FS.ensureRoot();
    input = input || Module["stdin"];
    output = output || Module["stdout"];
    error = error || Module["stderr"];
    var stdinOverridden = true, stdoutOverridden = true, stderrOverridden = true;
    if (!input) {
      stdinOverridden = false;
      input = (function() {
        if (!input.cache || !input.cache.length) {
          var result;
          if (typeof window != "undefined" && typeof window.prompt == "function") {
            result = window.prompt("Input: ");
            if (result === null) result = String.fromCharCode(0);
          } else if (typeof readline == "function") {
            result = readline();
          }
          if (!result) result = "";
          input.cache = intArrayFromString(result + "\n", true);
        }
        return input.cache.shift();
      });
    }
    var utf8 = new Runtime.UTF8Processor;
    function simpleOutput(val) {
      if (val === null || val === "\n".charCodeAt(0)) {
        output.printer(output.buffer.join(""));
        output.buffer = [];
      } else {
        output.buffer.push(utf8.processCChar(val));
      }
    }
    if (!output) {
      stdoutOverridden = false;
      output = simpleOutput;
    }
    if (!output.printer) output.printer = Module["print"];
    if (!output.buffer) output.buffer = [];
    if (!error) {
      stderrOverridden = false;
      error = simpleOutput;
    }
    if (!error.printer) error.printer = Module["print"];
    if (!error.buffer) error.buffer = [];
    try {
      FS.createFolder("/", "tmp", true, true);
    } catch (e) {}
    var devFolder = FS.createFolder("/", "dev", true, true);
    var stdin = FS.createDevice(devFolder, "stdin", input);
    var stdout = FS.createDevice(devFolder, "stdout", null, output);
    var stderr = FS.createDevice(devFolder, "stderr", null, error);
    FS.createDevice(devFolder, "tty", input, output);
    FS.streams[1] = {
      path: "/dev/stdin",
      object: stdin,
      position: 0,
      isRead: true,
      isWrite: false,
      isAppend: false,
      isTerminal: !stdinOverridden,
      error: false,
      eof: false,
      ungotten: []
    };
    FS.streams[2] = {
      path: "/dev/stdout",
      object: stdout,
      position: 0,
      isRead: false,
      isWrite: true,
      isAppend: false,
      isTerminal: !stdoutOverridden,
      error: false,
      eof: false,
      ungotten: []
    };
    FS.streams[3] = {
      path: "/dev/stderr",
      object: stderr,
      position: 0,
      isRead: false,
      isWrite: true,
      isAppend: false,
      isTerminal: !stderrOverridden,
      error: false,
      eof: false,
      ungotten: []
    };
    _stdin = allocate([ 1 ], "void*", ALLOC_STACK);
    _stdout = allocate([ 2 ], "void*", ALLOC_STACK);
    _stderr = allocate([ 3 ], "void*", ALLOC_STACK);
    FS.createPath("/", "dev/shm/tmp", true, true);
    for (var i = FS.streams.length; i < Math.max(_stdin, _stdout, _stderr) + 4; i++) {
      FS.streams[i] = null;
    }
    FS.streams[_stdin] = FS.streams[1];
    FS.streams[_stdout] = FS.streams[2];
    FS.streams[_stderr] = FS.streams[3];
    __impure_ptr = allocate([ allocate([ 0, 0, 0, 0, _stdin, 0, 0, 0, _stdout, 0, 0, 0, _stderr, 0, 0, 0 ], "void*", ALLOC_STATIC) ], "void*", ALLOC_STATIC);
  }),
  quit: (function() {
    if (!FS.init.initialized) return;
    if (FS.streams[2] && FS.streams[2].object.output.buffer.length > 0) FS.streams[2].object.output("\n".charCodeAt(0));
    if (FS.streams[3] && FS.streams[3].object.output.buffer.length > 0) FS.streams[3].object.output("\n".charCodeAt(0));
  }),
  standardizePath: (function(path) {
    if (path.substr(0, 2) == "./") path = path.substr(2);
    return path;
  }),
  deleteFile: (function(path) {
    var path = FS.analyzePath(path);
    if (!path.parentExists || !path.exists) {
      throw "Invalid path " + path;
    }
    delete path.parentObject.contents[path.name];
  })
};
function _pwrite(fildes, buf, nbyte, offset) {
  var stream = FS.streams[fildes];
  if (!stream || stream.object.isDevice) {
    ___setErrNo(ERRNO_CODES.EBADF);
    return -1;
  } else if (!stream.isWrite) {
    ___setErrNo(ERRNO_CODES.EACCES);
    return -1;
  } else if (stream.object.isFolder) {
    ___setErrNo(ERRNO_CODES.EISDIR);
    return -1;
  } else if (nbyte < 0 || offset < 0) {
    ___setErrNo(ERRNO_CODES.EINVAL);
    return -1;
  } else {
    var contents = stream.object.contents;
    while (contents.length < offset) contents.push(0);
    for (var i = 0; i < nbyte; i++) {
      contents[offset + i] = HEAPU8[buf + i];
    }
    stream.object.timestamp = Date.now();
    return i;
  }
}
function _write(fildes, buf, nbyte) {
  var stream = FS.streams[fildes];
  if (!stream) {
    ___setErrNo(ERRNO_CODES.EBADF);
    return -1;
  } else if (!stream.isWrite) {
    ___setErrNo(ERRNO_CODES.EACCES);
    return -1;
  } else if (nbyte < 0) {
    ___setErrNo(ERRNO_CODES.EINVAL);
    return -1;
  } else {
    if (stream.object.isDevice) {
      if (stream.object.output) {
        for (var i = 0; i < nbyte; i++) {
          try {
            stream.object.output(HEAP8[buf + i]);
          } catch (e) {
            ___setErrNo(ERRNO_CODES.EIO);
            return -1;
          }
        }
        stream.object.timestamp = Date.now();
        return i;
      } else {
        ___setErrNo(ERRNO_CODES.ENXIO);
        return -1;
      }
    } else {
      var bytesWritten = _pwrite(fildes, buf, nbyte, stream.position);
      if (bytesWritten != -1) stream.position += bytesWritten;
      return bytesWritten;
    }
  }
}
function _fwrite(ptr, size, nitems, stream) {
  var bytesToWrite = nitems * size;
  if (bytesToWrite == 0) return 0;
  var bytesWritten = _write(stream, ptr, bytesToWrite);
  if (bytesWritten == -1) {
    if (FS.streams[stream]) FS.streams[stream].error = true;
    return 0;
  } else {
    return Math.floor(bytesWritten / size);
  }
}
function __formatString(format, varargs) {
  var textIndex = format;
  var argIndex = 0;
  function getNextArg(type) {
    var ret;
    if (type === "double") {
      ret = (tempDoubleI32[0] = HEAP32[varargs + argIndex >> 2], tempDoubleI32[1] = HEAP32[argIndex + (varargs + 4) >> 2], tempDoubleF64[0]);
    } else if (type == "i64") {
      ret = [ HEAP32[varargs + argIndex >> 2], HEAP32[argIndex + (varargs + 4) >> 2] ];
    } else {
      type = "i32";
      ret = HEAP32[varargs + argIndex >> 2];
    }
    argIndex += Runtime.getNativeFieldSize(type);
    return ret;
  }
  var ret = [];
  var curr, next, currArg;
  while (1) {
    var startTextIndex = textIndex;
    curr = HEAP8[textIndex];
    if (curr === 0) break;
    next = HEAP8[textIndex + 1];
    if (curr == "%".charCodeAt(0)) {
      var flagAlwaysSigned = false;
      var flagLeftAlign = false;
      var flagAlternative = false;
      var flagZeroPad = false;
      flagsLoop : while (1) {
        switch (next) {
         case "+".charCodeAt(0):
          flagAlwaysSigned = true;
          break;
         case "-".charCodeAt(0):
          flagLeftAlign = true;
          break;
         case "#".charCodeAt(0):
          flagAlternative = true;
          break;
         case "0".charCodeAt(0):
          if (flagZeroPad) {
            break flagsLoop;
          } else {
            flagZeroPad = true;
            break;
          }
         default:
          break flagsLoop;
        }
        textIndex++;
        next = HEAP8[textIndex + 1];
      }
      var width = 0;
      if (next == "*".charCodeAt(0)) {
        width = getNextArg("i32");
        textIndex++;
        next = HEAP8[textIndex + 1];
      } else {
        while (next >= "0".charCodeAt(0) && next <= "9".charCodeAt(0)) {
          width = width * 10 + (next - "0".charCodeAt(0));
          textIndex++;
          next = HEAP8[textIndex + 1];
        }
      }
      var precisionSet = false;
      if (next == ".".charCodeAt(0)) {
        var precision = 0;
        precisionSet = true;
        textIndex++;
        next = HEAP8[textIndex + 1];
        if (next == "*".charCodeAt(0)) {
          precision = getNextArg("i32");
          textIndex++;
        } else {
          while (1) {
            var precisionChr = HEAP8[textIndex + 1];
            if (precisionChr < "0".charCodeAt(0) || precisionChr > "9".charCodeAt(0)) break;
            precision = precision * 10 + (precisionChr - "0".charCodeAt(0));
            textIndex++;
          }
        }
        next = HEAP8[textIndex + 1];
      } else {
        var precision = 6;
      }
      var argSize;
      switch (String.fromCharCode(next)) {
       case "h":
        var nextNext = HEAP8[textIndex + 2];
        if (nextNext == "h".charCodeAt(0)) {
          textIndex++;
          argSize = 1;
        } else {
          argSize = 2;
        }
        break;
       case "l":
        var nextNext = HEAP8[textIndex + 2];
        if (nextNext == "l".charCodeAt(0)) {
          textIndex++;
          argSize = 8;
        } else {
          argSize = 4;
        }
        break;
       case "L":
       case "q":
       case "j":
        argSize = 8;
        break;
       case "z":
       case "t":
       case "I":
        argSize = 4;
        break;
       default:
        argSize = null;
      }
      if (argSize) textIndex++;
      next = HEAP8[textIndex + 1];
      if ([ "d", "i", "u", "o", "x", "X", "p" ].indexOf(String.fromCharCode(next)) != -1) {
        var signed = next == "d".charCodeAt(0) || next == "i".charCodeAt(0);
        argSize = argSize || 4;
        var currArg = getNextArg("i" + argSize * 8);
        var origArg = currArg;
        var argText;
        if (argSize == 8) {
          currArg = Runtime.makeBigInt(currArg[0], currArg[1], next == "u".charCodeAt(0));
        }
        if (argSize <= 4) {
          var limit = Math.pow(256, argSize) - 1;
          currArg = (signed ? reSign : unSign)(currArg & limit, argSize * 8);
        }
        var currAbsArg = Math.abs(currArg);
        var prefix = "";
        if (next == "d".charCodeAt(0) || next == "i".charCodeAt(0)) {
          if (argSize == 8 && i64Math) argText = i64Math.stringify(origArg[0], origArg[1]); else argText = reSign(currArg, 8 * argSize, 1).toString(10);
        } else if (next == "u".charCodeAt(0)) {
          if (argSize == 8 && i64Math) argText = i64Math.stringify(origArg[0], origArg[1], true); else argText = unSign(currArg, 8 * argSize, 1).toString(10);
          currArg = Math.abs(currArg);
        } else if (next == "o".charCodeAt(0)) {
          argText = (flagAlternative ? "0" : "") + currAbsArg.toString(8);
        } else if (next == "x".charCodeAt(0) || next == "X".charCodeAt(0)) {
          prefix = flagAlternative ? "0x" : "";
          if (currArg < 0) {
            currArg = -currArg;
            argText = (currAbsArg - 1).toString(16);
            var buffer = [];
            for (var i = 0; i < argText.length; i++) {
              buffer.push((15 - parseInt(argText[i], 16)).toString(16));
            }
            argText = buffer.join("");
            while (argText.length < argSize * 2) argText = "f" + argText;
          } else {
            argText = currAbsArg.toString(16);
          }
          if (next == "X".charCodeAt(0)) {
            prefix = prefix.toUpperCase();
            argText = argText.toUpperCase();
          }
        } else if (next == "p".charCodeAt(0)) {
          if (currAbsArg === 0) {
            argText = "(nil)";
          } else {
            prefix = "0x";
            argText = currAbsArg.toString(16);
          }
        }
        if (precisionSet) {
          while (argText.length < precision) {
            argText = "0" + argText;
          }
        }
        if (flagAlwaysSigned) {
          if (currArg < 0) {
            prefix = "-" + prefix;
          } else {
            prefix = "+" + prefix;
          }
        }
        while (prefix.length + argText.length < width) {
          if (flagLeftAlign) {
            argText += " ";
          } else {
            if (flagZeroPad) {
              argText = "0" + argText;
            } else {
              prefix = " " + prefix;
            }
          }
        }
        argText = prefix + argText;
        argText.split("").forEach((function(chr) {
          ret.push(chr.charCodeAt(0));
        }));
      } else if ([ "f", "F", "e", "E", "g", "G" ].indexOf(String.fromCharCode(next)) != -1) {
        var currArg = getNextArg("double");
        var argText;
        if (isNaN(currArg)) {
          argText = "nan";
          flagZeroPad = false;
        } else if (!isFinite(currArg)) {
          argText = (currArg < 0 ? "-" : "") + "inf";
          flagZeroPad = false;
        } else {
          var isGeneral = false;
          var effectivePrecision = Math.min(precision, 20);
          if (next == "g".charCodeAt(0) || next == "G".charCodeAt(0)) {
            isGeneral = true;
            precision = precision || 1;
            var exponent = parseInt(currArg.toExponential(effectivePrecision).split("e")[1], 10);
            if (precision > exponent && exponent >= -4) {
              next = (next == "g".charCodeAt(0) ? "f" : "F").charCodeAt(0);
              precision -= exponent + 1;
            } else {
              next = (next == "g".charCodeAt(0) ? "e" : "E").charCodeAt(0);
              precision--;
            }
            effectivePrecision = Math.min(precision, 20);
          }
          if (next == "e".charCodeAt(0) || next == "E".charCodeAt(0)) {
            argText = currArg.toExponential(effectivePrecision);
            if (/[eE][-+]\d$/.test(argText)) {
              argText = argText.slice(0, -1) + "0" + argText.slice(-1);
            }
          } else if (next == "f".charCodeAt(0) || next == "F".charCodeAt(0)) {
            argText = currArg.toFixed(effectivePrecision);
          }
          var parts = argText.split("e");
          if (isGeneral && !flagAlternative) {
            while (parts[0].length > 1 && parts[0].indexOf(".") != -1 && (parts[0].slice(-1) == "0" || parts[0].slice(-1) == ".")) {
              parts[0] = parts[0].slice(0, -1);
            }
          } else {
            if (flagAlternative && argText.indexOf(".") == -1) parts[0] += ".";
            while (precision > effectivePrecision++) parts[0] += "0";
          }
          argText = parts[0] + (parts.length > 1 ? "e" + parts[1] : "");
          if (next == "E".charCodeAt(0)) argText = argText.toUpperCase();
          if (flagAlwaysSigned && currArg >= 0) {
            argText = "+" + argText;
          }
        }
        while (argText.length < width) {
          if (flagLeftAlign) {
            argText += " ";
          } else {
            if (flagZeroPad && (argText[0] == "-" || argText[0] == "+")) {
              argText = argText[0] + "0" + argText.slice(1);
            } else {
              argText = (flagZeroPad ? "0" : " ") + argText;
            }
          }
        }
        if (next < "a".charCodeAt(0)) argText = argText.toUpperCase();
        argText.split("").forEach((function(chr) {
          ret.push(chr.charCodeAt(0));
        }));
      } else if (next == "s".charCodeAt(0)) {
        var arg = getNextArg("i8*") || nullString;
        var argLength = String_len(arg);
        if (precisionSet) argLength = Math.min(argLength, precision);
        if (!flagLeftAlign) {
          while (argLength < width--) {
            ret.push(" ".charCodeAt(0));
          }
        }
        for (var i = 0; i < argLength; i++) {
          ret.push(HEAPU8[arg++]);
        }
        if (flagLeftAlign) {
          while (argLength < width--) {
            ret.push(" ".charCodeAt(0));
          }
        }
      } else if (next == "c".charCodeAt(0)) {
        if (flagLeftAlign) ret.push(getNextArg("i8"));
        while (--width > 0) {
          ret.push(" ".charCodeAt(0));
        }
        if (!flagLeftAlign) ret.push(getNextArg("i8"));
      } else if (next == "n".charCodeAt(0)) {
        var ptr = getNextArg("i32*");
        HEAP32[ptr >> 2] = ret.length;
      } else if (next == "%".charCodeAt(0)) {
        ret.push(curr);
      } else {
        for (var i = startTextIndex; i < textIndex + 2; i++) {
          ret.push(HEAP8[i]);
        }
      }
      textIndex += 2;
    } else {
      ret.push(curr);
      textIndex += 1;
    }
  }
  return ret;
}
function _fprintf(stream, format, varargs) {
  var result = __formatString(format, varargs);
  var stack = Runtime.stackSave();
  var ret = _fwrite(allocate(result, "i8", ALLOC_STACK), 1, result.length, stream);
  Runtime.stackRestore(stack);
  return ret;
}
function _printf(format, varargs) {
  var stdout = HEAP32[_stdout >> 2];
  return _fprintf(stdout, format, varargs);
}
var ___dirent_struct_layout = null;
function _open(path, oflag, varargs) {
  var mode = HEAP32[varargs >> 2];
  var accessMode = oflag & 3;
  var isWrite = accessMode != 0;
  var isRead = accessMode != 1;
  var isCreate = Boolean(oflag & 512);
  var isExistCheck = Boolean(oflag & 2048);
  var isTruncate = Boolean(oflag & 1024);
  var isAppend = Boolean(oflag & 8);
  var origPath = path;
  path = FS.analyzePath(Pointer_stringify(path));
  if (!path.parentExists) {
    ___setErrNo(path.error);
    return -1;
  }
  var target = path.object || null;
  var finalPath;
  if (target) {
    if (isCreate && isExistCheck) {
      ___setErrNo(ERRNO_CODES.EEXIST);
      return -1;
    }
    if ((isWrite || isCreate || isTruncate) && target.isFolder) {
      ___setErrNo(ERRNO_CODES.EISDIR);
      return -1;
    }
    if (isRead && !target.read || isWrite && !target.write) {
      ___setErrNo(ERRNO_CODES.EACCES);
      return -1;
    }
    if (isTruncate && !target.isDevice) {
      target.contents = [];
    } else {
      if (!FS.forceLoadFile(target)) {
        ___setErrNo(ERRNO_CODES.EIO);
        return -1;
      }
    }
    finalPath = path.path;
  } else {
    if (!isCreate) {
      ___setErrNo(ERRNO_CODES.ENOENT);
      return -1;
    }
    if (!path.parentObject.write) {
      ___setErrNo(ERRNO_CODES.EACCES);
      return -1;
    }
    target = FS.createDataFile(path.parentObject, path.name, [], mode & 256, mode & 128);
    finalPath = path.parentPath + "/" + path.name;
  }
  var id = FS.streams.length;
  if (target.isFolder) {
    var entryBuffer = 0;
    if (___dirent_struct_layout) {
      entryBuffer = _malloc(___dirent_struct_layout.__size__);
    }
    var contents = [];
    for (var key in target.contents) contents.push(key);
    FS.streams[id] = {
      path: finalPath,
      object: target,
      position: -2,
      isRead: true,
      isWrite: false,
      isAppend: false,
      error: false,
      eof: false,
      ungotten: [],
      contents: contents,
      currentEntry: entryBuffer
    };
  } else {
    FS.streams[id] = {
      path: finalPath,
      object: target,
      position: 0,
      isRead: isRead,
      isWrite: isWrite,
      isAppend: isAppend,
      error: false,
      eof: false,
      ungotten: []
    };
  }
  return id;
}
function _fopen(filename, mode) {
  var flags;
  mode = Pointer_stringify(mode);
  if (mode[0] == "r") {
    if (mode.indexOf("+") != -1) {
      flags = 2;
    } else {
      flags = 0;
    }
  } else if (mode[0] == "w") {
    if (mode.indexOf("+") != -1) {
      flags = 2;
    } else {
      flags = 1;
    }
    flags |= 512;
    flags |= 1024;
  } else if (mode[0] == "a") {
    if (mode.indexOf("+") != -1) {
      flags = 2;
    } else {
      flags = 1;
    }
    flags |= 512;
    flags |= 8;
  } else {
    ___setErrNo(ERRNO_CODES.EINVAL);
    return 0;
  }
  var ret = _open(filename, flags, allocate([ 511, 0, 0, 0 ], "i32", ALLOC_STACK));
  return ret == -1 ? 0 : ret;
}
function _mbtowc(pwc, pmb, maxx) {
  if (!pmb) return 0;
  maxx = Math.min(85, maxx);
  var i;
  for (i = 0; i < maxx; i++) {
    var curr = HEAP8[pmb];
    if (pwc) {
      HEAP8[pwc] = curr;
      HEAP8[pwc + 1] = 0;
      pwc += 2;
    }
    pmb++;
    if (!curr) break;
  }
  return i;
}
function _pread(fildes, buf, nbyte, offset) {
  var stream = FS.streams[fildes];
  if (!stream || stream.object.isDevice) {
    ___setErrNo(ERRNO_CODES.EBADF);
    return -1;
  } else if (!stream.isRead) {
    ___setErrNo(ERRNO_CODES.EACCES);
    return -1;
  } else if (stream.object.isFolder) {
    ___setErrNo(ERRNO_CODES.EISDIR);
    return -1;
  } else if (nbyte < 0 || offset < 0) {
    ___setErrNo(ERRNO_CODES.EINVAL);
    return -1;
  } else {
    var bytesRead = 0;
    while (stream.ungotten.length && nbyte > 0) {
      HEAP8[buf++] = stream.ungotten.pop();
      nbyte--;
      bytesRead++;
    }
    var contents = stream.object.contents;
    var size = Math.min(contents.length - offset, nbyte);
    if (contents.subarray || contents.slice) {
      for (var i = 0; i < size; i++) {
        HEAP8[buf + i] = contents[offset + i];
      }
    } else {
      for (var i = 0; i < size; i++) {
        HEAP8[buf + i] = contents.get(offset + i);
      }
    }
    bytesRead += size;
    return bytesRead;
  }
}
function _read(fildes, buf, nbyte) {
  var stream = FS.streams[fildes];
  if (!stream) {
    ___setErrNo(ERRNO_CODES.EBADF);
    return -1;
  } else if (!stream.isRead) {
    ___setErrNo(ERRNO_CODES.EACCES);
    return -1;
  } else if (nbyte < 0) {
    ___setErrNo(ERRNO_CODES.EINVAL);
    return -1;
  } else {
    var bytesRead;
    if (stream.object.isDevice) {
      if (stream.object.input) {
        bytesRead = 0;
        while (stream.ungotten.length && nbyte > 0) {
          HEAP8[buf++] = stream.ungotten.pop();
          nbyte--;
          bytesRead++;
        }
        for (var i = 0; i < nbyte; i++) {
          try {
            var result = stream.object.input();
          } catch (e) {
            ___setErrNo(ERRNO_CODES.EIO);
            return -1;
          }
          if (result === null || result === undefined) break;
          bytesRead++;
          HEAP8[buf + i] = result;
        }
        return bytesRead;
      } else {
        ___setErrNo(ERRNO_CODES.ENXIO);
        return -1;
      }
    } else {
      var ungotSize = stream.ungotten.length;
      bytesRead = _pread(fildes, buf, nbyte, stream.position);
      if (bytesRead != -1) {
        stream.position += stream.ungotten.length - ungotSize + bytesRead;
      }
      return bytesRead;
    }
  }
}
function _fgetc(stream) {
  if (!FS.streams[stream]) return -1;
  var streamObj = FS.streams[stream];
  if (streamObj.eof || streamObj.error) return -1;
  var ret = _read(stream, _fgetc.ret, 1);
  if (ret == 0) {
    streamObj.eof = true;
    return -1;
  } else if (ret == -1) {
    streamObj.error = true;
    return -1;
  } else {
    return HEAPU8[_fgetc.ret];
  }
}
var _getc = _fgetc;
function _close(fildes) {
  if (FS.streams[fildes]) {
    if (FS.streams[fildes].currentEntry) {
      _free(FS.streams[fildes].currentEntry);
    }
    FS.streams[fildes] = null;
    return 0;
  } else {
    ___setErrNo(ERRNO_CODES.EBADF);
    return -1;
  }
}
function _fsync(fildes) {
  if (FS.streams[fildes]) {
    return 0;
  } else {
    ___setErrNo(ERRNO_CODES.EBADF);
    return -1;
  }
}
function _fclose(stream) {
  _fsync(stream);
  return _close(stream);
}
function _isspace(chr) {
  return chr in {
    32: 0,
    9: 0,
    10: 0,
    11: 0,
    12: 0,
    13: 0
  };
}
function _isdigit(chr) {
  return chr >= "0".charCodeAt(0) && chr <= "9".charCodeAt(0);
}
function _strtod(str, endptr) {
  var origin = str;
  while (_isspace(HEAP8[str])) str++;
  var multiplier = 1;
  if (HEAP8[str] == "-".charCodeAt(0)) {
    multiplier = -1;
    str++;
  } else if (HEAP8[str] == "+".charCodeAt(0)) {
    str++;
  }
  var chr;
  var ret = 0;
  var whole = false;
  while (1) {
    chr = HEAP8[str];
    if (!_isdigit(chr)) break;
    whole = true;
    ret = ret * 10 + chr - "0".charCodeAt(0);
    str++;
  }
  var fraction = false;
  if (HEAP8[str] == ".".charCodeAt(0)) {
    str++;
    var mul = 1 / 10;
    while (1) {
      chr = HEAP8[str];
      if (!_isdigit(chr)) break;
      fraction = true;
      ret += mul * (chr - "0".charCodeAt(0));
      mul /= 10;
      str++;
    }
  }
  if (!whole && !fraction) {
    if (endptr) {
      HEAP32[endptr >> 2] = origin;
    }
    return 0;
  }
  chr = HEAP8[str];
  if (chr == "e".charCodeAt(0) || chr == "E".charCodeAt(0)) {
    str++;
    var exponent = 0;
    var expNegative = false;
    chr = HEAP8[str];
    if (chr == "-".charCodeAt(0)) {
      expNegative = true;
      str++;
    } else if (chr == "+".charCodeAt(0)) {
      str++;
    }
    chr = HEAP8[str];
    while (1) {
      if (!_isdigit(chr)) break;
      exponent = exponent * 10 + chr - "0".charCodeAt(0);
      str++;
      chr = HEAP8[str];
    }
    if (expNegative) exponent = -exponent;
    ret *= Math.pow(10, exponent);
  }
  if (endptr) {
    HEAP32[endptr >> 2] = str;
  }
  return ret * multiplier;
}
function _atof(ptr) {
  return _strtod(ptr, null);
}
var _llvm_va_start;
var _vfprintf = _fprintf;
function _llvm_va_end() {}
function __exit(status) {
  function ExitStatus() {
    this.name = "ExitStatus";
    this.message = "Program terminated with exit(" + status + ")";
    this.status = status;
  }
  ExitStatus.prototype = new Error;
  ExitStatus.prototype.constructor = ExitStatus;
  exitRuntime();
  ABORT = true;
  throw new ExitStatus;
}
function _exit(status) {
  __exit(status);
}
function _strncmp(px, py, n) {
  var i = 0;
  while (i < n) {
    var x = HEAPU8[px + i];
    var y = HEAPU8[py + i];
    if (x == y && x == 0) return 0;
    if (x == 0) return -1;
    if (y == 0) return 1;
    if (x == y) {
      i++;
      continue;
    } else {
      return x > y ? 1 : -1;
    }
  }
  return 0;
}
function _pclose(stream) {
  ___setErrNo(ERRNO_CODES.ECHILD);
  return -1;
}
function _strcmp(px, py) {
  return _strncmp(px, py, TOTAL_MEMORY);
}
var _strcoll = _strcmp;
function _strlen(ptr) {
  return String_len(ptr);
}
function _strcpy(pdest, psrc) {
  var i = 0;
  do {
    HEAP8[pdest + i] = HEAP8[psrc + i];
    i++;
  } while (HEAP8[psrc + (i - 1)] != 0);
  return pdest;
}
function _snprintf(s, n, format, varargs) {
  var result = __formatString(format, varargs);
  var limit = n === undefined ? result.length : Math.min(result.length, n - 1);
  for (var i = 0; i < limit; i++) {
    HEAP8[s + i] = result[i];
  }
  HEAP8[s + i] = 0;
  return result.length;
}
function _memset(ptr, value, num, align) {
  if (num >= 20) {
    var stop = ptr + num;
    while (ptr % 4) {
      HEAP8[ptr++] = value;
    }
    if (value < 0) value += 256;
    var ptr4 = ptr >> 2, stop4 = stop >> 2, value4 = value | value << 8 | value << 16 | value << 24;
    while (ptr4 < stop4) {
      HEAP32[ptr4++] = value4;
    }
    ptr = ptr4 << 2;
    while (ptr < stop) {
      HEAP8[ptr++] = value;
    }
  } else {
    while (num--) {
      HEAP8[ptr++] = value;
    }
  }
}
var _llvm_memset_p0i8_i32 = _memset;
var _log = Math.log;
var _exp = Math.exp;
var _sqrt = Math.sqrt;
function _popen(command, mode) {
  ___setErrNo(ERRNO_CODES.EMFILE);
  return 0;
}
var ___flock_struct_layout = null;
function _fcntl(fildes, cmd, varargs, dup2) {
  if (!FS.streams[fildes]) {
    ___setErrNo(ERRNO_CODES.EBADF);
    return -1;
  }
  var stream = FS.streams[fildes];
  switch (cmd) {
   case 0:
    var arg = HEAP32[varargs >> 2];
    if (arg < 0) {
      ___setErrNo(ERRNO_CODES.EINVAL);
      return -1;
    }
    var newStream = {};
    for (var member in stream) {
      newStream[member] = stream[member];
    }
    arg = dup2 ? arg : Math.max(arg, FS.streams.length);
    for (var i = FS.streams.length; i < arg; i++) {
      FS.streams[i] = null;
    }
    FS.streams[arg] = newStream;
    return arg;
   case 1:
   case 2:
    return 0;
   case 3:
    var flags = 0;
    if (stream.isRead && stream.isWrite) flags = 2; else if (!stream.isRead && stream.isWrite) flags = 1; else if (stream.isRead && !stream.isWrite) flags = 0;
    if (stream.isAppend) flags |= 8;
    return flags;
   case 4:
    var arg = HEAP32[varargs >> 2];
    stream.isAppend = Boolean(arg | 8);
    return 0;
   case 7:
   case 20:
    var arg = HEAP32[varargs >> 2];
    var offset = ___flock_struct_layout.l_type;
    HEAP16[arg + offset >> 1] = 3;
    return 0;
   case 8:
   case 9:
   case 21:
   case 22:
    return 0;
   case 6:
   case 5:
    ___setErrNo(ERRNO_CODES.EINVAL);
    return -1;
   default:
    ___setErrNo(ERRNO_CODES.EINVAL);
    return -1;
  }
  return -1;
}
function _fileno(stream) {
  return stream;
}
function _fflush(stream) {
  var flush = (function(filedes) {
    if (FS.streams[filedes] && FS.streams[filedes].object.output) {
      if (!FS.streams[filedes].isTerminal) {
        FS.streams[filedes].object.output(null);
      }
    }
  });
  try {
    if (stream === 0) {
      for (var i = 0; i < FS.streams.length; i++) if (FS.streams[i]) flush(i);
    } else {
      flush(stream);
    }
    return 0;
  } catch (e) {
    ___setErrNo(ERRNO_CODES.EIO);
    return -1;
  }
}
var _vsnprintf = _snprintf;
function ___libgenSplitName(path) {
  if (path === 0 || HEAP8[path] === 0) {
    var me = ___libgenSplitName;
    if (!me.ret) {
      me.ret = allocate([ ".".charCodeAt(0), 0 ], "i8", ALLOC_NORMAL);
    }
    return [ me.ret, -1 ];
  } else {
    var slash = "/".charCodeAt(0);
    var allSlashes = true;
    var slashPositions = [];
    for (var i = 0; HEAP8[path + i] !== 0; i++) {
      if (HEAP8[path + i] === slash) {
        slashPositions.push(i);
      } else {
        allSlashes = false;
      }
    }
    var length = i;
    if (allSlashes) {
      HEAP8[path + 1] = 0;
      return [ path, -1 ];
    } else {
      while (slashPositions.length && slashPositions[slashPositions.length - 1] == length - 1) {
        HEAP8[path + slashPositions.pop(i)] = 0;
        length--;
      }
      return [ path, slashPositions.pop() ];
    }
  }
}
function _basename(path) {
  var result = ___libgenSplitName(path);
  return result[0] + result[1] + 1;
}
function _nl_langinfo(item) {
  var result;
  switch (item) {
   case 0:
    result = "ANSI_X3.4-1968";
    break;
   case 1:
    result = "%a %b %e %H:%M:%S %Y";
    break;
   case 2:
    result = "%m/%d/%y";
    break;
   case 3:
    result = "%H:%M:%S";
    break;
   case 4:
    result = "%I:%M:%S %p";
    break;
   case 5:
    result = "AM";
    break;
   case 6:
    result = "PM";
    break;
   case 7:
    result = "Sunday";
    break;
   case 8:
    result = "Monday";
    break;
   case 9:
    result = "Tuesday";
    break;
   case 10:
    result = "Wednesday";
    break;
   case 11:
    result = "Thursday";
    break;
   case 12:
    result = "Friday";
    break;
   case 13:
    result = "Saturday";
    break;
   case 14:
    result = "Sun";
    break;
   case 15:
    result = "Mon";
    break;
   case 16:
    result = "Tue";
    break;
   case 17:
    result = "Wed";
    break;
   case 18:
    result = "Thu";
    break;
   case 19:
    result = "Fri";
    break;
   case 20:
    result = "Sat";
    break;
   case 21:
    result = "January";
    break;
   case 22:
    result = "February";
    break;
   case 23:
    result = "March";
    break;
   case 24:
    result = "April";
    break;
   case 25:
    result = "May";
    break;
   case 26:
    result = "June";
    break;
   case 27:
    result = "July";
    break;
   case 28:
    result = "August";
    break;
   case 29:
    result = "September";
    break;
   case 30:
    result = "October";
    break;
   case 31:
    result = "November";
    break;
   case 32:
    result = "December";
    break;
   case 33:
    result = "Jan";
    break;
   case 34:
    result = "Feb";
    break;
   case 35:
    result = "Mar";
    break;
   case 36:
    result = "Apr";
    break;
   case 37:
    result = "May";
    break;
   case 38:
    result = "Jun";
    break;
   case 39:
    result = "Jul";
    break;
   case 40:
    result = "Aug";
    break;
   case 41:
    result = "Sep";
    break;
   case 42:
    result = "Oct";
    break;
   case 43:
    result = "Nov";
    break;
   case 44:
    result = "Dec";
    break;
   case 49:
    result = "";
    break;
   case 50:
    result = ".";
    break;
   case 51:
    result = "";
    break;
   case 52:
    result = "^[yY]";
    break;
   case 53:
    result = "^[nN]";
    break;
   case 56:
    result = "-";
    break;
   case 45:
   case 46:
   case 47:
   case 48:
   default:
    result = "";
    break;
  }
  var me = _nl_langinfo;
  if (!me.ret) me.ret = _malloc(32);
  for (var i = 0; i < result.length; i++) {
    HEAP8[me.ret + i] = result.charCodeAt(i);
  }
  HEAP8[me.ret + i] = 0;
  return me.ret;
}
function __parseInt(str, endptr, base, min, max, bits, unsign) {
  while (_isspace(HEAP8[str])) str++;
  var multiplier = 1;
  if (HEAP8[str] == "-".charCodeAt(0)) {
    multiplier = -1;
    str++;
  } else if (HEAP8[str] == "+".charCodeAt(0)) {
    str++;
  }
  var finalBase = base;
  if (!finalBase) {
    if (HEAP8[str] == "0".charCodeAt(0)) {
      if (HEAP8[str + 1] == "x".charCodeAt(0) || HEAP8[str + 1] == "X".charCodeAt(0)) {
        finalBase = 16;
        str += 2;
      } else {
        finalBase = 8;
        str++;
      }
    }
  }
  if (!finalBase) finalBase = 10;
  var chr;
  var ret = 0;
  while ((chr = HEAP8[str]) != 0) {
    var digit = parseInt(String.fromCharCode(chr), finalBase);
    if (isNaN(digit)) {
      break;
    } else {
      ret = ret * finalBase + digit;
      str++;
    }
  }
  ret *= multiplier;
  if (endptr) {
    HEAP32[endptr >> 2] = str;
  }
  if (unsign) {
    if (Math.abs(ret) > max) {
      ret = max;
      ___setErrNo(ERRNO_CODES.ERANGE);
    } else {
      ret = unSign(ret, bits);
    }
  }
  if (ret > max || ret < min) {
    ret = ret > max ? max : min;
    ___setErrNo(ERRNO_CODES.ERANGE);
  }
  if (bits == 64) {
    ret = [ ret >>> 0, Math.min(Math.floor(ret / 4294967296), 4294967295) ];
  }
  return ret;
}
function _strtol(str, endptr, base) {
  return __parseInt(str, endptr, base, -2147483648, 2147483647, 32);
}
function _atoi(ptr) {
  return _strtol(ptr, null, 10);
}
function ___errno_location() {
  return ___setErrNo.ret;
}
var ___errno = ___errno_location;
function _isatty(fildes) {
  if (!FS.streams[fildes]) {
    ___setErrNo(ERRNO_CODES.EBADF);
    return 0;
  }
  if (FS.streams[fildes].isTerminal) return 1;
  ___setErrNo(ERRNO_CODES.ENOTTY);
  return 0;
}
function _strncpy(pdest, psrc, num) {
  var padding = false, curr;
  for (var i = 0; i < num; i++) {
    curr = padding ? 0 : HEAP8[psrc + i];
    HEAP8[pdest + i] = curr;
    padding = padding || HEAP8[psrc + i] == 0;
  }
  return pdest;
}
function _sbrk(bytes) {
  var self = _sbrk;
  if (!self.called) {
    STATICTOP = alignMemoryPage(STATICTOP);
    self.called = true;
    _sbrk.DYNAMIC_START = STATICTOP;
  }
  var ret = STATICTOP;
  if (bytes != 0) Runtime.staticAlloc(bytes);
  return ret;
}
function _tolower(chr) {
  if (chr >= "A".charCodeAt(0) && chr <= "Z".charCodeAt(0)) {
    return chr - "A".charCodeAt(0) + "a".charCodeAt(0);
  } else {
    return chr;
  }
}
function _toupper(chr) {
  if (chr >= "a".charCodeAt(0) && chr <= "z".charCodeAt(0)) {
    return chr - "a".charCodeAt(0) + "A".charCodeAt(0);
  } else {
    return chr;
  }
}
function _isxdigit(chr) {
  return chr >= "0".charCodeAt(0) && chr <= "9".charCodeAt(0) || chr >= "a".charCodeAt(0) && chr <= "f".charCodeAt(0) || chr >= "A".charCodeAt(0) && chr <= "F".charCodeAt(0);
}
function _isupper(chr) {
  return chr >= "A".charCodeAt(0) && chr <= "Z".charCodeAt(0);
}
function _abort() {
  ABORT = true;
  throw "abort() at " + (new Error).stack;
}
function _sysconf(name) {
  switch (name) {
   case 8:
    return PAGE_SIZE;
   case 54:
   case 56:
   case 21:
   case 61:
   case 63:
   case 22:
   case 67:
   case 23:
   case 24:
   case 25:
   case 26:
   case 27:
   case 69:
   case 28:
   case 101:
   case 70:
   case 71:
   case 29:
   case 30:
   case 199:
   case 75:
   case 76:
   case 32:
   case 43:
   case 44:
   case 80:
   case 46:
   case 47:
   case 45:
   case 48:
   case 49:
   case 42:
   case 82:
   case 33:
   case 7:
   case 108:
   case 109:
   case 107:
   case 112:
   case 119:
   case 121:
    return 200809;
   case 13:
   case 104:
   case 94:
   case 95:
   case 34:
   case 35:
   case 77:
   case 81:
   case 83:
   case 84:
   case 85:
   case 86:
   case 87:
   case 88:
   case 89:
   case 90:
   case 91:
   case 94:
   case 95:
   case 110:
   case 111:
   case 113:
   case 114:
   case 115:
   case 116:
   case 117:
   case 118:
   case 120:
   case 40:
   case 16:
   case 79:
   case 19:
    return -1;
   case 92:
   case 93:
   case 5:
   case 72:
   case 6:
   case 74:
   case 92:
   case 93:
   case 96:
   case 97:
   case 98:
   case 99:
   case 102:
   case 103:
   case 105:
    return 1;
   case 38:
   case 66:
   case 50:
   case 51:
   case 4:
    return 1024;
   case 15:
   case 64:
   case 41:
    return 32;
   case 55:
   case 37:
   case 17:
    return 2147483647;
   case 18:
   case 1:
    return 47839;
   case 59:
   case 57:
    return 99;
   case 68:
   case 58:
    return 2048;
   case 0:
    return 2097152;
   case 3:
    return 65536;
   case 14:
    return 32768;
   case 73:
    return 32767;
   case 39:
    return 16384;
   case 60:
    return 1e3;
   case 106:
    return 700;
   case 52:
    return 256;
   case 62:
    return 255;
   case 2:
    return 100;
   case 65:
    return 64;
   case 36:
    return 20;
   case 100:
    return 16;
   case 20:
    return 6;
   case 53:
    return 4;
  }
  ___setErrNo(ERRNO_CODES.EINVAL);
  return -1;
}
function _time(ptr) {
  var ret = Math.floor(Date.now() / 1e3);
  if (ptr) {
    HEAP32[ptr >> 2] = ret;
  }
  return ret;
}
function _fputc(c, stream) {
  var chr = unSign(c & 255);
  HEAP8[_fputc.ret] = chr;
  var ret = _write(stream, _fputc.ret, 1);
  if (ret == -1) {
    if (FS.streams[stream]) FS.streams[stream].error = true;
    return -1;
  } else {
    return chr;
  }
}
function _fputs(s, stream) {
  return _write(stream, s, _strlen(s));
}
function _puts(s) {
  var stdout = HEAP32[_stdout >> 2];
  var ret = _fputs(s, stdout);
  if (ret < 0) {
    return ret;
  } else {
    var newlineRet = _fputc("\n".charCodeAt(0), stdout);
    return newlineRet < 0 ? -1 : ret + 1;
  }
}
var Browser = {
  mainLoop: {
    scheduler: null,
    shouldPause: false,
    paused: false,
    queue: [],
    pause: (function() {
      Browser.mainLoop.shouldPause = true;
    }),
    resume: (function() {
      if (Browser.mainLoop.paused) {
        Browser.mainLoop.paused = false;
        Browser.mainLoop.scheduler();
      }
      Browser.mainLoop.shouldPause = false;
    }),
    updateStatus: (function() {
      if (Module["setStatus"]) {
        var message = Module["statusMessage"] || "Please wait...";
        var remaining = Browser.mainLoop.remainingBlockers;
        var expected = Browser.mainLoop.expectedBlockers;
        if (remaining) {
          if (remaining < expected) {
            Module["setStatus"](message + " (" + (expected - remaining) + "/" + expected + ")");
          } else {
            Module["setStatus"](message);
          }
        } else {
          Module["setStatus"]("");
        }
      }
    })
  },
  pointerLock: false,
  moduleContextCreatedCallbacks: [],
  workers: [],
  ensureObjects: (function() {
    if (Browser.ensured) return;
    Browser.ensured = true;
    try {
      new Blob;
      Browser.hasBlobConstructor = true;
    } catch (e) {
      Browser.hasBlobConstructor = false;
      console.log("warning: no blob constructor, cannot create blobs with mimetypes");
    }
    Browser.BlobBuilder = typeof MozBlobBuilder != "undefined" ? MozBlobBuilder : typeof WebKitBlobBuilder != "undefined" ? WebKitBlobBuilder : !Browser.hasBlobConstructor ? console.log("warning: no BlobBuilder") : null;
    Browser.URLObject = typeof window != "undefined" ? window.URL ? window.URL : window.webkitURL : console.log("warning: cannot create object URLs");
    function getMimetype(name) {
      return {
        "jpg": "image/jpeg",
        "png": "image/png",
        "bmp": "image/bmp",
        "ogg": "audio/ogg",
        "wav": "audio/wav",
        "mp3": "audio/mpeg"
      }[name.substr(-3)];
      return ret;
    }
    if (!Module["preloadPlugins"]) Module["preloadPlugins"] = [];
    var imagePlugin = {};
    imagePlugin["canHandle"] = (function(name) {
      return name.substr(-4) in {
        ".jpg": 1,
        ".png": 1,
        ".bmp": 1
      };
    });
    imagePlugin["handle"] = (function(byteArray, name, onload, onerror) {
      var b = null;
      if (Browser.hasBlobConstructor) {
        try {
          b = new Blob([ byteArray ], {
            type: getMimetype(name)
          });
        } catch (e) {
          Runtime.warnOnce("Blob constructor present but fails: " + e + "; falling back to blob builder");
        }
      }
      if (!b) {
        var bb = new Browser.BlobBuilder;
        bb.append((new Uint8Array(byteArray)).buffer);
        b = bb.getBlob();
      }
      var url = Browser.URLObject.createObjectURL(b);
      assert(typeof url == "string", "createObjectURL must return a url as a string");
      var img = new Image;
      img.onload = (function() {
        assert(img.complete, "Image " + name + " could not be decoded");
        var canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;
        var ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0);
        Module["preloadedImages"][name] = canvas;
        Browser.URLObject.revokeObjectURL(url);
        if (onload) onload(byteArray);
      });
      img.onerror = (function(event) {
        console.log("Image " + url + " could not be decoded");
        if (onerror) onerror();
      });
      img.src = url;
    });
    Module["preloadPlugins"].push(imagePlugin);
    var audioPlugin = {};
    audioPlugin["canHandle"] = (function(name) {
      return name.substr(-4) in {
        ".ogg": 1,
        ".wav": 1,
        ".mp3": 1
      };
    });
    audioPlugin["handle"] = (function(byteArray, name, onload, onerror) {
      var done = false;
      function finish(audio) {
        if (done) return;
        done = true;
        Module["preloadedAudios"][name] = audio;
        if (onload) onload(byteArray);
      }
      function fail() {
        if (done) return;
        done = true;
        Module["preloadedAudios"][name] = new Audio;
        if (onerror) onerror();
      }
      if (Browser.hasBlobConstructor) {
        try {
          var b = new Blob([ byteArray ], {
            type: getMimetype(name)
          });
        } catch (e) {
          return fail();
        }
        var url = Browser.URLObject.createObjectURL(b);
        assert(typeof url == "string", "createObjectURL must return a url as a string");
        var audio = new Audio;
        audio.addEventListener("canplaythrough", (function() {
          finish(audio);
        }), false);
        audio.onerror = (function(event) {
          if (done) return;
          console.log("warning: browser could not fully decode audio " + name + ", trying slower base64 approach");
          function encode64(data) {
            var BASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            var PAD = "=";
            var ret = "";
            var leftchar = 0;
            var leftbits = 0;
            for (var i = 0; i < data.length; i++) {
              leftchar = leftchar << 8 | data[i];
              leftbits += 8;
              while (leftbits >= 6) {
                var curr = leftchar >> leftbits - 6 & 63;
                leftbits -= 6;
                ret += BASE[curr];
              }
            }
            if (leftbits == 2) {
              ret += BASE[(leftchar & 3) << 4];
              ret += PAD + PAD;
            } else if (leftbits == 4) {
              ret += BASE[(leftchar & 15) << 2];
              ret += PAD;
            }
            return ret;
          }
          audio.src = "data:audio/x-" + name.substr(-3) + ";base64," + encode64(byteArray);
          finish(audio);
        });
        audio.src = url;
        setTimeout((function() {
          finish(audio);
        }), 1e4);
      } else {
        return fail();
      }
    });
    Module["preloadPlugins"].push(audioPlugin);
  }),
  createContext: (function(canvas, useWebGL, setInModule) {
    try {
      var ctx = canvas.getContext(useWebGL ? "experimental-webgl" : "2d");
      if (!ctx) throw ":(";
    } catch (e) {
      Module.print("Could not create canvas - " + e);
      return null;
    }
    if (useWebGL) {
      canvas.style.backgroundColor = "black";
      canvas.addEventListener("webglcontextlost", (function(event) {
        alert("WebGL context lost. You will need to reload the page.");
      }), false);
    }
    if (setInModule) {
      Module.ctx = ctx;
      Module.useWebGL = useWebGL;
      Browser.moduleContextCreatedCallbacks.forEach((function(callback) {
        callback();
      }));
    }
    return ctx;
  }),
  requestFullScreen: (function() {
    var canvas = Module["canvas"];
    function fullScreenChange() {
      var isFullScreen = false;
      if ((document["webkitFullScreenElement"] || document["webkitFullscreenElement"] || document["mozFullScreenElement"] || document["mozFullscreenElement"] || document["fullScreenElement"] || document["fullscreenElement"]) === canvas) {
        canvas.requestPointerLock = canvas["requestPointerLock"] || canvas["mozRequestPointerLock"] || canvas["webkitRequestPointerLock"];
        canvas.requestPointerLock();
        isFullScreen = true;
      }
      if (Module["onFullScreen"]) Module["onFullScreen"](isFullScreen);
    }
    document.addEventListener("fullscreenchange", fullScreenChange, false);
    document.addEventListener("mozfullscreenchange", fullScreenChange, false);
    document.addEventListener("webkitfullscreenchange", fullScreenChange, false);
    function pointerLockChange() {
      Browser.pointerLock = document["pointerLockElement"] === canvas || document["mozPointerLockElement"] === canvas || document["webkitPointerLockElement"] === canvas;
    }
    document.addEventListener("pointerlockchange", pointerLockChange, false);
    document.addEventListener("mozpointerlockchange", pointerLockChange, false);
    document.addEventListener("webkitpointerlockchange", pointerLockChange, false);
    canvas.requestFullScreen = canvas["requestFullScreen"] || canvas["mozRequestFullScreen"] || (canvas["webkitRequestFullScreen"] ? (function() {
      canvas["webkitRequestFullScreen"](Element["ALLOW_KEYBOARD_INPUT"]);
    }) : null);
    canvas.requestFullScreen();
  }),
  requestAnimationFrame: (function(func) {
    if (!window.requestAnimationFrame) {
      window.requestAnimationFrame = window["requestAnimationFrame"] || window["mozRequestAnimationFrame"] || window["webkitRequestAnimationFrame"] || window["msRequestAnimationFrame"] || window["oRequestAnimationFrame"] || window["setTimeout"];
    }
    window.requestAnimationFrame(func);
  }),
  getMovementX: (function(event) {
    return event["movementX"] || event["mozMovementX"] || event["webkitMovementX"] || 0;
  }),
  getMovementY: (function(event) {
    return event["movementY"] || event["mozMovementY"] || event["webkitMovementY"] || 0;
  }),
  xhrLoad: (function(url, onload, onerror) {
    var xhr = new XMLHttpRequest;
    xhr.open("GET", url, true);
    xhr.responseType = "arraybuffer";
    xhr.onload = (function() {
      if (xhr.status == 200) {
        onload(xhr.response);
      } else {
        onerror();
      }
    });
    xhr.onerror = onerror;
    xhr.send(null);
  }),
  asyncLoad: (function(url, onload, onerror) {
    Browser.xhrLoad(url, (function(arrayBuffer) {
      assert(arrayBuffer, 'Loading data file "' + url + '" failed (no arrayBuffer).');
      onload(new Uint8Array(arrayBuffer));
      removeRunDependency("al " + url);
    }), (function(event) {
      if (onerror) {
        onerror();
      } else {
        throw 'Loading data file "' + url + '" failed.';
      }
    }));
    addRunDependency("al " + url);
  }),
  resizeListeners: [],
  updateResizeListeners: (function() {
    var canvas = Module["canvas"];
    Browser.resizeListeners.forEach((function(listener) {
      listener(canvas.width, canvas.height);
    }));
  }),
  setCanvasSize: (function(width, height, noUpdates) {
    var canvas = Module["canvas"];
    canvas.width = width;
    canvas.height = height;
    if (!noUpdates) Browser.updateResizeListeners();
  })
};
__ATINIT__.unshift({
  func: (function() {
    if (!Module["noFSInit"] && !FS.init.initialized) FS.init();
  })
});
__ATMAIN__.push({
  func: (function() {
    FS.ignorePermissions = false;
  })
});
__ATEXIT__.push({
  func: (function() {
    FS.quit();
  })
});
Module["FS_createFolder"] = FS.createFolder;
Module["FS_createPath"] = FS.createPath;
Module["FS_createDataFile"] = FS.createDataFile;
Module["FS_createPreloadedFile"] = FS.createPreloadedFile;
Module["FS_createLazyFile"] = FS.createLazyFile;
Module["FS_createLink"] = FS.createLink;
Module["FS_createDevice"] = FS.createDevice;
___setErrNo(0);
_fgetc.ret = allocate([ 0 ], "i8", ALLOC_STATIC);
_fputc.ret = allocate([ 0 ], "i8", ALLOC_STATIC);
Module["requestFullScreen"] = (function() {
  Browser.requestFullScreen();
});
Module["requestAnimationFrame"] = (function(func) {
  Browser.requestAnimationFrame(func);
});
Module["pauseMainLoop"] = (function() {
  Browser.mainLoop.pause();
});
Module["resumeMainLoop"] = (function() {
  Browser.mainLoop.resume();
});
Module.callMain = function callMain(args) {
  var argc = args.length + 1;
  function pad() {
    for (var i = 0; i < 4 - 1; i++) {
      argv.push(0);
    }
  }
  var argv = [ allocate(intArrayFromString("/bin/this.program"), "i8", ALLOC_STATIC) ];
  pad();
  for (var i = 0; i < argc - 1; i = i + 1) {
    argv.push(allocate(intArrayFromString(args[i]), "i8", ALLOC_STATIC));
    pad();
  }
  argv.push(0);
  argv = allocate(argv, "i32", ALLOC_STATIC);
  try {
    return _main(argc, argv, 0);
  } catch (e) {
    if (e.name == "ExitStatus") return e.status;
    throw e;
  }
};
var _infile;
var _EMPTY;
var _maxfld;
var _record;
var _RECSIZE;
var _fields;
var _fldtab;
var _field0;
var _donefld_b;
var _donerec_b;
var _file;
var _stdin;
var _mustfld_b;
var _MAXFLD;
var _errorflag;
var _stderr;
var _FINIT;
var _yynerrs;
var _yychar;
var _yypact;
var _yycheck;
var _yytable;
var _yylval;
var _yypgoto;
var _yydefgoto;
var _winner;
var _true;
var _false;
var _filenum;
var _files;
var _tmps;
var _nullval;
var _pairstack;
var _print_s;
var _print_ssz;
var _paircnt;
var _dbg_b;
var _radixchar;
var _radixcharlen;
var _mb_cur_max_b;
var _progname;
var _lexprog;
var _svargc;
var _svargv;
var _llvm_used;
var _proctab;
var _yyin;
var _yyout;
var _lineno;
var _yylex_sc_flag_b;
var _yy_start;
var _yy_init_b;
var _stdout;
var _yy_buffer_stack;
var _yy_c_buf_p;
var _yy_hold_char;
var _yy_ec;
var _yy_accept;
var _yy_last_accepting_state;
var _yy_last_accepting_cpos;
var _yy_base;
var _yy_chk;
var _yy_def;
var _yy_meta;
var _yy_nxt;
var _yytext;
var _yyleng;
var _clen;
var _cbuf;
var _yy_n_chars;
var _yy_buffer_stack_max;
var _symtab;
var __str2320;
var _recloc;
var _FS;
var _RS;
var _OFS;
var _ORS;
var _OFMT;
var _FILENAME;
var _NF;
var _nrloc;
var _NR;
var _libuxre_lc_collate_curinfo;
var __gm_;
var _mparams;
_infile = allocate(4, "i8", ALLOC_STATIC);
_EMPTY = allocate(1, "i8", ALLOC_STATIC);
_maxfld = allocate(4, "i8", ALLOC_STATIC);
_record = allocate(4, "i8", ALLOC_STATIC);
_RECSIZE = allocate(4, "i8", ALLOC_STATIC);
_fields = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str = allocate([ 114, 101, 99, 111, 114, 100, 32, 96, 37, 46, 50, 48, 115, 46, 46, 46, 39, 32, 116, 111, 111, 32, 108, 111, 110, 103, 0 ], "i8", ALLOC_STATIC);
_fldtab = allocate(4, "i8", ALLOC_STATIC);
_field0 = allocate([ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0 ], [ "*", 0, 0, 0, "*", 0, 0, 0, "double", 0, 0, 0, 0, 0, 0, 0, "i32", 0, 0, 0, "*", 0, 0, 0 ], ALLOC_STATIC);
STRING_TABLE.__str1 = allocate([ 42, 42, 82, 83, 61, 37, 111, 44, 32, 42, 42, 70, 83, 61, 37, 111, 10, 0 ], "i8", ALLOC_STATIC);
_donefld_b = allocate(4, "i8", ALLOC_STATIC);
_donerec_b = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str2 = allocate([ 115, 118, 97, 114, 103, 99, 61, 37, 100, 44, 32, 42, 115, 118, 97, 114, 103, 118, 61, 37, 115, 10, 0 ], "i8", ALLOC_STATIC);
_file = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str3 = allocate([ 111, 112, 101, 110, 105, 110, 103, 32, 102, 105, 108, 101, 32, 37, 115, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str4 = allocate([ 115, 116, 97, 110, 100, 97, 114, 100, 32, 105, 110, 112, 117, 116, 32, 97, 108, 114, 101, 97, 100, 121, 32, 117, 115, 101, 100, 32, 102, 111, 114, 32, 114, 101, 97, 100, 105, 110, 103, 32, 99, 111, 109, 109, 97, 110, 100, 115, 0 ], "i8", ALLOC_STATIC);
_mustfld_b = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str7 = allocate([ 99, 111, 109, 109, 97, 110, 100, 32, 108, 105, 110, 101, 32, 115, 101, 116, 32, 37, 115, 32, 116, 111, 32, 124, 37, 115, 124, 10, 0 ], "i8", ALLOC_STATIC);
_MAXFLD = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str9 = allocate([ 102, 105, 101, 108, 100, 32, 37, 100, 58, 32, 124, 37, 115, 124, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str10 = allocate([ 105, 110, 32, 114, 101, 99, 98, 108, 100, 32, 70, 83, 61, 37, 108, 111, 44, 32, 114, 101, 99, 108, 111, 99, 61, 37, 108, 111, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str11 = allocate([ 114, 101, 99, 98, 108, 100, 32, 61, 32, 124, 37, 115, 124, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str12 = allocate([ 116, 114, 121, 105, 110, 103, 32, 116, 111, 32, 97, 99, 99, 101, 115, 115, 32, 102, 105, 101, 108, 100, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
_errorflag = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str13 = allocate([ 37, 115, 58, 32, 37, 115, 32, 110, 101, 97, 114, 32, 108, 105, 110, 101, 32, 37, 108, 108, 100, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str14 = allocate([ 37, 115, 58, 32, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str16 = allocate([ 32, 114, 101, 99, 111, 114, 100, 32, 110, 117, 109, 98, 101, 114, 32, 37, 103, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str19 = allocate([ 114, 101, 99, 111, 114, 100, 32, 96, 37, 46, 50, 48, 115, 46, 46, 46, 39, 32, 104, 97, 115, 32, 116, 111, 111, 32, 109, 97, 110, 121, 32, 102, 105, 101, 108, 100, 115, 0 ], "i8", ALLOC_STATIC);
_FINIT = allocate([ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0 ], [ "*", 0, 0, 0, "*", 0, 0, 0, "double", 0, 0, 0, 0, 0, 0, 0, "i32", 0, 0, 0, "*", 0, 0, 0 ], ALLOC_STATIC);
STRING_TABLE.__str20 = allocate([ 111, 117, 116, 32, 111, 102, 32, 115, 112, 97, 99, 101, 32, 105, 110, 32, 65, 76, 76, 79, 67, 0 ], "i8", ALLOC_STATIC);
_yynerrs = allocate(4, "i8", ALLOC_STATIC);
_yychar = allocate(4, "i8", ALLOC_STATIC);
_yypact = allocate([ 772, 0, -106, 0, -85, 0, 10, 0, -9, 0, -106, 0, -106, 0, -106, 0, 1133, 0, 219, 0, -77, 0, 1602, 0, -38, 0, 1493, 0, -14, 0, -12, 0, -10, 0, -47, 0, -106, 0, -106, 0, -106, 0, 1493, 0, 1638, 0, 1638, 0, -106, 0, 181, 0, 181, 0, 1638, 0, -106, 0, -106, 0, 17, 0, -106, 0, -106, 0, -106, 0, -31, 0, 111, 0, 1529, 0, -29, 0, -43, 0, -106, 0, -106, 0, -106, 0, 1602, 0, 1602, 0, -5, 0, -3, 0, 3, 0, -29, 0, 808, 0, -29, 0, -29, 0, 1638, 0, -106, 0, -106, 0, 629, 0, 1638, 0, -29, 0, -106, 0, 629, 0, -106, 0, -106, 0, 1602, 0, 969, 0, -106, 0, -25, 0, 1638, 0, -106, 0, 1638, 0, 1638, 0, 1247, 0, 1638, 0, 2, 0, 24, 0, 1206, 0, 55, 0, 28, 0, 15, 0, -106, 0, -106, 0, 75, 0, -106, 0, -106, 0, -106, 0, 289, 0, -106, 0, 1638, 0, -106, 0, -106, 0, 1638, 0, 1638, 0, 1638, 0, 1638, 0, 1638, 0, 48, 0, 1638, 0, 111, 0, -106, 0, -106, 0, -106, 0, 1493, 0, 1493, 0, -106, 0, 1493, 0, -20, 0, -20, 0, 1566, 0, 1566, 0, 672, 0, -106, 0, 808, 0, -106, 0, -106, 0, -106, 0, 1288, 0, 357, 0, 90, 0, -106, 0, -106, 0, 425, 0, 887, 0, -66, 0, 1638, 0, 1638, 0, 1010, 0, 1051, 0, 1092, 0, -106, 0, 1329, 0, 1169, 0, -106, 0, -106, 0, -106, 0, -106, 0, 52, 0, -106, 0, 1638, 0, 14, 0, 14, 0, -106, 0, -106, 0, -106, 0, -106, 0, 674, 0, 82, 0, -106, 0, 493, 0, -17, 0, -106, 0, -106, 0, 1638, 0, 1638, 0, 1566, 0, 1566, 0, -106, 0, -23, 0, -106, 0, 1529, 0, -106, 0, -13, 0, -28, 0, 38, 0, -106, 0, -106, 0, 106, 0, 629, 0, -106, 0, -106, 0, 1638, 0, 1638, 0, 80, 0, 1638, 0, 1638, 0, -106, 0, -106, 0, -106, 0, -106, 0, -106, 0, 1638, 0, 1638, 0, -106, 0, 49, 0, 58, 0, 24, 0, 1206, 0, 28, 0, 1566, 0, 1566, 0, 106, 0, 106, 0, 88, 0, 851, 0, -106, 0, -106, 0, -106, 0, -18, 0, 1370, 0, 928, 0, 561, 0, -106, 0, 89, 0, -106, 0, -106, 0, -106, 0, 56, 0, 731, 0, -26, 0, -106, 0, 1638, 0, -106, 0, -106, 0, 1638, 0, -106, 0, 106, 0, 59, 0, 731, 0, 1411, 0, 1452, 0, 629, 0, 106, 0, 60, 0, -106, 0, -106, 0, -106, 0, 629, 0, 106, 0, -106, 0, 629, 0, -106, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
STRING_TABLE._yytranslate = allocate([ 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 70, 76, 2, 2, 68, 91, 74, 72, 94, 73, 2, 75, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 96, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 92, 2, 93, 69, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 89, 95, 90, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 71, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88 ], "i8", ALLOC_STATIC);
_yycheck = allocate([ 8, 0, 30, 0, 107, 0, 11, 0, 89, 0, 13, 0, 49, 0, 50, 0, 29, 0, 8, 0, 0, 0, 39, 0, 89, 0, 21, 0, 13, 0, 22, 0, 23, 0, 48, 0, 25, 0, 26, 0, 27, 0, 30, 0, 21, 0, 49, 0, 50, 0, 91, 0, 49, 0, 50, 0, 94, 0, 36, 0, 68, 0, 52, 0, 49, 0, 50, 0, 42, 0, 43, 0, 49, 0, 50, 0, 54, 0, 60, 0, 48, 0, 61, 0, 58, 0, 51, 0, 13, 0, 92, 0, 89, 0, 30, 0, 55, 0, 80, 0, 81, 0, 94, 0, 21, 0, 61, 0, 68, 0, 62, 0, 68, 0, 65, 0, 68, 0, 67, 0, 68, 0, 69, 0, 70, 0, 68, 0, 92, 0, 68, 0, 73, 0, 96, 0, 91, 0, 94, 0, 96, 0, 68, 0, 89, 0, 91, 0, 8, 0, 95, 0, 94, 0, 85, 0, 91, 0, 13, 0, 101, 0, 88, 0, 89, 0, 90, 0, 91, 0, 92, 0, 94, 0, 21, 0, 74, 0, 75, 0, 76, 0, 99, 0, 100, 0, 91, 0, 102, 0, 80, 0, 81, 0, 105, 0, 106, 0, 204, 0, 99, 0, 100, 0, 109, 0, 102, 0, 49, 0, 50, 0, 113, 0, 49, 0, 50, 0, 214, 0, 42, 0, 43, 0, 119, 0, 121, 0, 122, 0, 91, 0, 123, 0, 124, 0, 125, 0, 91, 0, 127, 0, 128, 0, 47, 0, 75, 0, 22, 0, 23, 0, 36, 0, 75, 0, 135, 0, 27, 0, 99, 0, 100, 0, 50, 0, 102, 0, 96, 0, 142, 0, 30, 0, 57, 0, 36, 0, 50, 0, 91, 0, 149, 0, 150, 0, 151, 0, 152, 0, 57, 0, 152, 0, 91, 0, 164, 0, 156, 0, 91, 0, 91, 0, 106, 0, 152, 0, 21, 0, 176, 0, 61, 0, 55, 0, 104, 0, -1, 0, 167, 0, 168, 0, 170, 0, 171, 0, 62, 0, 99, 0, 100, 0, 93, 0, 102, 0, -1, 0, 177, 0, 178, 0, -1, 0, -1, 0, -1, 0, 73, 0, 183, 0, 185, 0, 186, 0, -1, 0, -1, 0, -1, 0, 190, 0, 72, 0, 73, 0, 74, 0, 75, 0, 76, 0, 195, 0, 196, 0, 88, 0, 89, 0, 90, 0, 91, 0, 92, 0, -1, 0, -1, 0, 151, 0, 152, 0, 207, 0, -1, 0, 217, 0, 210, 0, 47, 0, 48, 0, 49, 0, 50, 0, 223, 0, 215, 0, 216, 0, 226, 0, 109, 0, 56, 0, -1, 0, -1, 0, 113, 0, -1, 0, -1, 0, 152, 0, -1, 0, 1, 0, 119, 0, -1, 0, -1, 0, -1, 0, 123, 0, 124, 0, 125, 0, -1, 0, 127, 0, 128, 0, 185, 0, 186, 0, -1, 0, -1, 0, -1, 0, 190, 0, 135, 0, 57, 0, 58, 0, -1, 0, -1, 0, -1, 0, -1, 0, 142, 0, -1, 0, -1, 0, -1, 0, 67, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 35, 0, -1, 0, 37, 0, 38, 0, 156, 0, 40, 0, 41, 0, 42, 0, 43, 0, -1, 0, -1, 0, 109, 0, -1, 0, 86, 0, 87, 0, 167, 0, 168, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, 177, 0, 178, 0, -1, 0, -1, 0, -1, 0, -1, 0, 183, 0, 67, 0, 68, 0, -1, 0, -1, 0, 1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, 195, 0, 196, 0, 80, 0, 81, 0, -1, 0, -1, 0, 187, 0, 188, 0, 86, 0, 87, 0, -1, 0, 89, 0, 90, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 96, 0, -1, 0, 215, 0, 216, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 35, 0, -1, 0, 37, 0, 38, 0, 212, 0, 40, 0, 41, 0, 42, 0, 43, 0, -1, 0, 218, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 224, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 1, 0, -1, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, 89, 0, 90, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 96, 0, -1, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 35, 0, -1, 0, 37, 0, 38, 0, -1, 0, 40, 0, 41, 0, 42, 0, 43, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 1, 0, -1, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, 89, 0, 90, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 96, 0, -1, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 35, 0, -1, 0, 37, 0, 38, 0, -1, 0, 40, 0, 41, 0, 42, 0, 43, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 1, 0, -1, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, 89, 0, 90, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 96, 0, -1, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 35, 0, -1, 0, 37, 0, 38, 0, -1, 0, 40, 0, 41, 0, 42, 0, 43, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 1, 0, -1, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, 89, 0, 90, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 96, 0, -1, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 35, 0, -1, 0, 37, 0, 38, 0, -1, 0, 40, 0, 41, 0, 42, 0, 43, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 1, 0, -1, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, 89, 0, 90, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 96, 0, -1, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 35, 0, -1, 0, 37, 0, 38, 0, -1, 0, 40, 0, 41, 0, 42, 0, 43, 0, 1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 31, 0, 32, 0, 33, 0, 34, 0, 33, 0, 34, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, 89, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, 96, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, 1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 67, 0, 68, 0, -1, 0, 72, 0, 73, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, 80, 0, 81, 0, -1, 0, -1, 0, 86, 0, 87, 0, 86, 0, 87, 0, 31, 0, 32, 0, 33, 0, 34, 0, -1, 0, -1, 0, 96, 0, -1, 0, -1, 0, -1, 0, 0, 0, 1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 28, 0, 29, 0, 30, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, 51, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 30, 0, 67, 0, 68, 0, 33, 0, 34, 0, -1, 0, 72, 0, 73, 0, -1, 0, 75, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, 52, 0, 89, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, 33, 0, 34, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 51, 0, 52, 0, 96, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 33, 0, 34, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, 96, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, 94, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, 94, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, 94, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, 94, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 52, 0, 94, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, 29, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, -1, 0, 51, 0, 52, 0, 94, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 33, 0, 34, 0, -1, 0, 72, 0, 73, 0, -1, 0, 75, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, 52, 0, 89, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, 33, 0, 34, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, 93, 0, 57, 0, 58, 0, 59, 0, 60, 0, 61, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, -1, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, 33, 0, 34, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, -1, 0, -1, 0, -1, 0, 91, 0, 51, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 33, 0, 34, 0, -1, 0, 72, 0, 73, 0, -1, 0, 75, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, 60, 0, 61, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, 33, 0, 34, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, 51, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 33, 0, 34, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, 33, 0, 34, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0, 52, 0, -1, 0, 54, 0, 55, 0, -1, 0, 57, 0, 58, 0, 59, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 67, 0, 68, 0, -1, 0, -1, 0, -1, 0, 72, 0, 73, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 80, 0, 81, 0, -1, 0, -1, 0, -1, 0, -1, 0, 86, 0, 87, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yytable = allocate([ 36, 0, 96, 0, 160, 0, 62, 0, 5, 0, 36, 0, 99, 0, 100, 0, 83, 0, 33, 0, 6, 0, 189, 0, 60, 0, 73, 0, 33, 0, 76, 0, 76, 0, 85, 0, 80, 0, 81, 0, 76, 0, 7, 0, 72, 0, 185, 0, 186, 0, 166, 0, 185, 0, 186, 0, 122, 0, 76, 0, 65, 0, 114, 0, 99, 0, 100, 0, 62, 0, 62, 0, 185, 0, 186, 0, 115, 0, 118, 0, 109, 0, 147, 0, 117, 0, 113, 0, 66, 0, 70, 0, 101, 0, 84, 0, 76, 0, 86, 0, 87, 0, 102, 0, 74, 0, 119, 0, 67, 0, 76, 0, 68, 0, 123, 0, 69, 0, 124, 0, 125, 0, 127, 0, 128, 0, 105, 0, 70, 0, 106, 0, 76, 0, 97, 0, 187, 0, 122, 0, 214, 0, 107, 0, 176, 0, 206, 0, 40, 0, 148, 0, 207, 0, 135, 0, 188, 0, 40, 0, 145, 0, 76, 0, 76, 0, 76, 0, 76, 0, 76, 0, 142, 0, 75, 0, 90, 0, 91, 0, 92, 0, 36, 0, 36, 0, 129, 0, 36, 0, 86, 0, 87, 0, 156, 0, 156, 0, 213, 0, 33, 0, 33, 0, 76, 0, 33, 0, 99, 0, 100, 0, 76, 0, 185, 0, 186, 0, 219, 0, 103, 0, 104, 0, 76, 0, 167, 0, 168, 0, 130, 0, 76, 0, 76, 0, 76, 0, 132, 0, 76, 0, 76, 0, 133, 0, 24, 0, 77, 0, 78, 0, 163, 0, 174, 0, 76, 0, 82, 0, 143, 0, 144, 0, 100, 0, 146, 0, 190, 0, 76, 0, 191, 0, 194, 0, 95, 0, 186, 0, 198, 0, 177, 0, 178, 0, 156, 0, 183, 0, 203, 0, 180, 0, 212, 0, 193, 0, 76, 0, 218, 0, 224, 0, 158, 0, 182, 0, 71, 0, 197, 0, 120, 0, 95, 0, 150, 0, 0, 0, 76, 0, 76, 0, 195, 0, 196, 0, 95, 0, 40, 0, 40, 0, 141, 0, 40, 0, 0, 0, 76, 0, 76, 0, 0, 0, 0, 0, 0, 0, 95, 0, 76, 0, 156, 0, 156, 0, 0, 0, 0, 0, 0, 0, 156, 0, 88, 0, 89, 0, 90, 0, 91, 0, 92, 0, 76, 0, 76, 0, 136, 0, 137, 0, 138, 0, 139, 0, 140, 0, 0, 0, 0, 0, 179, 0, 181, 0, 215, 0, 0, 0, 222, 0, 216, 0, 108, 0, 110, 0, 111, 0, 112, 0, 225, 0, 76, 0, 76, 0, 227, 0, 95, 0, 116, 0, 0, 0, 0, 0, 95, 0, 0, 0, 0, 0, 184, 0, 0, 0, 41, 0, 95, 0, 0, 0, 0, 0, 0, 0, 95, 0, 95, 0, 95, 0, 0, 0, 95, 0, 95, 0, 199, 0, 200, 0, 0, 0, 0, 0, 0, 0, 205, 0, 95, 0, 17, 0, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 0, 0, 0, 0, 0, 0, 0, 20, 0, -92, 0, 42, 0, 43, 0, 11, 0, 12, 0, 44, 0, 0, 0, 45, 0, 46, 0, 95, 0, 47, 0, 48, 0, 49, 0, 50, 0, 0, 0, 0, 0, 161, 0, 0, 0, 27, 0, 28, 0, 95, 0, 95, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 95, 0, 95, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 0, 20, 0, 51, 0, 0, 0, 0, 0, 41, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 0, 95, 0, 25, 0, 26, 0, 0, 0, 0, 0, 201, 0, 202, 0, 27, 0, 28, 0, 0, 0, 52, 0, 53, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -92, 0, 0, 0, 95, 0, 95, 0, -92, 0, 42, 0, 43, 0, 11, 0, 12, 0, 44, 0, 0, 0, 45, 0, 46, 0, 217, 0, 47, 0, 48, 0, 49, 0, 50, 0, 0, 0, 223, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 226, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 41, 0, 0, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 52, 0, 134, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -92, 0, 0, 0, -92, 0, 42, 0, 43, 0, 11, 0, 12, 0, 44, 0, 0, 0, 45, 0, 46, 0, 0, 0, 47, 0, 48, 0, 49, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 41, 0, 0, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 52, 0, 162, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -92, 0, 0, 0, -92, 0, 42, 0, 43, 0, 11, 0, 12, 0, 44, 0, 0, 0, 45, 0, 46, 0, 0, 0, 47, 0, 48, 0, 49, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 41, 0, 0, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 52, 0, 165, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -92, 0, 0, 0, -92, 0, 42, 0, 43, 0, 11, 0, 12, 0, 44, 0, 0, 0, 45, 0, 46, 0, 0, 0, 47, 0, 48, 0, 49, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 41, 0, 0, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 52, 0, 175, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -92, 0, 0, 0, -92, 0, 42, 0, 43, 0, 11, 0, 12, 0, 44, 0, 0, 0, 45, 0, 46, 0, 0, 0, 47, 0, 48, 0, 49, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 41, 0, 0, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 52, 0, 211, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -92, 0, 0, 0, -92, 0, 42, 0, 43, 0, 11, 0, 12, 0, 44, 0, 0, 0, 45, 0, 46, 0, 0, 0, 47, 0, 48, 0, 49, 0, 50, 0, 41, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 42, 0, 43, 0, 11, 0, 12, 0, 11, 0, 12, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 52, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, -92, 0, 15, 0, 16, 0, 0, 0, 159, 0, 18, 0, 19, 0, 41, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 20, 0, 51, 0, 0, 0, 22, 0, 23, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 25, 0, 26, 0, 0, 0, 0, 0, 27, 0, 28, 0, 27, 0, 28, 0, 42, 0, 43, 0, 11, 0, 12, 0, 0, 0, 0, 0, -92, 0, 0, 0, 0, 0, 0, 0, -6, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 2, 0, -6, 0, -6, 0, 22, 0, 23, 0, -6, 0, -6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, -92, 0, -6, 0, -6, 0, 0, 0, -6, 0, -6, 0, 0, 0, -6, 0, -6, 0, -6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 0, -6, 0, -6, 0, 11, 0, 12, 0, 0, 0, -6, 0, -6, 0, 0, 0, -6, 0, 0, 0, 0, 0, 0, 0, 0, 0, -6, 0, -6, 0, 0, 0, 0, 0, 0, 0, 0, 0, -6, 0, -6, 0, 14, 0, -6, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 11, 0, 12, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 151, 0, 14, 0, 97, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 152, 0, 11, 0, 12, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 204, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 131, 0, 0, 0, 14, 0, 121, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 209, 0, 0, 0, 14, 0, 210, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 121, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 169, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 170, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 10, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 14, 0, 171, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 21, 0, 11, 0, 12, 0, 0, 0, 22, 0, 23, 0, 0, 0, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 14, 0, 29, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 11, 0, 12, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 173, 0, 17, 0, 18, 0, 19, 0, 93, 0, 94, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 131, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 126, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 131, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 172, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 208, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 220, 0, 0, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 11, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 0, 0, 0, 0, 0, 0, 221, 0, 13, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 21, 0, 11, 0, 12, 0, 0, 0, 22, 0, 23, 0, 0, 0, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 93, 0, 94, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 11, 0, 12, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 151, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 152, 0, 11, 0, 12, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 61, 0, 11, 0, 12, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0, 14, 0, 0, 0, 15, 0, 16, 0, 0, 0, 17, 0, 18, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 51, 0, 0, 0, 0, 0, 0, 0, 22, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 0, 26, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 28, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yylval = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE._yydefact = allocate([ 0, 3, 0, 0, 67, 106, 1, 5, 9, 0, 0, 75, 0, 0, 0, 0, 35, 30, 28, 34, 29, 0, 0, 0, 81, 0, 0, 0, 23, 106, 2, 72, 32, 71, 33, 56, 0, 68, 61, 69, 70, 93, 75, 75, 0, 0, 0, 0, 0, 0, 0, 0, 106, 4, 0, 91, 0, 105, 0, 98, 106, 0, 73, 38, 74, 0, 16, 0, 0, 0, 0, 72, 71, 0, 0, 70, 33, 51, 50, 0, 53, 52, 24, 0, 8, 0, 55, 54, 0, 0, 0, 0, 0, 0, 0, 57, 85, 86, 66, 0, 0, 106, 0, 88, 90, 0, 0, 0, 99, 0, 100, 102, 103, 0, 0, 95, 94, 97, 0, 0, 0, 0, 0, 0, 0, 0, 36, 0, 0, 17, 27, 44, 84, 0, 65, 58, 45, 46, 47, 48, 49, 26, 83, 14, 15, 0, 63, 79, 80, 0, 0, 0, 0, 21, 0, 20, 18, 19, 0, 30, 0, 101, 104, 60, 0, 7, 78, 76, 77, 0, 0, 0, 37, 31, 82, 62, 106, 87, 89, 12, 21, 0, 20, 18, 19, 0, 0, 60, 60, 0, 0, 59, 22, 96, 0, 0, 0, 0, 13, 10, 11, 25, 107, 0, 0, 0, 42, 0, 43, 40, 0, 64, 60, 0, 0, 0, 0, 0, 60, 0, 41, 39, 110, 0, 60, 109, 0, 108 ], "i8", ALLOC_STATIC);
STRING_TABLE._yyr2 = allocate([ 0, 2, 3, 1, 4, 2, 0, 4, 2, 0, 3, 3, 2, 3, 3, 3, 2, 3, 1, 1, 1, 1, 2, 1, 2, 5, 3, 3, 1, 1, 1, 4, 1, 1, 1, 1, 3, 4, 2, 8, 6, 8, 6, 6, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 1, 2, 3, 1, 0, 1, 4, 3, 6, 3, 3, 0, 2, 1, 1, 1, 1, 1, 1, 0, 3, 3, 3, 1, 1, 0, 4, 3, 3, 1, 1, 4, 2, 4, 2, 1, 0, 1, 2, 2, 4, 2, 1, 2, 2, 3, 2, 2, 3, 2, 0, 5, 10, 9, 8 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str123 = allocate([ 88, 66, 69, 71, 73, 78, 32, 108, 105, 115, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str224 = allocate([ 101, 109, 112, 116, 121, 32, 88, 66, 69, 71, 73, 78, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str325 = allocate([ 88, 69, 78, 68, 32, 108, 105, 115, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str426 = allocate([ 101, 109, 112, 116, 121, 32, 69, 78, 68, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str527 = allocate([ 99, 111, 110, 100, 124, 124, 99, 111, 110, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str628 = allocate([ 99, 111, 110, 100, 38, 38, 99, 111, 110, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str729 = allocate([ 33, 99, 111, 110, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str830 = allocate([ 112, 97, 116, 124, 124, 112, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str931 = allocate([ 112, 97, 116, 38, 38, 112, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1032 = allocate([ 33, 112, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1133 = allocate([ 101, 120, 112, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1335 = allocate([ 114, 101, 108, 101, 120, 112, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1436 = allocate([ 108, 101, 120, 101, 120, 112, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1537 = allocate([ 99, 111, 109, 112, 99, 111, 110, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1638 = allocate([ 101, 108, 115, 101, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1739 = allocate([ 102, 105, 101, 108, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1840 = allocate([ 105, 110, 100, 32, 102, 105, 101, 108, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1941 = allocate([ 105, 102, 40, 99, 111, 110, 100, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str2042 = allocate([ 101, 120, 112, 114, 126, 114, 101, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str21 = allocate([ 40, 108, 101, 120, 95, 101, 120, 112, 114, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str2243 = allocate([ 110, 117, 109, 98, 101, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str23 = allocate([ 115, 116, 114, 105, 110, 103, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str24 = allocate([ 118, 97, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str25 = allocate([ 97, 114, 114, 97, 121, 91, 93, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str26 = allocate([ 103, 101, 116, 108, 105, 110, 101, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str27 = allocate([ 102, 117, 110, 99, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str29 = allocate([ 102, 117, 110, 99, 40, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str30 = allocate([ 102, 117, 110, 99, 40, 101, 120, 112, 114, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str31 = allocate([ 115, 112, 114, 105, 110, 116, 102, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str32 = allocate([ 115, 117, 98, 115, 116, 114, 40, 101, 44, 101, 44, 101, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str33 = allocate([ 115, 112, 108, 105, 116, 40, 101, 44, 101, 44, 101, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str34 = allocate([ 105, 110, 100, 101, 120, 40, 101, 44, 101, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str35 = allocate([ 40, 101, 120, 112, 114, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str36 = allocate([ 116, 43, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str37 = allocate([ 116, 45, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str38 = allocate([ 116, 42, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str39 = allocate([ 116, 47, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str40 = allocate([ 116, 37, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str41 = allocate([ 45, 116, 101, 114, 109, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str42 = allocate([ 43, 116, 101, 114, 109, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str43 = allocate([ 43, 43, 118, 97, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str44 = allocate([ 45, 45, 118, 97, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str45 = allocate([ 118, 97, 114, 43, 43, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str46 = allocate([ 118, 97, 114, 45, 45, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str47 = allocate([ 116, 101, 114, 109, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str48 = allocate([ 101, 120, 112, 114, 32, 116, 101, 114, 109, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str49 = allocate([ 118, 97, 114, 61, 101, 120, 112, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str50 = allocate([ 112, 97, 116, 116, 101, 114, 110, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str51 = allocate([ 112, 97, 116, 116, 101, 114, 110, 32, 123, 46, 46, 46, 125, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str52 = allocate([ 115, 114, 99, 104, 44, 115, 114, 99, 104, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str53 = allocate([ 115, 114, 99, 104, 44, 32, 115, 114, 99, 104, 32, 123, 46, 46, 46, 125, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str54 = allocate([ 110, 117, 108, 108, 32, 112, 97, 116, 116, 101, 114, 110, 32, 123, 46, 46, 46, 125, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str55 = allocate([ 112, 97, 95, 115, 116, 97, 116, 115, 32, 112, 97, 95, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str56 = allocate([ 110, 117, 108, 108, 32, 112, 97, 95, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str57 = allocate([ 114, 101, 103, 101, 120, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str58 = allocate([ 99, 111, 109, 112, 32, 112, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str59 = allocate([ 112, 101, 95, 108, 105, 115, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str60 = allocate([ 110, 117, 108, 108, 32, 112, 114, 105, 110, 116, 95, 108, 105, 115, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str61 = allocate([ 47, 114, 47, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str62 = allocate([ 101, 120, 112, 114, 32, 114, 101, 108, 111, 112, 32, 101, 120, 112, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str63 = allocate([ 40, 114, 101, 108, 101, 120, 112, 114, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str64 = allocate([ 112, 114, 105, 110, 116, 62, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str65 = allocate([ 112, 114, 105, 110, 116, 32, 108, 105, 115, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str66 = allocate([ 112, 114, 105, 110, 116, 102, 62, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str67 = allocate([ 112, 114, 105, 110, 116, 102, 32, 108, 105, 115, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str68 = allocate([ 110, 117, 108, 108, 32, 115, 105, 109, 112, 108, 101, 32, 115, 116, 97, 116, 101, 109, 101, 110, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str69 = allocate([ 105, 108, 108, 101, 103, 97, 108, 32, 115, 116, 97, 116, 101, 109, 101, 110, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str70 = allocate([ 115, 105, 109, 112, 108, 101, 32, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str71 = allocate([ 105, 102, 32, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str72 = allocate([ 105, 102, 45, 101, 108, 115, 101, 32, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str73 = allocate([ 119, 104, 105, 108, 101, 32, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str74 = allocate([ 102, 111, 114, 32, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str75 = allocate([ 110, 101, 120, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str76 = allocate([ 101, 120, 105, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str77 = allocate([ 98, 114, 101, 97, 107, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str78 = allocate([ 99, 111, 110, 116, 105, 110, 117, 101, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str79 = allocate([ 123, 115, 116, 97, 116, 108, 105, 115, 116, 125, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str80 = allocate([ 115, 116, 97, 116, 95, 108, 105, 115, 116, 32, 115, 116, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str81 = allocate([ 110, 117, 108, 108, 32, 115, 116, 97, 116, 32, 108, 105, 115, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str82 = allocate([ 119, 104, 105, 108, 101, 40, 99, 111, 110, 100, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str83 = allocate([ 102, 111, 114, 40, 101, 59, 101, 59, 101, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str84 = allocate([ 102, 111, 114, 40, 118, 32, 105, 110, 32, 118, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE._yyr1 = allocate([ 0, 97, 98, 98, 99, 99, 99, 100, 100, 100, 101, 101, 101, 101, 102, 102, 102, 102, 103, 103, 103, 103, 104, 105, 105, 106, 107, 107, 108, 108, 108, 108, 108, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 109, 110, 110, 110, 111, 111, 112, 112, 112, 112, 112, 113, 113, 113, 114, 114, 114, 114, 115, 115, 115, 116, 116, 116, 117, 117, 119, 118, 120, 120, 121, 121, 122, 122, 122, 122, 122, 122, 122, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 124, 124, 125, 126, 126, 126 ], "i8", ALLOC_STATIC);
_yypgoto = allocate([ -106, 0, -106, 0, -106, 0, -106, 0, -6, 0, 133, 0, 46, 0, -106, 0, -106, 0, -106, 0, 1, 0, -7, 0, 102, 0, -8, 0, 116, 0, -106, 0, -106, 0, 31, 0, 68, 0, 95, 0, 54, 0, 74, 0, -106, 0, 66, 0, 156, 0, -105, 0, -16, 0, -21, 0, -106, 0, -106, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yydefgoto = allocate([ -1, 0, 3, 0, 4, 0, 30, 0, 153, 0, 31, 0, 154, 0, 164, 0, 32, 0, 54, 0, 155, 0, 34, 0, 35, 0, 55, 0, 192, 0, 37, 0, 8, 0, 38, 0, 63, 0, 64, 0, 149, 0, 39, 0, 79, 0, 157, 0, 98, 0, 56, 0, 57, 0, 9, 0, 58, 0, 59, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
STRING_TABLE.__str88 = allocate([ 109, 101, 109, 111, 114, 121, 32, 101, 120, 104, 97, 117, 115, 116, 101, 100, 0 ], "i8", ALLOC_STATIC);
_winner = allocate(4, "i8", ALLOC_STATIC);
_true = allocate([ 2, 1, 0, 0, 0, 0, 0, 0 ], [ "i8", "i8", 0, 0, "*", 0, 0, 0 ], ALLOC_STATIC);
_false = allocate([ 2, 2, 0, 0, 0, 0, 0, 0 ], [ "i8", "i8", 0, 0, "*", 0, 0, 0 ], ALLOC_STATIC);
_filenum = allocate(4, "i8", ALLOC_STATIC);
_files = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str92 = allocate([ 105, 108, 108, 101, 103, 97, 108, 32, 115, 116, 97, 116, 101, 109, 101, 110, 116, 32, 37, 111, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str193 = allocate([ 117, 110, 101, 120, 112, 101, 99, 116, 101, 100, 32, 98, 114, 101, 97, 107, 44, 32, 99, 111, 110, 116, 105, 110, 117, 101, 32, 111, 114, 32, 110, 101, 120, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str395 = allocate([ 117, 110, 107, 110, 111, 119, 110, 32, 98, 111, 111, 108, 101, 97, 110, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str496 = allocate([ 117, 110, 107, 110, 111, 119, 110, 32, 114, 101, 108, 97, 116, 105, 111, 110, 97, 108, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
_tmps = allocate(480, "i8", ALLOC_STATIC);
STRING_TABLE.__str597 = allocate([ 111, 117, 116, 32, 111, 102, 32, 116, 101, 109, 112, 111, 114, 97, 114, 105, 101, 115, 32, 105, 110, 32, 103, 101, 116, 116, 101, 109, 112, 0 ], "i8", ALLOC_STATIC);
_nullval = allocate([ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0 ], [ "*", 0, 0, 0, "*", 0, 0, 0, "double", 0, 0, 0, 0, 0, 0, 0, "i32", 0, 0, 0, "*", 0, 0, 0 ], ALLOC_STATIC);
STRING_TABLE.__str698 = allocate([ 115, 117, 98, 115, 116, 114, 58, 32, 109, 61, 37, 100, 44, 32, 110, 61, 37, 100, 44, 32, 115, 61, 37, 115, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str8100 = allocate([ 111, 117, 116, 32, 111, 102, 32, 115, 112, 97, 99, 101, 32, 105, 110, 32, 102, 111, 114, 109, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str9101 = allocate([ 102, 111, 114, 109, 97, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str10102 = allocate([ 37, 115, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str11103 = allocate([ 110, 111, 116, 32, 101, 110, 111, 117, 103, 104, 32, 97, 114, 103, 117, 109, 101, 110, 116, 115, 32, 105, 110, 32, 112, 114, 105, 110, 116, 102, 40, 37, 115, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str12104 = allocate([ 105, 108, 108, 101, 103, 97, 108, 32, 97, 114, 105, 116, 104, 109, 101, 116, 105, 99, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str13105 = allocate([ 100, 105, 118, 105, 115, 105, 111, 110, 32, 98, 121, 32, 122, 101, 114, 111, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str14106 = allocate([ 105, 108, 108, 101, 103, 97, 108, 32, 97, 115, 115, 105, 103, 110, 109, 101, 110, 116, 32, 111, 112, 101, 114, 97, 116, 111, 114, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
_pairstack = allocate(116, "i8", ALLOC_STATIC);
STRING_TABLE.__str15107 = allocate([ 115, 112, 108, 105, 116, 58, 32, 115, 61, 124, 37, 115, 124, 44, 32, 97, 61, 37, 115, 44, 32, 115, 101, 112, 61, 124, 37, 108, 99, 124, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str16108 = allocate([ 37, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str17109 = allocate([ 37, 115, 32, 105, 115, 32, 110, 111, 116, 32, 97, 110, 32, 97, 114, 114, 97, 121, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str18110 = allocate([ 105, 108, 108, 101, 103, 97, 108, 32, 106, 117, 109, 112, 32, 116, 121, 112, 101, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str19111 = allocate([ 105, 108, 108, 101, 103, 97, 108, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 116, 121, 112, 101, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
_print_s = allocate(4, "i8", ALLOC_STATIC);
_print_ssz = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str20112 = allocate([ 115, 116, 114, 105, 110, 103, 32, 37, 46, 50, 48, 115, 32, 46, 46, 46, 32, 116, 111, 111, 32, 108, 111, 110, 103, 32, 116, 111, 32, 112, 114, 105, 110, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str21113 = allocate([ 116, 111, 111, 32, 109, 97, 110, 121, 32, 111, 117, 116, 112, 117, 116, 32, 102, 105, 108, 101, 115, 32, 37, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str22114 = allocate([ 119, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str23115 = allocate([ 97, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str24116 = allocate([ 99, 97, 110, 39, 116, 32, 111, 112, 101, 110, 32, 102, 105, 108, 101, 32, 37, 115, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str25117 = allocate([ 99, 108, 111, 115, 101, 32, 111, 110, 32, 101, 120, 101, 99, 32, 102, 97, 105, 108, 117, 114, 101, 0 ], "i8", ALLOC_STATIC);
_paircnt = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str26120 = allocate([ 111, 117, 116, 32, 111, 102, 32, 37, 115, 32, 115, 112, 97, 99, 101, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str27121 = allocate([ 102, 111, 114, 109, 97, 116, 32, 105, 116, 101, 109, 32, 37, 46, 50, 48, 115, 46, 46, 46, 32, 116, 111, 111, 32, 108, 111, 110, 103, 0 ], "i8", ALLOC_STATIC);
_dbg_b = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str124 = allocate([ 46, 0 ], "i8", ALLOC_STATIC);
_radixchar = allocate(4, "i8", ALLOC_STATIC);
_radixcharlen = allocate([ 1 ], [ "i32", 0, 0, 0 ], ALLOC_STATIC);
_mb_cur_max_b = allocate(4, "i8", ALLOC_STATIC);
_progname = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str3135 = allocate([ 85, 115, 97, 103, 101, 58, 32, 37, 115, 32, 91, 45, 102, 32, 115, 111, 117, 114, 99, 101, 32, 124, 32, 39, 99, 109, 100, 115, 39, 93, 32, 91, 102, 105, 108, 101, 115, 93, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str4136 = allocate([ 110, 111, 32, 97, 114, 103, 117, 109, 101, 110, 116, 32, 102, 111, 114, 32, 45, 102, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str5137 = allocate([ 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str6138 = allocate([ 99, 97, 110, 39, 116, 32, 111, 112, 101, 110, 32, 37, 115, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str7139 = allocate([ 99, 109, 100, 115, 61, 124, 37, 115, 124, 10, 0 ], "i8", ALLOC_STATIC);
_lexprog = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str8142 = allocate([ 45, 100, 0 ], "i8", ALLOC_STATIC);
_svargc = allocate(4, "i8", ALLOC_STATIC);
_svargv = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str9147 = allocate([ 115, 118, 97, 114, 103, 99, 61, 37, 100, 32, 115, 118, 97, 114, 103, 118, 91, 48, 93, 61, 37, 115, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str10148 = allocate([ 101, 114, 114, 111, 114, 102, 108, 97, 103, 61, 37, 100, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE._sccsid = allocate([ 64, 40, 35, 41, 111, 97, 119, 107, 46, 115, 108, 32, 32, 50, 46, 51, 49, 32, 40, 103, 114, 105, 116, 116, 101, 114, 41, 32, 49, 50, 47, 50, 53, 47, 48, 54, 0 ], "i8", ALLOC_STATIC);
_llvm_used = allocate(8, "i8", ALLOC_STATIC);
_proctab = allocate([ 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 8, 0, 0, 0, 8, 0, 0, 0, 4, 0, 0, 0, 10, 0, 0, 0, 10, 0, 0, 0, 10, 0, 0, 0, 10, 0, 0, 0, 10, 0, 0, 0, 10, 0, 0, 0, 12, 0, 0, 0, 12, 0, 0, 0, 12, 0, 0, 0, 12, 0, 0, 0, 12, 0, 0, 0, 12, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 14, 0, 0, 0, 16, 0, 0, 0, 18, 0, 0, 0, 20, 0, 0, 0, 22, 0, 0, 0, 4, 0, 0, 0, 24, 0, 0, 0, 26, 0, 0, 0, 28, 0, 0, 0, 30, 0, 0, 0, 30, 0, 0, 0, 30, 0, 0, 0, 30, 0, 0, 0, 32, 0, 0, 0, 34, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 36, 0, 0, 0, 36, 0, 0, 0, 36, 0, 0, 0, 38, 0, 0, 0, 4, 0, 0, 0, 40, 0, 0, 0, 42, 0, 0, 0, 44, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 46, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 48, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 50, 0, 0, 0, 50, 0, 0, 0, 50, 0, 0, 0, 50, 0, 0, 0, 52, 0, 0, 0, 4, 0, 0, 0 ], [ "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0 ], ALLOC_STATIC);
STRING_TABLE.__str273 = allocate([ 114, 101, 103, 117, 108, 97, 114, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 32, 116, 111, 111, 32, 108, 111, 110, 103, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1274 = allocate([ 109, 97, 107, 101, 100, 102, 97, 58, 32, 114, 101, 32, 61, 32, 47, 37, 115, 47, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str2275 = allocate([ 115, 121, 110, 116, 97, 120, 32, 101, 114, 114, 111, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str3276 = allocate([ 98, 97, 105, 108, 105, 110, 103, 32, 111, 117, 116, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str4277 = allocate([ 109, 97, 116, 99, 104, 58, 32, 114, 101, 32, 61, 32, 47, 37, 115, 47, 32, 105, 110, 32, 61, 32, 124, 37, 115, 124, 32, 118, 97, 108, 61, 124, 37, 100, 124, 10, 0 ], "i8", ALLOC_STATIC);
_yyin = allocate(4, "i8", ALLOC_STATIC);
_yyout = allocate(4, "i8", ALLOC_STATIC);
_lineno = allocate([ 1 ], [ "i64", 0, 0, 0, "i32", 0, 0, 0 ], ALLOC_STATIC);
_yylex_sc_flag_b = allocate(4, "i8", ALLOC_STATIC);
_yy_start = allocate(4, "i8", ALLOC_STATIC);
_yy_init_b = allocate(4, "i8", ALLOC_STATIC);
_yy_buffer_stack = allocate(4, "i8", ALLOC_STATIC);
_yy_c_buf_p = allocate(4, "i8", ALLOC_STATIC);
_yy_hold_char = allocate(4, "i8", ALLOC_STATIC);
_yy_ec = allocate([ 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 4, 0, 0, 0, 5, 0, 0, 0, 6, 0, 0, 0, 7, 0, 0, 0, 8, 0, 0, 0, 9, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 10, 0, 0, 0, 11, 0, 0, 0, 1, 0, 0, 0, 12, 0, 0, 0, 13, 0, 0, 0, 14, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 15, 0, 0, 0, 1, 0, 0, 0, 16, 0, 0, 0, 17, 0, 0, 0, 18, 0, 0, 0, 19, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 20, 0, 0, 0, 21, 0, 0, 0, 20, 0, 0, 0, 22, 0, 0, 0, 23, 0, 0, 0, 24, 0, 0, 0, 25, 0, 0, 0, 20, 0, 0, 0, 26, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 27, 0, 0, 0, 28, 0, 0, 0, 29, 0, 0, 0, 20, 0, 0, 0, 30, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 31, 0, 0, 0, 32, 0, 0, 0, 33, 0, 0, 0, 34, 0, 0, 0, 20, 0, 0, 0, 1, 0, 0, 0, 35, 0, 0, 0, 36, 0, 0, 0, 37, 0, 0, 0, 38, 0, 0, 0, 39, 0, 0, 0, 40, 0, 0, 0, 41, 0, 0, 0, 42, 0, 0, 0, 43, 0, 0, 0, 20, 0, 0, 0, 44, 0, 0, 0, 45, 0, 0, 0, 20, 0, 0, 0, 46, 0, 0, 0, 47, 0, 0, 0, 48, 0, 0, 0, 49, 0, 0, 0, 50, 0, 0, 0, 51, 0, 0, 0, 52, 0, 0, 0, 53, 0, 0, 0, 20, 0, 0, 0, 54, 0, 0, 0, 55, 0, 0, 0, 20, 0, 0, 0, 20, 0, 0, 0, 1, 0, 0, 0, 56, 0, 0, 0, 57, 0, 0, 0, 58, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0 ], [ "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0 ], ALLOC_STATIC);
_yy_accept = allocate([ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 85, 0, 62, 0, 3, 0, 35, 0, 10, 0, 58, 0, 59, 0, 29, 0, 62, 0, 62, 0, 62, 0, 62, 0, 62, 0, 62, 0, 62, 0, 31, 0, 62, 0, 14, 0, 27, 0, 18, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 62, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 62, 0, 33, 0, 12, 0, 3, 0, 1, 0, 59, 0, 78, 0, 70, 0, 69, 0, 78, 0, 82, 0, 81, 0, 82, 0, 80, 0, 68, 0, 67, 0, 66, 0, 63, 0, 65, 0, 83, 0, 84, 0, 61, 0, 60, 0, 11, 0, 13, 0, 29, 0, 28, 0, 26, 0, 9, 0, 24, 0, 20, 0, 22, 0, 21, 0, 23, 0, 31, 0, 25, 0, 31, 0, 31, 0, 0, 0, 34, 0, 15, 0, 16, 0, 17, 0, 19, 0, 57, 0, 57, 0, 57, 0, 30, 0, 57, 0, 4, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 38, 0, 50, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 5, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 2, 0, 71, 0, 77, 0, 75, 0, 76, 0, 72, 0, 74, 0, 73, 0, 79, 0, 64, 0, 31, 0, 0, 0, 31, 0, 57, 0, 7, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 55, 0, 37, 0, 57, 0, 57, 0, 54, 0, 57, 0, 53, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 57, 0, 39, 0, 41, 0, 57, 0, 57, 0, 57, 0, 40, 0, 57, 0, 57, 0, 57, 0, 56, 0, 57, 0, 57, 0, 6, 0, 57, 0, 42, 0, 57, 0, 57, 0, 49, 0, 57, 0, 44, 0, 47, 0, 57, 0, 57, 0, 36, 0, 57, 0, 57, 0, 57, 0, 52, 0, 45, 0, 57, 0, 48, 0, 8, 0, 57, 0, 51, 0, 46, 0, 43, 0, 0, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yy_last_accepting_state = allocate(4, "i8", ALLOC_STATIC);
_yy_last_accepting_cpos = allocate(4, "i8", ALLOC_STATIC);
_yy_base = allocate([ 0, 0, 0, 0, 57, 0, 59, 0, 62, 0, 63, 0, 65, 0, 58, 0, 68, 0, 242, 0, 241, 0, 240, 0, 239, 0, 241, 0, 246, 0, 246, 0, 246, 0, 51, 0, 246, 0, 246, 0, 68, 0, 222, 0, 230, 0, 220, 0, 62, 0, 63, 0, 222, 0, 218, 0, 63, 0, 232, 0, 216, 0, 215, 0, 66, 0, 0, 0, 209, 0, 204, 0, 206, 0, 199, 0, 225, 0, 177, 0, 179, 0, 32, 0, 178, 0, 185, 0, 61, 0, 64, 0, 184, 0, 172, 0, 57, 0, 179, 0, 164, 0, 90, 0, 246, 0, 102, 0, 246, 0, 216, 0, 246, 0, 246, 0, 246, 0, 83, 0, 246, 0, 246, 0, 185, 0, 246, 0, 246, 0, 246, 0, 246, 0, 183, 0, 213, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 213, 0, 199, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 97, 0, 246, 0, 98, 0, 101, 0, 115, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 0, 0, 188, 0, 190, 0, 0, 0, 183, 0, 246, 0, 171, 0, 163, 0, 157, 0, 31, 0, 157, 0, 154, 0, 0, 0, 79, 0, 159, 0, 163, 0, 148, 0, 159, 0, 89, 0, 151, 0, 164, 0, 156, 0, 246, 0, 139, 0, 246, 0, 116, 0, 195, 0, 194, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 246, 0, 123, 0, 181, 0, 180, 0, 168, 0, 0, 0, 168, 0, 157, 0, 139, 0, 151, 0, 137, 0, 0, 0, 0, 0, 143, 0, 148, 0, 0, 0, 145, 0, 0, 0, 133, 0, 138, 0, 140, 0, 139, 0, 129, 0, 129, 0, 134, 0, 151, 0, 154, 0, 132, 0, 132, 0, 0, 0, 0, 0, 118, 0, 105, 0, 107, 0, 0, 0, 106, 0, 105, 0, 110, 0, 0, 0, 103, 0, 115, 0, 0, 0, 126, 0, 0, 0, 106, 0, 105, 0, 0, 0, 108, 0, 109, 0, 0, 0, 96, 0, 97, 0, 0, 0, 123, 0, 91, 0, 104, 0, 0, 0, 0, 0, 92, 0, 0, 0, 0, 0, 89, 0, 0, 0, 0, 0, 0, 0, 246, 0, 162, 0, 164, 0, 166, 0, 168, 0, 170, 0, 123, 0, 172, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yy_chk = allocate([ 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 2, 0, 2, 0, 7, 0, 3, 0, 2, 0, 3, 0, 4, 0, 5, 0, 4, 0, 6, 0, 17, 0, 20, 0, 8, 0, 7, 0, 24, 0, 103, 0, 25, 0, 28, 0, 41, 0, 28, 0, 103, 0, 24, 0, 25, 0, 8, 0, 20, 0, 32, 0, 32, 0, 28, 0, 41, 0, 59, 0, 7, 0, 7, 0, 3, 0, 51, 0, 51, 0, 4, 0, 5, 0, 5, 0, 6, 0, 6, 0, 8, 0, 8, 0, 44, 0, 28, 0, 45, 0, 53, 0, 48, 0, 48, 0, 44, 0, 53, 0, 17, 0, 48, 0, 45, 0, 84, 0, 86, 0, 87, 0, 59, 0, 87, 0, 107, 0, 119, 0, 59, 0, 84, 0, 86, 0, 119, 0, 59, 0, 87, 0, 202, 0, 88, 0, 88, 0, 192, 0, 59, 0, 88, 0, 107, 0, 189, 0, 59, 0, 112, 0, 59, 0, 84, 0, 86, 0, 132, 0, 112, 0, 87, 0, 117, 0, 117, 0, 186, 0, 185, 0, 184, 0, 132, 0, 182, 0, 181, 0, 179, 0, 178, 0, 176, 0, 175, 0, 173, 0, 171, 0, 170, 0, 168, 0, 167, 0, 166, 0, 164, 0, 163, 0, 162, 0, 132, 0, 197, 0, 197, 0, 198, 0, 198, 0, 199, 0, 199, 0, 200, 0, 200, 0, 201, 0, 201, 0, 203, 0, 203, 0, 159, 0, 158, 0, 157, 0, 156, 0, 155, 0, 154, 0, 153, 0, 152, 0, 151, 0, 150, 0, 149, 0, 147, 0, 145, 0, 144, 0, 141, 0, 140, 0, 139, 0, 138, 0, 137, 0, 135, 0, 134, 0, 133, 0, 121, 0, 120, 0, 115, 0, 114, 0, 113, 0, 111, 0, 110, 0, 109, 0, 108, 0, 105, 0, 104, 0, 102, 0, 101, 0, 100, 0, 98, 0, 96, 0, 95, 0, 76, 0, 75, 0, 68, 0, 67, 0, 62, 0, 55, 0, 50, 0, 49, 0, 47, 0, 46, 0, 43, 0, 42, 0, 40, 0, 39, 0, 38, 0, 37, 0, 36, 0, 35, 0, 34, 0, 31, 0, 30, 0, 29, 0, 27, 0, 26, 0, 23, 0, 22, 0, 21, 0, 13, 0, 12, 0, 11, 0, 10, 0, 9, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yy_def = allocate([ 0, 0, 196, 0, 1, 0, 197, 0, 197, 0, 198, 0, 198, 0, 199, 0, 199, 0, 200, 0, 200, 0, 201, 0, 201, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 196, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 203, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 196, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 196, 0, 196, 0, 196, 0, 196, 0, 203, 0, 203, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 202, 0, 0, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yy_meta = allocate([ 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0 ], [ "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0 ], ALLOC_STATIC);
_yy_nxt = allocate([ 0, 0, 14, 0, 15, 0, 16, 0, 17, 0, 18, 0, 19, 0, 20, 0, 21, 0, 22, 0, 23, 0, 24, 0, 25, 0, 26, 0, 27, 0, 28, 0, 29, 0, 30, 0, 31, 0, 32, 0, 33, 0, 34, 0, 33, 0, 35, 0, 33, 0, 33, 0, 33, 0, 36, 0, 33, 0, 37, 0, 33, 0, 14, 0, 38, 0, 14, 0, 14, 0, 33, 0, 39, 0, 40, 0, 33, 0, 41, 0, 42, 0, 43, 0, 33, 0, 44, 0, 33, 0, 45, 0, 46, 0, 33, 0, 47, 0, 33, 0, 33, 0, 48, 0, 33, 0, 33, 0, 49, 0, 33, 0, 50, 0, 51, 0, 52, 0, 53, 0, 54, 0, 65, 0, 57, 0, 55, 0, 58, 0, 57, 0, 61, 0, 58, 0, 61, 0, 73, 0, 75, 0, 65, 0, 66, 0, 80, 0, 141, 0, 82, 0, 86, 0, 102, 0, 87, 0, 142, 0, 81, 0, 83, 0, 66, 0, 76, 0, 92, 0, 93, 0, 88, 0, 103, 0, 123, 0, 67, 0, 68, 0, 59, 0, 117, 0, 118, 0, 59, 0, 62, 0, 63, 0, 62, 0, 63, 0, 67, 0, 68, 0, 106, 0, 88, 0, 108, 0, 119, 0, 112, 0, 113, 0, 107, 0, 120, 0, 74, 0, 114, 0, 109, 0, 84, 0, 132, 0, 86, 0, 124, 0, 87, 0, 145, 0, 119, 0, 125, 0, 88, 0, 88, 0, 120, 0, 126, 0, 88, 0, 94, 0, 133, 0, 133, 0, 195, 0, 127, 0, 134, 0, 146, 0, 194, 0, 128, 0, 151, 0, 129, 0, 88, 0, 88, 0, 132, 0, 152, 0, 88, 0, 117, 0, 118, 0, 193, 0, 192, 0, 191, 0, 88, 0, 190, 0, 189, 0, 188, 0, 187, 0, 186, 0, 185, 0, 184, 0, 183, 0, 182, 0, 181, 0, 180, 0, 179, 0, 178, 0, 177, 0, 176, 0, 88, 0, 56, 0, 56, 0, 60, 0, 60, 0, 64, 0, 64, 0, 69, 0, 69, 0, 71, 0, 71, 0, 121, 0, 121, 0, 175, 0, 174, 0, 173, 0, 172, 0, 171, 0, 170, 0, 169, 0, 168, 0, 167, 0, 166, 0, 165, 0, 164, 0, 163, 0, 162, 0, 161, 0, 160, 0, 159, 0, 158, 0, 157, 0, 156, 0, 134, 0, 134, 0, 122, 0, 122, 0, 155, 0, 154, 0, 153, 0, 150, 0, 149, 0, 148, 0, 147, 0, 144, 0, 143, 0, 140, 0, 139, 0, 138, 0, 137, 0, 136, 0, 135, 0, 76, 0, 75, 0, 99, 0, 131, 0, 130, 0, 122, 0, 116, 0, 115, 0, 111, 0, 110, 0, 105, 0, 104, 0, 101, 0, 100, 0, 99, 0, 98, 0, 97, 0, 96, 0, 95, 0, 91, 0, 90, 0, 89, 0, 85, 0, 84, 0, 79, 0, 78, 0, 77, 0, 196, 0, 72, 0, 72, 0, 70, 0, 70, 0, 13, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0, 196, 0 ], [ "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0, "i16", 0 ], ALLOC_STATIC);
_yytext = allocate(4, "i8", ALLOC_STATIC);
_yyleng = allocate(4, "i8", ALLOC_STATIC);
_clen = allocate(4, "i8", ALLOC_STATIC);
_cbuf = allocate(800, "i8", ALLOC_STATIC);
STRING_TABLE.__str2290 = allocate([ 115, 116, 114, 105, 110, 103, 32, 116, 111, 111, 32, 108, 111, 110, 103, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str3291 = allocate([ 110, 101, 119, 108, 105, 110, 101, 32, 105, 110, 32, 114, 101, 103, 117, 108, 97, 114, 32, 101, 120, 112, 114, 101, 115, 115, 105, 111, 110, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str4292 = allocate([ 110, 101, 119, 108, 105, 110, 101, 32, 105, 110, 32, 115, 116, 114, 105, 110, 103, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str5293 = allocate([ 110, 101, 119, 108, 105, 110, 101, 32, 105, 110, 32, 99, 104, 97, 114, 97, 99, 116, 101, 114, 32, 99, 108, 97, 115, 115, 0 ], "i8", ALLOC_STATIC);
_yy_n_chars = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str6294 = allocate([ 102, 97, 116, 97, 108, 32, 102, 108, 101, 120, 32, 115, 99, 97, 110, 110, 101, 114, 32, 105, 110, 116, 101, 114, 110, 97, 108, 32, 101, 114, 114, 111, 114, 45, 45, 110, 111, 32, 97, 99, 116, 105, 111, 110, 32, 102, 111, 117, 110, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str7295 = allocate([ 111, 117, 116, 32, 111, 102, 32, 100, 121, 110, 97, 109, 105, 99, 32, 109, 101, 109, 111, 114, 121, 32, 105, 110, 32, 121, 121, 95, 99, 114, 101, 97, 116, 101, 95, 98, 117, 102, 102, 101, 114, 40, 41, 0 ], "i8", ALLOC_STATIC);
_yy_buffer_stack_max = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str17305 = allocate([ 37, 115, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str18306 = allocate([ 111, 117, 116, 32, 111, 102, 32, 100, 121, 110, 97, 109, 105, 99, 32, 109, 101, 109, 111, 114, 121, 32, 105, 110, 32, 121, 121, 101, 110, 115, 117, 114, 101, 95, 98, 117, 102, 102, 101, 114, 95, 115, 116, 97, 99, 107, 40, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str19307 = allocate([ 102, 108, 101, 120, 32, 115, 99, 97, 110, 110, 101, 114, 32, 112, 117, 115, 104, 45, 98, 97, 99, 107, 32, 111, 118, 101, 114, 102, 108, 111, 119, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str20308 = allocate([ 102, 97, 116, 97, 108, 32, 102, 108, 101, 120, 32, 115, 99, 97, 110, 110, 101, 114, 32, 105, 110, 116, 101, 114, 110, 97, 108, 32, 101, 114, 114, 111, 114, 45, 45, 101, 110, 100, 32, 111, 102, 32, 98, 117, 102, 102, 101, 114, 32, 109, 105, 115, 115, 101, 100, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str21309 = allocate([ 102, 97, 116, 97, 108, 32, 101, 114, 114, 111, 114, 32, 45, 32, 115, 99, 97, 110, 110, 101, 114, 32, 105, 110, 112, 117, 116, 32, 98, 117, 102, 102, 101, 114, 32, 111, 118, 101, 114, 102, 108, 111, 119, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str22310 = allocate([ 111, 117, 116, 32, 111, 102, 32, 100, 121, 110, 97, 109, 105, 99, 32, 109, 101, 109, 111, 114, 121, 32, 105, 110, 32, 121, 121, 95, 103, 101, 116, 95, 110, 101, 120, 116, 95, 98, 117, 102, 102, 101, 114, 40, 41, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str316 = allocate([ 48, 0 ], "i8", ALLOC_STATIC);
_symtab = allocate(200, "i8", ALLOC_STATIC);
STRING_TABLE.__str1319 = allocate([ 36, 122, 101, 114, 111, 38, 110, 117, 108, 108, 0 ], "i8", ALLOC_STATIC);
__str2320 = allocate(1, "i8", ALLOC_STATIC);
STRING_TABLE.__str3321 = allocate([ 36, 114, 101, 99, 111, 114, 100, 0 ], "i8", ALLOC_STATIC);
_recloc = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str4324 = allocate([ 114, 101, 99, 108, 111, 99, 32, 37, 108, 111, 32, 108, 111, 111, 107, 117, 112, 32, 37, 108, 111, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str5325 = allocate([ 70, 83, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str6326 = allocate([ 32, 0 ], "i8", ALLOC_STATIC);
_FS = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str7329 = allocate([ 82, 83, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str8330 = allocate([ 10, 0 ], "i8", ALLOC_STATIC);
_RS = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str9333 = allocate([ 79, 70, 83, 0 ], "i8", ALLOC_STATIC);
_OFS = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str10336 = allocate([ 79, 82, 83, 0 ], "i8", ALLOC_STATIC);
_ORS = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str11339 = allocate([ 79, 70, 77, 84, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str12340 = allocate([ 37, 46, 54, 103, 0 ], "i8", ALLOC_STATIC);
_OFMT = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str13341 = allocate([ 70, 73, 76, 69, 78, 65, 77, 69, 0 ], "i8", ALLOC_STATIC);
_FILENAME = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str14344 = allocate([ 78, 70, 0 ], "i8", ALLOC_STATIC);
_NF = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str15347 = allocate([ 78, 82, 0 ], "i8", ALLOC_STATIC);
_nrloc = allocate(4, "i8", ALLOC_STATIC);
_NR = allocate(4, "i8", ALLOC_STATIC);
STRING_TABLE.__str16352 = allocate([ 111, 117, 116, 32, 111, 102, 32, 115, 112, 97, 99, 101, 32, 105, 110, 32, 109, 97, 107, 101, 115, 121, 109, 116, 97, 98, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str17353 = allocate([ 115, 101, 116, 115, 121, 109, 116, 97, 98, 32, 102, 111, 117, 110, 100, 32, 37, 108, 111, 58, 32, 37, 115, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str18354 = allocate([ 32, 37, 115, 32, 37, 103, 32, 37, 111, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str19355 = allocate([ 115, 121, 109, 98, 111, 108, 32, 116, 97, 98, 108, 101, 32, 111, 118, 101, 114, 102, 108, 111, 119, 32, 97, 116, 32, 37, 115, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str20356 = allocate([ 115, 101, 116, 115, 121, 109, 116, 97, 98, 32, 115, 101, 116, 32, 37, 108, 111, 58, 32, 37, 115, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str21357 = allocate([ 115, 101, 116, 102, 118, 97, 108, 58, 32, 37, 108, 111, 32, 37, 103, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str22358 = allocate([ 99, 97, 110, 39, 116, 32, 115, 101, 116, 32, 36, 48, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str23359 = allocate([ 115, 101, 116, 115, 118, 97, 108, 58, 32, 37, 108, 111, 32, 37, 115, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str24360 = allocate([ 103, 101, 116, 102, 118, 97, 108, 58, 32, 37, 108, 111, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str25361 = allocate([ 32, 32, 37, 103, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str26362 = allocate([ 103, 101, 116, 115, 118, 97, 108, 58, 32, 37, 108, 111, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str27363 = allocate([ 37, 46, 50, 48, 103, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str28364 = allocate([ 32, 32, 37, 115, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str29365 = allocate([ 105, 108, 108, 101, 103, 97, 108, 32, 114, 101, 102, 101, 114, 101, 110, 99, 101, 32, 116, 111, 32, 97, 114, 114, 97, 121, 32, 37, 115, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str30366 = allocate([ 102, 117, 110, 110, 121, 32, 118, 97, 114, 105, 97, 98, 108, 101, 32, 37, 111, 58, 32, 37, 115, 32, 37, 115, 32, 37, 103, 32, 37, 111, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str31367 = allocate([ 111, 117, 116, 32, 111, 102, 32, 115, 112, 97, 99, 101, 32, 105, 110, 32, 116, 111, 115, 116, 114, 105, 110, 103, 32, 111, 110, 32, 37, 115, 0 ], "i8", ALLOC_STATIC);
_libuxre_lc_collate_curinfo = allocate([ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, undef ], [ "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "*", 0, 0, 0, "i32", 0, 0, 0, "i32", 0, 0, 0, "i16", 0, "i16", 0, "i8", "i8", "i8", "i8" ], ALLOC_STATIC);
STRING_TABLE._sccsid388 = allocate([ 64, 40, 35, 41, 108, 105, 98, 117, 120, 114, 101, 46, 115, 108, 9, 49, 46, 50, 55, 32, 40, 103, 114, 105, 116, 116, 101, 114, 41, 32, 54, 47, 50, 54, 47, 48, 53, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str419 = allocate([ 101, 109, 115, 99, 114, 105, 112, 116, 101, 110, 45, 115, 116, 117, 98, 32, 101, 114, 114, 111, 114, 58, 32, 39, 37, 115, 39, 32, 99, 97, 108, 108, 101, 100, 10, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str1420 = allocate([ 98, 116, 111, 119, 99, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str2421 = allocate([ 105, 115, 119, 99, 116, 121, 112, 101, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str3422 = allocate([ 105, 115, 119, 97, 108, 110, 117, 109, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str4423 = allocate([ 116, 111, 119, 108, 111, 119, 101, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str5424 = allocate([ 116, 111, 119, 117, 112, 112, 101, 114, 0 ], "i8", ALLOC_STATIC);
STRING_TABLE.__str6425 = allocate([ 119, 99, 116, 121, 112, 101, 0 ], "i8", ALLOC_STATIC);
__gm_ = allocate(468, "i8", ALLOC_STATIC);
_mparams = allocate(24, "i8", ALLOC_STATIC);
HEAP32[_field0 >> 2] = STRING_TABLE.__str3321 | 0;
HEAP32[_field0 + 4 >> 2] = _EMPTY | 0;
HEAP32[_FINIT >> 2] = _EMPTY | 0;
HEAP32[_FINIT + 4 >> 2] = _EMPTY | 0;
HEAP32[_nullval >> 2] = _EMPTY | 0;
HEAP32[_nullval + 4 >> 2] = _EMPTY | 0;
HEAP32[_radixchar >> 2] = STRING_TABLE.__str124 | 0;
HEAP32[_llvm_used >> 2] = STRING_TABLE._sccsid | 0;
HEAP32[_llvm_used + 4 >> 2] = STRING_TABLE._sccsid388 | 0;
FUNCTION_TABLE = [ 0, 0, _dopa2, 0, _nullproc, 0, _relop, 0, _matchop, 0, _arith, 0, _assign, 0, _print, 0, _aprintf, 0, _awsprintf, 0, _split, 0, _ifstat, 0, _whilestat, 0, _forstat, 0, _instat, 0, _jump, 0, _program, 0, _pastat, 0, _boolop, 0, _sindex, 0, _substr, 0, _fncn, 0, _array, 0, _xxgetline, 0, _cat, 0, _incrdecr, 0, _indirect, 0 ];
Module["FUNCTION_TABLE"] = FUNCTION_TABLE;
function run(args) {
  args = args || Module["arguments"];
  if (runDependencies > 0) {
    Module.printErr("run() called, but dependencies remain, so not running");
    return 0;
  }
  if (Module["preRun"]) {
    if (typeof Module["preRun"] == "function") Module["preRun"] = [ Module["preRun"] ];
    var toRun = Module["preRun"];
    Module["preRun"] = [];
    for (var i = toRun.length - 1; i >= 0; i--) {
      toRun[i]();
    }
    if (runDependencies > 0) {
      return 0;
    }
  }
  function doRun() {
    var ret = 0;
    calledRun = true;
    if (Module["_main"]) {
      preMain();
      ret = Module.callMain(args);
      if (!Module["noExitRuntime"]) {
        exitRuntime();
      }
    }
    if (Module["postRun"]) {
      if (typeof Module["postRun"] == "function") Module["postRun"] = [ Module["postRun"] ];
      while (Module["postRun"].length > 0) {
        Module["postRun"].pop()();
      }
    }
    return ret;
  }
  if (Module["setStatus"]) {
    Module["setStatus"]("Running...");
    setTimeout((function() {
      setTimeout((function() {
        Module["setStatus"]("");
      }), 1);
      doRun();
    }), 1);
    return 0;
  } else {
    return doRun();
  }
}
Module["run"] = run;
if (Module["preInit"]) {
  if (typeof Module["preInit"] == "function") Module["preInit"] = [ Module["preInit"] ];
  while (Module["preInit"].length > 0) {
    Module["preInit"].pop()();
  }
}
initRuntime();
var shouldRunNow = true;
if (Module["noInitialRun"]) {
  shouldRunNow = false;
}
if (shouldRunNow) {
  var ret = run();
  Module.print("Exit Status: " + ret);
}
// EMSCRIPTEN_GENERATED_FUNCTIONS: ["_awsprintf","_mcce","_substr","_post","_checkval","_getsval","_jump","_yy_flush_buffer","_growrec","_first","_execute","_format","_place","_match","_towupper","_yyensure_buffer_stack","_cat394","_yy_fatal_error","_freesymtab","_exptostat","_leftmost","_libuxre_regnfaexec","_assign","_regcomp","_deltolist","_syminit","_release_unused_segments","_morefields","_sys_alloc","_free","_error","_delgraph","_chrdist","_leaf","_ifstat","_nullproc","_yy_init_buffer","_iswalnum","_init_mparams","_libuxre_collelem","_boolop","_libuxre_regdeldfa","_split","_growbuf","_main","_chcls","_yyerror","_pa2stat","_tostring","_tmalloc_small","_isanumber","_arith","_getrec","_makedfa","_libuxre_regdeltree","_setclvar","_yylex","_realloc","_yy_create_buffer","_tmalloc_large","_libuxre_bktmbexec","_eqcls","_regtrans","_array","_follow","_run","_towlower","_mkgraph","_regdfaexec_opt","_relop","_fieldadr","_clsym","_redirprint","_instat","_btowc","_copy","_libuxre_regnfacomp","_makesymtab","_libuxre_bktmbcomp","_addstate","_linkum","_yyparse","_sys_trim","_yyrestart","_program","_newstck","_indirect","_mmap_resize","_newctxt","_PUTS","_stat1","_addwide","_ems_stub_error","_yy_get_next_buffer","_prepend_alloc","_wctype","_lookup","_libuxre_mb2wc","_yy_try_NUL_trans","_firstop","_incrdecr","_stat4","_lex","_nopskip","_libuxre_reg1tree","_libuxre_regdfaexec","_iswctype","_arrayel","_tempfree","_genprint","_node3","_node2","_node1","_node0","_regexec","_node4","_gettemp","_overflo","_chrlen","_add_segment","_init_bins","_startreg","_mkstck","_libuxre_regdfacomp","_setsval","_xxgetline","_pastat","_casecmp","_yyunput","_op2","_op3","_op1","_matchop","_fncn","_setfval","_print","_nodetoobj","_libuxre_bktfree","_calloc","_fldinit","_cat","_yyalloc","_forstat","_yyrealloc","_init_top","_fldbld","_internal_realloc","_posnfoll","_aprintf","_libuxre_collmult","_hash","_libuxre_regdelnfa","_setsymtab","_segment_holding","_dopa2","_ALLOC","_libuxre_reg2tree","_yy_get_previous_state","_libuxre_regparse","_stat3","_stat2","_sindex","_member","_yy_load_buffer_state","_getfval","_growsprintf","_findposn","_malloc","_addrange","_alt","_recbld","_valtonode","_whilestat"]


